/*	Gilson Araujo do Nascimento		6552042
	Rafael Yuri Bardini				6552098
	Tamires Tessarolli de Souza		6427282
*/

#include <stdint.h>
#include "BMPFile.h"


int main(int argc, char *argv[]) {
	FILE *in = NULL, *out = NULL;
	char option = 0, option2 = 0;
	char filename[500];
	while (option != '3') {
		system("cls");
		// Menu inicial
		printf("Escolha uma opcao:\n");
		printf("1 - Comprimir\n");
		printf("2 - Descomprimir\n");
		printf("3 - Sair\n");
		option = getch();
		// Compressao
		if (option == '1') {
			// Solicita que o usuario forneca o arquivo .bmp que ser� comprimido e o abre para leitura
			system("cls");
			printf("Digite o nome do arquivo BMP: ");
			gets(filename);
			while ((in = fopen(filename,"rb")) == NULL) {
				printf("Arquivo inexistente\n");
				printf("Digite o nome do arquivo BMP: ");
				gets(filename);
			}
			filename[strlen(filename)-4] = '\0';
			strcat(filename,".bmpeg");
			// Abre para escrita o arquivo .bmpeg que conter� o resultado da compressao
			out = fopen(filename,"wb+");
			system("cls");
			// Funcao que realiza a compressao
			comprime(in,out);
			printf(" - Arquivo de saida temporario \"%s\" escrito\n\n",filename);
			system("pause");
		// Descompressao
		} else if (option == '2') {
			system("cls");
			// Solicita que o usuario forneca o arquivo .bmpeg que sera descomprimido
			printf("Digite o nome do arquivo BMPEG: ");
			gets(filename);
			while ((in = fopen(filename,"rb")) == NULL) {
				printf("Arquivo inexistente\n");
				printf("Digite o nome do arquivo BMPEG: ");
				gets(filename);
			}
			filename[strlen(filename)-6] = '\0';
			strcat(filename,"_out.bmp");
			// Abre para escrita o arquivo .bmp que contera o resultado da descompressao
			out = fopen(filename,"wb+");
			system("cls");
			// Realiza a descompressao
			descomprime(in,out);
			printf(" - Arquivo de saida \"%s\" escrito\n\n",filename);
			system("pause");
		}
	}
	return 0;
}
