#!/bin/sh

make clean > /dev/null
make > /dev/null

mkdir -p local/{{,des}codificado,frequencias}

for arq in $(ls imagens/)
do
	nome_arq="$(basename "$arq" ".bmp")"

	echo "********************************************************************************"
	echo "*  Testando $arq"
	echo "********************************************************************************"
	echo

	echo Separando as tabelas de frequencias
	./Trabalho3 -t c "imagens/$arq" "local/frequencias/${nome_arq}.sem.tabelas.cod" > /dev/null
	mv tabelas_diff "local/frequencias/${nome_arq}.diferencas"
	mv tabelas_run "local/frequencias/${nome_arq}.carreira"
	echo

	echo Codificando $arq com as tabelas de frequencias no mesmo arquivo
	./Trabalho3 c "imagens/$arq" "local/codificado/${nome_arq}.cod"
	./Trabalho3 d "local/codificado/${nome_arq}.cod" "local/descodificado/${nome_arq}.bmp"
	echo

	echo md5sum dos arquivos criados
	md5sum "imagens/$arq" "local/descodificado/${nome_arq}.bmp"
	echo

	echo Tamanho dos arquivos "(em bytes)"
	du -sb "imagens/$arq" "local/codificado/${nome_arq}.cod" local/frequencias/${nome_arq}.*
	echo
done
