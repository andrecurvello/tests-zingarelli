/* Compressão de Imagem Digital
 * Fase 3
 *
 * Materia: SCC0261 Multimidia
 *
 * Entrega:  14/06/2011
 * Grupo: 7
 *  Fábio Abrão Luca
 *  Giulianne Katlauskas Montemurro
 *  Lucas Cuculo Badiale
 */

#ifndef _VETORIZACAO_H_
#define _VETORIZACAO_H_

#include "prepara.h"

typedef int VetorElemento;

typedef VetorElemento* Vetor;

typedef struct {
	Vetor** lista;
	int size;
} ListaVetor;

typedef struct {
	ListaVetor *r;
	ListaVetor *g;
	ListaVetor *b;
	int size;
} ListaRGB;

// inicializa o vetor
Vetor* inicializa_vetor ();

// limpa o vetor
void finaliza_vetor (Vetor *v);

// inicializa uma lista de vetores
ListaVetor* inicializa_listavetor ();

// limpa a lista de vetores
void limpa_listavetor (ListaVetor *lista);

// adiciona um elemento a lista de vetores
void adiciona_listavetor (ListaVetor *lista, Vetor *v);

// pega um elemento da lista
Vetor* pega_listavetor (ListaVetor *lista, int index);

// vetoriza um bloco
Vetor* vetoriza_bloco (int b[8][8]);

// desvetoriza um bloco
int** desvetorisa_bloco (Vetor *v);

// vetoriza todos os blocos
ListaRGB* vetoriza (listaBloco b);

// desvetoriza todos os blocos
listaBloco desvetoriza (ListaRGB *lista);

#endif
