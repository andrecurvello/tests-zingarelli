/* Compressão de Imagem Digital
 * Fase 3
 *
 * Materia: SCC0261 Multimidia
 *
 * Entrega:  14/06/2011
 * Grupo: 7
 *  Fábio Abrão Luca
 *  Giulianne Katlauskas Montemurro
 *  Lucas Cuculo Badiale
 */

#include "vetorizacao.h"

#include "prepara.h"

#include <stdlib.h>
#include <stdio.h>

// inicializa o vetor
Vetor* inicializa_vetor () {
	Vetor *v = (Vetor*) malloc (sizeof(Vetor));
	*v = (VetorElemento*) malloc (sizeof(VetorElemento) * 64);
	return v;
}

// limpa o vetor
void finaliza_vetor (Vetor *v) {
	free(*v);
	free(v);
	v = NULL;
}

// inicializa uma lista de vetores
ListaVetor* inicializa_listavetor () {
	ListaVetor* lista = (ListaVetor*) malloc(sizeof(ListaVetor));
	lista->size = 0;
	lista->lista = NULL;
	return lista;
}

// limpa a lista de vetores
void limpa_listavetor (ListaVetor *lista) {
	if (lista->lista != NULL) {
		int i;
		for (i = 0; i < lista->size; i++) {
			free(lista->lista[i]);
		}
		free(lista->lista);
		free(lista);
	}
}

// adiciona um elemento a lista de vetores
void adiciona_listavetor (ListaVetor *lista, Vetor *v) {
	lista->size++;
	lista->lista = (Vetor**) realloc (lista->lista, sizeof(Vetor*) * lista->size);
	lista->lista[lista->size - 1] = v;
}

// pega um elemento da lista
Vetor* pega_listavetor (ListaVetor *lista, int index) {
	return lista->lista[index];
}

// vetoriza um bloco
Vetor* vetoriza_bloco (int b[8][8]) {
	// transforma um bloco em um vetor de 8*8 = 64 posicoes
	// fazendo zigue-zegue no vetor
	// tem um exemplo de como eh isso nesse slide, na pagina 15
	// http://www.lncc.br/~jauvane/SMM/2002/SMM-A05.pdf
	   Vetor *v = inicializa_vetor();
	   (*v)[0]=b[0][0];
	   (*v)[1]=b[0][1];
	   (*v)[2]=b[1][0];
	   (*v)[3]=b[2][0];	
	   (*v)[4]=b[1][1];			
	   (*v)[5]=b[0][2];
       (*v)[6]=b[0][3];
	   (*v)[7]=b[1][2];
	   (*v)[8]=b[2][1];
	   (*v)[9]=b[3][0];
	   (*v)[10]=b[4][0];
	   (*v)[11]=b[3][1];
	   (*v)[12]=b[2][2];
	   (*v)[13]=b[1][3];
	   (*v)[14]=b[0][4];
	   (*v)[15]=b[0][5];
	   (*v)[16]=b[1][4];
	   (*v)[17]=b[2][3];
	   (*v)[18]=b[3][2];
	   (*v)[19]=b[4][1];
	   (*v)[20]=b[5][0];
	   (*v)[21]=b[6][0];
	   (*v)[22]=b[5][1];
	   (*v)[23]=b[4][2];
	   (*v)[24]=b[3][3];
	   (*v)[25]=b[2][4];
	   (*v)[26]=b[1][5];
	   (*v)[27]=b[0][6];
	   (*v)[28]=b[0][7];
	   (*v)[29]=b[1][6];
	   (*v)[30]=b[2][5];
	   (*v)[31]=b[3][4];
	   (*v)[32]=b[4][3];
	   (*v)[33]=b[5][2];
	   (*v)[34]=b[6][1];
	   (*v)[35]=b[7][0];
	   (*v)[36]=b[7][1];
	   (*v)[37]=b[6][2];
	   (*v)[38]=b[5][3];
	   (*v)[39]=b[4][4];
	   (*v)[40]=b[3][5];
	   (*v)[41]=b[2][6];
	   (*v)[42]=b[1][7];
	   (*v)[43]=b[2][7];
	   (*v)[44]=b[3][6];
	   (*v)[45]=b[4][5];
	   (*v)[46]=b[5][4];
	   (*v)[47]=b[6][3];
	   (*v)[48]=b[7][2];
	   (*v)[49]=b[7][3];
	   (*v)[50]=b[6][4];
	   (*v)[51]=b[5][5];
	   (*v)[52]=b[4][6];
	   (*v)[53]=b[3][7];
	   (*v)[54]=b[4][7];
	   (*v)[55]=b[5][6];
	   (*v)[56]=b[6][5];
	   (*v)[57]=b[7][4];
	   (*v)[58]=b[7][5];
	   (*v)[59]=b[6][6];
	   (*v)[60]=b[5][7];
	   (*v)[61]=b[6][7];
	   (*v)[62]=b[7][6];
	   (*v)[63]=b[7][7];

   	   return v;
}

// desvetoriza um bloco
int** desvetoriza_bloco (Vetor *v) {
      int **b, i;

      b = (int**) malloc (sizeof(int*) * 8);
      for (i = 0; i < 8; i++) b[i] = (int*) malloc (sizeof(int) * 8);

      //faz o zig zague de volta 
      b[0][0]=(*v)[0];
	  b[0][1]=(*v)[1];
	  b[1][0]=(*v)[2];
	  b[2][0]=(*v)[3];
      b[1][1]=(*v)[4];
      b[0][2]=(*v)[5];
      b[0][3]=(*v)[6];
      b[1][2]=(*v)[7];
	  b[2][1]=(*v)[8];
	  b[3][0]=(*v)[9];
	  b[4][0]=(*v)[10];
	  b[3][1]=(*v)[11];
	  b[2][2]=(*v)[12];
	  b[1][3]=(*v)[13];
	  b[0][4]=(*v)[14];
	  b[0][5]=(*v)[15];
	  b[1][4]=(*v)[16];
	  b[2][3]=(*v)[17];
	  b[3][2]=(*v)[18];
      b[4][1]=(*v)[19];
      b[5][0]=(*v)[20];
      b[6][0]=(*v)[21];
      b[5][1]=(*v)[22];
      b[4][2]=(*v)[23];
      b[3][3]=(*v)[24];
      b[2][4]=(*v)[25];
      b[1][5]=(*v)[26];
      b[0][6]=(*v)[27];
      b[0][7]=(*v)[28];
      b[1][6]=(*v)[29];
      b[2][5]=(*v)[30];
      b[3][4]=(*v)[31];
      b[4][3]=(*v)[32];
      b[5][2]=(*v)[33];
      b[6][1]=(*v)[34];
      b[7][0]=(*v)[35];
      b[7][1]=(*v)[36];
      b[6][2]=(*v)[37];
      b[5][3]=(*v)[38];
      b[4][4]=(*v)[39];
      b[3][5]=(*v)[40];
	  b[2][6]=(*v)[41];
	  b[1][7]=(*v)[42];
	  b[2][7]=(*v)[43];
	  b[3][6]=(*v)[44];
	  b[4][5]=(*v)[45];
	  b[5][4]=(*v)[46];
	  b[6][3]=(*v)[47];
	  b[7][2]=(*v)[48];
	  b[7][3]=(*v)[49];
	  b[6][4]=(*v)[50];
	  b[5][5]=(*v)[51];
	  b[4][6]=(*v)[52];
	  b[3][7]=(*v)[53];
	  b[4][7]=(*v)[54];
	  b[5][6]=(*v)[55];
	  b[6][5]=(*v)[56];
	  b[7][4]=(*v)[57];
	  b[7][5]=(*v)[58];
	  b[6][6]=(*v)[59];
	  b[5][7]=(*v)[60];
	  b[6][7]=(*v)[61];
	  b[7][6]=(*v)[62];
	  b[7][7]=(*v)[63];	

	  return b;
}

// vetoriza todos os blocos
ListaRGB* vetoriza (listaBloco b) {
	Vetor *v_aux;

	ListaRGB *lv = (ListaRGB*) malloc(sizeof(ListaRGB));
	ListaVetor *lvr = NULL;
	ListaVetor *lvg = NULL;
	ListaVetor *lvb = NULL;

	lvr = inicializa_listavetor();
	lvg = inicializa_listavetor();
	lvb = inicializa_listavetor();

//listaBloco aux = b;
//int i, j;
//while (aux != NULL) {
//	for (i = 0; i < 8; i++) {
//		for (j = 0; j < 8; j++) {
//			printf("%02X,%02X,%02X ", aux->r[i][j] + 128, aux->g[i][j] + 128, aux->b[i][j] + 128);
//		}
//		printf("\n");
//	}
//	printf("\n");
//	aux = aux->next;
//}
//printf("fim lista blocos\n");

	while (b != NULL){
        // vetoriza a matriz R do bloco
		v_aux = vetoriza_bloco(b->r); 
        adiciona_listavetor(lvr, v_aux);

        // vetoriza a matriz G do bloco
        v_aux = vetoriza_bloco(b->g);
        adiciona_listavetor(lvg, v_aux);

		// vetoriza a matriz B do bloco
		v_aux = vetoriza_bloco(b->b);
		adiciona_listavetor(lvb, v_aux);

		b = b->next;
	}
	lv->r = lvr;
	lv->g = lvg;
	lv->b = lvb;
	lv->size = lv->r->size;

//int i, j;
//for (i = 0; i < lv->size; i++) {
//	for (j = 0; j < 64; j++) {
//		printf("(%3d, %3d): %3d %3d %3d \n", i, j,
//		//printf("(%3d, %3d): %02X %02X %02X \n", i, j,
//				(*(lv->r->lista[i]))[j],// + 128,
//				(*(lv->g->lista[i]))[j],// + 128,
//				(*(lv->b->lista[i]))[j] // + 128
//				);
//	}
//	printf("\n");
//}

	return lv;
}

// desvetoriza todos os blocos
listaBloco desvetoriza (ListaRGB *lista) {
    ListaRGB *lv = lista;
    listaBloco b;   
    novaLista(&b);
	
	int i, j, k;

	int **bloco_auxR;
    int **bloco_auxG;
    int **bloco_auxB;
	
//for (i = 0; i < lv->size; i++) {
//	for (j = 0; j < 64; j++) {
//		printf("(%3d, %3d): %3d %3d %3d \n", i, j,
//		//printf("(%3d, %3d): %02X %02X %02X \n", i, j,
//				(*(lv->r->lista[i]))[j],// + 128,
//				(*(lv->g->lista[i]))[j],// + 128,
//				(*(lv->b->lista[i]))[j] // + 128
//				);
//	}
//	printf("\n");
//}

	listaBloco aux;
    for (i = 0; i < lv->size; i++) {
		aux = novoBloco(&b);

		//desvetoriza o vetor correspondente a matriz R do bloco
		bloco_auxR = desvetoriza_bloco(lv->r->lista[i]);

		//desvetoriza o vetor correspondente a matriz G do bloco
		bloco_auxG = desvetoriza_bloco(lv->g->lista[i]);

		//desvetoriza o vetor correspondente a matriz B do bloco
		bloco_auxB = desvetoriza_bloco(lv->b->lista[i]);

		for (j = 0; j < 8; j++) {
			for (k = 0; k < 8; k++) {
				aux->r[j][k] = bloco_auxR[j][k];
				aux->g[j][k] = bloco_auxG[j][k];
				aux->b[j][k] = bloco_auxB[j][k];
			}
		}

		// libera a memoria auxiliar
		for (j = 0; j < 8; j++) free(bloco_auxR[j]);
		for (j = 0; j < 8; j++) free(bloco_auxG[j]);
		for (j = 0; j < 8; j++) free(bloco_auxB[j]);
		free(bloco_auxR);
		free(bloco_auxG);
		free(bloco_auxB);
	}
	
//aux = b;
//while (aux != NULL) {
//	for (i = 0; i < 8; i++) {
//		for (j = 0; j < 8; j++) {
//			printf("%02X,%02X,%02X ", aux->r[i][j] + 128, aux->g[i][j] + 128, aux->b[i][j] + 128);
//		}
//		printf("\n");
//	}
//	printf("\n");
//	aux = aux->next;
//}

	return b;
}

