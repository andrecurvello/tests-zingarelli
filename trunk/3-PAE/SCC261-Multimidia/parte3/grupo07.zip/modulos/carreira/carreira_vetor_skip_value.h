/* Compressão de Imagem Digital
 * Fase 3
 *
 * Materia: SCC0261 Multimidia
 *
 * Entrega:  14/06/2011
 * Grupo: 7
 *  Fábio Abrão Luca
 *  Giulianne Katlauskas Montemurro
 *  Lucas Cuculo Badiale
 */

#ifndef _CARREIRA_VETOR_SKIP_VALUE_H_
#define _CARREIRA_VETOR_SKIP_VALUE_H_

#include "carreira_skip_value.h"
#include "../vetorizacao.h"

// vetor com o skip e o value
typedef struct {
	CarreiraSkipValue **vetor;
	int size;
} CarreiraVetor;

// constructors
CarreiraVetor* CarreiraVetorNew();

// destructors
void CarreiraVetorDelete (CarreiraVetor *cv);

// adders
void CarreiraVetorAdd (CarreiraVetor *cv, CarreiraSkipValue *csv);

// getters
int CarreiraVetorGetSize (CarreiraVetor *cv);
CarreiraSkipValue* CarreiraVetorGet (CarreiraVetor *cv, int index);

// removers
void CarreiraVetorRemove (CarreiraVetor *cv, int index);

// other methods
// converte usando codificacao por carreira
CarreiraVetor* CarreiraVetorCode (Vetor *v);

// desconverter usando codificacao por carreira
Vetor* CarreiraVetorDeCode (CarreiraVetor *cv);

#endif
