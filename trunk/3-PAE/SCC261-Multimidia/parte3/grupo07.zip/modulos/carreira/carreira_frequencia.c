/* Compressão de Imagem Digital
 * Fase 3
 *
 * Materia: SCC0261 Multimidia
 *
 * Entrega:  14/06/2011
 * Grupo: 7
 *  Fábio Abrão Luca
 *  Giulianne Katlauskas Montemurro
 *  Lucas Cuculo Badiale
 */

#include "carreira_frequencia.h"
#include "carreira_skip_sss.h"

#include <stdlib.h>
#include <stdio.h>

// constructors
CarreiraFrequencia* CarreiraFrequenciaNew (CarreiraSkipSSS *css) {
	CarreiraFrequencia *cf = (CarreiraFrequencia*) malloc (sizeof(CarreiraFrequencia));
	
	cf->simbolo = CarreiraSkipSSSNewSSS (css->skip, css->sss);
	cf->frequencia = 1;
	cf->bitstream = bitstream_new();

	return cf;
}

// destructors
void CarreiraFrequenciaDelete (CarreiraFrequencia *cf) {
	if (cf != NULL) {
		CarreiraSkipSSSDelete(cf->simbolo);
		bitstream_delete(cf->bitstream);
		free(cf);
		cf = NULL;
	}
}

// setters
void CarreiraFrequenciaSetSkip       (CarreiraFrequencia *cf, int skip) { cf->simbolo->skip = skip; }
void CarreiraFrequenciaSetSSS        (CarreiraFrequencia *cf, int sss) { cf->simbolo->sss = sss; }
void CarreiraFrequenciaSetSimble     (CarreiraFrequencia *cf, CarreiraSkipSSS *css) { cf->simbolo = css; }
void CarreiraFrequenciaSetFrequencia (CarreiraFrequencia *cf, int frequencia) { cf->frequencia = frequencia; }
void CarreiraFrequenciaSetBitstream  (CarreiraFrequencia *cf, BITSTREAM *bitstream) { 
	if (cf->bitstream != NULL) bitstream_delete(cf->bitstream);
	cf->bitstream = bitstream;
}

// getters
int              CarreiraFrequenciaGetSkip       (CarreiraFrequencia *cf) { return cf->simbolo->skip; }
int              CarreiraFrequenciaGetSSS        (CarreiraFrequencia *cf) { return cf->simbolo->sss ; }
CarreiraSkipSSS* CarreiraFrequenciaGetSimble     (CarreiraFrequencia *cf) { return cf->simbolo      ; }
int              CarreiraFrequenciaGetFrequencia (CarreiraFrequencia *cf) { return cf->frequencia   ; }
BITSTREAM*       CarreiraFrequenciaGetBitstream  (CarreiraFrequencia *cf) { return cf->bitstream    ; }

// other methods
void CarreiraFrequenciaFrequenciaUp (CarreiraFrequencia *cf) { cf->frequencia++; }
char* CarreiraFrequenciaToString (CarreiraFrequencia *cf) { 
	char *string = (char*) malloc (sizeof(char) * 16);
	
	int erro = !sprintf(string, "(%3d, %3d, %3d, %s)", 
			CarreiraFrequenciaGetSkip(cf),
			CarreiraFrequenciaGetSSS(cf),
			CarreiraFrequenciaGetFrequencia(cf),
			bitstream_to_string(cf->bitstream));

	if (erro) {
		perror("CarreiraFrequenciaToString");
		free(string);
		string = NULL;
	}

	return string;
}

// compara duas frequencias
int CarreiraFrequenciaEqualsSimble (CarreiraFrequencia *cf1, CarreiraFrequencia *cf2) {
	int comp = CarreiraSkipSSSEquals (cf1->simbolo, cf2->simbolo);
	return comp;
}

int CarreiraFrequenciaEqualsFrequencia (CarreiraFrequencia *cf1, CarreiraFrequencia *cf2) {
	int retorno = 0;
	int f1 = cf1->frequencia;
	int f2 = cf2->frequencia;

	if (f1 < f2) retorno = -1;
	else if (f1 == f2) retorno = 0;
	else retorno = 1;

	return retorno;
}

//// teste de unidade
//int main (void) {
//	CarreiraSkipSSS *css1 = CarreiraSkipSSSNewValue(10, 5);
//	CarreiraSkipSSS *css2 = CarreiraSkipSSSNewValue( 0,-5);
//	
//	CarreiraFrequencia *cf1 = CarreiraFrequenciaNew(css1);
//	CarreiraFrequencia *cf2 = CarreiraFrequenciaNew(css2);
//
//	CarreiraFrequenciaFrequenciaUp(cf1);
//	CarreiraFrequenciaFrequenciaUp(cf2);
//	CarreiraFrequenciaFrequenciaUp(cf2);
//
//	printf("%s\n", CarreiraFrequenciaToString(cf1));
//	printf("%s\n", CarreiraFrequenciaToString(cf2));
//	printf("Por par: %d\n", CarreiraFrequenciaEqualsSimbles(cf1, cf2));
//	printf("Por frequencia: %d\n", CarreiraFrequenciaEqualsFrequencia(cf1, cf2));
//
//	CarreiraFrequenciaDelete(cf1);
//	CarreiraFrequenciaDelete(cf2);
//
//	CarreiraSkipSSSDelete(css1);
//	CarreiraSkipSSSDelete(css2);
//
//	return 0;
//}
