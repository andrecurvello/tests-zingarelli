/* Compressão de Imagem Digital
 * Fase 3
 *
 * Materia: SCC0261 Multimidia
 *
 * Entrega:  14/06/2011
 * Grupo: 7
 *  Fábio Abrão Luca
 *  Giulianne Katlauskas Montemurro
 *  Lucas Cuculo Badiale
 */

#include "carreira_vetor_skip_value.h"
#include "carreira_skip_value.h"
#include "../vetorizacao.h"

#include <stdlib.h>

// constructors
CarreiraVetor* CarreiraVetorNew() {
	CarreiraVetor *cv = (CarreiraVetor *) malloc (sizeof(CarreiraVetor));
	cv->vetor = NULL;
	cv->size = 0;
	return cv;
}

// destructors
void CarreiraVetorDelete (CarreiraVetor *cv) {
	if (cv != NULL) {
		if (cv->vetor != NULL) {
			int i;
			for (i = 0; i < cv->size; i++) {
				CarreiraSkipValueDelete(cv->vetor[i]);
			}
			free(cv->vetor);
		}
		free(cv);
		cv = NULL;
	}
}

// adders
void CarreiraVetorAdd (CarreiraVetor *cv, CarreiraSkipValue *csv) {
	cv->size++;
	cv->vetor = (CarreiraSkipValue**) realloc (cv->vetor, sizeof(CarreiraSkipValue*) * cv->size);
	cv->vetor[cv->size - 1] = csv;
}

// getters
int CarreiraVetorGetSize (CarreiraVetor *cv) { 
	return cv->size; 
}

CarreiraSkipValue* CarreiraVetorGet (CarreiraVetor *cv, int index) { 
	if (index >= 0 && index < cv->size)
		return cv->vetor[index]; 
	else
		return NULL;
}

// removers
void CarreiraVetorRemove (CarreiraVetor *cv, int index) {
	if (index >= 0 && index < cv->size) {
		cv->size--;
		CarreiraSkipValueDelete (cv->vetor[index]);
		cv->vetor[index] = cv->vetor[cv->size];
		cv->vetor = (CarreiraSkipValue**) realloc (cv->vetor, sizeof(CarreiraSkipValue*) * cv->size);
	}
}

// other methods
// converte usando codificacao por carreira
CarreiraVetor* CarreiraVetorCode (Vetor *v) {
	int skip = 0;
	int i = 0;

	CarreiraVetor *cv = CarreiraVetorNew();
	
//	// carreira tradicional: pula apenas zeros consecutivos
//	for (i = 1; i < 64; i++) {
//		// se for zero
//		if ((*v)[i] == 0) {
//			// e nao for o ultimo elemento do vetor, aumenta o skip
//			if (i < 63) skip++;
//
//			// se for o ultimo elemento do vetor, coloca (0, 0) no final da carreira
//			else {
//				CarreiraVetorAdd(cv, CarreiraSkipValueNew(0, 0));
//			}
//		// se for diferente de zero
//		} else {
//			// coloca o par (skip, value) no vetor
//			CarreiraVetorAdd(cv, CarreiraSkipValueNew(skip, (*v)[i]));
//
//			// comeca novamente a contagem de zeros
//			skip = 0;
//		}
//	}

	// carreira que pula qualquer coisa repetida
	int value = (*v)[1];
	skip = 0;
	for (i = 2; i < 64; i++) {
		// enquanto for igual, vai poulando
		if (value == (*v)[i]) {
			skip++;
		}

		// se for diferente, para de pular
		else {
			// coloca o par (skip, value) no vetor
			CarreiraVetorAdd(cv, CarreiraSkipValueNew(skip, value));

			// comeca novamente os pulos
			skip = 0;
			value = (*v)[i];
		}

		if (i == 63) {
			CarreiraVetorAdd(cv, CarreiraSkipValueNew(skip, value));
		}
	}

	return cv;
}

// desconverter usando codificacao por carreira
Vetor* CarreiraVetorDeCode (CarreiraVetor *cv) {
	Vetor *v = inicializa_vetor();
	CarreiraSkipValue *csv = NULL;

	int i, j, index = 1;
	
	for (i = 0; i < 64; i++) (*v)[i] = 0;

//	// metodo tradicional de pular apenas zeros
//	for (i = 0; i < cv->size; i++) {
//		csv = cv->vetor[i];
//		for (j = 0; j < csv->skip; j++) {
//			(*v)[index++] = 0;
//		}
//		(*v)[index++] = csv->value;
//	}

	// metodo de pular qualquer coisa repetida
	for (i = 0; i < cv->size; i++) {
		csv = cv->vetor[i];
		for (j = 0; j < csv->skip; j++) {
			(*v)[index++] = csv->value;
		}
		(*v)[index++] = csv->value;
	}

	return v;
}

//// teste de unidade
//#include <stdio.h>
//int main (void) {
//	CarreiraVetor *cv = CarreiraVetorNew();
//
//	CarreiraVetorAdd(cv, CarreiraSkipValueNew(10, 2));
//	CarreiraVetorAdd(cv, CarreiraSkipValueNew( 8, 5));
//	CarreiraVetorAdd(cv, CarreiraSkipValueNew( 4,12));
//	CarreiraVetorAdd(cv, CarreiraSkipValueNew( 6, 4));
//	CarreiraVetorAdd(cv, CarreiraSkipValueNew( 3,-3));
//	CarreiraVetorAdd(cv, CarreiraSkipValueNew( 9,16));
//
//	CarreiraVetorRemove (cv, 3);
//	
//	int i;
//	for (i = 0; i < CarreiraVetorGetSize(cv); i++) {
//		printf("%s\n", CarreiraSkipValueToString( CarreiraVetorGet(cv, i) ) );
//	}
//
//	CarreiraVetorDelete(cv);
//
//	// teste do decode / encode
//	printf("\n\n");
//	
//	Vetor *v1, *v2;
//	v1 = inicializa_vetor();
//	
//	for (i = 0; i < 64; i++) {
//		(*v1)[i] = (i < 32);
//	}
//	(*v1)[20] = 2;
//	(*v1)[40] = 2;
//	(*v1)[50] = 2;
//	(*v1)[63] = 0;
//	
//	CarreiraVetor *cv2;
//	cv2 = CarreiraVetorCode(v1);
//	
//	printf("codificado\n");
//	for (i = 0; i < CarreiraVetorGetSize(cv2); i++) {
//		printf("%s\n", CarreiraSkipValueToString( CarreiraVetorGet(cv2, i) ) );
//	}
//
//	v2 = CarreiraVetorDeCode(cv2);
//	
//	printf("original\n");
//	for (i = 0; i < 64; i++) {
//		printf("%d ", (*v1)[i]);
//	}
//	printf("\n");
//	
//	printf("decodificado\n");
//	for (i = 0; i < 64; i++) {
//		printf("%d ", (*v2)[i]);
//	}
//	printf("\n");
//	
//	CarreiraVetorDelete(cv2);
//
//	finaliza_vetor(v1);
//	finaliza_vetor(v2);
//
//	return 0;
//}
