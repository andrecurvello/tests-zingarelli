/* Compressão de Imagem Digital
 * Fase 3
 *
 * Materia: SCC0261 Multimidia
 *
 * Entrega:  14/06/2011
 * Grupo: 7
 *  Fábio Abrão Luca
 *  Giulianne Katlauskas Montemurro
 *  Lucas Cuculo Badiale
 */

#include "carreira_skip_value.h"

#include <stdlib.h>
#include <stdio.h>

// construtores
CarreiraSkipValue *CarreiraSkipValueNew (int skip, int value) {
	CarreiraSkipValue *csv = (CarreiraSkipValue*) malloc (sizeof(CarreiraSkipValue));
	csv->skip = skip;
	csv->value = value;
	return csv;
}

// destrutor
void CarreiraSkipValueDelete (CarreiraSkipValue *csv) {
	if (csv != NULL) {
		free(csv);
		csv = NULL;
	}
}

// setters
void CarreiraSkipValueSetSkip  (CarreiraSkipValue *csv, int skip ) { csv->skip  = skip ; }
void CarreiraSkipValueSetValue (CarreiraSkipValue *csv, int value) { csv->value = value; }

// getters
int CarreiraSkipValueGetSkip  (CarreiraSkipValue *csv) { return csv->skip ; }
int CarreiraSkipValueGetValue (CarreiraSkipValue *csv) { return csv->value; }

// others methods

// converte para uma string
char *CarreiraSkipValueToString (CarreiraSkipValue *csv) {
	char *string = (char*) malloc (sizeof(char) * (11));

	int error = !sprintf(string, "(%3d, %3d)", 
			CarreiraSkipValueGetSkip(csv),
			CarreiraSkipValueGetValue(csv));

	if (error) {
		perror("CarreiraSkipValueToString ");
		free(string);
		string = NULL;
	}

	return string;
}

//// teste de unidade
//int main (void) {
//	CarreiraSkipValue *csv1 = CarreiraSkipValueNew(0, 2);
//	CarreiraSkipValue *csv2 = CarreiraSkipValueNew(4, 1);
//	
//	printf("%s\n", CarreiraSkipValueToString(csv1));
//	printf("%s\n", CarreiraSkipValueToString(csv2));
//
//	CarreiraSkipValueDelete(csv1);
//	CarreiraSkipValueDelete(csv2);
//	return 1;
//}
