/* Compressão de Imagem Digital
 * Fase 3
 *
 * Materia: SCC0261 Multimidia
 *
 * Entrega:  14/06/2011
 * Grupo: 7
 *  Fábio Abrão Luca
 *  Giulianne Katlauskas Montemurro
 *  Lucas Cuculo Badiale
 */

#include "carreira_vetor_frequencias.h"
#include "carreira_skip_sss.h"
#include "carreira_frequencia.h"
#include "Stack.h"
#include "../bitstream.h"

#include <stdlib.h>
#include <stdio.h>

// constructors
CarreiraVetorFrequencias* CarreiraVetorFrequenciasNew () {
	CarreiraVetorFrequencias *cvf = (CarreiraVetorFrequencias*) malloc (sizeof(CarreiraVetorFrequencias));
	cvf->simbolos = NULL;
	cvf->size = 0;
	return cvf;
}

// destructors
void CarreiraVetorFrequenciasDelete (CarreiraVetorFrequencias *cvf) {
	if (cvf != NULL) {
		int i;
		for (i = 0; i < cvf->size; i++) {
			CarreiraFrequenciaDelete(cvf->simbolos[i]);
		}
		free(cvf->simbolos);
		free(cvf);
		cvf = NULL;
	}
}

// add
void CarreiraVetorFrequenciasAddEnd (CarreiraVetorFrequencias *cvf, CarreiraFrequencia *cf) {
	cvf->size++;
	cvf->simbolos = (CarreiraFrequencia**) realloc (cvf->simbolos, sizeof(CarreiraFrequencia*) * cvf->size);
	cvf->simbolos[cvf->size - 1] = cf;
}

void CarreiraVetorFrequenciasAdd (CarreiraVetorFrequencias *cvf, CarreiraSkipSSS *css) {
	CarreiraFrequencia *cf = CarreiraFrequenciaNew(css);
	
	CarreiraFrequencia *res = CarreiraVetorFrequenciasSearch(cvf, cf);
	
	if (res == NULL) {
		CarreiraVetorFrequenciasAddEnd (cvf, cf);
		CarreiraVetorFrequenciasSort(cvf);
	} else {
		CarreiraFrequenciaFrequenciaUp(res);
		CarreiraFrequenciaDelete(cf);
	}
}

// get
int CarreiraVetorFrequenciasGetSize (CarreiraVetorFrequencias *cvf) { return cvf->size; }
CarreiraFrequencia* CarreiraVetorFrequenciasGet (CarreiraVetorFrequencias *cvf, int index) {
	if (index >= 0 && index < cvf->size)
		return cvf->simbolos[index];
	else
		return NULL;
}

// remove
void CarreiraVetorFrequenciasRemove (CarreiraVetorFrequencias *cvf, int index) {
	// FIXME realloc(): invalid next size
	if (index >= 0 && index < cvf->size) {
		cvf->size--;
		CarreiraFrequenciaDelete (cvf->simbolos[index]);
		cvf->simbolos[index] = cvf->simbolos[cvf->size];
		cvf->simbolos = (CarreiraFrequencia**) realloc (cvf->simbolos, sizeof(CarreiraFrequencia*) * cvf->size);
	}
}

// busca
CarreiraFrequencia* CarreiraVetorFrequenciasSearch (CarreiraVetorFrequencias *cvf, CarreiraFrequencia *cf) {
	int inf = 0;
	int sup = cvf->size - 1;
	int meio;
	int achou = 0;
	int compara;
	
	while (!achou && (inf <= sup)) {
		meio = (inf + sup) / 2;
		compara = CarreiraFrequenciaEqualsSimble(cvf->simbolos[meio], cf);
		if (compara == 0) {
			achou = 1;
		} else if (compara > 0) {
			sup = meio - 1;
		} else if (compara < 0) {
			inf = meio + 1;
		}
	}
	if (achou) return cvf->simbolos[meio]; 
	else return NULL;
}

// busca por um (skip,sss)
CarreiraFrequencia* CarreiraVetorFrequenciasSearchSkipSSS (CarreiraVetorFrequencias *cvf, CarreiraSkipSSS *css) {
	CarreiraFrequencia *cf1 = CarreiraFrequenciaNew(css);
	CarreiraFrequencia *achou = CarreiraVetorFrequenciasSearch(cvf, cf1);
	CarreiraFrequenciaDelete(cf1);
	return achou;
}

// other methods
// ordena o vetor
void CarreiraVetorFrequenciasSort (CarreiraVetorFrequencias *cvf) {
	StackInterval *pilha = SINew();
	StackIntervalElement *elem;

	SIPush(pilha, 0, cvf->size - 1);
	
	while (!SIEmpty(pilha)) {
		elem = SIPop(pilha);

		int p = elem->start;
		int r = elem->end;
		free(elem); elem = NULL;

		if (p < r) {
			int v = (p + r) / 2;
			CarreiraFrequencia* pivo = cvf->simbolos[v];
			cvf->simbolos[v] = cvf->simbolos[r];
			cvf->simbolos[r] = pivo;

			int i = p - 1;
			int j = r;

			do {
				do { i++; } while (CarreiraFrequenciaEqualsSimble(cvf->simbolos[i], pivo) < 0);
				do { j--; } while (CarreiraFrequenciaEqualsSimble(cvf->simbolos[j], pivo) > 0 && j > p);

				if (i < j) {
					CarreiraFrequencia *aux = cvf->simbolos[i];
					cvf->simbolos[i] = cvf->simbolos[j];
					cvf->simbolos[j] = aux;
				}
			} while (i < j);

			cvf->simbolos[r] = cvf->simbolos[i];
			cvf->simbolos[i] = pivo;

			SIPush (pilha, p, i - 1);
			SIPush (pilha, i + 1, r);
		}
	}

	SIDelete(pilha);
}

// ordena o vetor pelas frequencias
void CarreiraVetorFrequenciasSortFrequencia (CarreiraVetorFrequencias *cvf) {
	StackInterval *pilha = SINew();
	StackIntervalElement *elem;

	SIPush(pilha, 0, cvf->size - 1);
	
	while (!SIEmpty(pilha)) {
		elem = SIPop(pilha);

		int p = elem->start;
		int r = elem->end;
		free(elem); elem = NULL;

		if (p < r) {
			int v = (p + r) / 2;
			CarreiraFrequencia* pivo = cvf->simbolos[v];
			cvf->simbolos[v] = cvf->simbolos[r];
			cvf->simbolos[r] = pivo;

			int i = p - 1;
			int j = r;

			do {
				do { i++; } while (CarreiraFrequenciaEqualsFrequencia(cvf->simbolos[i], pivo) < 0);
				do { j--; } while (CarreiraFrequenciaEqualsFrequencia(cvf->simbolos[j], pivo) > 0 && j > p);

				if (i < j) {
					CarreiraFrequencia *aux = cvf->simbolos[i];
					cvf->simbolos[i] = cvf->simbolos[j];
					cvf->simbolos[j] = aux;
				}
			} while (i < j);

			cvf->simbolos[r] = cvf->simbolos[i];
			cvf->simbolos[i] = pivo;

			SIPush (pilha, p, i - 1);
			SIPush (pilha, i + 1, r);
		}
	}

	SIDelete(pilha);
}

// salva a tabela de frequencias
void CarreiraVetorFrequenciasSave (CarreiraVetorFrequencias *cvf, FILE *fp) {
	int i;
	BITSTREAM *bits = bitstream_new();
	bitstream_add_number(bits, cvf->size, sizeof(int) * 8);
	for (i = 0; i < cvf->size; i++) {
		bitstream_add_number (bits, CarreiraVetorFrequenciasGet(cvf, i)->simbolo->skip, 6); // skip no maximo eh 63
		bitstream_add_number (bits, CarreiraVetorFrequenciasGet(cvf, i)->simbolo->sss, 4); // maximo de 8 bits
		bitstream_add_number (bits, CarreiraVetorFrequenciasGet(cvf, i)->frequencia, sizeof(int) * 8);
	}

	bitstream_save(bits, fp);
}

// salva a tabela de frequencias "minima"
void CarreiraVetorFrequenciasSaveMinimun (CarreiraVetorFrequencias *cvf, BITSTREAM *bits) {
	int i;
	bitstream_add_number(bits, cvf->size, 6); // maximo de 63 entradas
	for (i = 0; i < cvf->size; i++) {
		bitstream_add_number (bits, CarreiraVetorFrequenciasGet(cvf, i)->simbolo->skip, 6); // maximo de 63
		bitstream_add_number (bits, CarreiraVetorFrequenciasGet(cvf, i)->simbolo->sss,  4); // maximo de 8
		bitstream_add_number (bits, CarreiraVetorFrequenciasGet(cvf, i)->frequencia,    6); // maximo de 63
	}
}

// carrega a tabela de frequencias
void CarreiraVetorFrequenciasLoad (CarreiraVetorFrequencias **cvf, FILE *fp) {
	int i;

//printf("bitstream loading \n");
	BITSTREAM *bits = bitstream_new();
	bitstream_load(bits, fp);
//printf("bitstream loaded\n");
	
	*cvf = CarreiraVetorFrequenciasNew();
//printf("bitstream: %s\n", bitstream_to_string(bits));
	int n = bitstream_get_number_no_conversion(bits, sizeof(int) * 8);
//printf("num of frequences %d\n", n);
	for (i = 0; i < n; i++) {
//printf("load frequencias step %d start\n", i);
		int skip = bitstream_get_number_no_conversion (bits, 6);
		int sss = bitstream_get_number_no_conversion (bits,  4);

		CarreiraFrequencia *cf = CarreiraFrequenciaNew( CarreiraSkipSSSNewSSS(skip, sss));
		CarreiraVetorFrequenciasAddEnd(*cvf, cf);

		int frequencia = bitstream_get_number_no_conversion (bits, sizeof(int) * 8);
		(*cvf)->simbolos[i]->frequencia = frequencia;

//printf("load frequencias step %d done %s %d %d\n", i, CarreiraFrequenciaToString(cf), skip, sss);
	}

	CarreiraVetorFrequenciasSort(*cvf);
}

// carrega a tabela de frequencias "minima"
void CarreiraVetorFrequenciasLoadMinimun (CarreiraVetorFrequencias **cvf, BITSTREAM *bits) {
	int i;

	*cvf = CarreiraVetorFrequenciasNew();
	int n = bitstream_get_number_no_conversion(bits, 6);
	for (i = 0; i < n; i++) {
		int skip = bitstream_get_number_no_conversion (bits, 6);
		int sss = bitstream_get_number_no_conversion (bits, 4);

		CarreiraFrequencia *cf = CarreiraFrequenciaNew( CarreiraSkipSSSNewSSS(skip, sss));
		CarreiraVetorFrequenciasAddEnd(*cvf, cf);

		int frequencia = bitstream_get_number_no_conversion (bits, 6);
		(*cvf)->simbolos[i]->frequencia = frequencia;
	}

	CarreiraVetorFrequenciasSort(*cvf);
}

//// teste de unidade
//int main (void) {
//	CarreiraSkipSSS *css1 = CarreiraSkipSSSNewValue( 2, 4);
//	CarreiraSkipSSS *css2 = CarreiraSkipSSSNewValue(10,-2);
//	CarreiraSkipSSS *css3 = CarreiraSkipSSSNewValue( 1, 5);
//	
//	CarreiraVetorFrequencias* cvf = CarreiraVetorFrequenciasNew ();
//	
//	CarreiraVetorFrequenciasAdd(cvf, css1);
//	CarreiraVetorFrequenciasAdd(cvf, css2);
//	CarreiraVetorFrequenciasAdd(cvf, css3);
//	CarreiraVetorFrequenciasAdd(cvf, css3);
//
//	//CarreiraVetorFrequenciasRemove(cvf, 1);
//	
//	int i;
//	for (i = 0; i < CarreiraVetorFrequenciasGetSize(cvf); i++) {
//		printf("%s\n", CarreiraFrequenciaToString(CarreiraVetorFrequenciasGet(cvf, i)));
//	}
//
//	CarreiraVetorFrequenciasDelete (cvf);
//
//	CarreiraSkipSSSDelete (css1);
//	CarreiraSkipSSSDelete (css2);
//	CarreiraSkipSSSDelete (css3);
//
//	return 0;
//}
