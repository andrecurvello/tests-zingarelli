/* Compressão de Imagem Digital
 * Fase 3
 *
 * Materia: SCC0261 Multimidia
 *
 * Entrega:  14/06/2011
 * Grupo: 7
 *  Fábio Abrão Luca
 *  Giulianne Katlauskas Montemurro
 *  Lucas Cuculo Badiale
 */

#ifndef _CARREIRA_HUFFMAN_H_
#define _CARREIRA_HUFFMAN_H_

#include "carreira_frequencia.h"
#include "carreira_vetor_frequencias.h"
#include "../bitstream.h"

#define CH_ESQUERDA 1
#define CH_DIREITA  0

// strututura para uma arvore de huffman
typedef struct _CarreiraHuffman {
	int peso;
	CarreiraFrequencia *simbolo;
	struct _CarreiraHuffman *esquerda;
	struct _CarreiraHuffman *direita;
} CarreiraHuffman;

// aloca um novo noh na memoria
void CarreiraHuffmanNew (CarreiraHuffman ** ch, int peso, CarreiraFrequencia *simbolo, CarreiraHuffman *esquerda, CarreiraHuffman *direita);

// remove um noh da memoria
void CarreiraHuffmanDelete (CarreiraHuffman **ch);

// remove uma arvore de huffman da memoria
void CarreiraHuffmanDeleteTree (CarreiraHuffman **ch);

// pega um no da esquerda
CarreiraHuffman *CarreiraHuffmanGetLeft (CarreiraHuffman *pai);

// pega um no da direita
CarreiraHuffman *CarreiraHuffmanGetRight (CarreiraHuffman *pai);

// pega um no da esquerda ou da direita, se o bit for 1 ou 0, respectivamente
CarreiraHuffman *CarreiraHuffmanGet (CarreiraHuffman *pai, int bit);

// cria uma arvore de huffman, usando a tabela de frequencias
void CarreiraHuffmanCreate (CarreiraHuffman **pai, CarreiraVetorFrequencias *cvf);

// pega o sss, percorrendo uma arvore de huffman
CarreiraSkipSSS* CarreiraHuffmanGetSimble (CarreiraHuffman *pai, BITSTREAM *bitstream);

// exibe a arvore de huffman
void CarreiraHuffmanPrint(CarreiraHuffman *pai);

#endif
