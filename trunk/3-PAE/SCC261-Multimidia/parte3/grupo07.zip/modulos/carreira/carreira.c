/* Compressão de Imagem Digital
 * Fase 3
 *
 * Materia: SCC0261 Multimidia
 *
 * Entrega:  14/06/2011
 * Grupo: 7
 *  Fábio Abrão Luca
 *  Giulianne Katlauskas Montemurro
 *  Lucas Cuculo Badiale
 */

#include "carreira.h"

#include "../bitstream.h"
#include "../vetorizacao.h"
#include "carreira_vetor_skip_value.h"
#include "carreira_skip_sss.h"
#include "carreira_vetor_frequencias.h"
#include "carreira_huffman.h"

#include <stdio.h>

// cria uma tabela de frequencias global
CarreiraVetorFrequencias * CarreiraCreatGlobal (ListaVetor *lv) {
	int i;
	CarreiraVetorFrequencias *cvf = CarreiraVetorFrequenciasNew();

	for (i = 0; i < lv->size; i++) {
		Vetor *v = pega_listavetor(lv, i);
		CarreiraVetor *cv = CarreiraVetorCode(v);

		int j;
		for (j = 0; j < cv->size; j++) {
			CarreiraVetorFrequenciasAdd(cvf, CarreiraSkipSSSNew(CarreiraVetorGet(cv, j)));
		}

		CarreiraVetorDelete(cv);
	}

	return cvf;
}

// codifica um vetor com carreiras e salva num arquivo
void CarreiraCodeVetor (BITSTREAM *bits, Vetor *v, CarreiraVetorFrequencias *cvf, CarreiraHuffman *ch, BITSTREAM *tabela) {
	int i, clean = 0;

	// codifica com as carreiras
	CarreiraVetor *cv = CarreiraVetorCode(v);
//printf("Codificado por carreiras\n");
//printf("cv->size: %d\n", cv->size);
//for (i = 0; i < cv->size; i++) printf("%s\n", CarreiraSkipValueToString(CarreiraVetorGet(cv, i)));

  // monta a tabela de frequencias localmente
  if (cvf == NULL) {
	  cvf = CarreiraVetorFrequenciasNew();
	  for (i = 0; i < cv->size; i++) {
		CarreiraVetorFrequenciasAdd(cvf, CarreiraSkipSSSNew(CarreiraVetorGet(cv, i)));
	  }
	  clean = 1; // forca deletar a tabela de frequencias no final do procedimento
//printf("Tabela de frequencias\n");
//for (i = 0; i < cvf->size; i++) printf("%s\n", CarreiraFrequenciaToString(cvf->simbolos[i]));
  }

  // monta o huffman
  if (clean) {
  	ch = NULL;
  	CarreiraHuffmanCreate(&ch, cvf);
//printf("Tabela de frequencias com huffman\n");
//for (i = 0; i < cvf->size; i++) printf("%s\n", CarreiraFrequenciaToString(cvf->simbolos[i]));
  }

  // salva a tabela de frequencias
  if (clean) CarreiraVetorFrequenciasSaveMinimun(cvf, tabela);

  // cria um bitstream para salvar
  CarreiraSkipValue *csv = NULL;
  CarreiraSkipSSS *css = NULL;
  bitstream_add_number (bits, cv->size, 6); // maximo de 63
  for (i = 0; i < cv->size; i++) {
  	csv = CarreiraVetorGet(cv, i);

  	// para pegar o sss
  	css = CarreiraSkipSSSNewValue (csv->skip, csv->value);
  	CarreiraFrequencia *cf = CarreiraVetorFrequenciasSearchSkipSSS(cvf, css);

  	// adiciona o value ao bitstream
  	bitstream_cat (bits, cf->bitstream);
  	bitstream_add_number(bits, csv->value, css->sss);

  	// deleta o (skip, sss)
  	CarreiraSkipSSSDelete(css);
  }
  
//printf("bitstream: %s\n", bitstream_to_string(bits));

  // limpa a memoria
  CarreiraVetorDelete(cv);
  if (clean) {
  	CarreiraVetorFrequenciasDelete(cvf);
  	CarreiraHuffmanDeleteTree(&ch);
  }
//printf("fim do encode\n");
}

// le um arquivo e descodifica com carreiras um vetor
Vetor *CarreiraDeCodeVetor (BITSTREAM *bits, CarreiraVetorFrequencias *cvf, CarreiraHuffman *ch, BITSTREAM *tabela) {
	int i, clean = 0;
	Vetor *v = inicializa_vetor();

	// carrega a tabela de frequencias localmente
	if (cvf == NULL) {
		clean = 1;
		CarreiraVetorFrequenciasLoadMinimun (&cvf, tabela);
//printf("Tabela de frequencias %d\n", cvf->size);
//for (i = 0; i < cvf->size; i++) printf("%s\n", CarreiraFrequenciaToString(cvf->simbolos[i]));
	}

    // monta o huffman
	if (clean) {
    	ch = NULL;
    	CarreiraHuffmanCreate(&ch, cvf);
//printf("Tabela de frequencias com huffman\n");
//for (i = 0; i < cvf->size; i++) printf("%s\n", CarreiraFrequenciaToString(cvf->simbolos[i]));
	}

    // carrega o bitstream
//printf("bitstream: %s\n", bitstream_to_string(bits));

    // monta o vetor de (skip, value)
    CarreiraVetor *cv = CarreiraVetorNew();
    int n = bitstream_get_number_no_conversion (bits, 6);
    for (i = 0; i < n; i++) {
    	CarreiraSkipSSS *css = CarreiraHuffmanGetSimble(ch, bits);
    	int value = bitstream_get_number(bits, css->sss);
    	CarreiraVetorAdd(cv, CarreiraSkipValueNew( css->skip, value));
    }
//printf("Codificado por carreiras %d %d\n", n, cv->size);
//printf("cv->size: %d\n", cv->size);
//for (i = 0; i < cv->size; i++) printf("%s\n", CarreiraSkipValueToString(CarreiraVetorGet(cv, i)));

    // descomprime usando carreiras
    v = CarreiraVetorDeCode (cv);
//printf("vetor original\n");
//for (i = 0; i < 64; i++) printf("%4d ", (*v)[i]);
//printf("\n");
    
    // limpa a memoria
	if (clean) {
    	CarreiraVetorFrequenciasDelete(cvf);
	    CarreiraHuffmanDeleteTree(&ch);
	}
    CarreiraVetorDelete(cv);

//printf("fim do decode\n");
	
	return v;
}

// codifica uma lista de vetores e salva num arquivo
void CarreiraCode (FILE *fp, ListaVetor *lv, int global, FILE *tabela) {
	if (tabela == NULL) tabela = fp;
	int i;
	
	fwrite(&(lv->size), sizeof(int), 1, fp);
	
	// carreira de frequencias global
	CarreiraVetorFrequencias *cvf = NULL;
	if (global) {
		cvf = CarreiraCreatGlobal(lv);
		printf("Tamanho da tabela de frequencias: %d\n", cvf->size);
	}

	// salva a tabela de frequencias
  	if (global) CarreiraVetorFrequenciasSave(cvf, tabela);

	// monta o codigo de huffman
	CarreiraHuffman *ch = NULL;
	if (global) CarreiraHuffmanCreate(&ch, cvf);

//printf("%d blocos para codificar\n", lv->size);
	BITSTREAM *bits = bitstream_new();
	BITSTREAM *bits_tabela = bitstream_new();
	for (i = 0; i < lv->size; i++) {
		CarreiraCodeVetor(bits, pega_listavetor(lv, i), cvf, ch, bits_tabela);
	}
	bitstream_save(bits_tabela, tabela);
	bitstream_save(bits, fp);
//printf("%d blocos codificados\n", lv->size);
    
	if (global) CarreiraVetorFrequenciasDelete(cvf);
    if (global) CarreiraHuffmanDeleteTree(&ch);
}

// decodifica uma lista de vetores, lendo de um arquivo
ListaVetor* CarreiraDeCode (FILE *fp, int global, FILE *tabela) {
	if (tabela == NULL) tabela = fp;
	int i, n;

	ListaVetor *lv = inicializa_listavetor();
	
	fread(&n, sizeof(int), 1, fp);

	// carrega a tabela de frequencias
	CarreiraVetorFrequencias *cvf = NULL;
	if (global) CarreiraVetorFrequenciasLoad (&cvf, tabela);

	// monta o codigo de huffman
	CarreiraHuffman *ch = NULL;
	if (global) CarreiraHuffmanCreate(&ch, cvf);

//printf("%d blocos decodificados\n", n);
	BITSTREAM *bits = bitstream_new();
	BITSTREAM *bits_tabela = bitstream_new();
    bitstream_load (bits_tabela, tabela);
    bitstream_load (bits, fp);
	for (i = 0; i < n; i++) {
		Vetor *v = CarreiraDeCodeVetor(bits, cvf, ch, bits_tabela);
		adiciona_listavetor(lv, v);
	}
	bitstream_delete(bits_tabela);
	bitstream_delete(bits);
    
	if (global) CarreiraVetorFrequenciasDelete(cvf);
    if (global) CarreiraHuffmanDeleteTree(&ch);

//printf("%d blocos decodificados\n", lv->size);
	return lv;
}

//// teste de unidade
//int main (void) {
//	ListaVetor *lv = inicializa_listavetor ();
//	Vetor *v = NULL;
//	FILE *fp = NULL;
//	
//	int i, j;
//	for (j = 0; j < 3; j++) {
//		v = inicializa_vetor();
//	
//		for (i = 0; i < 64; i++) (*v)[i] = (i < 32);
//		(*v)[20] = j;
//		(*v)[40] = j;
//		(*v)[50] = j;
//
//		adiciona_listavetor(lv, v);
//	}
//	
//	printf("lista de vetores %d\n", lv->size);
//	for (j = 0; j < lv->size; j++) {
//		v = pega_listavetor(lv, j);
//		for (i = 0; i < 64; i++) printf("%d ", (*v)[i]);
//		printf("\n");
//	}
//	
//
//	printf("Codificando\n");
//	fp = fopen("teste2.cod", "wb");
//	CarreiraCode(fp, lv);
//	fclose(fp);
//	limpa_listavetor(lv);
//
//	printf("Decodificando\n");
//	fp = fopen("teste2.cod", "rb");
//	lv = CarreiraDeCode (fp);
//	fclose(fp);
//	
//	printf("Decodificado\n");
//	printf("lista de vetores %d\n", lv->size);
//	for (j = 0; j < lv->size; j++) {
//		v = pega_listavetor(lv, j);
//		for (i = 0; i < 64; i++) printf("%d ", (*v)[i]);
//		printf("\n");
//	}
//	
//	limpa_listavetor(lv);
//
////	FILE *fp = fopen("teste.cod", "wb");
////	CarreiraCodeVetor(fp, v);
////	fclose(fp);
//	
////	finaliza_vetor(&v);
//
////	inicializa_vetor(&v);
//
////	fp = fopen("teste.cod", "rb");
////	CarreiraDeCodeVetor(fp, &v);
////	fclose(fp);
//	
////	printf("Vetor decodificado\n");
////	for (i = 0; i < 64; i++) printf("%d ", v[i]);
////	printf("\n");
//
////	finaliza_vetor(&v);
//	return 0;
//}
