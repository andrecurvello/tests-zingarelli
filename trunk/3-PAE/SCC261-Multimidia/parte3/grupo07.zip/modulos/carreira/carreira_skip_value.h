/* Compressão de Imagem Digital
 * Fase 3
 *
 * Materia: SCC0261 Multimidia
 *
 * Entrega:  14/06/2011
 * Grupo: 7
 *  Fábio Abrão Luca
 *  Giulianne Katlauskas Montemurro
 *  Lucas Cuculo Badiale
 */

#ifndef _CARREIRA_SKIP_VALUE_H_
#define _CARREIRA_SKIP_VALUE_H_

// skip e o valor
typedef struct {
	int skip;
	int value;
} CarreiraSkipValue;

// construtores
CarreiraSkipValue *CarreiraSkipValueNew (int skip, int value);

// destrutor
void CarreiraSkipValueDelete (CarreiraSkipValue *csv);

// setters
void CarreiraSkipValueSetSkip  (CarreiraSkipValue *csv, int skip );
void CarreiraSkipValueSetValue (CarreiraSkipValue *csv, int value);

// getters
int CarreiraSkipValueGetSkip  (CarreiraSkipValue *csv);
int CarreiraSkipValueGetValue (CarreiraSkipValue *csv);

// others methods

// converte para uma string
char *CarreiraSkipValueToString (CarreiraSkipValue *csv);

#endif
