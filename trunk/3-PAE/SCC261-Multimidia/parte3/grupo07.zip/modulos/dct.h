/* Compressão de Imagem Digital
 * Fase 3
 *
 * Materia: SCC0261 Multimidia
 *
 * Entrega:  14/06/2011
 * Grupo: 7
 *  Fábio Abrão Luca
 *  Giulianne Katlauskas Montemurro
 *  Lucas Cuculo Badiale
 */

#ifndef _DCT_H_
#define _DCT_H_

#include "prepara.h"

// faz a transformada DCT e a quantizacao em um bloco
void dct(int b[8][8]);

// desfaz a transformada DCT e a quantizacao de um bloco
void desdct(int b[8][8]);

// realiza a dct e a quantizacao de todos os blocos
void dctquantiza (listaBloco b);

// desfaz a dct e a quantizacao de todos os blocos
void desdctquantiza (listaBloco b);

#endif
