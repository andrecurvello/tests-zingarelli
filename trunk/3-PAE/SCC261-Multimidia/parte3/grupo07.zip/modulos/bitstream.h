/* Compressão de Imagem Digital
 * Fase 3
 *
 * Materia: SCC0261 Multimidia
 *
 * Entrega:  14/06/2011
 * Grupo: 7
 *  Fábio Abrão Luca
 *  Giulianne Katlauskas Montemurro
 *  Lucas Cuculo Badiale
 */

#ifndef _BITSTREAM_H_
#define _BITSTREAM_H_

#include <stdio.h>

typedef struct {
	char *vetor;
	int size;
	int start;
	int end;
} BITSTREAM;

// inicializa o bitstream
BITSTREAM* bitstream_new ();

// deleta o bitstream
void bitstream_delete (BITSTREAM *b);

// coloca um bit no final
void bitstream_add_bit (BITSTREAM *b, int bit);

// coloca um numero no final do bitstream
void bitstream_add_number (BITSTREAM *b, int numero, int quantidade_bits);

// pega um bit do comeco do bitstream
int bitstream_get_bit (BITSTREAM *b);

// pega um numero do comeco do bitstream
int bitstream_get_number (BITSTREAM *b, int quantidade_de_bits);

// pega um numero sem converter para negativo
int bitstream_get_number_no_conversion (BITSTREAM *b, int quantidade_de_bits);

// converte um bitstream em uma string
char* bitstream_to_string (BITSTREAM *b);

// concatena um bitstream source no final do target
void bitstream_cat (BITSTREAM *target, BITSTREAM *source);

// copia um bitstream no outro
void bitstream_copy (BITSTREAM *source, BITSTREAM *target);

// muda o inicio da 'cabeca de leitura'
void bitstream_seek (BITSTREAM *b, int posicao);

// salva o bitstream
int bitstream_save (BITSTREAM *b, FILE *fp);

// carrega o bitstream
int bitstream_load (BITSTREAM *b, FILE *fp);

// Retorna a quantidade minima de bits necessarios para o inteiro 'numero'
int nbits (int numero);

#endif
