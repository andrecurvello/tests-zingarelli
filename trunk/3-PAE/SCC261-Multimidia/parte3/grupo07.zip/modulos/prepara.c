/* Compressão de Imagem Digital
 * Fase 3
 *
 * Materia: SCC0261 Multimidia
 *
 * Entrega:  14/06/2011
 * Grupo: 7
 *  Fábio Abrão Luca
 *  Giulianne Katlauskas Montemurro
 *  Lucas Cuculo Badiale
 */

#include "prepara.h"

#include <stdlib.h>
#include <stdio.h>

/*cria nova lista*/
void novaLista(listaBloco *lista) {
    *lista = NULL;
}

/*cria um novo bloco*/
listaBloco AllocLista() {
    listaBloco p;
    p = (listaBloco) malloc(sizeof (noBloco));
    novaLista(&p->next);
    return p;
}

/*adiciona um novo bloco na lista*/
listaBloco novoBloco(listaBloco *lista) {
    listaBloco p, q, r;
    p = AllocLista();
    if (*lista == NULL) {
        *lista = p;
    } else {
        q = *lista;
        while (!(q->next == NULL)) {
            q = q->next;
        }
        r = q->next;
        q->next = p;
        p->next = r;
    }

	return p;
}

/*confere se a lista esta vazia*/
int listaVazia(listaBloco lista) {
    return lista == NULL;
}

void preparacaoImagem(char * filename, BMPFILEHEADER *fHeader, BMPINFOHEADER *header, listaBloco *bloco) {
    BMPMAGICNUMBER bmpnum;
    int nroBlocosLinha, nroBlocosCol, linha_aux, coluna_aux;
    int restaLinha, restaColuna;
    int i, j, k, l, exc, comecar;
    FILE *entrada;
    listaBloco bloco1, bloco1l;

    /*abertura do arquivo passado por parametro*/
    entrada = fopen(filename, "rb");

    if (entrada == NULL) {
        fprintf(stderr, "Nao foi possivel abrir o arquivo %s\n ", filename);
        exit(EXIT_FAILURE);
    } else {
        // Le o file headers do bitmap
        // a struct BMPFILEHEADER tem um tamanho errado, devido � problemas de alinhamento
        fread(&bmpnum, 2, 1, entrada);
        fread(fHeader, sizeof(BMPFILEHEADER), 1, entrada);

        // verifica se o arquivo eh um bitmap
        if (bmpnum.bfType != 19778) {
            fprintf(stderr, "Arquivo nao eh um bitmap.\n");
            exit(EXIT_FAILURE);
        }
        // le o info header
        fread(header, sizeof (BMPINFOHEADER), 1, entrada);
        //fseek(entrada, fHeader->bfOffBits, SEEK_SET);

        /*numero de blocos que existem na largura*/
        nroBlocosLinha = header->biWidth / 8;
        //nroBlocosLinha = 1680/8;

        /*numero de pixels a sobrar na largura*/
        restaLinha = header->biWidth % 8;
        //restaLinha = 1680%8;
        linha_aux = restaLinha;

        /*numero de blocos que existem na altura*/
        nroBlocosCol = header->biHeight / 8;
        // nroBlocosCol = 1050/8;

        /*numero de pixels a sobrar na altura*/
        restaColuna = header->biHeight % 8;
        //restaColuna = 1050%8;
        coluna_aux = restaColuna;

        /*cria nova lista de blocos*/
        novaLista(&(*bloco));

        /*extrai as cores de uma
        lista de blocos da imagem na vertical*/
        for (i = 0; i < nroBlocosCol; i++) {

            if ((*bloco) != NULL)
                while ((*bloco)->next != NULL)
                    (*bloco) = (*bloco)->next;

            /*calcula a quantidade de blocos presentes na vertical da imagem (qtas linhas de (*bloco))*/
            for (j = 0; j < nroBlocosLinha; j++) {
                novoBloco(&(*bloco));
                if ((i==0)&&(j==0)) {
                    bloco1 = (*bloco);
                    bloco1l = (*bloco);
                }
                else if ((i!=0)&&(j==0)) {
                    (*bloco) = (*bloco)->next;
                    bloco1l = (*bloco);
                }
            }

            /*o que restar sera colocado em um ultimo (*bloco)*/
            if (restaLinha != 0) {
                novoBloco(&(*bloco));
            }

            comecar = 1;

            /*cada (*bloco) da lista armazena as cores de apenas uma linha. executa 8 vezes para completar 8 linhas de 8 pixels*/
            for (j = 0; j < 8; j++) {
                /*armazena cores de uma linha de 8 pixels*/
                for (l = 0; l < nroBlocosLinha; l++) {
                    for (k = 0; k < 8; k++) {
                        (*bloco)->r[j][k] = fgetc(entrada);
                        (*bloco)->g[j][k] = fgetc(entrada);
                        (*bloco)->b[j][k] = fgetc(entrada);
                    }
                    /*aponta para o proximo (*bloco) da lista*/
                    (*bloco) = (*bloco)->next;
                }
                //se houver sobra de pixel, armazena no ultimo (*bloco) da lista
                if (restaLinha != 0) {
                    //completa uma linha de 8 pixels do ultimo (*bloco) da lista
                    for (k = 0; k < 8; k++) {
                        if (linha_aux != 0) {
                            (*bloco)->r[j][k] = fgetc(entrada);
                            (*bloco)->g[j][k] = fgetc(entrada);
                            (*bloco)->b[j][k] = fgetc(entrada);
                            linha_aux--;
                        } else {
                            (*bloco)->r[j][k] = 0;
                            (*bloco)->g[j][k] = 0;
                            (*bloco)->b[j][k] = 0;
                        }
                    }
                    //l� e ignora a informacao adicional que o proprio arquivo BMP cria qndo existe sobra de pixels
                    for (exc = 0; exc < header->biWidth % 4; exc++)
                        fgetc(entrada);

                    linha_aux = restaLinha;
                }
                (*bloco) = bloco1l;
            }
        }
        (*bloco) = bloco1;
    }
}

// salva o arquivo decodificado
void salvaBMP(char *decsaida, BMPFILEHEADER fheader, BMPINFOHEADER iheader, listaBloco decblocos) {
    // abre o arquivo de saida
    // salva o header de arquivo (fheader) com 14 bytes (nao usar sizeof)
    // salva o header de informacoes (iheader). (pode usar o sizeof neste caso)
    // salva os blocos
    // fecha o arquivo
    FILE *saida;
    int nroBlocosLinha;
    int i, j, l;
    listaBloco b, b1l;
    int contador = 0;
    unsigned short magicnum = 19778;
    
	// abre o arquivo de saida
    saida = fopen(decsaida, "wb");

    if (saida == NULL) {
        fprintf(stderr, "Nao foi possivel abrir o arquivo %s\n ", decsaida);
        exit(EXIT_FAILURE);
    } else {
        // salva o header de arquivo (fheader) com 14 bytes
        fwrite(&magicnum, 2, 1, saida);
        fwrite(&fheader, sizeof(BMPFILEHEADER), 1, saida);
        // salva o header de informacoes (iheader).
        fwrite(&iheader, sizeof(BMPINFOHEADER), 1, saida);
        
        nroBlocosLinha = iheader.biWidth / 8;
        b = decblocos;
        // salva os blocos
        while (b != NULL) {
            b1l = b;
            for (i = 0; i < 8; i++) {
                for (l = 0; l < nroBlocosLinha; l++) {
                    for (j = 0; j < 8; j++) {
                        fputc(b->r[i][j],saida);
                        fputc(b->g[i][j],saida);
                        fputc(b->b[i][j],saida);
                    }
                    b = b->next;
                }
                if (i != 7) b = b1l;
                else contador++;
            }
        }
        // fecha o arquivo
        fclose(saida);
    }
}

// faz o level shift dos elementos de cada bloco (subtrai 128)
void levelShift(listaBloco *blocos) {
    // cada elemento dos bloquinhos varia entre 0 e 255
    // nessa funcao temos que subtrair 128 de cada elemento.
    listaBloco b = *blocos;
    int i, j;

//	printf("original\n");
//    while (b != NULL) {
//        for (i = 0; i <8; i++) {
//            for (j = 0; j < 8; j++) {
//                printf("%02X%02X%02X ", b->r[i][j], b->g[i][j], b->b[i][j]);
//            }
//			printf("\n");
//        }
//		printf("\n");
//        b = b->next;
//    }

	b = *blocos;
    while (b != NULL) {
        for (i = 0; i <8; i++) {
            for (j = 0; j < 8; j++) {
                b->r[i][j] -= 128;
                b->g[i][j] -= 128;
                b->b[i][j] -= 128;
            }
        }
        b = b->next;
    }
}

// faz o level UNshift dos elementos de cada bloco (soma 128)
void levelUnshift(listaBloco *decblocos) {
    // cada elemento dos bloquinhos varia entre -128 e 127
    // nessa funcao temos que somar 128 de cada elemento.
    listaBloco b = *decblocos;
    int i, j;

    while (b != NULL) {
        for (i = 0; i < 8; i++) {
            for (j = 0; j < 8; j++) {
                b->r[i][j] += 128;
                b->g[i][j] += 128;
                b->b[i][j] += 128;
            }
        }
        b = b->next;
    }
   
//	printf("decodificado\n");
//	b = *decblocos;
//	while (b != NULL) {
//        for (i = 0; i <8; i++) {
//            for (j = 0; j < 8; j++) {
//                printf("%02X%02X%02X ", b->r[i][j], b->g[i][j], b->b[i][j]);
//            }
//			printf("\n");
//        }
//		printf("\n");
//        b = b->next;
//    }
}

