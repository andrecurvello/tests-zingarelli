/* Compressão de Imagem Digital
 * Fase 3
 *
 * Materia: SCC0261 Multimidia
 *
 * Entrega:  14/06/2011
 * Grupo: 7
 *  Fábio Abrão Luca
 *  Giulianne Katlauskas Montemurro
 *  Lucas Cuculo Badiale
 */

#include "diferencas.h"

#define DC 0	// Indice do coeficiente DC nos blocos vetorizados
#define ESQ 1 	// Bit quando desce na arvore de Huffman pela esquerda
#define DIR 0 	// Bit quando desce na arvore de Huffman pela direita

// ENCODE =====================================================================

void diferencas(ListaVetor **vetores) {
	int nvetores = (*vetores)->size;
	Vetor *v1 = NULL;
	Vetor *v2 = NULL;
	
	// Imagem possui mais de um coeficiente DC
	if (nvetores > 1) {
		int i;
		// Faz as diferencas de trás pra frente
		for (i = nvetores-1; i > 0; i--) {
			v1 = pega_listavetor(*vetores, i);
			v2 = pega_listavetor(*vetores, i - 1);
			(*v1)[DC] -= (*v2)[DC];
		}
	}
}

// Verifica se um simbolo esta na tabela de frequencias
// Retorno: Posicao do simbolo se encontrado ou -1 caso contrario
int tabelafreq_simbpos(TabelaFrequenciaDif *tf, int simbolo) {
	if (tf->tabela != NULL) {
		int i = 0;
		for (i = 0; i < tf->size; i++)
			if (tf->tabela[i].simbolo == simbolo)
				return i;
	}
	return -1;
}

// Monta e retorna a tabela de frequencias dos coeficientes DC
TabelaFrequenciaDif* tabelafrequencia_dif(ListaVetor *vetores) {
	int nvetores = vetores->size;
	Vetor** vetor = vetores->lista;

	// Imagem possui mais de um coeficiente DC
	if (nvetores > 1) { 
		TabelaFrequenciaDif *tf = (TabelaFrequenciaDif*) malloc(sizeof(TabelaFrequenciaDif)) ;
		tf->tabela = NULL;
		tf->size = 0;

		int i;
		for (i = 0; i < nvetores; i++) {
			int nrobits = nbits((*(vetor[i]))[DC]);
			int pos = tabelafreq_simbpos(tf,nrobits);
			if (pos == -1) {
				// Simbolo nao presente na tabela
				// Aloca espaco pra novo simbolo no fim do vetor (Indice tf->size-1)
				tf->size++;
				tf->tabela = (SimboloDif*) realloc(tf->tabela,tf->size * sizeof(SimboloDif));
				tf->tabela[tf->size-1].simbolo = nrobits;
				tf->tabela[tf->size-1].frequencia = 1;
			} else {
				// Simbolo presente (Indice pos), aumenta frequencia
				tf->tabela[pos].frequencia++;
			}
		}
		return tf;
	}
	return NULL;
}

// Funcao de comparacao de frequencias para o qsort
// Retorno: Se frequencia de a < frequencia de b, retorna um valor positivo,
//			se frequencia de a > frequencia de b, retorna um valor negativo,
//			se frequencia de a = frequencia de b, retorna 0.
int comparafreq(const void* a, const void* b) {
	return -(((SimboloDif*)a)->frequencia - ((SimboloDif*)b)->frequencia);
}
// Funcao de comparacao de numero de bits para o qsort
// Retorno: Se frequencia de a > frequencia de b, retorna um valor positivo,
//			se frequencia de a < frequencia de b, retorna um valor negativo,
//			se frequencia de a = frequencia de b, retorna 0.
int comparanbits(const void* a, const void* b) {
	return (((SimboloDif*)a)->simbolo - ((SimboloDif*)b)->simbolo);
}

// Algoritmo de Huffman para as diferencas
huffnode* huffman_dif(TabelaFrequenciaDif *tf) {
	int i;

	// Eh necessario ordenar pelos dois campos para manter a montagem da tabela
	// sempre consistente.
	
	// qsort faz ordenacao crescente da tabela por numero de bits
	qsort(tf->tabela,tf->size,sizeof(SimboloDif),comparanbits);
	// qsort ordena a tabela da maior frequencia para a menor
	qsort(tf->tabela,tf->size,sizeof(SimboloDif),comparafreq);

	// Fila de nos para gerar a arvore
	huffnode* fila[tf->size];
	for (i = 0; i < tf->size; i++) fila[i] = NULL;

	// Gera as estruturas dos nos a partir da tabela
	for (i = 0; i < tf->size; i++) {
		huffnode* no = (huffnode*) malloc(sizeof(huffnode));
		no->simbolo = tf->tabela[i].simbolo;
		no->peso = tf->tabela[i].frequencia;
		no->esq = NULL;
		no->dir = NULL;
		fila[i] = no;
	}

	// Gera a arvore de Huffman
	int n = tf->size-1;
	while (n > 0) {
		// Desenfileira os 2 com menor peso e cria noh pai com peso = soma dos 2 pesos
		huffnode* pai = (huffnode*) malloc(sizeof(huffnode));
		pai->simbolo = -1;
		pai->peso = fila[n]->peso + fila[n-1]->peso;
		pai->esq = fila[n];
		pai->dir = fila[n-1];
		fila[n] = NULL;
		fila[n-1] = NULL;
		
		// Enfileira noh pai na posicao correta
		i = n-2;
		while ((i >= 0)&&(pai->peso > fila[i]->peso)) {
			fila[i+1] = fila[i];
			i--;
		}
		fila[i+1] = pai;
		n--;
	}
	return fila[0];
}

// Funcao recursiva para extracao do huffcode
void extraiHuffcodes_rec(huffnode *node, BITSTREAM *code, TabelaFrequenciaDif *tf) {
	if (node != NULL) {
		// Noh folha
		if (node->simbolo != -1) {
			int i = 0;
			while  (tf->tabela[i].simbolo != node->simbolo) i++;
			tf->tabela[i].huffcode = code;
		}
		// Noh intermediário, desce na arvore
		else {
			// Filho da esquerda
			BITSTREAM *bsesq = bitstream_new();
			bitstream_copy(code,bsesq);
			bitstream_add_bit(bsesq,ESQ);
			extraiHuffcodes_rec(node->esq,bsesq,tf);

			// Filho da direita
			BITSTREAM *bsdir = bitstream_new();
			bitstream_copy(code,bsdir);
			bitstream_add_bit(bsdir,DIR);
			extraiHuffcodes_rec(node->dir,bsdir,tf);

			// limpa a memoria
			bitstream_delete(code);
		}
	}
}

// Extrai os huffcodes da arvore para a tabela
void extraiHuffcodes(huffnode *hufftree, TabelaFrequenciaDif *tf) {
	extraiHuffcodes_rec(hufftree, bitstream_new(), tf);
}

// Monta o bitstream com os huffcodes e coeficientes DC
BITSTREAM* bitstream_dif(ListaVetor *vetores, TabelaFrequenciaDif *tf) {
	BITSTREAM *bs = bitstream_new();
	
	// qsort faz ordenacao crescente da tabela por numero de bits
	qsort(tf->tabela,tf->size,sizeof(SimboloDif),comparanbits);
	
	int i;
	for (i = 0; i < vetores->size; i++) {
		int dc = (*pega_listavetor(vetores, i))[DC];
		// Acha codigo de huffman na tabela pelo numero de bits
		int numbits = nbits(dc);
		SimboloDif *entrada = (SimboloDif*) bsearch(&numbits,tf->tabela,tf->size,
												sizeof(SimboloDif),comparanbits);
		// Coloca o huffcode no bitstream
		bitstream_cat(bs,entrada->huffcode);

		// Coloca o coeficiente DC no bitstream
		bitstream_add_number(bs,dc,numbits);
	}
	
	return bs;
}

// Salva tabela de frequencias em um arquivo binario
void toFile_dif (TabelaFrequenciaDif *tf, FILE *fd) {
	if ((tf != NULL)&&(fd != NULL)) {
		int size = tf->size;
		fwrite(&size,sizeof(int),1,fd);

		int i;
		for (i = 0; i < tf->size; i++) {
			short simbolo =    (short) tf->tabela[i].simbolo;
			short frequencia = (short) tf->tabela[i].frequencia;
			fwrite(&simbolo,sizeof(short),1,fd); // pode ir de -255 a 255
			fwrite(&frequencia,sizeof(short),1,fd);
		}
	} else {
        fprintf(stderr, "Ocorreu um erro ao salvar a tabela de frequencias das diferencas\n");
    }
}

// Executa todo o processo de codificacao por diferencas
void diferencas_encode(ListaVetor *vetores, FILE *fd, FILE *tabela) {
//int i;
    // Calcula diferencas
//printf("Original\n");
//for (i = 0; i < vetores->size; i++) { printf("%4d ", (*pega_listavetor(vetores, i))[0]); }
//printf("\n");
    diferencas(&vetores);
//printf("Diferencas\n");
//for (i = 0; i < vetores->size; i++) { printf("%4d ", (*pega_listavetor(vetores, i))[0]); }
//printf("\n");

    // Monta tabela de frequencias
    TabelaFrequenciaDif* tf = tabelafrequencia_dif(vetores);
//printf("Tabela de diferencas %d\n", tf->size);
//int i;
//for (i = 0; i < tf->size; i++) { 
//	printf("%4d %4d\n", tf->tabela[i].simbolo, tf->tabela[i].frequencia);
//}

    // Monta arvore de Huffman
    huffnode* htree = huffman_dif(tf);

    // Adiciona Huffcodes na tabela a partir da arvore
    extraiHuffcodes(htree,tf);

//printf("Tabela de diferencas com huffman\n");
//for (i = 0; i < tf->size; i++) { 
//	printf("%4d %4d %s\n", tf->tabela[i].simbolo, tf->tabela[i].frequencia, bitstream_to_string(tf->tabela[i].huffcode));
//}

    // Monta bitstream
    BITSTREAM *bs = bitstream_dif(vetores, tf);
//printf("bitstream end %d\n", bs->end);
//printf("bitstream %s\n", bitstream_to_string(bs));

    // Escreve tabela no arquivo
	if (tabela == NULL) tabela = fd;
    toFile_dif(tf,tabela);
//printf("Tabela de frequencias salva\n");

    // Escreve bitstream no arquivo
    bitstream_save(bs,fd);
//printf("Bitstream salvo\n");
//printf("Fim do encoding\n");
}

// DECODE =====================================================================

// Calcula os coeficientes DC a partir das diferencas
void desdiferencas (ListaVetor **vetores) {
	int nvetores = (*vetores)->size;
	Vetor** vetor = (*vetores)->lista;

	// Imagem possui mais de um coeficiente DC
	if (nvetores > 1) {
		int i;
		for (i = 1; i < nvetores; i++) {
			(*(vetor[i]))[DC] += (*(vetor[i-1]))[DC];
		}
	}
}

// Carrega tabela de frequencias do arquivo binario
TabelaFrequenciaDif* loadTable_dif (FILE *fd) {
	if (fd != NULL) {
		TabelaFrequenciaDif *tf = (TabelaFrequenciaDif*) malloc(sizeof(TabelaFrequenciaDif));
		int size;
		fread(&size,sizeof(int),1,fd);
		tf->size = size;
		tf->tabela = (SimboloDif*) malloc(tf->size*sizeof(SimboloDif));

		int i;
		for (i = 0; i < tf->size; i++) {
			short simbolo;
			short frequencia;
			fread(&simbolo,sizeof(short),1,fd);
			fread(&frequencia,sizeof(short),1,fd);
			tf->tabela[i].simbolo = (int) simbolo;
			tf->tabela[i].frequencia = (int) frequencia;
		}
		return tf;
	} else {
        fprintf(stderr, "Ocorreu um erro ao carregar a tabela de frequencias das diferencas\n");
    }
    return NULL;
}

// Executa processo de decodificacao e alocacao das estruturas
ListaVetor* diferencas_decode(FILE *fd, FILE *tabela) {
	int i;

	// Carrega tabela de frequencias do arquivo
	if (tabela == NULL) tabela = fd;
	TabelaFrequenciaDif *tf = loadTable_dif(tabela);
//printf("Tabela de diferencas %d\n", tf->size);
//for (i = 0; i < tf->size; i++) { 
//	printf("%4d %4d\n", tf->tabela[i].simbolo, tf->tabela[i].frequencia);
//}

    // Monta arvore de Huffman
    huffnode* htree = huffman_dif(tf);

//extraiHuffcodes(htree,tf);
//printf("Tabela de diferencas com huffman\n");
//for (i = 0; i < tf->size; i++) { 
//	printf("%4d %4d %s\n", tf->tabela[i].simbolo, tf->tabela[i].frequencia, bitstream_to_string(tf->tabela[i].huffcode));
//}

    // Carrega bitstream do arquivo
    BITSTREAM *bs = bitstream_new();
    bitstream_load(bs, fd);
//printf("end: %d\n", bs->end);
//printf("bitstream: %s\n", bitstream_to_string(bs));

    // Conta o número de blocos vetorizados
    int nvetores = 0;
    for (i = 0; i < tf->size; i++)
    	nvetores += tf->tabela[i].frequencia;

    // Aloca a lista de vetores
    //ListaVetor *lv = (ListaVetor*) malloc(sizeof(ListaVetor));
    //lv->size = nvetores;
    //lv->lista = (Vetor*) malloc(lv->size*sizeof(Vetor*));
    ListaVetor* lv = inicializa_listavetor();
    
    // Processa o bitstream para as estruturas de dados
    for (i = 0; i < nvetores; i++) {
    	// Aloca o vetor
    	Vetor *v = inicializa_vetor();

    	//lv->lista[i] = (VetorElemento*) malloc(64*sizeof(VetorElemento));
    	adiciona_listavetor(lv, v);

    	// Noh que desce na arvore
    	huffnode* node = htree;

    	// Le stream bit a bit e desce pro lado correspondente ateh a folha
    	while (node->simbolo == -1) {
    		int bit = bitstream_get_bit(bs);
    		if (bit == ESQ) {
    			node = node->esq;
    		} else {
    			node = node->dir;
    		}
    	}

    	// Pega o numero de acordo com o numero de bits descrito no noh folha
    	// e joga na primeira posicao (indide do DC) do vetor
    	(*v)[DC] = bitstream_get_number(bs,node->simbolo);
//printf("node->simbolo %d\n", node->simbolo);
    }

//printf("Diferencas\n");
//for (i = 0; i < lv->size; i++) { printf("%4d ", (*pega_listavetor(lv, i))[0]); }
//printf("\n");
    
    // Converte as diferencas nos valores originais	
    desdiferencas (&lv);
//printf("Original\n");
//for (i = 0; i < lv->size; i++) { printf("%4d ", (*pega_listavetor(lv, i))[0]); }
//printf("\n");

//printf("Fim do decode\n");
	return lv;
}

//// Testes de Unidade
//int main (void) {
//	int i, a[2], b[2], c[2], d[2], e[2], f[2], g[2], h[2];
//	a[0]  = 127;
//	b[0]  = 63;
//	c[0]  = 31;
//	d[0]  = 15;
//	e[0]  = 7;
//	f[0]  = 3;
//	g[0]  = 1;
//	h[0]  = 0;
//	
//	ListaVetor *lv = (ListaVetor*) malloc(sizeof(ListaVetor));
//	lv->size = 8;
//	lv->lista = (Vetor*) malloc(lv->size*sizeof(Vetor*));
//
//	lv->lista[0] = a;
//	lv->lista[1] = b;
//	lv->lista[2] = c;
//	lv->lista[3] = d;
//	lv->lista[4] = e;
//	lv->lista[5] = f;
//	lv->lista[6] = g;
//	lv->lista[7] = h;
//
//	// diferencas() e desdiferencas()
//	diferencas(&lv);
//	printf("DCs dif:");
//	for (i = 0; i < lv->size; i++)	printf(" %d",lv->lista[i][0]);
//	printf("\n");
//	
//	desdiferencas(&lv);
////	printf("DCs desdif:");
////	for (i = 0; i < lv->size; i++)	printf(" %d",lv->lista[i][0]);
////	printf("\n");
///*
//	// nbits()
//	int n;
//	printf("N = "); scanf("%d",&n);
//	printf("NBITS: %d\n",nbits(n));
//
//	// Tabela de Frequencias
//	TabelaFrequenciaDif* tf = tabelafrequencia_dif(lv);
//
//	// Impressao da tabela
//	for (i = 0; i < tf->size; i++)
//		printf("Nbits: %d, Freq: %d\n",tf->tabela[i].simbolo,tf->tabela[i].frequencia);
//
//	// Huffman
//	huffnode* htree = huffman_dif(tf);
//	extraiHuffcodes(htree,tf);
//	bitstream_dif(lv, tf);
//	// Impressao da tabela com Huffcodes
//	for (i = 0; i < tf->size; i++)
//		printf("Nbits: %d, Freq: %d, Huffcode: %s\n",tf->tabela[i].simbolo,tf->tabela[i].frequencia,bitstream_to_string(tf->tabela[i].huffcode));
//
//	// Bitstream
//	BITSTREAM *ba = bitstream_new();
//	BITSTREAM *bb = bitstream_new();
//	bitstream_add_number(ba,1,nbits(4));
//
//	// Bitstream Copy
//	bitstream_copy(ba,bb);
//
//	//Bitstream Cat
//	bitstream_add_number(bb,0,nbits(4));
//	bitstream_cat(ba,bb);
//
//	// Print Bitstream
//	printf("BA: %s, BB: %s\n",bitstream_to_string(ba),bitstream_to_string(bb));
//
//	// Escrita da tabela no arquivo
//	FILE *fd = fopen("tabela.txt","wb");
//	toFile_dif(tf,fd);
//	fclose(fd);
//
//	// Leitura da tabela do arquivo
//	fd = fopen("tabela.txt","rb");
//	TabelaFrequenciaDif* tt = loadTable_dif(fd);
//	// Impressao da tabela
//	for (i = 0; i < tt->size; i++)
//		printf("Simb: %d, Freq: %d\n",tt->tabela[i].simbolo,tt->tabela[i].frequencia);
//	fclose(fd);
//*/
//	// ENCODE
//	printf("DCs:");
//	for (i = 0; i < lv->size; i++)	printf(" %d",lv->lista[i][0]);
//	printf("\n");
//	FILE *fd = fopen("binario.txt","wb");
//	diferencas_encode(lv,fd);
//	fclose(fd);
//	
//	// DECODE
//	fd = fopen("binario.txt","rb");
//	ListaVetor *dlv = diferencas_decode(fd);
//	printf("DECODE:");
//	for (i = 0; i < dlv->size; i++)	printf(" %d",dlv->lista[i][0]);
//	printf("\n");
//	fclose(fd);
//
//	return 0;
//}
