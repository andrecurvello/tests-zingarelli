/* Compressão de Imagem Digital
 * Fase 3
 *
 * Materia: SCC0261 Multimidia
 *
 * Entrega:  14/06/2011
 * Grupo: 7
 *  Fábio Abrão Luca
 *  Giulianne Katlauskas Montemurro
 *  Lucas Cuculo Badiale
 */

#include "dct.h"

#include "prepara.h"

#include <stdlib.h>
#include <math.h>

//// tabela de quantizacao dos slides
//int QUANTIZACAO[8][8] = {
//	{ 10,  10,  15,  20,  25,  30,  35,  40},
//	{ 10,  15,  20,  25,  30,  35,  40,  50},
//	{ 15,  20,  25,  30,  35,  40,  50,  60},
//	{ 20,  25,  30,  35,  40,  50,  60,  70},
//	{ 25,  30,  35,  40,  50,  60,  70,  80},
//	{ 30,  35,  40,  50,  60,  70,  80,  90},
//	{ 35,  40,  50,  60,  70,  80,  90, 100},
//	{ 40,  50,  60,  70,  80,  90, 100, 110}
//};

// tabela JPEG padrao de luminancia
int QUANTIZACAO[8][8] = {
	{ 16, 11, 10, 16,  24,  40,  51,  61 },
	{ 12, 12, 14, 19,  26,  58,  60,  55 },
	{ 14, 13, 16, 24,  40,  57,  69,  56 },
	{ 14, 17, 22, 29,  51,  87,  80,  62 },
	{ 18, 22, 37, 56,  68, 109, 103,  77 },
	{ 24, 35, 55, 64,  81, 104, 113,  92 },
	{ 49, 64, 78, 87, 103, 121, 120, 101 },
	{ 72, 92, 95, 98, 112, 100, 103,  99 }
};

//// tabela JPEG padrao de crominancia
//int QUANTIZACAO[8][8] = {
//	{ 17, 18, 24, 47, 99, 99, 99, 99 },
//	{ 18, 21, 26, 66, 99, 99, 99, 99 },
//	{ 24, 26, 56, 99, 99, 99, 99, 99 },
//	{ 47, 66, 99, 99, 99, 99, 99, 99 },
//	{ 99, 99, 99, 99, 99, 99, 99, 99 },
//	{ 99, 99, 99, 99, 99, 99, 99, 99 },
//	{ 99, 99, 99, 99, 99, 99, 99, 99 },
//	{ 99, 99, 99, 99, 99, 99, 99, 99 }
//};

// funcao C
double funcao_c (int index) {
	if (index == 0) return sqrt(2) / 2; // == 1 / raiz(2)
	return 1;
}

// faz a transformada DCT de um bloco
void dct(int b[8][8]) {
	int i, j, x, y;
	
	double F[8][8];
	
	// faz a transformada DCT
	for (i = 0; i < 8; i++) {
		for (j = 0; j < 8; j++) {
			// somatorio muito loko
			double sum = 0;
			for (x = 0; x < 8; x++) {
				for (y = 0; y < 8; y++) {
					double cos1 = cos ( ( ( 2 * x + 1 ) * (i * M_PI) ) / 16 );
					double cos2 = cos ( ( ( 2 * y + 1 ) * (j * M_PI) ) / 16 );
					sum += b[x][y] *  cos1 * cos2;
				}
			}
			
			// multiplicacao com o somatorio muito loko
			F[i][j] = (funcao_c(i) * funcao_c(j) * sum) / 4;

		}
	}

	// salva o resultado no bloco
	// AQUI ACONTECE PERDA DE PRECISAO
	for (i = 0; i < 8; i++) {
		for (j = 0; j < 8; j++) {
			b[i][j] = F[i][j] / QUANTIZACAO[i][j] + 0.5;
		}
	}
}

// desfaz a transformada DCT de um bloco
void desdct(int b[8][8]) {
	int i, j, x, y;
	
	double F[8][8];
	
	// desfaz a quantizacao
	for (i = 0; i < 8; i++) {
		for (j = 0; j < 8; j++) {
			F[i][j] = b[i][j] * QUANTIZACAO[i][j];
		}
	}
	
	// faz a transformada DCT inversa
	for (x = 0; x < 8; x++) {
		for (y = 0; y < 8; y++) {
			// somatorio muito loko
			double sum = 0;
			for (i = 0; i < 8; i++) {
				for (j = 0; j < 8; j++) {
					double cos1 = cos ( ( ( 2 * x + 1 ) * (i * M_PI) ) / 16 );
					double cos2 = cos ( ( ( 2 * y + 1 ) * (j * M_PI) ) / 16 );
					sum += (funcao_c(i) * funcao_c(j) * F[i][j] *  cos1 * cos2);
				}
			}
			
			// multiplicacao com o somatorio muito loko
			b[x][y] = (sum) / 4;
		
			// a quantizacao inversa pode fazer com que -128 vire -129, ou 127 vire 128, por exemplo
			// quando formos salvar a imagem como char ao inves de int, temos alguns probleminhas...
			// para resolver isso, precisamos desse if
			if (b[x][y] > 127) b[x][y] = 127;
			else if (b[x][y] < - 128) b[x][y] = -128;
		}
	}
}

// realiza a dct e a quantizacao de todos os blocos
void dctquantiza (listaBloco b) {
	listaBloco aux = b;

	while (aux != NULL) {
		dct(aux->r);
		dct(aux->g);
		dct(aux->b);

		aux = aux->next;
	}
}

// desfaz a dct e a quantizacao de todos os blocos
void desdctquantiza (listaBloco b) {
	listaBloco aux = b;

	while (aux != NULL) {
		desdct(aux->r);
		desdct(aux->g);
		desdct(aux->b);

		aux = aux->next;
	}
}

//// teste de unidade
//#include <stdio.h>
//int main (void) {
//	int i, j;
//	int b[8][8];
//
//	// bloco que ficava errado
//	int orig[8][8] = {
//		{  0x00, 0x03, 0x17, 0x28, 0x33, 0x32, 0x32, 0x33 },
//		{  0x00, 0x02, 0x13, 0x25, 0x32, 0x34, 0x35, 0x36 },
//		{  0x00, 0x02, 0x12, 0x23, 0x32, 0x39, 0x3B, 0x3B },
//		{  0x00, 0x00, 0x0A, 0x19, 0x2C, 0x37, 0x3D, 0x3E },
//		{  0x00, 0x00, 0x05, 0x0F, 0x21, 0x32, 0x3C, 0x3E },
//		{  0x00, 0x00, 0x01, 0x06, 0x14, 0x26, 0x34, 0x3B },
//		{  0x00, 0x00, 0x00, 0x00, 0x05, 0x16, 0x2A, 0x33 },
//		{  0x00, 0x00, 0x00, 0x00, 0x00, 0x0F, 0x24, 0x31 },
//	};
//
//	// inicializa
//	for (i = 0; i < 8; i++) {
//		for (j = 0; j < 8; j++) {
//			orig[i][j] -= 128;
//			b[i][j] = orig[i][j];
//		}
//	}
//	
//	printf("Antes da DCT:\n");
//	for (i = 0; i < 8; i++) {
//		for (j = 0; j < 8; j++) printf("%4d ", b[i][j] + 128);
//		printf("\n");
//	}
//	printf("\n");
//	
//	dct(b);
//	
//	printf("Depois da DCT:\n");
//	for (i = 0; i < 8; i++) {
//		for (j = 0; j < 8; j++) printf("%4d ", b[i][j]);
//		printf("\n");
//	}
//	printf("\n");
//	
//	desdct(b);
//
//	printf("Depois de desfazer a DCT:\n");
//	for (i = 0; i < 8; i++) {
//		for (j = 0; j < 8; j++) printf("%4d ", b[i][j] + 128);
//		printf("\n");
//	}
//	printf("\n");
//	
//	printf("Erros: \n");
//	int erros = 0;
//	for (i = 0; i < 8; i++) {
//		for (j = 0; j < 8; j++) {
//			if (b[i][j] == orig[i][j]) printf(" _ ");
//			else {
//				printf(" X ");
//				erros++;
//			}
//		}
//		printf("\n");
//	}
//	printf("\nUm total de %d erros.\n", erros);
//
//	return 0;
//}
