/************************************************************/
/*              UNIVERSIDADE DE S�O PAULO - ICMC            */
/*           DEPARTAMENTO DE CI�NCIAS DE COMPUTA��O         */
/*             SCC0261 Multim�dia - 1o Sem /2011            */
/*                 Prof. Rudinei Goularte                   */
/*          Estagi�rio PAE: Matheus R. U. Zingarelli        */
/*                                                          */
/* Projeto - Parte 3                                        */
/*                                                          */
/* Grupo:                                                   */
/*       C�ssio de Matos Silva, 5909002                     */
/*       Dhyego Palacios Bonifacio, 5378050                 */
/************************************************************/

#include <stdio.h>
#include "geral.h"
#include "huffman_diferencas.h"
#include "huffman_carreira.h"
#include "dct.h"

#define MAX_WIDTH 1280
#define MAX_HEIGHT 800

//-----------------------------------------------------------------------------------------
//--------------------------------- Estruturas de dados -----------------------------------
//-----------------------------------------------------------------------------------------

//Tabela de frequencia de valores para a codificacao por diferencas
typedef struct
{
	char *value;
	int *freq;
	//valido = 1 (ainda nao foi contado no Huffman); valido = 0 (ja esta na arvore de Huffman)
} FREQ_TABLE_DIF;

//Estrutura para a tabela de Huffman da codificacao por diferencas
typedef struct TABELA_HUFFMAN1
{
	char *sss;
	char *codigo;
} TABELA_HUFFMAN1;

//Estrutura para a tabela de Huffman da codificacao por carreira
typedef struct TABELA_HUFFMAN2
{
	int *skip;
	char *sss;
	char *codigo;
} TABELA_HUFFMAN2;

//Estrutura base para a tabela criada em arquivo para auxiliar a descompactacao.
typedef struct
{
	unsigned int n;
	char *bits;
} TABLE;

//Stream de dados a ser gravado em disco (arquivo compactado).
typedef struct
{
	unsigned int num_bits;
	char *data;
} STREAM;

//-----------------------------------------------------------------------------------------
//--------------------------------------- Funcoes -----------------------------------------
//-----------------------------------------------------------------------------------------

//Le o header completo do BMP.
void readFileHeader(char *filename, BMPFILEHEADER *fheader);

//Le o info completo do BMP.
void readInfoHeader(char *filename, BMPINFOHEADER *finfo);

// Imprime o header BMP.
void printBMPHeader(BMPFILEHEADER *fheader, BMPINFOHEADER *finfo);

//Le os dados do arquivo e guarda no vetor de dados e nos vetores R, G, B.
void readData2(const char *filename, BMPFILEHEADER *fheader, BMPINFOHEADER *finfo, char *data, char *dataR, char *dataG, char *dataB);

// Imprime os dados lidos do arquivo BMP.
void printData2(BMPFILEHEADER *fheader, BMPINFOHEADER *finfo, char *data, char *dataR, char *dataG, char *dataB);

//Divide os vetores de dados R, G, B em blocos de 8x8.
void dataToBlocks2(BMPFILEHEADER *fheader, BMPINFOHEADER *finfo, char *dataR, char *dataG, char *dataB, PIXEL_BLOCK *blockR, PIXEL_BLOCK *blockG, PIXEL_BLOCK *blockB);

//Imprime os dados dos blocos 8x8.
void printBlocks2(BMPFILEHEADER *fheader, BMPINFOHEADER *finfo, PIXEL_BLOCK *blockR, PIXEL_BLOCK *blockG, PIXEL_BLOCK *blockB);

//Transforma o range dos blocos 8x8 de 0 a 255 para -128 a 127.
void levelShift2(BMPFILEHEADER *fheader, BMPINFOHEADER *finfo, PIXEL_BLOCK *blockR, PIXEL_BLOCK *blockG, PIXEL_BLOCK *blockB);

//Imprime somente os primeiros elementos dos blocos R (para testar as diferencas).
void printBlocks3(BMPFILEHEADER *fheader, BMPINFOHEADER *finfo, PIXEL_BLOCK *blockR, PIXEL_BLOCK *blockG, PIXEL_BLOCK *blockB);

//Converte um valor decimal de 8 bits em um valor binario (representados em complemento de 1).
void dec2bin(short decimal, char binary[]);

//Converte um valor decimal de 64 bits em um valor binario (representados em complemento de 1).
void dec2bin_long(long long int decimal, char binary[]);

//Salva as diferen�as no arquivo compactado, utiliza da tabela de Huffman das diferen�as
void salvarDiferencas(char *filename, BMPFILEHEADER *fheader, BMPINFOHEADER *finfo, PIXEL_BLOCK *blockR, PIXEL_BLOCK *blockG, PIXEL_BLOCK *blockB, HD_TABLE *t);

//Salva a codifica��o por carreira no arquivo compactado, utiliza da tabela de Huffman gerada para as carreiras
void salvarCarreira(char *filename, BMPFILEHEADER *fheader, BMPINFOHEADER *finfo, ELEM_CARREIRA v[], int numElCarreira, HC_TABLE *t);


//-----------------------------------------------------------------------------------------
//----------------------------------------- Implementacao ---------------------------------
//-----------------------------------------------------------------------------------------

//Funcao que le o header completo do BMP.
void readFileHeader(char *filename, BMPFILEHEADER *fheader)
{
	FILE *fp;
	fp = fopen(filename, "rb");
	fseek(fp, 0, SEEK_SET);
	fread(&(fheader->bfType), 2, 1, fp);
	fseek(fp, 2, SEEK_SET);
	fread(&(fheader->bfSize), 4, 1, fp);
	fseek(fp, 6, SEEK_SET);
	fread(&(fheader->bfReserved1), 2, 1, fp);
	fseek(fp, 8, SEEK_SET);
	fread(&(fheader->bfReserved2), 2, 1, fp);
	fseek(fp, 10, SEEK_SET);
	fread(&(fheader->bfOffBits), 4, 1, fp);
	fclose(fp);
}

//Funcao que le o info completo do BMP.
void readInfoHeader(char *filename, BMPINFOHEADER *finfo)
{
	FILE *fp;
	fp = fopen(filename, "rb");
	fseek(fp, 14, SEEK_SET);
	fread(&(finfo->biSize), 4, 1, fp);
	fseek(fp, 18, SEEK_SET);
	fread(&(finfo->biWidth), 4, 1, fp);
	fseek(fp, 22, SEEK_SET);
	fread(&(finfo->biHeight), 4, 1, fp);
	fseek(fp, 26, SEEK_SET);
	fread(&(finfo->biPlanes), 2, 1, fp);
	fseek(fp, 28, SEEK_SET);
	fread(&(finfo->biBitCount), 2, 1, fp);
	fseek(fp, 30, SEEK_SET);
	fread(&(finfo->biCompression), 4, 1, fp);
	fseek(fp, 34, SEEK_SET);
	fread(&(finfo->biSizeImage), 4, 1, fp);
	fseek(fp, 38, SEEK_SET);
	fread(&(finfo->biXPelsPerMeter), 4, 1, fp);
	fseek(fp, 42, SEEK_SET);
	fread(&(finfo->biYPelsPerMeter), 4, 1, fp);
	fseek(fp, 46, SEEK_SET);
	fread(&(finfo->biClrUsed), 4, 1, fp);
	fseek(fp, 50, SEEK_SET);
	fread(&(finfo->biClrImportant), 4, 1, fp);
	fclose(fp);
}

//Le os dados do arquivo e guarda no vetor de dados e nos vetores R, G, B.
void readData2(const char *filename, BMPFILEHEADER *fheader, BMPINFOHEADER *finfo, char *data, char *dataR, char *dataG, char *dataB)
{
	FILE *arq1;
	int temp;
	char tempChar;
	int i, j;
	arq1 = fopen(filename, "rb");
	
	for (i = 0; i < (finfo->biWidth * finfo->biHeight * 3); i++)
	{
		fseek(arq1, fheader->bfOffBits + i, SEEK_SET);
		fread(&data[i], sizeof(char), 1, arq1);
		
	}
	
	for (i = 0; i < finfo->biHeight; i++)
	{
		for (j = 0; j < finfo->biWidth; j++)
		{
			dataB[finfo->biWidth*i + j] = data[3*(i*(finfo->biWidth) + j)];
			dataG[finfo->biWidth*i + j] = data[3*(i*(finfo->biWidth) + j) + 1];
			dataR[finfo->biWidth*i + j] = data[3*(i*(finfo->biWidth) + j) + 2];
		}
	}
	
	fclose(arq1);
}

// Divide os vetores de dados R, G, B em blocos de 8x8.
void dataToBlocks2(BMPFILEHEADER *fheader, BMPINFOHEADER *finfo, char *dataR, char *dataG, char *dataB, PIXEL_BLOCK *blockR, PIXEL_BLOCK *blockG, PIXEL_BLOCK *blockB)
{
	
	int index[(finfo->biWidth * finfo->biHeight) / 64]; // Indice que sera usado para popular os blocos
	int i;
	int blNumber; // Numero do bloco
	short dado = 0x0000;
	short mascara = 0x00FF;
	
	// Inicializa os indices com 0
	for (i = 0; i < (finfo->biWidth * finfo->biHeight) / 64; i++)
		index[i] = 0;
		
	// Loop que copia os dados para as estruturas dos blocos
	for (i = 0; i < (finfo->biWidth * finfo->biHeight); i++)
	{
		blNumber = (((i/finfo->biWidth)/8)*(finfo->biWidth/8) + (i % finfo->biWidth)/8);
		
		dado = dataR[i]; 
		blockR[blNumber].data[index[blNumber]] = (mascara & dado);
		dado = dataG[i];
		blockG[blNumber].data[index[blNumber]] = (mascara & dado);
		dado = dataB[i];
		blockB[blNumber].data[index[blNumber]] = (mascara & dado);
		
		index[blNumber]++;
		
	}
	
}

//Imprime o header BMP.
void printBMPHeader(BMPFILEHEADER *fheader, BMPINFOHEADER *finfo)
{
	printf("\n");
	printf("Magic Number: %x\n", fheader->bfType);
	printf("Size of file: %d\n", fheader->bfSize);
	printf("Reserved1: %x\n", fheader->bfReserved1);
	printf("Reserved2: %x\n", fheader->bfReserved2);
	printf("Offset: %d\n", fheader->bfOffBits);
	
	printf("\n");
	printf("Size of info header: %u\n", finfo->biSize);
	printf("Width: %d\n", finfo->biWidth);
	printf("Height: %d\n", finfo->biHeight);
	printf("Color planes: %x\n", finfo->biPlanes);
	printf("Bits per pixel: %x\n", finfo->biBitCount);
	printf("Compression: %u\n", finfo->biCompression);
	printf("Size of image data: %u\n", finfo->biSizeImage);
	printf("X Pixels per meter: %d\n", finfo->biXPelsPerMeter);
	printf("Y Pixels per meter: %d\n", finfo->biYPelsPerMeter);
	printf("Colors used: %u\n", finfo->biClrUsed);
	printf("Important colors: %u\n", finfo->biClrImportant);
	
}

// Imprime os dados lidos do arquivo BMP.
void printData2(BMPFILEHEADER *fheader, BMPINFOHEADER *finfo, char *data, char *dataR, char *dataG, char *dataB)
{
	int i;
	int j;
	
	
	for (i = 0; i < finfo->biHeight; i++)
	{
		printf("\ni=%d ", i);
		for (j = 0; j < finfo->biWidth; j++)
			printf("%d>%d>%d ", data[3*(i*(finfo->biWidth) + j)], data[3*(i*(finfo->biWidth) + j) + 1], data[3*(i*(finfo->biWidth) + j) + 2]);
	}
	printf("\n");
	
	printf("\nRed matrix:\n");
	for (i = 0; i < finfo->biHeight; i++)
	{
		printf("\ni=%d ", i);
		for (j = 0; j < finfo->biWidth; j++)
			printf("%d ", dataR[(i*(finfo->biWidth) + j)]);
	}
	printf("\n");
	
	printf("\nGreen matrix:\n");
	for (i = 0; i < finfo->biHeight; i++)
	{
		printf("\ni=%d ", i);
		for (j = 0; j < finfo->biWidth; j++)
			printf("%d ", dataG[(i*(finfo->biWidth) + j)]);
	}
	printf("\n");
	
	printf("\nBlue matrix:\n");
	for (i = 0; i < finfo->biHeight; i++)
	{
		printf("\ni=%d ", i);
		for (j = 0; j < finfo->biWidth; j++)
			printf("%d ", dataB[(i*(finfo->biWidth) + j)]);
	}
	
	
	printf("\n");	
	
}

//Imprime os dados dos blocos 8x8.
void printBlocks2(BMPFILEHEADER *fheader, BMPINFOHEADER *finfo, PIXEL_BLOCK *blockR, PIXEL_BLOCK *blockG, PIXEL_BLOCK *blockB)
{
	int i;
	int j;
	int k;
	
	
	printf("\nRed blocks:\n");
	for (i = 0; i < (finfo->biWidth * finfo->biHeight) / 64; i++)
	{
		printf("\nBlock %d = ", i);
				
		for (j = 0; j < 8; j++)
		{
			printf("\n");
			for (k = 0; k < 8; k++)
				printf("%d ", blockR[i].data[8*j + k]);
		}
	}
	printf("\n\n");
	
	printf("\nGreen blocks:\n");
	for (i = 0; i < (finfo->biWidth * finfo->biHeight) / 64; i++)
	{
		printf("\nBlock %d = ", i);
				
		for (j = 0; j < 8; j++)
		{
			printf("\n");
			for (k = 0; k < 8; k++)
				printf("%d ", blockG[i].data[8*j + k]);
		}
	}
	printf("\n\n");
	
	printf("\nBlue blocks:\n");
	for (i = 0; i < (finfo->biWidth * finfo->biHeight) / 64; i++)
	{
		printf("\nBlock %d = ", i);
				
		for (j = 0; j < 8; j++)
		{
			printf("\n");
			for (k = 0; k < 8; k++)
				printf("%d ", blockB[i].data[8*j + k]);
		}
	}
	printf("\n");
	
}

//Imprime os dados dos blocos 8x8.
void printBlocks3(BMPFILEHEADER *fheader, BMPINFOHEADER *finfo, PIXEL_BLOCK *blockR, PIXEL_BLOCK *blockG, PIXEL_BLOCK *blockB)
{
	int i;
	int j;
	int k;
	
	printf("\nRed blocks:\n");
	for (i = 0; i < (finfo->biWidth * finfo->biHeight) / 64; i++)
	{		
		printf("%d ", blockR[i].data[0]);
	}
	printf("\n\n");
	/*
	printf("\nGreen blocks:\n");
	for (i = 0; i < (finfo->biWidth * finfo->biHeight) / 64; i++)
	{
		printf("\nBlock %d = ", i);
				
		for (j = 0; j < 8; j++)
		{
			printf("\n");
			for (k = 0; k < 8; k++)
				printf("%d ", blockG[i].data[8*j + k]);
		}
	}
	printf("\n\n");
	
	printf("\nBlue blocks:\n");
	for (i = 0; i < (finfo->biWidth * finfo->biHeight) / 64; i++)
	{
		printf("\nBlock %d = ", i);
				
		for (j = 0; j < 8; j++)
		{
			printf("\n");
			for (k = 0; k < 8; k++)
				printf("%d ", blockB[i].data[8*j + k]);
		}
	}
	printf("\n");
	*/
	
}

//Transforma o range dos blocos 8x8 de 0 a 255 para -128 a 127.
void levelShift2(BMPFILEHEADER *fheader, BMPINFOHEADER *finfo, PIXEL_BLOCK *blockR, PIXEL_BLOCK *blockG, PIXEL_BLOCK *blockB)
{
	int i, j, k;
	for (i = 0; i < (finfo->biWidth * finfo->biHeight) / 64; i++)
		for (j = 0; j < 8; j++)
			for (k = 0; k < 8; k++)
			{
				blockR[i].data[8*j + k] -= 128;
				blockG[i].data[8*j + k] -= 128;
				blockB[i].data[8*j + k] -= 128;
			}
}

//Converte um valor decimal em um valor bin�rio (representados em complemento de 1)
void dec2bin(short decimal, char binary[]) {
     int i, n = 0;
     for (i = 0; i < 16; i++) binary[i] = 0;
     if (decimal < 0) {
                 decimal = abs(decimal);
                 n = 1;
     }
     i = 15;
     do {
         binary[i--] = decimal % 2;
         decimal /= 2;
     } while (decimal > 1);
     binary[i] = decimal;
     if (n == 1) {
           for (i = 0; i < 16; i++) {
               if (binary[i] == 1) binary[i] = 0;
               else binary[i] = 1;
           }
     }
}

//Converte um valor decimal de 64 bits em um valor binario (representados em complemento de 1).
void dec2bin_long(long long int decimal, char binary[]) {
     int i, n = 0;
     for (i = 0; i < 64; i++) binary[i] = 0;
     if (decimal < 0) {
                 decimal = abs(decimal);
                 n = 1;
     }
     i = 63;
     do {
         binary[i--] = decimal % 2;
         decimal /= 2;
     } while (decimal > 1);
     binary[i] = decimal;
     if (n == 1) {
           for (i = 0; i < 64; i++) {
               if (binary[i] == 1) binary[i] = 0;
               else binary[i] = 1;
           }
     }
}

//Salva as diferen�as no arquivo compactado, utiliza da tabela de Huffman das diferen�as
void salvarDiferencas(char *filename, BMPFILEHEADER *fheader, BMPINFOHEADER *finfo, PIXEL_BLOCK *blockR, PIXEL_BLOCK *blockG, PIXEL_BLOCK *blockB, HD_TABLE *t) {
     int i, j, ctl=0, posR, posG, posB;
     FILE *arq;
     char aux[16], byte;     
     arq = fopen(filename,"a+b");
     //Percorre todos os blocos, codificando os coeficientes DC/
     for (i = 0; i < (finfo->biWidth * finfo->biHeight) / 64; i++) {
         posR = hd_search(numBits2(blockR[i].data[0]), t);
         dec2bin(t->codigo[posR], aux);
         byte = 0x00;
         //Grava c�digo Huffman
         for (j=16-t->numB[posR];j<16;j++) {
             if (aux[j] == 1) {
                        byte = byte | 0x01;
             }
             ctl++;
             if (ctl == 8) {
                     fwrite(&byte, sizeof(char), 1, arq);
                     ctl = 0;
                     byte = 0x00;
             }
             byte << 1;
         }
         //Grava valor DC
         dec2bin(blockR[i].data[0], aux);
         for (j=16-t->sss[posR];j<16;j++) {
             if (aux[j] == 1) {
                        byte = byte | 0x01;
             }
             ctl++;
             if (ctl == 8) {
                     fwrite(&byte, sizeof(char), 1, arq);
                     ctl = 0;
                     byte = 0x00;
             }
             byte << 1;
         }
         posG = hd_search(numBits2(blockG[i].data[0]), t);
         dec2bin(t->codigo[posG], aux);
         byte = 0x00;
         //Grava c�digo Huffman
         for (j=16-t->numB[posG];j<16;j++) {
             if (aux[j] == 1) {
                        byte = byte | 0x01;
             }
             ctl++;
             if (ctl == 8) {
                     fwrite(&byte, sizeof(char), 1, arq);
                     ctl = 0;
                     byte = 0x00;
             }
             byte << 1;
         }
         dec2bin(blockG[i].data[0], aux);
         //Grava valor DC
         for (j=16-t->sss[posG];j<16;j++) {
             if (aux[j] == 1) {
                        byte = byte | 0x01;
             }
             ctl++;
             if (ctl == 8) {
                     fwrite(&byte, sizeof(char), 1, arq);
                     ctl = 0;
                     byte = 0x00;
             }
             byte << 1;
         }
         posB = hd_search(numBits2(blockB[i].data[0]), t);
         dec2bin(t->codigo[posB], aux);
         byte = 0x00;
         //Grava c�digo Huffman
         for (j=16-t->numB[posB];j<16;j++) {
             if (aux[j] == 1) {
                        byte = byte | 0x01;
             }
             ctl++;
             if (ctl == 8) {
                     fwrite(&byte, sizeof(char), 1, arq);
                     ctl = 0;
                     byte = 0x00;
             }
             byte << 1;
         }
         dec2bin(blockB[i].data[0], aux);
         //Grava valor DC
         for (j=16-t->sss[posB];j<16;j++) {
             if (aux[j] == 1) {
                        byte = byte | 0x01;
             }
             ctl++;
             if (ctl == 8) {
                     fwrite(&byte, sizeof(char), 1, arq);
                     ctl = 0;
                     byte = 0x00;
             }
             byte << 1;
         }
     }
     //Completa ultimo byte com zeros
     if (ctl < 8) {
             for (i=ctl;i<8;i++) byte << 1;
             fwrite(&byte, sizeof(char), 1, arq);
     }
     fclose(arq);
}

//Salva a codifica��o por carreira no arquivo compactado, utiliza da tabela de Huffman gerada para as carreiras
void salvarCarreira(char *filename, BMPFILEHEADER *fheader, BMPINFOHEADER *finfo, ELEM_CARREIRA *v, int numElCarreira, HC_TABLE *t) {
     int i, j, k, skip, ctl=0, pos;
     FILE *arq;
     short value;
     char aux[16], aux2[64], byte;
     
     int codigos=0, values=0, bytes=0, dados=0, qtdbits=0, qtdbits2=0;
     
     arq = fopen(filename,"a+b");
     byte = 0x00;
     //Percorre cada bloco da imagem, codificando os AC
     for (i = 0; i < numElCarreira; i++) {
         pos = hc_search(v[i].skip, v[i].sss, t);
         dec2bin_long(t->codigo[pos], aux2);
         //Grava c�digo Huffman SKIP, SSS
         qtdbits2 += t->numB[pos];
         for (k=64-t->numB[pos];k<64;k++) {
             qtdbits++;
             if (aux2[k] == 1) byte = byte | 0x01;
             ctl++;
             if (ctl == 8) {
                     fwrite(&byte, sizeof(char), 1, arq);
                     bytes++;
                     ctl = 0;
                     byte = 0x00;
             }
             byte << 1;
         }
         codigos++;
         dec2bin(v[i].value, aux);
         //Grava valor AC
         qtdbits2 += t->sss[pos];
         for (k=16-t->sss[pos];k<16;k++) {
             qtdbits++;
             if (aux[k] == 1) byte = byte | 0x01;
             ctl++;
             if (ctl == 8) {
                     fwrite(&byte, sizeof(char), 1, arq);
                     bytes++;
                     ctl = 0;
                     byte = 0x00;
             }
         byte << 1;
         }
     }
     //Completa ultimo byte com zeros
     if (ctl < 8) {
             for (i=ctl;i<8;i++) byte << 1;
             fwrite(&byte, sizeof(char), 1, arq);
             bytes++;
     }
     fclose(arq);
}

//----------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------

int main(int argc, char *argv[])
{
	int i;
	FILE *arq1;
	char *data, *dataR, *dataG, *dataB;
	PIXEL_BLOCK *blockR; // Blocos R
	PIXEL_BLOCK *blockG; // Blocos G
	PIXEL_BLOCK *blockB; // Blocos B
	
	TABLE t;
	STREAM s;
	BMPFILEHEADER fheader;
	BMPINFOHEADER finfo;
	
	// ----------------------- Variaveis adicionais usadas ------------------------
	
	int numElCarreira_; //Numero de valores (skip, sss) ao todo
	int numSimCar_; //Numero de (skip, sss) diferentes na cod. por carreira
	int numSimDif_; //Numero de (sss) diferentes na cod. por diferencas
	HD_FREQ_TABLE tabela1; //Tabela de frequencias para o Huffman das diferencas (3 cores)
	HD_TABLE tabelaHuff1; //Tabela de simbolos(codigos) de Huffman para as diferencas (3 cores)
	ELEM_CARREIRA *vetor; //Vetor de elementos skip, value, sss para carreira (1 cor)
	HC_FREQ_TABLE tabela2; //Tabela de frequencias para o Huffman de carreira (1 cor)
	HC_TABLE tabelaHuff2; //Tabela de simbolos(codigos) de Huffman para a carreira (1 cor)
	
	char indice[64], *str_temp;
	
	if (argc == 3)
	{
		if (strcmp(argv[1], "-d") == 0)
		{
            readFileHeader(argv[2], &fheader);
        	readInfoHeader(argv[2], &finfo);
        	
        	printBMPHeader(&fheader, &finfo);
            printf("\nIndisponivel.\n");
		}
		else if (strcmp(argv[1], "-c") == 0) 
		{
            readFileHeader(argv[2], &fheader);
        	readInfoHeader(argv[2], &finfo);
        	
        	printBMPHeader(&fheader, &finfo);
        	
        	data = malloc(finfo.biWidth * finfo.biHeight * sizeof(char) * 3);
        	dataR = malloc(finfo.biWidth * finfo.biHeight * sizeof(char));
        	dataG = malloc(finfo.biWidth * finfo.biHeight * sizeof(char));
        	dataB = malloc(finfo.biWidth * finfo.biHeight * sizeof(char));
        	blockR = malloc(((finfo.biWidth * finfo.biHeight) / 64) * sizeof(PIXEL_BLOCK));
        	blockG = malloc(((finfo.biWidth * finfo.biHeight) / 64) * sizeof(PIXEL_BLOCK));
        	blockB = malloc(((finfo.biWidth * finfo.biHeight) / 64) * sizeof(PIXEL_BLOCK));
        	
        	readData2(argv[2], &fheader, &finfo, data, dataR, dataG, dataB);
        	dataToBlocks2(&fheader, &finfo, dataR, dataG, dataB, blockR, blockG, blockB);
        	
        	levelShift2(&fheader, &finfo, blockR, blockG, blockB);
        	
			//Inicializa os indices em zig-zag
        	initIndices(indice);
			
			// ----------------------- Aplicando DCT e quantizando -------------------------------
			
			//Aplicando a DCT
			printf("Aplicando a DCT...\n");
			aplicarDCT(&fheader, &finfo, blockR, blockG, blockB, indice);
			
        	// ------------------ Codificando por diferencas (as 3 cores) ------------------------
        	
			printf("Codificando as diferencas...\n");
			
        	//Aplica as diferencas nos blocos
        	aplicarDiferencas(&fheader, &finfo, blockR, blockG, blockB);
        	//Pega o numero de simbolos
        	numSimDif_ = numSimDifHuff(&fheader, &finfo, blockR, blockG, blockB);
			//printf("Numero de simbolos para a diferenca: %d\n", numSimDif_);
        	//Cria a tabela no tamanho certo
        	tabela1.value = malloc(numSimDif_* sizeof(char));
        	tabela1.freq = malloc(numSimDif_* sizeof(int));
        	//Cria a tabela de Huffman
        	tabelaHuff1.sss = malloc(numSimDif_* sizeof(char));
        	tabelaHuff1.codigo = malloc(numSimDif_* sizeof(char));
        	tabelaHuff1.numB = malloc(numSimDif_* sizeof(char));
        	//Seta os valores para a tabela de frequencia
        	initDifFreqTable(&fheader, &finfo, &tabela1, numSimDif_, blockR, blockG, blockB);
        	//printDifFreqTable(&tabela1, numSimDif_);
        	//Roda o Huffman, gerando a tabela de simbolos
        	hd_Huffman(&tabela1, numSimDif_, &tabelaHuff1);
        	//hd_printTable(&tabelaHuff1, numSimDif_);
        	//Inicia arquivo compactado
        	str_temp = (char *) malloc(sizeof(char)*strlen(argv[2]));
            strcpy(str_temp, argv[2]);
            str_temp[strlen(str_temp)-1] = 't';
            str_temp[strlen(str_temp)-2] = 'p';
            str_temp[strlen(str_temp)-3] = 'c';
        	saveFile(str_temp, &fheader, &finfo);
        	//Salva tabela de Huffman das diferen�as
         	hd_saveHuffman(str_temp, &tabelaHuff1, &numSimDif_);
         	salvarDiferencas(str_temp, &fheader, &finfo, blockR, blockG, blockB, &tabelaHuff1);
        	
        	// ----------------------------------------------------------------------
        	
        	// ----- Codificando por carreira (deve ser aplicado 1 vez para cada cor) ------------
        	
			printf("Codificando as carreiras (vermelho)...\n");
			
        	//Inicializa os indices em zig-zag
        	initIndices(indice);
        	
        	// -------- Vermelho -----------
        	//Pega o numero de elementos para a codificacao por carreira
        	numElCarreira_ = numElCarreira(&fheader, &finfo, blockR, indice);
        	//Cria um vetor do tamanho certo
        	vetor = malloc(numElCarreira_ * sizeof(ELEM_CARREIRA));
        	//Gera os elementos, contando a partir do bloco
        	gerarElCarreira(&fheader, &finfo, blockR, vetor, indice);
        	//Pega o numero de elementos (skip, sss) diferentes
        	numSimCar_ = numSimCarHuff(vetor, numElCarreira_);
        	//printElCarreira(vetor, numElCarreira_);
        	//Cria a tabela de frequencias do tamanho certo
        	tabela2.skip = malloc(numSimCar_* sizeof(int));
        	tabela2.sss = malloc(numSimCar_* sizeof(char));
        	tabela2.freq = malloc(numSimCar_* sizeof(int));
        	//Cria a tabela para o Huffman
        	tabelaHuff2.skip = malloc(numSimCar_* sizeof(int));
        	tabelaHuff2.sss = malloc(numSimCar_* sizeof(char));
        	tabelaHuff2.codigo = malloc(numSimCar_* sizeof(long long int));
        	tabelaHuff2.numB = malloc(numSimCar_* sizeof(int));
        	//Seta os valores da tabela de frequencias
        	initCarFreqTable(&fheader, &finfo, &tabela2, numElCarreira_, vetor);
        	//printCarFreqTable(&tabela2, numSimCar_);
        	//Roda o Huffman, gerando a tabela de simbolos
        	hc_Huffman(&tabela2, numSimCar_, &tabelaHuff2);
        	//hc_printTable(&tabelaHuff2, numSimCar_);
        	hc_saveHuffman(str_temp, &tabelaHuff2, &numSimCar_);
        	salvarCarreira(str_temp, &fheader, &finfo, vetor, numElCarreira_, &tabelaHuff2);
			
        	// -------- Verde -----------
			
			printf("Codificando as carreiras (verde)...\n");
			
        	//Pega o numero de elementos para a codificacao por carreira
        	numElCarreira_ = numElCarreira(&fheader, &finfo, blockG, indice);
        	//Cria um vetor do tamanho certo
        	vetor = malloc(numElCarreira_ * sizeof(ELEM_CARREIRA));
        	//Gera os elementos, contando a partir do bloco
        	gerarElCarreira(&fheader, &finfo, blockG, vetor, indice);
        	//Pega o numero de elementos (skip, sss) diferentes
        	numSimCar_ = numSimCarHuff(vetor, numElCarreira_);
        	//printElCarreira(vetor, numElCarreira_);
        	//Cria a tabela de frequencias do tamanho certo
        	tabela2.skip = malloc(numSimCar_* sizeof(int));
        	tabela2.sss = malloc(numSimCar_* sizeof(char));
        	tabela2.freq = malloc(numSimCar_* sizeof(int));
        	//Cria a tabela para o Huffman
        	tabelaHuff2.skip = malloc(numSimCar_* sizeof(int));
        	tabelaHuff2.sss = malloc(numSimCar_* sizeof(char));
        	tabelaHuff2.codigo = malloc(numSimCar_* sizeof(long long int));
        	tabelaHuff2.numB = malloc(numSimCar_* sizeof(int));
        	//Seta os valores da tabela de frequencias
        	initCarFreqTable(&fheader, &finfo, &tabela2, numElCarreira_, vetor);
        	//printCarFreqTable(&tabela2, numSimCar_);
        	//Roda o Huffman, gerando a tabela de simbolos
        	hc_Huffman(&tabela2, numSimCar_, &tabelaHuff2);
        	//hc_printTable(&tabelaHuff2, numSimCar_);
        	hc_saveHuffman(str_temp, &tabelaHuff2, &numSimCar_);
        	salvarCarreira(str_temp, &fheader, &finfo, vetor, numElCarreira_, &tabelaHuff2);
        	
        	// -------- Azul -----------
			
			printf("Codificando as carreiras (azul)...\n");
			
        	//Pega o numero de elementos para a codificacao por carreira
        	numElCarreira_ = numElCarreira(&fheader, &finfo, blockB, indice);
        	//Cria um vetor do tamanho certo
        	vetor = malloc(numElCarreira_ * sizeof(ELEM_CARREIRA));
        	//Gera os elementos, contando a partir do bloco
        	gerarElCarreira(&fheader, &finfo, blockB, vetor, indice);
        	//Pega o numero de elementos (skip, sss) diferentes
        	numSimCar_ = numSimCarHuff(vetor, numElCarreira_);
        	//printElCarreira(vetor, numElCarreira_);
        	//Cria a tabela de frequencias do tamanho certo
        	tabela2.skip = malloc(numSimCar_* sizeof(int));
        	tabela2.sss = malloc(numSimCar_* sizeof(char));
        	tabela2.freq = malloc(numSimCar_* sizeof(int));
        	//Cria a tabela para o Huffman
        	tabelaHuff2.skip = malloc(numSimCar_* sizeof(int));
        	tabelaHuff2.sss = malloc(numSimCar_* sizeof(char));
        	tabelaHuff2.codigo = malloc(numSimCar_* sizeof(long long int));
        	tabelaHuff2.numB = malloc(numSimCar_* sizeof(int));
        	//Seta os valores da tabela de frequencias
        	initCarFreqTable(&fheader, &finfo, &tabela2, numElCarreira_, vetor);
        	//printCarFreqTable(&tabela2, numSimCar_);
        	//Roda o Huffman, gerando a tabela de simbolos
        	hc_Huffman(&tabela2, numSimCar_, &tabelaHuff2);
        	//hc_printTable(&tabelaHuff2, numSimCar_);
        	hc_saveHuffman(str_temp, &tabelaHuff2, &numSimCar_);
        	salvarCarreira(str_temp, &fheader, &finfo, vetor, numElCarreira_, &tabelaHuff2);
        	
        	// ----------------------------------------------------------------------
			printf("\nArquivo %s compactado no arquivo %s\n",argv[2],str_temp);
			printf("Utilize: %s -d %s para descompactar.\n",argv[0],str_temp);
		}
        else
		{
            printf("Opcao invalida");
        }
	}
	else
	{
		printf("Erro.\n");
		printf("Utilize %s -c <nome do arquivo>.BMP para compactar ou\n",argv[0]);
		printf("utilize %s -d <nome do arquivo>.CPT para descompactar.",argv[0]);
	}     
	
	exit(0);
}
