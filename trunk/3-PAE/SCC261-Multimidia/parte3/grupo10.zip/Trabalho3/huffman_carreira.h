/************************************************************/
/*              UNIVERSIDADE DE S�O PAULO - ICMC            */
/*           DEPARTAMENTO DE CI�NCIAS DE COMPUTA��O         */
/*             SCC0261 Multim�dia - 1o Sem /2011            */
/*                 Prof. Rudinei Goularte                   */
/*          Estagi�rio PAE: Matheus R. U. Zingarelli        */
/*                                                          */
/* Projeto - Parte 3                                        */
/*                                                          */
/* Grupo:                                                   */
/*       C�ssio de Matos Silva, 5909002                     */
/*       Dhyego Palacios Bonifacio, 5378050                 */
/************************************************************/

#include <stdio.h>
#include "geral.h"

//-----------------------------------------------------------------------------------------
//--------------------------------- Estruturas de dados -----------------------------------
//-----------------------------------------------------------------------------------------

//Estrutura para a codificacao por carreira
typedef struct
{
	//int porque pode ser at� 1024000 no melhor caso (figura de 1 cor soh)
	int skip;
	
	short value;
	
	//sss = bits necessarios para representar o value
	char sss;
	
} ELEM_CARREIRA;

//Tabela de frequencia de valores para a codificacao por carreira
typedef struct
{
	int *skip;
	char *sss;
	int *freq;
} HC_FREQ_TABLE;

//Estrutura para a tabela de Huffman da codificacao por carreira
typedef struct 
{
	int *skip;
	char *sss;
	long long int *codigo;
	int *numB;
} HC_TABLE;

//Estrutura de no da lista/arvore que vai ser usada no Huffman
typedef struct HC_FREQ_NODE
{
	int skip;
	char sss;
	int freq;
	struct HC_FREQ_NODE *prox;
	struct HC_FREQ_NODE *ant;
	struct HC_FREQ_NODE *filho0;
	struct HC_FREQ_NODE *filho1;
} HC_FREQ_NODE;


//-----------------------------------------------------------------------------------------
//--------------------------------------- Funcoes -----------------------------------------
//-----------------------------------------------------------------------------------------

//Conta quantos "ELEM_CARREIRA" serao necessarios para representar todos os blocos de uma cor.
int numElCarreira(BMPFILEHEADER *fheader, BMPINFOHEADER *finfo, PIXEL_BLOCK *block, char indice[64]);

//Seta o vetor de valores skip, value e sss.
void gerarElCarreira(BMPFILEHEADER *fheader, BMPINFOHEADER *finfo, PIXEL_BLOCK *block, ELEM_CARREIRA *vetor, char indice[64]);

//Retorna quantos pares (skip, sss) diferentes existem.
int numSimCarHuff(ELEM_CARREIRA *vetor, int tam);

//Imprime skip, value e sss.
void printElCarreira(ELEM_CARREIRA *vetor, int n);

//Coloca os skip, sss e frequencias na tabela de frequencias para o Huffman.
void initCarFreqTable(BMPFILEHEADER *fheader, BMPINFOHEADER *finfo, HC_FREQ_TABLE *tabela, int num, ELEM_CARREIRA *vetor);

//Imprime a tabela de frequencias.
void printCarFreqTable(HC_FREQ_TABLE *tabela, int num);

//Coloca os codigos de huffman na tabela a partir da arvore de huffman.
void hc_gerarCodigos(HC_FREQ_NODE *no, long long int codigo, HC_TABLE *tabela, int *indice, int nivel);

//Gera a arvore de Huffman a partir da tabela de frequencias e cria a tabela de codigos.
void hc_Huffman(HC_FREQ_TABLE *tabela, int num, HC_TABLE *tabela_final);

//Imprime a tabela de codigos de Huffman.
void hc_printTable(HC_TABLE *tabela, int num);

//Grava tabela Huffman em arquivo
void hc_saveHuffman(char *filename, HC_TABLE *t, int *numSimCar);

//Carrega tabela Huffman do arquivo
void hc_loadHuffman(char *filename, HC_TABLE *t, int *numSimCar);

//Procura por um SKIP e SSS e retorna o indice da tabela correspondente
int hc_search(int skip, char sss, HC_TABLE *t);

//-----------------------------------------------------------------------------------------
//-------------------------------------- Implementacao ------------------------------------
//-----------------------------------------------------------------------------------------

//Conta quantos "ELEM_CARREIRA" serao necessarios para representar todos os blocos de uma cor.
int numElCarreira(BMPFILEHEADER *fheader, BMPINFOHEADER *finfo, PIXEL_BLOCK *block, char indice[64])
{
	int i, j;
	short elAtual = block[0].data[indice[1]];
	int numEl = 1;
	
	//Para todos os blocos
	for (i = 0; i < (finfo->biWidth * finfo->biHeight) / 64; i++)
	{
		//Para todos os elementos - o primeiro
		for (j = 1; j < 64; j++)
		{
			//Se for diferente, deve comecar mais 1 skip+value
			if (elAtual != block[i].data[indice[j]])
			{
				elAtual = block[i].data[indice[j]];
				numEl++;
			}
		}
	}
	
	
	return numEl;
}

//Seta o vetor de valores skip, value e sss.
void gerarElCarreira(BMPFILEHEADER *fheader, BMPINFOHEADER *finfo, PIXEL_BLOCK *block, ELEM_CARREIRA *vetor, char indice[64])
{
	int i, j;	
	short elAtual;
	int skip;
	int numElAtual = 0;
	
	elAtual = block[0].data[indice[1]];
	skip = 0;
	vetor[0].value = elAtual;
	
	//Para todos os blocos
	for (i = 0; i < (finfo->biWidth * finfo->biHeight) / 64; i++)
	{
		//Para todos os elementos - o primeiro
		for (j = 1; j < 64; j++)
		{
			//Se for diferente, deve comecar mais 1 skip+value, seta o skip e sss do anterior e value do atual
			if (elAtual != block[i].data[indice[j]])
			{
				vetor[numElAtual].skip = skip;
				vetor[numElAtual].sss = numBits2(vetor[numElAtual].value);
				
				numElAtual++;
				skip = 1;
				elAtual = block[i].data[indice[j]];
				vetor[numElAtual].value = elAtual;
			}
			else
			{
				skip++;
				
			}
		}
	}
	
	vetor[numElAtual].skip = skip;
	vetor[numElAtual].sss = numBits2(vetor[numElAtual].value);
	
}

//Retorna quantos pares (skip, sss) diferentes existem.
int numSimCarHuff(ELEM_CARREIRA *vetor, int tam)
{
	int i, j, flag;
	int num = 0;
	int numSimAtual = 0;
	ELEM_CARREIRA *simbolos;
	
	simbolos = malloc(tam* sizeof(ELEM_CARREIRA));
	
	
	for (i = 0; i < tam; i++)
	{
		flag = 0;
		if (numSimAtual == 0)
		{
			(simbolos)->sss = (vetor)->sss;
			(simbolos)->skip = (vetor)->skip;
			numSimAtual = 1;
		}
		else
		{
			for (j = 0; j < numSimAtual; j++)
			{
				//Ja foi contado
				if (((simbolos+j)->sss == (vetor+i)->sss) && ((simbolos+j)->skip == (vetor+i)->skip))
					flag = 1;
			}
			
			if (flag == 0)
			{
				(simbolos+numSimAtual)->sss = (vetor+i)->sss;
				(simbolos+numSimAtual)->skip = (vetor+i)->skip;
				numSimAtual++;
			}
		}
	}
	
	free(simbolos);
	return numSimAtual;	
}

//Imprime skip, value e sss.
void printElCarreira(ELEM_CARREIRA *vetor, int n)
{
	int i;
	
	printf("\nElementos da codificacao por carreira: \n");
	for (i=0; i < n; i++)
	{
		printf("Skip: %d Value: %d SSS: %d \n", vetor[i].skip, vetor[i].value, vetor[i].sss);
	}
	printf("Numero de elementos: %d\n", n);
}

//Coloca os skip, sss e frequencias na tabela de frequencias para o Huffman.
void initCarFreqTable(BMPFILEHEADER *fheader, BMPINFOHEADER *finfo, HC_FREQ_TABLE *tabela, int num, ELEM_CARREIRA *vetor)
{
	int i, j, k;
	int flag = 0;
	int numSimAtual = 0;
	
	for (i = 0; i < num; i++)
	{
		//printf("%d %d %d\n", i, numSimAtual, num);
		flag = 0;
		if (i == 0)
		{
			tabela->sss[0] = ((vetor+0)->sss);
			tabela->skip[0] = (vetor+0)->skip;
			tabela->freq[0] = 1;
			numSimAtual = 1;
		}
		else
		{
			for (j = 0; j < numSimAtual; j++)
			{
				//Se ja existe, conta mais 1 na frequencia
				if ((tabela->sss[j] == (vetor+i)->sss) && (tabela->skip[j] == ((vetor+i)->skip)))
				{
					(tabela->freq[j])++;
					flag = 1;
				}
			}
			
			//Ainda nao existe, coloca no vetor e faz freq = 1
			if (flag == 0)
			{
				tabela->sss[numSimAtual] = (vetor+i)->sss;
				tabela->skip[numSimAtual] = (vetor+i)->skip;
				tabela->freq[numSimAtual] = 1;
				numSimAtual++;				
			}
		}
	}
	
}

//Imprime a tabela de frequencias.
void printCarFreqTable(HC_FREQ_TABLE *tabela, int num)
{
	int i;
	
	printf("Tabela de frequencias do Huffman de carreira:\n");
	for (i = 0; i < num; i++)
		printf("SSS: %d Skip: %d Freq: %d\n", tabela->sss[i], tabela->skip[i], tabela->freq[i]);
	
	printf("Numero de simbolos diferentes: %d\n", num);
}


//Coloca os codigos de huffman na tabela a partir da arvore de huffman.
void hc_gerarCodigos(HC_FREQ_NODE *no, long long int codigo, HC_TABLE *tabela, int *indice, int nivel)
{
	long long int novo_codigo = 0x0000000000000000;
	//Esta na folha, adiciona na tabela
	if (no->filho0 == NULL && no->filho1 == NULL)
	{
		tabela->sss[*indice] = no->sss;
		tabela->skip[*indice] = no->skip;
		tabela->codigo[*indice] = codigo;
		tabela->numB[*indice] = nivel;
		//printf("sss: %d skip: %d numB: %d\n", tabela->sss[*indice], tabela->skip[*indice], tabela->numB[*indice]);
		/*
		if ((*indice) > 0)
			printf("nivel: %d indice: %d\n", tabela->numB[(*indice)-1], *indice);
		*/
		(*indice)++;
		
	}
	//Nao eh folha, chama a recursao para os filhos
	else
	{
		novo_codigo = codigo << 1;
		hc_gerarCodigos(no->filho0, novo_codigo, tabela, indice, (nivel+1));
		
		novo_codigo |= 0x0000000000000001;
		hc_gerarCodigos(no->filho1, novo_codigo, tabela, indice, (nivel+1));			
		
	}
	
}

//Gera a arvore de Huffman a partir da tabela de frequencias e cria a tabela de codigos.
void hc_Huffman(HC_FREQ_TABLE *tabela, int num, HC_TABLE *tabela_final)
{
	int i;
	int *indice = malloc(sizeof(int));
	HC_FREQ_NODE *lista = malloc(sizeof(HC_FREQ_NODE));
	HC_FREQ_NODE *lAtual = lista;
	HC_FREQ_NODE *menor = NULL;
	HC_FREQ_NODE *filho0 = NULL;
	HC_FREQ_NODE *filho1 = NULL;
	HC_FREQ_NODE *novo;
	
	*indice = 0;
	
	lista->ant = NULL;
	lista->prox = NULL;
	lista->filho0 = NULL;
	lista->filho1 = NULL;
	
	//Coloca os SSS's, Skip's e Frequencia na lista.
	//printf("Inserindo na lista...\n");
	for (i = 0; i < num; i ++)
	{
		novo = malloc(sizeof(HC_FREQ_NODE));
		novo->skip = tabela->skip[i];
		novo->sss = tabela->sss[i];
		novo->freq = tabela->freq[i];
		lAtual->prox = novo;
		novo->ant = lAtual;
		novo->prox = NULL;
		novo->filho0 = NULL;
		novo->filho1 = NULL;	

		lAtual = lAtual->prox;
		//printf("sss: %d skip: %d freq: %d\n", novo->sss, novo->skip, novo->freq);
		
	}
	
	
	//Gerando a arvore de huffman
	//printf("Gerando a arvore...\n");
	while (lista->prox->prox != NULL)
	{
		//Pega o que tem menor frequencia
		menor = lista->prox;
		lAtual = menor;
		while (lAtual != NULL)
		{
			if (lAtual->freq < menor->freq)
				menor = lAtual;
			lAtual = lAtual->prox;
		}
		
		filho0 = menor;
		//printf("Filho0: %d %d fr: %d\n", filho0->sss, filho0->skip, filho0->freq);
		
		menor->ant->prox = menor->prox;
		if (menor->prox != NULL)
			menor->prox->ant = menor->ant;
		
		//Pega o segundo que tem menor frequencia
		menor = lista->prox;
		lAtual = menor;
		while (lAtual != NULL)
		{
			if (lAtual->freq < menor->freq)
				menor = lAtual;
			lAtual = lAtual->prox;
		}
		
		filho1 = menor;
		//printf("Filho1: %d %d fr: %d\n", filho1->sss, filho1->skip, filho1->freq);
		
		menor->ant->prox = menor->prox;
		if (menor->prox != NULL)
			menor->prox->ant = menor->ant;
		
		//Cria um novo no na arvore com os filhos de menor frequencia
		novo = malloc(sizeof(HC_FREQ_NODE));
		novo = malloc(sizeof(HC_FREQ_NODE));
		novo->freq = filho0->freq + filho1->freq;
		
		lAtual = lista;
		while (lAtual->prox != NULL)
			lAtual = lAtual->prox;
		
		lAtual->prox = novo;
		novo->ant = lAtual;
		novo->prox = NULL;
		novo->filho0 = filho0;
		novo->filho1 = filho1;
		
		
	}
	//Arvore de Huffman pronta
	
	
	//Gerando os codigos na tabela
	hc_gerarCodigos(lista->prox, 0x0000000000000000, tabela_final, indice, 0);
	
}

//Imprime a tabela de codigos de Huffman.
void hc_printTable(HC_TABLE *tabela, int num)
{
	int i;
	
	printf("Tabela de codigos:\n");
	for (i = 0; i < num; i++)
		printf("SSS: %d Skip: %d Codigo: %lld numB: %d \n", tabela->sss[i], tabela->skip[i], tabela->codigo[i], tabela->numB[i]);
	
}

//Grava tabela Huffman em arquivo
void hc_saveHuffman(char *filename, HC_TABLE *t, int *numSimCar) {
     int i;
     FILE *arq;
     arq = fopen(filename,"a+b");
     fwrite(numSimCar, sizeof(int), 1, arq);
     for (i=0;i<*numSimCar;i++) {
         fwrite(&(t->skip[i]), sizeof(int), 1, arq);
         fwrite(&(t->sss[i]), sizeof(char), 1, arq);
         fwrite(&(t->codigo[i]), sizeof(long long int), 1, arq);
         fwrite(&(t->numB[i]), sizeof(int), 1, arq);
     }
     fclose(arq);
}

//Carrega tabela Huffman do arquivo
void hc_loadHuffman(char *filename, HC_TABLE *t, int *numSimCar) {
     int i;
     FILE *arq;
     arq = fopen(filename,"rb");
     fread(numSimCar, sizeof(int), 1, arq);
     t->skip = malloc(*numSimCar* sizeof(int));
	 t->sss = malloc(*numSimCar* sizeof(char));
	 t->codigo = malloc(*numSimCar* sizeof(long long int));
	 t->numB = malloc(*numSimCar* sizeof(int));
	 for (i=0;i<*numSimCar;i++) {
         fread(&(t->skip[i]), sizeof(int), 1, arq);
         fread(&(t->sss[i]), sizeof(char), 1, arq);
         fread(&(t->codigo[i]), sizeof(long long int), 1, arq);
         fread(&(t->numB[i]), sizeof(int), 1, arq);
     }
     fclose(arq);
}

//Procura por um SKIP e SSS e retorna o indice da tabela correspondente
int hc_search(int skip, char sss, HC_TABLE *t) {
    int i = 0;
    while ((t->skip[i] != skip) || (t->sss[i] != sss)) i++;
    return i;
}
