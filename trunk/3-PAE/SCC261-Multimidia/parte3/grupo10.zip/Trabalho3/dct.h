/************************************************************/
/*              UNIVERSIDADE DE S�O PAULO - ICMC            */
/*           DEPARTAMENTO DE CI�NCIAS DE COMPUTA��O         */
/*             SCC0261 Multim�dia - 1o Sem /2011            */
/*                 Prof. Rudinei Goularte                   */
/*          Estagi�rio PAE: Matheus R. U. Zingarelli        */
/*                                                          */
/* Projeto - Parte 3                                        */
/*                                                          */
/* Grupo:                                                   */
/*       C�ssio de Matos Silva, 5909002                     */
/*       Dhyego Palacios Bonifacio, 5378050                 */
/************************************************************/

#include <stdio.h>
#include <math.h>
#include "geral.h"

#define PI 3.1415926535897932384626

//-----------------------------------------------------------------------------------------
//--------------------------------------- Funcoes -----------------------------------------
//-----------------------------------------------------------------------------------------

//Retorna o valor de C(i).C(j) para a DCT
float constDCT(int i, int j);

//Retorna o valor do somatorio da DCT
double soma(int i_, int j_, PIXEL_BLOCK*block, int nBlock);

//Inicializa a tabela de discretizacao padrao
void initDiscretTable(PIXEL_BLOCK *table, char indice[64], int n);

//Aplica a transformada DCT nos blocos R, G e B.
void aplicarDCT(BMPFILEHEADER *fheader, BMPINFOHEADER *finfo, PIXEL_BLOCK *blockR, PIXEL_BLOCK *blockG, PIXEL_BLOCK *blockB, char indice[64]);

//-----------------------------------------------------------------------------------------
//----------------------------------------- Implementacao ---------------------------------
//-----------------------------------------------------------------------------------------

//Retorna o valor de C(i).C(j) para a DCT
float constDCT(int i, int j)
{
	if (i == 0 && j == 0)
		return 0.5;
	else
		return 1.0;
}

//Retorna o valor do somatorio da DCT
double soma(int i_, int j_, PIXEL_BLOCK *block, int nBlock)
{
	int i, j;
	double soma = 0.0;
	
	for (i = 0; i < 8; i++)
		for (j = 0; j < 8; j++)
			soma = soma + ((block[nBlock].data[8*i + j])*(cos((2*i + 1)*i_*PI/16.0))*(cos((2*j + 1)*j_*PI/16.0)));
	
	return soma;
}

//Inicializa a tabela de discretizacao padrao (do slide da aula 8 com um fator n)
void initDiscretTable(PIXEL_BLOCK *table, char indice[64], int n)
{
	int i;
	
	for (i = 0; i < 64; i++)
	{
		if (i < 3)
			table->data[indice[i]] = 10/n;
		else if (i < 6)
			table->data[indice[i]] = 15/n;
		else if (i < 10)
			table->data[indice[i]] = 20/n;
		else if (i < 15)
			table->data[indice[i]] = 25/n;
		else if (i < 21)
			table->data[indice[i]] = 30/n;
		else if (i < 28)
			table->data[indice[i]] = 35/n;
		else if (i < 36)
			table->data[indice[i]] = 40/n;
		else if (i < 43)
			table->data[indice[i]] = 50/n;
		else if (i < 49)
			table->data[indice[i]] = 60/n;
		else if (i < 54)
			table->data[indice[i]] = 70/n;
		else if (i < 58)
			table->data[indice[i]] = 80/n;
		else if (i < 61)
			table->data[indice[i]] = 90/n;
		else if (i < 63)
			table->data[indice[i]] = 100/n;
		else if (i == 63)
			table->data[indice[i]] = 110/n;
	}
	
}

//Aplica a transformada DCT nos blocos R, G e B.
void aplicarDCT(BMPFILEHEADER *fheader, BMPINFOHEADER *finfo, PIXEL_BLOCK *blockR, PIXEL_BLOCK *blockG, PIXEL_BLOCK *blockB, char indice[64])
{
	int i, j, k;
	double tempR[64], tempG[64], tempB[64]; //Para nao perder precisao
	
	PIXEL_BLOCK dTable;
	
	printf("Inicializando a tabela de discretizacao...\n");
	initDiscretTable(&dTable, indice, 2);
	
	printf("Calculando os valores da DCT...\n");
	for (k = 0; k < (finfo->biWidth * finfo->biHeight) / 64; k++) // Para todos os blocos
	{
		//printf("DCT...\n");
		//Calcula os valores da DCT
		for (i = 0; i < 8; i++)
			for (j = 0; j < 8; j++)
			{
				tempR[8*i + j] = 0.25*constDCT(i, j)*soma(i, j, blockR, k);
				tempG[8*i + j] = 0.25*constDCT(i, j)*soma(i, j, blockG, k);
				tempB[8*i + j] = 0.25*constDCT(i, j)*soma(i, j, blockB, k);
				
			}
		
		//printf("Copiando para o bloco...\n");
		//Copia para o bloco
		for (i = 0; i < 8; i++)
			for (j = 0; j < 8; j++)
			{
				blockR[k].data[8*i + j] = (short)tempR[8*i + j];
				blockG[k].data[8*i + j] = (short)tempG[8*i + j];
				blockB[k].data[8*i + j] = (short)tempB[8*i + j];
			}
		
		//printf("Discretizando...\n");
		//Discretiza os valores
		for (i = 0; i < 8; i++)
			for (j = 0; j < 8; j++)
			{
				blockR[k].data[8*i + j] /= dTable.data[8*i + j];
				blockG[k].data[8*i + j] /= dTable.data[8*i + j];
				blockB[k].data[8*i + j] /= dTable.data[8*i + j];
				
				//printf("Discretizados: %d %d %d\n", blockR[k].data[8*i + j], blockG[k].data[8*i + j], blockB[k].data[8*i + j]);
			}
	}
}


