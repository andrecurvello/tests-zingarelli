#include "reader.h"
#include "compress.h"
#include "lvlshift.h"
#include "huff.h"
#include "uncompress.h"

int main(void) {
    //obtem o nome do arquivo a ser lido
    char filename[20];
    printf("Name of the file to be compressed: ");
    scanf("%s", filename);

    //o vetor de vetores rgb recebe os valores pra cada vetor de cor lidos
    unsigned char ** rgb;
    rgb = readBMP(filename);

    //vetores de matrizes para a divis�o em blocos de cada um
    unsigned char *** bluesplit;
    unsigned char *** greensplit;
    unsigned char *** redsplit;

    //vetores recebem os valores adequados para suas matrizes
    printf("Spliting...\n");
    redsplit = splitArray(rgb[2],numRows,numCols);
    greensplit = splitArray(rgb[1], numRows,numCols);
    bluesplit = splitArray(rgb[0], numRows,numCols);

    //vetores de sinais depois do level shift
    char * redsigs; 
    char * greensigs;
    char * bluesigs;

    //vetores recebem os sinais, e a matriz rgb � modificada
    redsigs = lvlshift(rgb[2], numRows*numCols);
    greensigs = lvlshift(rgb[1], numRows*numCols);
    bluesigs = lvlshift(rgb[0], numRows*numCols);

    //vetores de tamanhos dos bytes compactados
    char * redsizes;
    char * greensizes;
    char * bluesizes;
    
    //vetores com os resultados das compactacoes e o tamanho de cada um deles
    unsigned char * redresult;
    unsigned char * greenresult;
    unsigned char * blueresult;
    unsigned long redresultsize[1];
    unsigned long greenresultsize[1];
    unsigned long blueresultsize[1];

    printf("Compressing...\n");
    redresult = (unsigned char*) malloc (sizeof(unsigned char) * numRows * numCols);
    greenresult = (unsigned char*) malloc (sizeof(unsigned char) * numRows * numCols);
    blueresult = (unsigned char*) malloc (sizeof(unsigned char) * numRows * numCols);

    //aloca os vetores de resultados e realiza compressao
    redsizes = compress(rgb[2], redresult, numRows, numCols, redresultsize);
    greensizes = compress(rgb[1], greenresult, numRows, numCols, greenresultsize);
    bluesizes = compress(rgb[0], blueresult, numRows, numCols, blueresultsize);

    FILE * fp = fopen("Saida.txt","wb");
    long i;
    //escreve o resultado no arquivo compactado de saida
    for (i = 0; i<redresultsize[0]; i++)
      fwrite(&redresult[i], sizeof(char),1,fp);
    for (i = 0; i<greenresultsize[0]; i++)
      fwrite(&greenresult[i], sizeof(char),1,fp);
    for (i = 0; i<blueresultsize[0]; i++)
      fwrite(&blueresult[i], sizeof(char),1,fp);
    fclose(fp);

    //escreve a tabela com informacoes sobre o arquivo
    FILE * fp2 = fopen("Tabela.txt","wb");
    
    //header
    fwrite(&h.ch1, sizeof(char), 1, fp2);
    fwrite(&h.ch2, sizeof(char), 1, fp2);
    fwrite(&h.fileSize, sizeof(char), 4, fp2);
    fwrite(&h.res1, sizeof(char), 2, fp2);
    fwrite(&h.res2, sizeof(char), 2, fp2);
    fwrite(&h.offBits, sizeof(char), 4, fp2);
    fwrite(&h.hdrSize, sizeof(char), 4, fp2);
    fwrite(&h.numCols, sizeof(char), 4, fp2);
    fwrite(&h.numRows, sizeof(char), 4, fp2);
    fwrite(&h.planes, sizeof(char), 2, fp2);
    fwrite(&h.bitsPix, sizeof(char), 2, fp2);            //8 or 24 bits per pixel
    fwrite(&h.compr, sizeof(char), 4, fp2);
    fwrite(&h.imgSize, sizeof(char), 4, fp2);
    fwrite(&h.xPels, sizeof(char), 4, fp2);
    fwrite(&h.yPels, sizeof(char), 4, fp2);
    fwrite(&h.lut, sizeof(char), 4, fp2);
    fwrite(&h.impCols, sizeof(char), 4, fp2);
    
    //informa��es sobre a compacta��o
    for (i = 0; i<(numCols*numRows); i++)
        fwrite(&redsizes[i], sizeof(char),1,fp2);
    for (i = 0; i<(numCols*numRows); i++)
        fwrite(&greensizes[i], sizeof(char),1,fp2);
    for (i = 0; i<(numCols*numRows); i++)
        fwrite(&bluesizes[i], sizeof(char),1,fp2);
    for (i = 0; i<(numCols*numRows); i++)
        fwrite(&redsigs[i], sizeof(char),1,fp2);
    for (i = 0; i<(numCols*numRows); i++)
        fwrite(&greensigs[i], sizeof(char),1,fp2);
    for (i = 0; i<(numCols*numRows); i++)
        fwrite(&bluesigs[i], sizeof(char),1,fp2);
    fclose(fp2);
    
    //desaloca os vetores
    free(rgb[0]);
    free(rgb[1]);
    free(rgb[2]);
    free(redsplit);
    free(greensplit);
    free(bluesplit);
    free(redsigs);
    free(bluesigs);
    free(greensigs);
    free(redsizes);
    free(greensizes);
    free(bluesizes);
    free(redresult);
    free(greenresult);
    free(blueresult); 
    printf("Compressed: Saida.txt, Tabela.txt\n");
    
    //descomprime o arquivo Saida.txt 
    printf("Decompressing...\n");
    decompress();
    printf("Decompressed: Saida.bmp\n"); 
    
    system("Pause");
    return 0;
}
