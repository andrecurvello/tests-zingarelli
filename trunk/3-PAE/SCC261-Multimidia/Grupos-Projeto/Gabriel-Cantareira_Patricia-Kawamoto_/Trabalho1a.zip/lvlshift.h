#include <stdio.h>

/*faz o level shift do vetor de chars, 
retorna um vetor com -1 se for negativo e 1 se for >= 0
tira o sinal de negativo*/
char * lvlshift(unsigned char * vnum, int n){
    char*vsinal = (char*)malloc(sizeof(char)*n);
    int i;
    unsigned char aux;
    for(i=0;i<n;i++){
        vnum[i] = vnum[i]-128; 
        if (vnum[i]>=128) 
          vsinal[i] = -1;
        else vsinal[i] = 1; 
        aux = vnum[i]<<1;
        vnum[i] = aux>>1; 
    }
    return vsinal;
}
