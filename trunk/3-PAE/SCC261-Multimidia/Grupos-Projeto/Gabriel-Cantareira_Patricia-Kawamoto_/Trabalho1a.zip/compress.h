#include <stdio.h>

//funcao de compressao. Utiliza-se um vetor de cor por vez
char * compress(unsigned char * array, unsigned char * result, 
int numCols, int numRows, unsigned long * resultsize){

  int sl;
  unsigned char t1;
  long i;
  //vetor com os tamanhos de cada byte compactado do vetor original
  char * sizes = (char*) malloc (sizeof(char) * numRows * numCols);

  for (i = 0; i<(numRows*numCols) ; i++)
    sizes[i] = 9;
  int currentsize;
  int resultindex = 0;
  int casas_livres = 8;
  int tamanho_numero = 0;

  //inicializa vetor de resultados
  for(i = 0; i<(numRows*numCols) ; i++)
    result[i] = 0;

  //encaixa os bytes em outro vetor de caracteres usando o minimo de espa�o possivel
  for(i = 0; i<(numRows*numCols) ; i++)
  {
        currentsize = 8;
        t1 = array[i];
        for(sl = 0; (t1<127 && currentsize>0); sl++)
        {
           t1 = t1<<1;
           currentsize--;
        }

        sizes[i] = currentsize;
        tamanho_numero = currentsize;
        t1 = t1>>(8-casas_livres);
        result[resultindex] = result[resultindex] + t1;
        casas_livres -= tamanho_numero;

        if (casas_livres < 0) {

            resultindex++;
            int faltando = - (casas_livres);
            t1 = array[i];
            t1 = t1<<sl;
            t1 = t1<<(tamanho_numero - faltando);
            result[resultindex] = result[resultindex] + t1;

            casas_livres = 8 - faltando;
        }
    }

  resultsize[0] = resultindex + 1;
  return sizes;
}




