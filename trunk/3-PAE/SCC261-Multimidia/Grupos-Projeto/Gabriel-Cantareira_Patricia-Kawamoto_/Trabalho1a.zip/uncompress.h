//funcao que desfaz o level shift
char * undoShift(char * array, unsigned long numCols, unsigned long numRows, char * sigs)
{
    char * array2;
    array2 = (unsigned char *) malloc (sizeof(unsigned char*) * numRows * numCols);
    int i;
    unsigned char aux;
    for(i=0;i<numRows * numCols;i++){
        array2[i] = array[i]+128; 
        if (sigs[i] == -1){
           aux = array2[i]<<1;
           array2[i] = aux>>1;} 
    }
    return array2;
}

//funcao que recupera da tabela os sinais de cada valor de um vetor
unsigned char * getSignal(FILE * fp2, unsigned long numCols, unsigned long NumRows)
{

 unsigned char sig;
 unsigned long i;
 unsigned char * sigs;
 
 sigs = (unsigned char*) malloc (sizeof(unsigned char) * numRows * numCols);
 for(i = 0; i<(numRows*numCols) ; i++){
     fread(&sig, sizeof(char), 1, fp2);
     sigs[i] = sig;
 }
 return sigs;
}

//funcao de descompactacao para cada vetor usando a tabela
unsigned char * uncompressArray(FILE * fp, FILE * fp2, unsigned long numCols, unsigned long NumRows)
{
  unsigned char currentchar;
  unsigned char size = 0;
  unsigned char sizesum = 0;
  unsigned char gone = 0;
  unsigned char t1;
  unsigned char change = 0;
  unsigned long i;

  unsigned char * out;
  out = (unsigned char*) malloc (sizeof(unsigned char) * numRows * numCols);

  for(i = 0; i<(numRows*numCols) ; i++)
    out[i] = 0;

  int preenchido = 0;

  fread(&currentchar, sizeof(char), 1, fp);

  for (i = 0; i<(numCols*numRows); i++)
  {
    t1 = currentchar;
    t1 = t1 << preenchido;

    fread(&size, sizeof(char), 1, fp2);
    t1 = t1 >> (8-size);
    out[i] += t1;

    if ((size + preenchido) >= 8) {
      fread(&currentchar, sizeof(char), 1, fp);
      t1 = currentchar;
      t1 = t1 >>(16 - (size + preenchido));
      out[i] += t1;
    }
    preenchido = (preenchido + size)%8;
  }
  return out;
}


//funcao para descompactacao total
void decompress(void) {
  FILE * fp = fopen("Saida.txt","rb");
  FILE * fp2 = fopen("Tabela.txt","rb");

//cria uma struct de header para ler o que foi salvo no arquivo
  bmphdr hhh;
  fread(&hhh.ch1, sizeof(char), 1, fp2);
  fread(&hhh.ch2, sizeof(char), 1, fp2);


  fread(&hhh.fileSize, sizeof(char), 4, fp2);
  fread(&hhh.res1, sizeof(char), 2, fp2);
  fread(&hhh.res2, sizeof(char), 2, fp2);
  fread(&hhh.offBits, sizeof(char), 4, fp2);
  fread(&hhh.hdrSize, sizeof(char), 4, fp2);
  fread(&hhh.numCols, sizeof(char), 4, fp2);
  fread(&hhh.numRows, sizeof(char), 4, fp2);
  fread(&hhh.planes, sizeof(char), 2, fp2);
  fread(&hhh.bitsPix, sizeof(char), 2, fp2);
  fread(&hhh.compr, sizeof(char), 4, fp2);
  fread(&hhh.imgSize, sizeof(char), 4, fp2);
  fread(&hhh.xPels, sizeof(char), 4, fp2);
  fread(&hhh.yPels, sizeof(char), 4, fp2);
  fread(&hhh.lut, sizeof(char), 4, fp2);
  fread(&hhh.impCols, sizeof(char), 4, fp2);

  //cria novamente os vetores de bytes para cada cor
  unsigned char * red;
  unsigned char * green;
  unsigned char * blue;

  //cria novamente os vetores de sinal
  unsigned char * redsigs;
  unsigned char * greensigs;
  unsigned char * bluesigs;

  //vetores para armazenar as informa��es finais para serem escritas 
  unsigned char * red2;
  unsigned char * green2;
  unsigned char * blue2;
    

  //estes vetores recebem os valores descompactados
  red = uncompressArray(fp, fp2, hhh.numCols, hhh.numRows);
  green = uncompressArray(fp, fp2, hhh.numCols, hhh.numRows);
  blue = uncompressArray(fp, fp2, hhh.numCols, hhh.numRows);
  
  //estes vetores recebem os sinais da tabela
  redsigs = getSignal(fp2, hhh.numCols, hhh.numRows);
  greensigs = getSignal(fp2, hhh.numCols, hhh.numRows);
  bluesigs = getSignal(fp2, hhh.numCols, hhh.numRows);
  
  //estes vetores recebem os valores depois de desfazer o level shift
  red2 = undoShift(red, hhh.numCols, hhh.numRows, redsigs);
  green2 = undoShift(green, hhh.numCols, hhh.numRows, greensigs);
  blue2 = undoShift(blue, hhh.numCols, hhh.numRows, bluesigs);

  //abre novo arquivo para emitir o arquivo descompactado
  FILE * fp3;

  //escreve o header e depois as informa��es de cada vetor, na ordem original
  fp3 = fopen("saida.bmp", "wb");
  fwrite(&hhh.ch1, sizeof(char), 1, fp3);
  fwrite(&hhh.ch2, sizeof(char), 1, fp3);
  fwrite(&hhh.fileSize, sizeof(char), 4, fp3);
  fwrite(&hhh.res1, sizeof(char), 2, fp3);
  fwrite(&hhh.res2, sizeof(char), 2, fp3);
  fwrite(&hhh.offBits, sizeof(char), 4, fp3);
  fwrite(&hhh.hdrSize, sizeof(char), 4, fp3);
  fwrite(&hhh.numCols, sizeof(char), 4, fp3);
  fwrite(&hhh.numRows, sizeof(char), 4, fp3);
  fwrite(&hhh.planes, sizeof(char), 2, fp3);
  fwrite(&hhh.bitsPix, sizeof(char), 2, fp3);
  fwrite(&hhh.compr, sizeof(char), 4, fp3);
  fwrite(&hhh.imgSize, sizeof(char), 4, fp3);
  fwrite(&hhh.xPels, sizeof(char), 4, fp3);
  fwrite(&hhh.yPels, sizeof(char), 4, fp3);
  fwrite(&hhh.lut, sizeof(char), 4, fp3);
  fwrite(&hhh.impCols, sizeof(char), 4, fp3);
  unsigned long row;
  unsigned long col;
  for (row=0;row<numRows;row++)
  {
    for (col=0;col<numCols;col++)
    {
        fwrite(&blue2[row * numCols + col], sizeof(unsigned char), 1, fp3);
        fwrite(&green2[row * numCols + col], sizeof(unsigned char), 1, fp3);
        fwrite(&red2[row * numCols + col], sizeof(unsigned char), 1, fp3);
    }
  }


  free(redsigs);
  free(bluesigs);
  free(greensigs);
  free(red);
  free(green);
  free(blue);
  free(red2);
  free(green2);
  free(blue2);
    
  fclose(fp);
  fclose(fp2);
  fclose(fp3);


}



