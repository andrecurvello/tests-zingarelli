//Renomeia as posicoes de 8 a 14 para -1 a -7
void rname(int*ord){
    int i, aux;
    for(i=0;i<15;i++)
        if (ord[i]>7){
           aux = ord[i]*-1;
           ord[i] = aux+7;              
        }                
}

//Retorna 0 se o numero j ja estiver em alguma posicao do vetor
int pertence(int j, int*ord){
    int i;
    for (i=0;i<15;i++){
        if(ord[i] == j)
            return 0;
    }
    return 1;
}

//Ordena os numeros de ord em ordem decrescente e coloca no vetor ord2
void*ordena(int*ord, int*ord2){
    int i, l, max;
    int j = 0;
    int k = 0;
    
    while(j<15){
        max = 0;
        k = 0;
        for (i=0;i<15;i++){
                if((pertence(i,ord2)==1)&&(max<=ord[i])){
                    max = ord[i];
                    k = i;
                } 
        }
        ord2[j] = k;        
        j++;
    }
}

//incrementa em ord a quantidade de vezes que o tamanho de tam com o sinal de sig aparece
void*increment(int*sig, int*tam, int n, int*ord){
    int i, number;
    for(i=0;i<n;i++){
        number = sig[i]*tam[i];
        switch(number){   
            case 0: ord[0]++; break;
            case 1: ord[1]++; break;
            case 2: ord[2]++; break;
            case 3: ord[3]++; break;
            case 4: ord[4]++; break;
            case 5: ord[5]++; break;
            case 6: ord[6]++; break;
            case 7: ord[7]++; break;
            case -1: ord[8]++; break;
            case -2: ord[9]++; break;
            case -3: ord[10]++; break;
            case -4: ord[11]++; break;
            case -5: ord[12]++; break;
            case -6: ord[13]++; break;
            case -7: ord[14]++;  break;
        }
    }
}

//Ordena um vetor em ordem crescente de aparicao de tamanhos dos bits dos vetores de RGB
int * huff(int*redsig, int*greensig, int*bluesig, int*redtam, int*greentam, int*bluetam, int n){
    int*ord = (int*)malloc(sizeof(int)*15);
    int*ord2 = (int*)malloc(sizeof(int)*15);
    int j;
    for (j=0;j<15;j++){
        ord[j] = 0;
        ord2[j] = -1;
    }
    //adiciona todas as aparicoes das 15 possibilidades em ord
    increment(redsig, redtam, n, ord);
    increment(greensig, greentam, n, ord);
    increment(bluesig, bluetam, n, ord);
    
    ordena(ord, ord2);
    rname(ord2);
    
    return ord2;
    
}
