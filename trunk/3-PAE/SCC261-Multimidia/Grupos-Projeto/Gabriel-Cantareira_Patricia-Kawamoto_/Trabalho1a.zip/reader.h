#include <stdio.h>
#include <string.h>
#include <stdlib.h>

//Struct para o header do arquivo .bmp
typedef struct hdr{
  char ch1,ch2;
  unsigned long  fileSize;
  unsigned short res1;
  unsigned short res2;
  unsigned long  offBits;
  unsigned long  hdrSize;
  unsigned long  numCols;
  unsigned long  numRows;
  unsigned short planes;
  unsigned short bitsPix;
  unsigned long  compr;
  unsigned long  imgSize;
  unsigned long  xPels;
  unsigned long  yPels;
  unsigned long  lut;
  unsigned long  impCols;
} bmphdr;

bmphdr h;
//numero de linhas, numero de colunas da imagem
unsigned long numCols; 
unsigned long numRows;


//funcao debug para imprimir o valor binario de um char
void printChar(unsigned char n) 
{
       int i = 0;
       unsigned char mask = 128;
       unsigned char tmp;
       for(;i < 8; i++)
       {
               tmp = n & mask;
               printf("%d", (tmp > 0)? 1 : 0);
               mask /= 2;
       }puts("");
}


//funcao para dividir o array de pixels em blocos 8x8. Essencialmente, ela cria um vetor de matrizes
//em que as linhas de cada matriz correspondem �s posi��es dos blocos no vetor de posicoes.
unsigned char *** splitArray (unsigned char * array, int numRows, int numCols) {
  int loops = 0;
  long int n = (numCols*numRows)/64;
  unsigned char *** result = (unsigned char***) malloc (sizeof(unsigned char**)*n);
  int i, j;
  for (i = 0; i<n; i++) {
      result[i] = (unsigned char**) malloc (sizeof(unsigned char*) * 8);
      for (j = loops*8; j<8+loops*8; j++) {
           result[i][j-loops*8] = &array[j*numRows + i*8];
      }
      if ((i*8 + 1) >= numCols)
           loops++;
  }
  return result;
}


//funcao para ler um arquivo .bmp dado
unsigned char ** readBMP(char* fname)
{
  FILE * fp;

  fp = fopen(fname,"rb");


  //le os 54 bytes de header e coloca na struct
  fread(&h.ch1, sizeof(char), 1, fp);
  fread(&h.ch2, sizeof(char), 1, fp);

  fread(&h.fileSize, sizeof(char), 4, fp);
  fread(&h.res1, sizeof(char), 2, fp);
  fread(&h.res2, sizeof(char), 2, fp);
  fread(&h.offBits, sizeof(char), 4, fp);
  fread(&h.hdrSize, sizeof(char), 4, fp);
  fread(&h.numCols, sizeof(char), 4, fp);
    numCols = h.numCols;
  fread(&h.numRows, sizeof(char), 4, fp);
    numRows = h.numRows;
  fread(&h.planes, sizeof(char), 2, fp);
  fread(&h.bitsPix, sizeof(char), 2, fp);
  fread(&h.compr, sizeof(char), 4, fp);
  fread(&h.imgSize, sizeof(char), 4, fp);
  fread(&h.xPels, sizeof(char), 4, fp);
  fread(&h.yPels, sizeof(char), 4, fp);
  fread(&h.lut, sizeof(char), 4, fp);
  fread(&h.impCols, sizeof(char), 4, fp);

  //um vetor para pixels vermelhos, um para pixels verdes e outro para azuis
  unsigned char * red;
  unsigned char * green;
  unsigned char * blue;

  red = (unsigned char *) malloc (sizeof(unsigned char) * numRows * numCols);
  green = (unsigned char *) malloc (sizeof(unsigned char) * numRows * numCols);
  blue = (unsigned char *) malloc (sizeof(unsigned char) * numRows * numCols);

  //variavel para verificar se a imagem tem 3 bytes por pixel
  int bpp = h.bitsPix/8;

  printf("Number of Columns: %d\n",numCols);
  printf("Number of Rows: %d\n",numRows);

  unsigned int row;
  unsigned int col;
  
  //aa = contador de bytes lidos. O tamanho da imagem deve ser aa + 54 ao final do programa
  int aa = 0;
  for (row=0;row<numRows;row++)
  {
    for (col=0;col<numCols;col++)
    {
      if (bpp==3)
      {
        //le os proximos 3 bytes em b, g, r.
        fread(&blue[row * numCols + col], sizeof(unsigned char), 1, fp);
        fread(&green[row * numCols + col], sizeof(unsigned char), 1, fp);
        fread(&red[row * numCols + col], sizeof(unsigned char), 1, fp);
        aa += 3;
      }
      else
      {
        return NULL;
      }
    }
  }
  printf("Number of image bytes read: %d\n",aa);
  fclose(fp);
  
  unsigned char ** f;
  f = (unsigned char**) malloc (sizeof(unsigned char *) * 3);
  f[0] = blue;
  f[1] = green;
  f[2] = red;
  //o retorno � um vetor com tr�s vetores, cada um com os pixels de uma cor
  return f;
}


