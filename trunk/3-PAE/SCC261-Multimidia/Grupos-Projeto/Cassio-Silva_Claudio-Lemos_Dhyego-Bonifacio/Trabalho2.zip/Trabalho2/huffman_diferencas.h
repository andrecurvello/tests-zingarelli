/************************************************************/
/*              UNIVERSIDADE DE S�O PAULO - ICMC            */
/*           DEPARTAMENTO DE CI�NCIAS DE COMPUTA��O         */
/*             SCC0261 Multim�dia - 1o Sem /2011            */
/*                 Prof. Rudinei Goularte                   */
/*          Estagi�rio PAE: Matheus R. U. Zingarelli        */
/*                                                          */
/* Projeto - Parte 2                                        */
/*                                                          */
/* Grupo:                                                   */
/*       C�ssio de Matos Silva, 5909002                     */
/*       Dhyego Palacios Bonifacio, 5378050                 */
/************************************************************/

#include <stdio.h>
#include "geral.h"

//-----------------------------------------------------------------------------------------
//--------------------------------- Estruturas de dados -----------------------------------
//-----------------------------------------------------------------------------------------

//Tabela de frequencia da codificacao por diferencas
typedef struct
{
	char *value;
	int *freq;
} HD_FREQ_TABLE;

//Estrutura para a tabela de Huffman da codificacao por diferencas
typedef struct 
{
	char *sss;
	char *codigo;
	char *numB;
} HD_TABLE;

//Estrutura de no da lista/arvore que vai ser usada no Huffman
typedef struct HD_FREQ_NODE
{
	char value;
	int freq;
	struct HD_FREQ_NODE *prox;
	struct HD_FREQ_NODE *ant;
	struct HD_FREQ_NODE *filho0;
	struct HD_FREQ_NODE *filho1;
} HD_FREQ_NODE;


//-----------------------------------------------------------------------------------------
//--------------------------------------- Funcoes -----------------------------------------
//-----------------------------------------------------------------------------------------

//Calcula as diferencas nos blocos R, G e B.
void aplicarDiferencas(BMPFILEHEADER *fheader, BMPINFOHEADER *finfo, PIXEL_BLOCK *blockR, PIXEL_BLOCK *blockG, PIXEL_BLOCK *blockB);

//Volta os valores originais das diferencas nos blocos R, G e B.
void retirarDiferencas(BMPFILEHEADER *fheader, BMPINFOHEADER *finfo, PIXEL_BLOCK *blockR, PIXEL_BLOCK *blockG, PIXEL_BLOCK *blockB);

//Retorna o numero de simbolos (sss) diferentes.
int numSimDifHuff(BMPFILEHEADER *fheader, BMPINFOHEADER *finfo, PIXEL_BLOCK *blockR, PIXEL_BLOCK *blockG, PIXEL_BLOCK *blockB);

//Coloca os valores e frequencias na tabela de frequencias para o Huffman.
void initDifFreqTable(BMPFILEHEADER *fheader, BMPINFOHEADER *finfo, HD_FREQ_TABLE *tabela, int num, PIXEL_BLOCK *blockR, PIXEL_BLOCK *blockG, PIXEL_BLOCK *blockB);

//Imprime a tabela de frequencias.
void printDifFreqTable(HD_FREQ_TABLE *tabela, int num);

//Coloca os codigos de huffman na tabela a partir da arvore de huffman.
void hd_gerarCodigos(HD_FREQ_NODE *no, char codigo, HD_TABLE *tabela, int *indice, int nivel);

//Gera a arvore de Huffman a partir da tabela de frequencias e cria a tabela de codigos.
void hd_Huffman(HD_FREQ_TABLE *tabela, int num, HD_TABLE *tabela_final);

//Imprime a tabela de codigos de Huffman.
void hd_printTable(HD_TABLE *tabela, int num);

//Salva a tabela Huffman no arquivo
void hd_saveHuffman(char *filename, HD_TABLE *t, int *numSimDif);

//Carrega a tabela Huffman do arquivo
void hd_loadHuffman(char *filename, HD_TABLE *t, int *numSimDif);

//Procura por um SSS e retorna o indice da tabela correspondente
int hd_search(char sss, HD_TABLE *t);

//-----------------------------------------------------------------------------------------
//----------------------------------------- Implementacao ---------------------------------
//-----------------------------------------------------------------------------------------

//Calcula as diferencas nos blocos R, G e B.
void aplicarDiferencas(BMPFILEHEADER *fheader, BMPINFOHEADER *finfo, PIXEL_BLOCK *blockR, PIXEL_BLOCK *blockG, PIXEL_BLOCK *blockB)
{
	short *blockR_, *blockG_, *blockB_;
	int i;
	
	blockR_ = malloc(((finfo->biWidth * finfo->biHeight) / 64)*sizeof(short));
	blockG_ = malloc(((finfo->biWidth * finfo->biHeight) / 64)*sizeof(short));
	blockB_ = malloc(((finfo->biWidth * finfo->biHeight) / 64)*sizeof(short));
	
	for (i = 0; i < (finfo->biWidth * finfo->biHeight) / 64; i++)
	{
		blockR_[i] = blockR[i].data[0];
		blockG_[i] = blockG[i].data[0];
		blockB_[i] = blockB[i].data[0];
		
	}
	
	for (i = 0; i < (finfo->biWidth * finfo->biHeight) / 64; i++)
	{
		if (i > 0)
		{
			blockR[i].data[0] = blockR_[i] - blockR_[i-1];
			blockG[i].data[0] = blockG_[i] - blockG_[i-1];
			blockB[i].data[0] = blockB_[i] - blockB_[i-1];
		}
	}
	
	free(blockR_);
	free(blockG_);
	free(blockB_);
}


//Volta os valores originais das diferencas nos blocos R, G e B.
void retirarDiferencas(BMPFILEHEADER *fheader, BMPINFOHEADER *finfo, PIXEL_BLOCK *blockR, PIXEL_BLOCK *blockG, PIXEL_BLOCK *blockB)
{
	int i;
	
	for (i = 0; i < (finfo->biWidth * finfo->biHeight) / 64; i++)
	{
		if (i > 0)
		{
			blockR[i].data[0] = blockR[i].data[0] + blockR[i-1].data[0];
			blockG[i].data[0] = blockG[i].data[0] + blockG[i-1].data[0];
			blockB[i].data[0] = blockB[i].data[0] + blockB[i-1].data[0];
		}
	}
}

//Retorna o numero de simbolos (sss) diferentes.
int numSimDifHuff(BMPFILEHEADER *fheader, BMPINFOHEADER *finfo, PIXEL_BLOCK *blockR, PIXEL_BLOCK *blockG, PIXEL_BLOCK *blockB)
{
	char *simbolos;
	char numSimAtual = 0;
	int flag = 0;
	int i, j;
	
	simbolos = malloc(((finfo->biWidth * finfo->biHeight) / 64)* sizeof(char));
	
	for (i = 0; i < (finfo->biWidth * finfo->biHeight) / 64; i++)
	{
		flag = 0;
		if (numSimAtual == 0)
		{
			simbolos[0] = numBits2(blockR[i].data[0]);
			numSimAtual = 1;
		}
		else
		{
			for (j = 0; j < numSimAtual; j++)
			{
				//Ja foi contado
				if (simbolos[j] == numBits2(blockR[i].data[0]))
					flag = 1;
			}
			
			if (flag == 0)
			{
				simbolos[numSimAtual] = numBits2(blockR[i].data[0]);
				numSimAtual++;
			}
		}
	}
	
	for (i = 0; i < (finfo->biWidth * finfo->biHeight) / 64; i++)
	{
		flag = 0;
		if (numSimAtual == 0)
		{
			simbolos[0] = numBits2(blockG[i].data[0]);
			numSimAtual = 1;
		}
		else
		{
			for (j = 0; j < numSimAtual; j++)
			{
				//Ja foi contado
				if (simbolos[j] == numBits2(blockG[i].data[0]))
					flag = 1;
			}
			
			if (flag == 0)
			{
				simbolos[numSimAtual] = numBits2(blockG[i].data[0]);
				numSimAtual++;
			}
		}
	}
	
	for (i = 0; i < (finfo->biWidth * finfo->biHeight) / 64; i++)
	{
		flag = 0;
		if (numSimAtual == 0)
		{
			simbolos[0] = numBits2(blockB[i].data[0]);
			numSimAtual = 1;
		}
		else
		{
			for (j = 0; j < numSimAtual; j++)
			{
				//Ja foi contado
				if (simbolos[j] == numBits2(blockB[i].data[0]))
					flag = 1;
			}
			
			if (flag == 0)
			{
				simbolos[numSimAtual] = numBits2(blockB[i].data[0]);
				numSimAtual++;
			}
		}
	}
	/*
	printf("Simbolos nas diferencas:\n");
	for (i = 0; i < numSimAtual; i++)
		printf("%d\n", simbolos[i]);
	*/
	free(simbolos);
	return numSimAtual;
}

//Coloca os valores e frequencias na tabela de frequencias para o Huffman.
void initDifFreqTable(BMPFILEHEADER *fheader, BMPINFOHEADER *finfo, HD_FREQ_TABLE *tabela, int num, PIXEL_BLOCK *blockR, PIXEL_BLOCK *blockG, PIXEL_BLOCK *blockB)
{
	int i, j;
	int flag = 0;
	int numSimAtual = 0;
	
	for (i = 0; i < (finfo->biWidth * finfo->biHeight) / 64; i++)
	{
		//printf("%d %d %d\n", i, numSimAtual, num);
		flag = 0;
		if (i == 0)
		{
			tabela->value[0] = numBits2(blockR[i].data[0]);
			tabela->freq[0] = 1;
			numSimAtual = 1;
		}
		else
		{
			for (j = 0; j < numSimAtual; j++)
			{
				//Se ja existe, conta mais 1 na frequencia
				if (tabela->value[j] == numBits2(blockR[i].data[0]))
				{
					tabela->freq[j]++;
					flag = 1;
				}
			}
			
			//Ainda nao existe, coloca no vetor e faz freq = 1
			if (flag == 0)
			{
				tabela->value[numSimAtual] = numBits2(blockR[i].data[0]);
				tabela->freq[numSimAtual] = 1;
				numSimAtual++;				
			}
		}
		
	}
	
	for (i = 0; i < (finfo->biWidth * finfo->biHeight) / 64; i++)
	{
		//printf("%d %d %d\n", i, numSimAtual, num);
		flag = 0;
		for (j = 0; j < numSimAtual; j++)
		{
			//Se ja existe, conta mais 1 na frequencia
			if (tabela->value[j] == numBits2(blockG[i].data[0]))
			{
				tabela->freq[j]++;
				flag = 1;
			}
		}
		
		//Ainda nao existe, coloca no vetor e faz freq = 1
		if (flag == 0)
		{
			tabela->value[numSimAtual] = numBits2(blockG[i].data[0]);
			tabela->freq[numSimAtual] = 1;
			numSimAtual++;				
		}
		
	}
	
	for (i = 0; i < (finfo->biWidth * finfo->biHeight) / 64; i++)
	{
		//printf("%d %d %d\n", i, numSimAtual, num);
		flag = 0;
		for (j = 0; j < numSimAtual; j++)
		{
			//Se ja existe, conta mais 1 na frequencia
			if (tabela->value[j] == numBits2(blockB[i].data[0]))
			{
				tabela->freq[j]++;
				flag = 1;
			}
		}
		
		//Ainda nao existe, coloca no vetor e faz freq = 1
		if (flag == 0)
		{
			tabela->value[numSimAtual] = numBits2(blockB[i].data[0]);
			tabela->freq[numSimAtual] = 1;
			numSimAtual++;				
		}
		
	}
}

//Imprime a tabela de frequencias.
void printDifFreqTable(HD_FREQ_TABLE *tabela, int num)
{
	int i;
	
	printf("Tabela de frequencias do Huffman de diferencas:\n");
	for (i = 0; i < num; i++)
		printf("Value: %d Freq: %d\n", tabela->value[i], tabela->freq[i]);
	
}

//Coloca os codigos de huffman na tabela a partir da arvore de huffman.
void hd_gerarCodigos(HD_FREQ_NODE *no, char codigo, HD_TABLE *tabela, int *indice, int nivel)
{
	char novo_codigo = 0;
	//Esta na folha, adiciona na tabela
	if (no->filho0 == NULL && no->filho1 == NULL)
	{
		//printf("sss: %d\n", no->value);
		tabela->sss[*indice] = no->value;
		tabela->codigo[*indice] = codigo;
		tabela->numB[*indice] = nivel;
		(*indice)++;
		
	}
	//Nao eh folha, chama a recursao para os filhos
	else
	{
		novo_codigo = codigo << 1;
		hd_gerarCodigos(no->filho0, novo_codigo, tabela, indice, nivel+1);
		
		novo_codigo |= 0x01;
		hd_gerarCodigos(no->filho1, novo_codigo, tabela, indice, nivel+1);			
		
	}
	
}

//Gera a arvore de Huffman a partir da tabela de frequencias e cria a tabela de codigos.
void hd_Huffman(HD_FREQ_TABLE *tabela, int num, HD_TABLE *tabela_final)
{
	int i;
	int *indice = malloc(sizeof(int));
	HD_FREQ_NODE *lista = malloc(sizeof(HD_FREQ_NODE));
	HD_FREQ_NODE *lAtual = lista;
	HD_FREQ_NODE *menor = NULL;
	HD_FREQ_NODE *filho0 = NULL;
	HD_FREQ_NODE *filho1 = NULL;
	HD_FREQ_NODE *novo;
	
	*indice = 0;
	
	lista->ant = NULL;
	lista->prox = NULL;
	lista->filho0 = NULL;
	lista->filho1 = NULL;
	
	//Coloca os valores de SSS e Frequencia na lista.
	//printf("Inserindo na lista...\n");
	for (i = 0; i < num; i ++)
	{
		novo = malloc(sizeof(HD_FREQ_NODE));
		novo->value = tabela->value[i];
		novo->freq = tabela->freq[i];
		lAtual->prox = novo;
		novo->ant = lAtual;
		novo->prox = NULL;
		novo->filho0 = NULL;
		novo->filho1 = NULL;	

		lAtual = lAtual->prox;
		//printf("value: %d freq: %d\n", novo->value, novo->freq);
	}
		
	//Gerando a arvore de huffman
	//printf("Gerando a arvore...\n");
	while (lista->prox->prox != NULL)
	{
		//Pega o que tem menor frequencia
		menor = lista->prox;
		lAtual = menor;
		while (lAtual != NULL)
		{
			if (lAtual->freq < menor->freq)
				menor = lAtual;
			lAtual = lAtual->prox;
		}
		
		filho0 = menor;
		//printf("Filho0: %d fr: %d\n", filho0->value, filho0->freq);
		
		menor->ant->prox = menor->prox;
		if (menor->prox != NULL)
			menor->prox->ant = menor->ant;
		
		//Pega o segundo que tem menor frequencia
		menor = lista->prox;
		lAtual = menor;
		while (lAtual != NULL)
		{
			if (lAtual->freq < menor->freq)
				menor = lAtual;
			lAtual = lAtual->prox;
		}
		
		filho1 = menor;
		//printf("Filho1: %d fr: %d\n", filho1->value, filho1->freq);
		
		menor->ant->prox = menor->prox;
		if (menor->prox != NULL)
			menor->prox->ant = menor->ant;
		
		//Cria um novo no na arvore com os filhos de menor frequencia
		novo = malloc(sizeof(HD_FREQ_NODE));
		novo->freq = filho0->freq + filho1->freq;
		
		lAtual = lista;
		while (lAtual->prox != NULL)
			lAtual = lAtual->prox;
		
		lAtual->prox = novo;
		novo->ant = lAtual;
		novo->prox = NULL;
		novo->filho0 = filho0;
		novo->filho1 = filho1;
		
		
	}
	//Arvore de Huffman pronta
	
	
	//Gerando os codigos de Huffman
	hd_gerarCodigos(lista->prox, 0, tabela_final, indice, 0);
	
}

//Imprime a tabela de codigos de Huffman.
void hd_printTable(HD_TABLE *tabela, int num)
{
	int i;
	
	printf("Tabela de codigos:\n");
	for (i = 0; i < num; i++)
		printf("SSS: %d Codigo: %d numB: %d\n", tabela->sss[i], tabela->codigo[i], tabela->numB[i]);
	
}

//Salva a tabela Huffman no arquivo
void hd_saveHuffman(char *filename, HD_TABLE *t, int *numSimDif) {
     int i;
     FILE *arq;
     arq = fopen(filename,"a+b");
     fwrite(numSimDif, sizeof(int), 1, arq);
     for (i=0;i<*numSimDif;i++) {
         fwrite(&(t->sss[i]), sizeof(char), 1, arq);
         fwrite(&(t->codigo[i]), sizeof(char), 1, arq);
         fwrite(&(t->numB[i]), sizeof(char), 1, arq);
     }
     fclose(arq);
}

//Carrega a tabela Huffman do arquivo
void hd_loadHuffman(char *filename, HD_TABLE *t, int *numSimDif) {
     int i;
     FILE *arq;
     arq = fopen(filename,"rb");
     fread(numSimDif, sizeof(int), 1, arq);
     t->sss = (char *) malloc(sizeof(char)*(*numSimDif));
     t->codigo = (char *) malloc(sizeof(char)*(*numSimDif));
     t->numB = (char *) malloc(sizeof(char)*(*numSimDif));
     for (i=0;i<*numSimDif;i++) {
         fread(&(t->sss[i]), sizeof(char), 1, arq);
         fread(&(t->codigo[i]), sizeof(char), 1, arq);
         fread(&(t->numB[i]), sizeof(char), 1, arq);
     }
     fclose(arq);
}

//Procura por um SSS e retorna o indice da tabela correspondente
int hd_search(char sss, HD_TABLE *t) {
    int i =0;
    while (t->sss[i] != sss) i++;
    return i;
}
