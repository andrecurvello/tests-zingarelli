/************************************************************/
/*              UNIVERSIDADE DE S�O PAULO - ICMC            */
/*           DEPARTAMENTO DE CI�NCIAS DE COMPUTA��O         */
/*             SCC0261 Multim�dia - 1o Sem /2011            */
/*                 Prof. Rudinei Goularte                   */
/*          Estagi�rio PAE: Matheus R. U. Zingarelli        */
/*                                                          */
/* Projeto - Parte 2                                        */
/*                                                          */
/* Grupo:                                                   */
/*       C�ssio de Matos Silva, 5909002                     */
/*       Dhyego Palacios Bonifacio, 5378050                 */
/************************************************************/

#ifndef geral_
#define geral_

#include <stdio.h>

//-----------------------------------------------------------------------------------------
//--------------------------------- Estruturas de dados -----------------------------------
//-----------------------------------------------------------------------------------------

// Estrutura para o bloco de 8x8 pixels.
// Obs. os blocos precisam ser short porque pode aparecer -255 nas diferencas, nao representavel com char.
typedef struct
{
	short data[64];
} PIXEL_BLOCK;

//FileHeader original do arquivo BMP.
typedef struct
{
	unsigned short bfType;           // Magic number for file
	int bfSize;              // Size of file
	unsigned short bfReserved1;    // Reserved
	unsigned short bfReserved2;    // ...
	unsigned int bfOffBits;           // Offset to bitmap data
} BMPFILEHEADER;

// bfType deve ser = "MB"

//InfoHeader original do arquivo BMP.
typedef struct
{
	unsigned int biSize;             // Size of info header
	int biWidth;               // Width of image
	int biHeight;              // Height of image
	unsigned short biPlanes;        // Number of color planes
	unsigned short biBitCount;     // Number of bits per pixel
	unsigned int biCompression; // Type of compression to use
	unsigned int biSizeImage;     // Size of image data
	int biXPelsPerMeter;    // X pixels per meter
	int biYPelsPerMeter;    // Y pixels per meter
	unsigned int biClrUsed;         // Number of colors used
	unsigned int biClrImportant;  // Number of important colors
} BMPINFOHEADER;

//-----------------------------------------------------------------------------------------
//--------------------------------------- Funcoes -----------------------------------------
//-----------------------------------------------------------------------------------------

//Retorna o numero de bits necessario para representar a entrada, usando a representacao
//comentada em aula.
char numBits2(short entrada);

//Inicializa os indices do bloco com zig-zag
void initIndices();

//Inicia arquivo compactado e salva os headers do BMP
void saveFile(char *filename, BMPFILEHEADER *fheader, BMPINFOHEADER *finfo);

//-----------------------------------------------------------------------------------------
//-------------------------------------- Implementacao ------------------------------------
//-----------------------------------------------------------------------------------------

//Avalia um valor e retorna o numero minimo de bits necessario para representar esse valor.
//Ja considera a representacao -1 => 0b0, -2 => 0b01, => -3 0b00, e 0 sem representacao.
char numBits2(short entrada)
{
	short num = entrada;
	
	if (num == 0) return 0;
	else if (num < 0) num = -num;
	
	if (num < 2) return 1;
	else if (num < 4) return 2;
	else if (num < 8) return 3;
	else if (num < 16) return 4;
	else if (num < 32) return 5;
	else if (num < 64) return 6;
	else if (num < 128) return 7;
	else return 8;
	
}

//Inicializa os indices dos blocos com zig-zag
void initIndices(char indice[64])
{
	indice[0] = 0;
	indice[1] = 1;
	indice[2] = 8;
	indice[3] = 16;
	indice[4] = 9;
	indice[5] = 2;
	indice[6] = 3;
	indice[7] = 10;
	indice[8] = 17;
	indice[9] = 24;
	indice[10] = 32;
	indice[11] = 25;
	indice[12] = 18;
	indice[13] = 11;
	indice[14] = 4;
	indice[15] = 5;
	indice[16] = 12;
	indice[17] = 19;
	indice[18] = 26;
	indice[19] = 33;
	indice[20] = 40;
	indice[21] = 48;
	indice[22] = 41;
	indice[23] = 34;
	indice[24] = 27;
	indice[25] = 20;
	indice[26] = 13;
	indice[27] = 6;
	indice[28] = 7;
	indice[29] = 14;
	indice[30] = 21;
	indice[31] = 28;
	indice[32] = 35;
	indice[33] = 42;
	indice[34] = 49;
	indice[35] = 56;
	indice[36] = 57;
	indice[37] = 50;
	indice[38] = 43;
	indice[39] = 36;
	indice[40] = 29;
	indice[41] = 22;
	indice[42] = 15;
	indice[43] = 23;
	indice[44] = 30;
	indice[45] = 37;
	indice[46] = 44;
	indice[47] = 51;
	indice[48] = 58;
	indice[49] = 59;
	indice[50] = 52;
	indice[51] = 45;
	indice[52] = 38;
	indice[53] = 31;
	indice[54] = 39;
	indice[55] = 46;
	indice[56] = 53;
	indice[57] = 60;
	indice[58] = 61;
	indice[59] = 54;
	indice[60] = 47;
	indice[61] = 55;
	indice[62] = 62;
	indice[63] = 63;
}

//Inicia arquivo compactado e salva os headers do BMP
void saveFile(char *filename, BMPFILEHEADER *fheader, BMPINFOHEADER *finfo) {
     FILE *fp;
     fp = fopen(filename,"w+b");
	 fseek(fp, 0, SEEK_SET);
	 fwrite(&(fheader->bfType), 2, 1, fp);
	 fseek(fp, 2, SEEK_SET);
	 fwrite(&(fheader->bfSize), 4, 1, fp);
	 fseek(fp, 6, SEEK_SET);
	 fwrite(&(fheader->bfReserved1), 2, 1, fp);
	 fseek(fp, 8, SEEK_SET);
	 fwrite(&(fheader->bfReserved2), 2, 1, fp);
	 fseek(fp, 10, SEEK_SET);
	 fwrite(&(fheader->bfOffBits), 4, 1, fp);
	 fseek(fp, 14, SEEK_SET);
	 fwrite(&(finfo->biSize), 4, 1, fp);
	 fseek(fp, 18, SEEK_SET);
	 fwrite(&(finfo->biWidth), 4, 1, fp);
	 fseek(fp, 22, SEEK_SET);
	 fwrite(&(finfo->biHeight), 4, 1, fp);
	 fseek(fp, 26, SEEK_SET);
	 fwrite(&(finfo->biPlanes), 2, 1, fp);
	 fseek(fp, 28, SEEK_SET);
	 fwrite(&(finfo->biBitCount), 2, 1, fp);
	 fseek(fp, 30, SEEK_SET);
	 fwrite(&(finfo->biCompression), 4, 1, fp);
	 fseek(fp, 34, SEEK_SET);
	 fwrite(&(finfo->biSizeImage), 4, 1, fp);
	 fseek(fp, 38, SEEK_SET);
	 fwrite(&(finfo->biXPelsPerMeter), 4, 1, fp);
	 fseek(fp, 42, SEEK_SET);
	 fwrite(&(finfo->biYPelsPerMeter), 4, 1, fp);
	 fseek(fp, 46, SEEK_SET);
	 fwrite(&(finfo->biClrUsed), 4, 1, fp);
	 fseek(fp, 50, SEEK_SET);
	 fwrite(&(finfo->biClrImportant), 4, 1, fp);
	 fclose(fp);
}

#endif
