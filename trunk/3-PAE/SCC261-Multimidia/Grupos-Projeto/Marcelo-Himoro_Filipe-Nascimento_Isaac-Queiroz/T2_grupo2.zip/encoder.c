/*
   Filipe de Carvalho Nascimento - 6427021
   Marcelo Yuji Himoro - 6426580
   */

#include"bmp.h"
#include"encoder.h"
#include"difHuffman.h"
#include"rlHuffman.h"
#include<stdio.h>
#include<string.h>
#include<stdlib.h>

// Descritor do arquivo codificado
FILE *fout;

enum Color {RED = 0, GREEN, BLUE };

// Variaveis auxiliares para gravacao dos dados codificados no arquivo
int freeSpace = 8;
unsigned char lastByte;

// Estrutura das diferencas: 
Pair_Dif_Freq *differences[3];
int lastDC[3], DCIndex = 0;

// Estrutura para os pares utilizados na codificacao por carreira:
Pair_Skip_Value skipValuePairs[3][63];

// Para cada bloco, esta funcao codifica por carreira todos ACs do bloco.
// O vetor de diferencas entre os DCs � montado a medida que esta funcao � chamada.
void processBlock(int offsetX, int offsetY, PixelMatrix *pixelMatrix)
{
	// CODIFICACAO POR DIFERENCAS (APENAS GUARDAMOS AS DIFERENCAS) -------------------------------------------
	// Valor do pixel atual
	int curValue[3] = {pixelMatrix->matrix[offsetX][offsetY].red, 
		pixelMatrix->matrix[offsetX][offsetY].green, 
		pixelMatrix->matrix[offsetX][offsetY].blue};

	// Diferenca recebe o resultado da subtracao do DC atual do DC anterior
	differences[RED][DCIndex].d = pixelMatrix->matrix[offsetX][offsetY].red - lastDC[RED]; 
	differences[GREEN][DCIndex].d = pixelMatrix->matrix[offsetX][offsetY].green - lastDC[GREEN];
	differences[BLUE][DCIndex++].d = pixelMatrix->matrix[offsetX][offsetY].blue - lastDC[BLUE];
	// DC anterior passa a ser o DC atual
	lastDC[RED] = curValue[RED];      lastDC[GREEN] = curValue[GREEN];      lastDC[BLUE] = curValue[BLUE];
	//  -------------------------------------------------------------------------------------------------------
	// CODIFICACAO POR CARREIRA ------------------------------------------------------------------------------
	int i, nzeros[3] = {0, 0, 0}, index[3] = {0, 0, 0};
	// Percorrendo em zig-zag identificamos as carreiras de zeros e montamos a lista de pares (skip, value) 
	for(i = 1; i < 64; i++){
		if(pixelMatrix->matrix[indexVector[i][0] + offsetX][indexVector[i][1] + offsetY].red != 0){
			skipValuePairs[RED][index[RED]].s = nzeros[RED];
			skipValuePairs[RED][index[RED]++].v = pixelMatrix->matrix[indexVector[i][0] + offsetX][indexVector[i][1] + offsetY].red;
			nzeros[RED] = 0;                                                            
		}
		else nzeros[RED]++;
		if(pixelMatrix->matrix[indexVector[i][0] + offsetX][indexVector[i][1] + offsetY].green != 0){
			skipValuePairs[GREEN][index[GREEN]].s = nzeros[GREEN];
			skipValuePairs[GREEN][index[GREEN]++].v = pixelMatrix->matrix[indexVector[i][0] + offsetX][indexVector[i][1] + offsetY].green;
			nzeros[GREEN] = 0;                                                            
		}
		else nzeros[GREEN]++;
		if(pixelMatrix->matrix[indexVector[i][0] + offsetX][indexVector[i][1] + offsetY].blue != 0){
			skipValuePairs[BLUE][index[BLUE]].s = nzeros[BLUE];
			skipValuePairs[BLUE][index[BLUE]++].v = pixelMatrix->matrix[indexVector[i][0] + offsetX][indexVector[i][1] + offsetY].blue;
			nzeros[BLUE] = 0;                                                            
		}
		else nzeros[BLUE]++;
	}
	if(nzeros[RED] > 0){
		skipValuePairs[RED][index[RED]].s = 0;
		skipValuePairs[RED][index[RED]++].v = 0;           
	}
	if(nzeros[GREEN] > 0){
		skipValuePairs[GREEN][index[GREEN]].s = 0;
		skipValuePairs[GREEN][index[GREEN]++].v = 0;           
	}
	if(nzeros[BLUE] > 0){
		skipValuePairs[BLUE][index[BLUE]].s = 0;
		skipValuePairs[BLUE][index[BLUE]++].v = 0;           
	}
	// Com todos (skip, value) do bloco, chamamos huffman e gravamos no arquivo o bloco codificado
	lastByte = huffmanRunlength(skipValuePairs, index, fout, lastByte, &freeSpace);
}

// nosso codificador recebe como argumento o arquivo bmp a ser codificado.
int main(int argc, char* argv[]) 
{ 	
	if(argc < 1) { printf("ERRO: Arquivo bmp nao especificado.\n"); return 0; }

	FileHeader fileHeader;
	InfoHeader infoHeader;
	PixelMatrix pixelMatrix;

	if((fout = fopen("coded.xxx", "wb+")) == NULL){ printf("ERRO: Nao foi possivel criar o arquivo codificado.\n"); return 0; }
	// o arquivo BMP e� carregado nas nossas estruturas de dados.
	loadBMP(argv[1], &fileHeader, &infoHeader, &pixelMatrix);
	describeBMP(fileHeader, infoHeader);
	// Verificamos o tipo do arquivo, deve ser "MB".
	if(fileHeader.type != 0x4d42){ printf("ERRO: Formato de arquivo invalido.\n"); return 0; }
	// salvamos o header em primeiro lugar.
	saveBMPHeader(fout, fileHeader, infoHeader);

	//INICIALIZACOES
	int i;
	for(i = 0; i < 3; i++)
		differences[i] = (Pair_Dif_Freq*)malloc(infoHeader.width*infoHeader.height*sizeof(Pair_Dif_Freq)/64);   
	lastDC[RED] = lastDC[GREEN] = lastDC[BLUE] = 0;

	// MODULO DE PREPARACAO DA IMAGEM/BLOCO
	int x, y;
	// LEVEL SHIFT
	for(x = 0; x < infoHeader.width; x++)
		for(y = 0; y < infoHeader.height; y++){
			pixelMatrix.matrix[x][y].red -= 128;
			pixelMatrix.matrix[x][y].green -= 128;  
			pixelMatrix.matrix[x][y].blue -= 128;        
		}	      
	// dividimos a imagem em blocos de 8x8 pixels e codificamos.
	for(x = 0; x < infoHeader.width / 8; x++)
		for(y = 0; y < infoHeader.height / 8; y++)
			processBlock(x*8, y*8, &pixelMatrix);

	// Apos os blocos (ACs) codificados serem gravados no arquivo, a codificacao por diferencas dos DCs e� feita
	huffmanDif(differences, DCIndex, fout, lastByte, &freeSpace);

	fclose(fout);
	return 0;
} 
