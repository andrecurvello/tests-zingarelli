/*
   Filipe de Carvalho Nascimento - 6427021
   Marcelo Yuji Himoro - 6426580
   */

#include"rlHuffman.h"

// maxSSS  = numero de bits para representar o maior sss
// maxS    = numero de bits para representar o maior s (skip)
// maxFreq = numero de bits para representar a maior frequencia
// sizeL   = quantidade de nos-folha da arvore de huffman 
int maxSSS, maxS, sizeL, maxFreq;

// dado um unsigned char, calculamos o sss
int rlCalcSSS(unsigned char n){
	unsigned char sss = 0, flag = 0, nbits = 0;
	unsigned char tmp = n;   
	while(sss < 8){
		if(tmp & 1) nbits = sss + 1;
		sss++;   
		tmp = tmp>>1;
	}
	return nbits;   
}

// funcao de comparacao do qsort para ordenacao pelas frequencias (VETOR DE PARES)
int rlCompare (const void *a, const void *b){
	Pair_Skip_Value *A = (Pair_Skip_Value *)a;
	Pair_Skip_Value *B = (Pair_Skip_Value *)b;
	return (B->f - A->f);    
}
// funcao de comparacao do qsort para ordenacao pelas frequencias (NOS DA ARVORE)
int rlCompareHuff (const void *a, const void *b){
	RLNode **A = (RLNode **)a;
	RLNode **B = (RLNode **)b;
	return ((*B)->f - (*A)->f);    
}
// funcao de comparacao do qsort para ordenacao pelos indices dos nos
int rlCompareHuffIndex (const void *a, const void *b){
	RLNode **A = (RLNode **)a;
	RLNode **B = (RLNode **)b;
	return ((*B)->index - (*A)->index);    
}

// Varre a arvore de huffman calculando o codigo para cada folha.
void rlCodeHuffTree(RLNode* root, int size, int stack[], int dir){
	if(root != NULL){
		if(dir >= 0)
			stack[size++] = dir;
		if(root->l == NULL && root->r == NULL){
			int i;
			for(i = 0; i < size; i++) { root->code[i] = stack[i]; }
			root->size = size;
		}
		rlCodeHuffTree(root->l, size, stack, 0);
		rlCodeHuffTree(root->r, size, stack, 1);             
	}    
}

// Dado um unsigned char, grava seus n primeiros bits na string a ser gravada no arquivo.
void rlWrite(unsigned char t, unsigned char n, unsigned char coded[], int *ix, int *fs){
	int index = *ix, freeSpace = *fs;
	if(freeSpace >= n){
		coded[index] |= t << (freeSpace - n);
		freeSpace -= n;   
	}
	else{
		if(freeSpace == 0){
			coded[++index] |= t << 8 - n;
			freeSpace = 8 - n;
		}
		else{
			coded[index] |= t >> (n - freeSpace);
			coded[++index] |= t << (8 - (n - freeSpace));
			freeSpace = 8 - (n - freeSpace);
		}     
	}
	*ix = index; *fs = freeSpace;   
}

// Recebe como parametros todos pares (S,V) de um bloco e codifica o bloco.
unsigned char huffmanRunlength(Pair_Skip_Value svs[3][63], int size[], FILE *fout, unsigned char lastByte, int *fs){
	maxSSS = maxS = sizeL = 0; maxFreq = 1;
	int i, j, k, sss;
	// Declaramos uma lista onde teremos as folhas da arvore, ou seja, onde todos os pares sao diferentes e cada
	// um tem sua frequencia:
	Pair_Skip_Value huffList[size[0] + size[1] + size[2]];

	// Montamos a lista de todos (sss,s) e suas frequencias
	// NOTA: temos um for de i = 0~2, pois esta montagem ocorre para cada cor (R,G,B)
	for(i = 0; i < 3; i++){
		for(j = 0; j < size[i]; j++){
			if(svs[i][j].v < 0) 
				sss = rlCalcSSS(-svs[i][j].v);       
			else sss = rlCalcSSS(svs[i][j].v);
			if(sss > maxSSS) maxSSS = sss;
			for(k = 0; k < sizeL; k++)
				if(sss == huffList[k].sss && svs[i][j].s == huffList[k].s){
					huffList[k].f++;
					if(huffList[k].f > maxFreq) maxFreq = huffList[k].f;
					// guardamos para (s,v) a referencia para o par correspondente (s,sss) na lista
					svs[i][j].indexList = k;
					break;
				}
			if(k == sizeL){
				huffList[k].s = svs[i][j].s;
				if(svs[i][j].s > maxS) maxS = svs[i][j].s;
				huffList[k].sss = sss;
				huffList[k].f = 1;
				// guardamos para (s,v) a referencia para o par correspondente (s,sss) na lista
				svs[i][j].indexList = k;
				sizeL++;          
			}     
		}      
	}

	// Vetor de folhas da arvore de huffman
	RLNode *huffTree[sizeL], *root;
	for(i = 0; i < sizeL; i++){
		huffTree[i] = (RLNode*)malloc(sizeof(RLNode));
		huffTree[i]->l = huffTree[i]->r = NULL;
		memset(huffTree[i]->code, 0, 64);
		huffTree[i]->sss = huffList[i].sss;   
		huffTree[i]->s = huffList[i].s;  
		huffTree[i]->f = huffList[i].f; 
		huffTree[i]->index = i;
		// guardamos na lista a referencia para folha
		huffList[i].leaf = huffTree[i];  
	}
	// Guardamos uma ordem das folhas para garantir a recuperacao da arvore na decodificacao
	qsort(huffTree, sizeL, sizeof(RLNode*), rlCompareHuffIndex);
	RLNode order[sizeL];
	for(i = 0; i < sizeL; i++){
		order[i].sss =  huffTree[i]->sss;   
		order[i].s =  huffTree[i]->s; 
		order[i].f =  huffTree[i]->f; 
	}
	// Montamos a arvore de huffman
	if(sizeL == 1){
		// CASO EXTREMO! Se tivermos apenas uma folha, assumimos que a arvore tenha esta forma:
		// um no raiz, com apenas um filho a esquerda representando a folha
		root = (RLNode*)malloc(sizeof(RLNode));
		root->l = huffTree[0];
		root->l->f = order[0].f;
		root->l->s = order[0].s;
		root->l->sss = order[0].sss;
		root->r = root->l->l = root->l->r = NULL;                      
	}
	else{
		i = sizeL;
		while(i > 1){           
			RLNode *n = (RLNode*)malloc(sizeof(RLNode));
			n->f = huffTree[i - 2]->f + huffTree[i - 1]->f;
			n->l = huffTree[i - 1]; n->r = huffTree[i - 2];
			root = huffTree[i - 2] = n;
			i--;
			qsort(huffTree, i, sizeof(RLNode*), rlCompareHuff);
		}
	}
	// Calculamos os codigos de huffman para cada folha:
	int stack[64*3]; // pilha auxiliar
	rlCodeHuffTree(root, 0, stack, -1);

	// Preparamos os dados para serem gravados no arquivo
	int freeSpace = 8, index = 0; 
	// Declaramos uma string grande suficiente para comportar tanto a descricao da arvore como os dados codificados.
	unsigned char coded[300];
	memset(coded, 0, 300);
	// Aproveitamos o espaco livre deixado no ultimo byte do bloco anterior
	if(0 < *fs && *fs < 8)
		rlWrite(lastByte >> *fs, 8 - *fs, coded, &index, &freeSpace);           

	// em svssize temos o maior comprimento dos vetores de pares (skip,value)
	unsigned char svssize = size[0];
	if(size[1] > svssize) svssize = size[1];
	if(size[2] > svssize) svssize = size[2];

	// GRAVACAO NO ARQUIVO ----------------------------------------------------------------------------------
	// Primeiramente gravamos os "atributos" da tabela de huffman:
	// sizeL              = numero de folhas
	// rlCalcSSS(maxSSS)  = numero de bits para representar o numero de bits de maxSSS
	// rlCalcSSS(maxS)    = numero de bits para representar o numero de bits de maxS
	// rlCalcSSS(maxFreq) = numero de bits para representar o numero de bits de maxFreq
	// rlCalcSSS(svssize) = numero de bits para representar o numero de bits de svssize

	unsigned char attributes[5] = { sizeL, rlCalcSSS(maxSSS), rlCalcSSS(maxS), rlCalcSSS(maxFreq), rlCalcSSS(svssize) };
	// Gravamos os atributos da tabela (assumimos que 8 bits sao suficientes para cada atributos)
	for(i = 0; i < 5; i++) rlWrite(attributes[i], 8, coded, &index, &freeSpace);

	// Gravamos as folhas da arvore
	for(i = 0; i < sizeL; i++){
		rlWrite(order[i].sss, attributes[1], coded, &index, &freeSpace);
		rlWrite(order[i].s, attributes[2], coded, &index, &freeSpace);
		rlWrite(order[i].f, attributes[3], coded, &index, &freeSpace);                 
	}

	// Gravamos os dados codificados (R,G,B)
	for(i =0; i < 3; i++){
		rlWrite(size[i], attributes[4], coded, &index, &freeSpace);
		for(j = 0; j < size[i]; j++){
			for(k = 0; k < (huffList[svs[i][j].indexList].leaf)->size; k++)
				rlWrite((huffList[svs[i][j].indexList].leaf)->code[k], 1, coded, &index, &freeSpace);
			if(svs[i][j].v < 0){
				unsigned char w = ~(-svs[i][j].v);
				w = w << (8 - (huffList[svs[i][j].indexList].leaf)->sss);
				w = w >> (8 - (huffList[svs[i][j].indexList].leaf)->sss);    
				rlWrite(w, (huffList[svs[i][j].indexList].leaf)->sss, coded, &index, &freeSpace);     
			}
			else rlWrite(svs[i][j].v, (huffList[svs[i][j].indexList].leaf)->sss, coded, &index, &freeSpace); 
		}
	}
	// Gravamos de fato, os dados no arquivo
	if(0 < freeSpace && freeSpace < 8){
		fwrite(coded, index, 1, fout);
		// caso o ultimo byte nao tenha sido completado, reservamos ele para o proximo bloco.
		lastByte = coded[index];
	}
	else{
		fwrite(coded, index + 1, 1, fout);
	}
	*fs = freeSpace;
	return lastByte; 
}
