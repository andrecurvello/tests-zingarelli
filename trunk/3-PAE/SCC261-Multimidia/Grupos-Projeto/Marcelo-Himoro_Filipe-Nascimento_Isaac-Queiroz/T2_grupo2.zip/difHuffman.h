/*
   Filipe de Carvalho Nascimento - 6427021
   Marcelo Yuji Himoro - 6426580
   */

#include<stdlib.h>
#include<stdio.h>
#include<string.h>

// No da arvore de huffman feita em cima dos DCs
typedef struct difNode{ 
	unsigned char sss;
	int f;
	unsigned char code[10000]; int size;
	struct difNode *l, *r; 
	int index;
}DifNode;

// Par (diferenca, frequencia)
typedef struct pair_dif_freq{
	int d, f;
	char sss;
	DifNode *leaf;
	int indexList;
}Pair_Dif_Freq;

// Funcoes de comparacao para as ordenacoes
int difCompare (const void *a, const void *b);
int difCompareHuff (const void *a, const void *b);
int difCompareHuffIndex (const void *a, const void *b);
void difCodeHuffTree(DifNode* root, int size, int stack[], int dir);

void huffmanDif(Pair_Dif_Freq *ds[3], int size, FILE *fout, unsigned char lastByte, int *fs);
