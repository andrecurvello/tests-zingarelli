/*
   Filipe de Carvalho Nascimento - 6427021
   Marcelo Yuji Himoro - 6426580
   */

#include"difHuffman.h"

// _maxSSS  = numero de bits para representar o maior sss
// _maxFreq = numero de bits para representar a maior frequencia
// _sizeL   = quantidade de nos-folha da arvore de huffman 
int _maxSSS, _sizeL, _maxFreq;

// dado um unsigned char, calculamos o sss
int difCalcSSS(unsigned char n){
	unsigned char sss = 0, nbits = 0;
	unsigned char tmp = n;   
	while(sss < 8){
		if(tmp & 1) nbits = sss + 1;
		sss++;   
		tmp = tmp>>1;
	}
	return nbits;   
}

// dado um unsigned int, calculamos o sss
int difCalcSSSInt(unsigned int n){
	unsigned char sss = 0, nbits = 0;
	unsigned int tmp = n;   
	while(sss < 32){
		if(tmp & 1) nbits = sss + 1;
		sss++;   
		tmp = tmp>>1;
	}
	return nbits;   
}

// funcao de comparacao do qsort para ordenacao pelas frequencias (VETOR DE PARES)
int difCompare (const void *a, const void *b){
	Pair_Dif_Freq *A = (Pair_Dif_Freq *)a;
	Pair_Dif_Freq *B = (Pair_Dif_Freq *)b;
	return (B->f - A->f);    
}
// funcao de comparacao do qsort para ordenacao pelas frequencias (NOS DA ARVORE)
int difCompareHuff (const void *a, const void *b){
	DifNode **A = (DifNode **)a;
	DifNode **B = (DifNode **)b;
	return ((*B)->f - (*A)->f);    
}
// funcao de comparacao do qsort para ordenacao pelos indices dos nos
int difCompareHuffIndex (const void *a, const void *b){
	DifNode **A = (DifNode **)a;
	DifNode **B = (DifNode **)b;
	return ((*B)->index - (*A)->index);    
}

// Varre a arvore de huffman calculando o codigo para cada folha.
void difCodeHuffTree(DifNode* root, int size, int stack[], int dir){
	if(root != NULL){
		if(dir >= 0)
			stack[size++] = dir;
		if(root->l == NULL && root->r == NULL){
			int i;
			for(i = 0; i < size; i++) root->code[i] = stack[i]; 
			root->size = size;
		}
		difCodeHuffTree(root->l, size, stack, 0);
		difCodeHuffTree(root->r, size, stack, 1);             
	}    
}

// Dado um unsigned char, grava seus n primeiros bits na string a ser gravada no arquivo.
void difWrite(unsigned char t, unsigned char n, unsigned char coded[], int *ix, int *fs){
	int index = *ix, freeSpace = *fs;
	if(freeSpace >= n){
		coded[index] |= t << (freeSpace - n);
		freeSpace -= n;   
	}
	else{
		if(freeSpace == 0){
			coded[++index] |= t << 8 - n;
			freeSpace = 8 - n; 
		}
		else{
			coded[index] |= t >> (n - freeSpace);
			coded[++index] |= t << (8 - (n - freeSpace));
			freeSpace = 8 - (n - freeSpace);
		}     
	}
	*ix = index; *fs = freeSpace;   
}

// Dado um unsigned int, grava seus n primeiros bits na string a ser gravada no arquivo.
void difWriteInt(unsigned int t, unsigned char n, unsigned char coded[], int *ix, int *fs){
	while(n > 8){
		difWrite((unsigned char)(t >> (n - 8)), 8, coded, ix, fs);
		t = t << (32 - (n - 8));
		t = t >> (32 - (n - 8));
		n -= 8;          
	}
	difWrite((unsigned char)t, n, coded, ix, fs);
}

// Recebe como parametros todos pares (S,V) de um bloco e codifica o bloco.
void huffmanDif(Pair_Dif_Freq *ds[3], int size, FILE *fout, unsigned char lastByte, int *fs){
	_maxSSS = _sizeL = 0; _maxFreq = 1;
	int i, j, k, sss;
	// Declaramos uma lista onde teremos as folhas da arvore, ou seja, onde todos os pares sao diferentes e cada
	// um tem sua frequencia:
	Pair_Dif_Freq *huffList = (Pair_Dif_Freq*)malloc(3*size*4*sizeof(Pair_Dif_Freq));
	// Montamos a lista de todos (sss) e suas frequencias
	// NOTA: temos um for de i = 0~2, pois esta montagem ocorre para cada cor (R,G,B)
	for(i = 0; i < 3; i++){
		for(j = 0; j < size; j++){
			if(ds[i][j].d < 0) 
				sss = difCalcSSSInt(-ds[i][j].d);       
			else sss = difCalcSSSInt(ds[i][j].d);
			ds[i][j].sss = sss;
			if(sss > _maxSSS) _maxSSS = sss;
			for(k = 0; k < _sizeL; k++)
				if(sss == huffList[k].sss){
					huffList[k].f++;
					if(huffList[k].f > _maxFreq) _maxFreq = huffList[k].f;
					// guardamos para (s,v) a referencia para o par correspondente (s,sss) na lista
					ds[i][j].indexList = k;
					break;
				}
			if(k == _sizeL){
				if(ds[i][j].sss > _maxSSS) _maxSSS = ds[i][j].sss;
				huffList[k].sss = sss;
				huffList[k].f = 1;
				// guardamos para (s,v) a referencia para o par correspondente (s,sss) na lista
				ds[i][j].indexList = k;
				_sizeL++;          
			}     
		}
	}

	// Vetor de folhas da arvore de huffman
	DifNode *huffTree[_sizeL], *root;
	for(i = 0; i < _sizeL; i++){
		huffTree[i] = (DifNode*)malloc(sizeof(DifNode));
		huffTree[i]->l = huffTree[i]->r = NULL;
		memset(huffTree[i]->code, 0, 64);
		huffTree[i]->sss = huffList[i].sss;     
		huffTree[i]->f = huffList[i].f; 
		// guardamos na lista a referencia para folha
		huffTree[i]->index = i;
		huffList[i].leaf = huffTree[i];  
	}

	// Guardamos uma ordem para as folhas para garantir a recuperacao da arvore na decodificacao
	qsort(huffTree, _sizeL, sizeof(DifNode*), difCompareHuffIndex);
	DifNode order[_sizeL];
	for(i = 0; i < _sizeL; i++){
		order[i].sss =  huffTree[i]->sss;    
		order[i].f =  huffTree[i]->f;  
	}

	// Montamos a arvore de huffman
	if(_sizeL == 1){
		// CASO EXTREMO! Se tivermos apenas uma folha, assumimos que a arvore tenha esta forma:
		// um no raiz, com apenas um filho a esquerda representando a folha
		root = (DifNode*)malloc(sizeof(DifNode));
		root->l = huffTree[0];
		root->l->f = order[0].f;
		root->l->sss = order[0].sss;
		root->r = root->l->l = root->l->r = NULL;            
	}
	else{
		i = _sizeL;
		while(i > 1){           
			DifNode *n = (DifNode*)malloc(sizeof(DifNode));
			n->f = huffTree[i - 2]->f + huffTree[i - 1]->f;
			n->l = huffTree[i - 1]; n->r = huffTree[i - 2];
			root = huffTree[i - 2] = n;
			i--;
			qsort(huffTree, i, sizeof(DifNode*), difCompareHuff);
		}
	}

	// Calculamos os codigos de huffman para cada folha:
	int stack[64*3]; // pilha auxiliar
	difCodeHuffTree(root, 0, stack, -1);

	// Preparamos os dados para serem gravados no arquivo
	int freeSpace = 8, index = 0; 
	// Declaramos uma string grande suficiente para comportar tanto a descricao da arvore como os dados codificados.
	unsigned char *coded = (unsigned char*)malloc(3*size*4*sizeof(unsigned char));
	memset(coded, 0, 3*size*4);
	// Aproveitamos o espaco livre do bloco anterior
	if(0 < *fs && *fs < 8)
		difWrite(lastByte >> *fs, 8 - *fs, coded, &index, &freeSpace);           

	// GRAVACAO NO ARQUIVO ----------------------------------------------------------------------------------
	// Primeiramente gravamos os "atributos" da tabela de huffman:
	// _sizeL              = numero de folhas
	// rlCalcSSS(_maxSSS)  = numero de bits para representar o numero de bits de _maxSSS
	// rlCalcSSS(_maxFreq) = numero de bits para representar o numero de bits de _maxFreq

	unsigned char attributes[3] = { _sizeL, difCalcSSS(_maxSSS), difCalcSSSInt(_maxFreq) };
	// Gravamos os atributos da tabela (assumimos que 8 bits sao suficientes para cada atributos)
	for(i = 0; i < 3; i++) difWrite(attributes[i], 8, coded, &index, &freeSpace);

	// Gravamos as folhas da arvore
	for(i = 0; i < _sizeL; i++){
		difWrite(order[i].sss, attributes[1], coded, &index, &freeSpace);
		unsigned int F = 0;
		F |= order[i].f; 
		difWriteInt((unsigned int)F, attributes[2], coded, &index, &freeSpace);  
	}

	// Gravamos os dados codificados (R,G,B)
	for(i =0; i < 3; i++){
		for(j = 0; j < size; j++){
			for(k = 0; k < (huffList[ds[i][j].indexList].leaf)->size; k++)
				difWrite((huffList[ds[i][j].indexList].leaf)->code[k], 1, coded, &index, &freeSpace);
			unsigned int w = ds[i][j].d;
			if(ds[i][j].d < 0){
				w = ~(-ds[i][j].d);
				w = w << (32 - (huffList[ds[i][j].indexList].leaf)->sss);
				w = w >> (32 - (huffList[ds[i][j].indexList].leaf)->sss);    
				difWriteInt((unsigned int)w, (huffList[ds[i][j].indexList].leaf)->sss, coded, &index, &freeSpace);     
			}
			else difWriteInt((unsigned int)w, (huffList[ds[i][j].indexList].leaf)->sss, coded, &index, &freeSpace); 
		}
	}

	fwrite(coded, index + 1, 1, fout);   
	*fs = freeSpace;
}
