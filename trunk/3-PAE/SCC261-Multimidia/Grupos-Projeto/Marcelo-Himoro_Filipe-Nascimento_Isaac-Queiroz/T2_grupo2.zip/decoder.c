/*
   Filipe de Carvalho Nascimento - 6427021
   Marcelo Yuji Himoro - 6426580
   */

#include"bmp.h"
#include"decoder.h"
#include"difHuffman.h"
#include"rlHuffman.h"
#include<stdio.h>
#include<string.h>
#include<stdlib.h>

FILE *fin;

int decodedIndex, usedSpace, i, k;

enum Color {RED = 0, GREEN, BLUE };
enum ATTRIBUTES { SIZEL = 0, MAXSSS, MAXS, MAXFREQSSS, SVSSIZE };
enum LEAFATTRIBUTES { SSS = 0, S, FREQ };

// Dado um unsigned char, grava EM seus n primeiros bits os proximos n bits nao usados da string
void load(unsigned char *r, unsigned char n, unsigned char coded[]){
	int i;
	unsigned char t, tt;
	if(8 - usedSpace >= n){
		t = coded[decodedIndex] << usedSpace;
		t = t >> (8 - n);
		usedSpace += n;
	}
	else{
		tt = coded[decodedIndex++] << usedSpace;
		t = coded[decodedIndex] >> (8 - (n - (8 - usedSpace)));
		t |= tt >> (8 - n); 
		usedSpace = n - (8 - usedSpace);
	}
	*r = t;
}

// Dado um unsigned int, grava EM seus n primeiros bits os proximos n bits nao usados da string
void loadInt(unsigned int *r, unsigned char n, unsigned char coded[]){
	unsigned char t = 0;
	while(n > 8){
		load(&t, 8, coded);
		*r |= ((unsigned int)t << (n - 8));
		n -= 8;          
	}
	load(&t, n, coded);
	*r |= t;
}

// Decodifica e reconstroi um bloco a partir da tabela de huffman e seus ACs codificados.
void processBlock(int offsetX, int offsetY, PixelMatrix *pixelMatrix, unsigned char coded[]){
	unsigned char attributes[5], leafAttributes[3];
	memset(attributes, 0, 5);
	int i, j ,k;
	// carrega os atributos da tabela
	for(i = 0; i < 5; i++)
		load(&attributes[i], 8, coded);

	// Aloca memoria para arvore de huffman
	RLNode *huffTree[attributes[SIZEL]];
	unsigned char sss, s;
	unsigned char code[64];

	// Carrega as folhas e seus atributos (s, sss, f)
	for(i = 0; i < attributes[SIZEL]; i++){
		memset(leafAttributes, 0, 3);
		huffTree[i] = (RLNode *)malloc(sizeof(RLNode));
		for(k = 0; k < 3; k++)
			load(&leafAttributes[k], attributes[k + 1], coded); 
		huffTree[i]->sss = leafAttributes[SSS];
		huffTree[i]->s = leafAttributes[S];
		huffTree[i]->f = leafAttributes[FREQ];
		huffTree[i]->l = huffTree[i]->r = NULL;
	}

	RLNode *root = NULL;
	//Reconstroi a arvore de huffman
	if(attributes[SIZEL] == 1){
		root = (RLNode*)malloc(sizeof(RLNode));
		root->l = huffTree[0];
		root->r = NULL;    
	}
	else {
		while(attributes[SIZEL] > 1){           
			RLNode *n = (RLNode*)malloc(sizeof(RLNode));
			n->f = huffTree[attributes[SIZEL] - 2]->f + huffTree[attributes[SIZEL] - 1]->f;
			n->l = huffTree[attributes[SIZEL] - 1]; n->r = huffTree[attributes[SIZEL] - 2];
			root = huffTree[attributes[SIZEL] - 2] = n;
			attributes[SIZEL]--;
			qsort(huffTree, attributes[SIZEL], sizeof(RLNode*), rlCompareHuff);
		}
	}

	// Calculamos os codigos de huffman para cada folha:
	int stack[64];
	rlCodeHuffTree(root, 0, stack, -1);

	int index;
	// PARA CADA COR:
	for(k = 0; k < 3; k++){
		// svs = numero de pares (s, v)
		unsigned char svs;
		load(&svs, attributes[4], coded);
		index = 1;
		for(i = 0; i < svs; i++){
			RLNode *step = root;
			// Percorremos a arvore a medida que lemos o codigo
			while(!(step->l == NULL && step->r == NULL)){
				unsigned char bit;
				load(&bit, 1, coded); 
				if(bit) step = step->r;
				else step = step->l;
			}
			unsigned char v;
			char value = 0;
			// recuperamos o valor
			load(&v, step->sss, coded);
			value |= v;
			if((v & (1 << (step->sss - 1))) == 0){
				//tratamento para numeros negativos
				value = 0;
				value |= v;
				value |= 0xff << step->sss;
				value = ~value;
				value *= -1;
			}
			// Recontruimos a matriz:
			switch(k){
				case 0: for(j = 0; j < step->s; j++, index++) pixelMatrix->matrix[indexVector[index][0] + offsetX][indexVector[index][1] + offsetY].red = 0;
						pixelMatrix->matrix[indexVector[index][0] + offsetX][indexVector[index][1] + offsetY].red = value;
					if(value == 0) for(; index < 64; index++) pixelMatrix->matrix[indexVector[index][0] + offsetX][indexVector[index][1] + offsetY].red = value;
					break;
				case 1: for(j = 0; j < step->s; j++, index++) pixelMatrix->matrix[indexVector[index][0] + offsetX][indexVector[index][1] + offsetY].green = 0;
						pixelMatrix->matrix[indexVector[index][0] + offsetX][indexVector[index][1] + offsetY].green = value;
					if(value == 0) for(; index < 64; index++) pixelMatrix->matrix[indexVector[index][0] + offsetX][indexVector[index][1] + offsetY].green = value;
					break;
				case 2: for(j = 0; j < step->s; j++, index++) pixelMatrix->matrix[indexVector[index][0] + offsetX][indexVector[index][1] + offsetY].blue = 0;
						pixelMatrix->matrix[indexVector[index][0] + offsetX][indexVector[index][1] + offsetY].blue = value;
					if(value == 0) for(; index < 64; index++) pixelMatrix->matrix[indexVector[index][0] + offsetX][indexVector[index][1] + offsetY].blue = value;
					break;
			}
			index++;
		}
	}
}

// Decodifica e reconstroi os DCs a partir da tabela de huffman e seus DCs codificados.
void processDCs(PixelMatrix *pixelMatrix, unsigned char coded[], int W, int H){
	unsigned char attributes[3], leafAttributes[2];
	memset(attributes, 0, 3);
	int i, j ,k;
	// carrega os atributos da tabela
	for(i = 0; i < 3; i++)
		load(&attributes[i], 8, coded);

	// Aloca memoria para arvore de huffman
	DifNode *huffTree[attributes[SIZEL]];
	unsigned char sss;
	unsigned char code[64];
	unsigned int frequency;

	// Carrega as folhas e seus atributos (sss, f)
	for(i = 0; i < attributes[SIZEL]; i++){
		memset(leafAttributes, 0, 2);
		huffTree[i] = (DifNode *)malloc(sizeof(DifNode));
		load(&leafAttributes[SSS], attributes[1], coded);
		frequency = 0;
		loadInt(&frequency, attributes[2], coded);
		huffTree[i]->sss = leafAttributes[SSS];
		huffTree[i]->f = frequency;
		huffTree[i]->l = huffTree[i]->r = NULL;
	}

	DifNode *root = NULL;
	//Reconstroi a arvore de huffman
	if(attributes[SIZEL] == 1){
		root = (DifNode*)malloc(sizeof(DifNode));
		root->l = huffTree[0];
		root->r = NULL;
	}
	else { 
		while(attributes[SIZEL] > 1){           
			DifNode *n = (DifNode*)malloc(sizeof(DifNode));
			n->f = huffTree[attributes[SIZEL] - 2]->f + huffTree[attributes[SIZEL] - 1]->f;
			n->l = huffTree[attributes[SIZEL] - 1]; n->r = huffTree[attributes[SIZEL] - 2];
			root = huffTree[attributes[SIZEL] - 2] = n;
			attributes[SIZEL]--;
			qsort(huffTree, attributes[SIZEL], sizeof(DifNode*), difCompareHuff);
		}
	} 

	// Calculamos os codigos de huffman para cada folha:
	int stack[30];
	difCodeHuffTree(root, 0, stack, -1);

	// PARA CADA COR:
	for(k = 0; k < 3; k++){
		int lastDif = 0;
		int x, y;
		for(x = 0; x < W; x++)
			for(y = 0; y < H; y++){
				DifNode *step = root;
				// Percorremos a arvore a medida que lemos o codigo
				while(!(step->l == NULL && step->r == NULL)){
					unsigned char bit;
					load(&bit, 1, coded);
					if(bit) step = step->r;
					else step = step->l;  
				}
				unsigned int d = 0;
				// recuperamos a diferenca
				loadInt(&d, step->sss, coded); 
				if((d & (1 << (step->sss - 1))) == 0 ){
					//tratamento para numeros negativos
					d |= 0xffffffff << step->sss;
					d = ~d;
					d *= -1;
				}
				// Recontruimos os DCs:
				switch(k){
					case 0: pixelMatrix->matrix[x*8][y*8].red = d + lastDif;
						break;
					case 1: pixelMatrix->matrix[x*8][y*8].green = d + lastDif;
						break;
					case 2: pixelMatrix->matrix[x*8][y*8].blue = d + lastDif;
						break;
				}
				lastDif += d;
			}    
	}
}


// nosso decodificador nao recebe argumentos.
int main(int argc, char* argv[]) 
{ 	
	FileHeader fileHeader;
	InfoHeader infoHeader;
	PixelMatrix pixelMatrix;

	if((fin = fopen("coded.xxx", "rb")) == NULL){ printf("ERRO: Nao foi possivel abrir arquivo coded.xxx\n"); return 0; }

	fseek(fin, 0, SEEK_END);
	long long fsize = ftell(fin);
	rewind(fin);

	// recuperamos o header bmp
	loadBMPHeader(fin, &fileHeader, &infoHeader);
	describeBMP(fileHeader, infoHeader);

	// Preparamos as estruturas para os dados codificados
	pixelMatrix.matrix = (Pixel**)malloc(infoHeader.width*sizeof(Pixel*));
	int i = 0;
	for(; i < infoHeader.width;i++)
		pixelMatrix.matrix[i] = (Pixel*)malloc(infoHeader.height*sizeof(Pixel));

	unsigned char *coded = (unsigned char *)malloc(fsize - 54);
	fread(coded, fsize - 54, 1, fin);

	int x, y;
	// Processamos os ACs dos blocos
	decodedIndex = usedSpace = 0;
	for(x = 0; x < infoHeader.width / 8; x++)
		for(y = 0; y < infoHeader.height / 8; y++)
			processBlock(x*8, y*8, &pixelMatrix, coded);
	// Processamos os DCs
	processDCs(&pixelMatrix, coded, infoHeader.width / 8, infoHeader.height / 8);  

	// LEVEL SHIFT
	for(x = 0; x < infoHeader.width; x++)
		for(y = 0; y < infoHeader.height; y++){
			pixelMatrix.matrix[x][y].red += 128;
			pixelMatrix.matrix[x][y].green += 128;  
			pixelMatrix.matrix[x][y].blue += 128;        
		}

	saveBMP("decoded.bmp", fileHeader, infoHeader, pixelMatrix);            
	fclose(fin);
	return 0;
} 
