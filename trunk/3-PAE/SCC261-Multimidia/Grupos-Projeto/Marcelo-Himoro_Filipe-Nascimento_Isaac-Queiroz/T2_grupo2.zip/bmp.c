/*
   Filipe de Carvalho Nascimento - 6427021
   Marcelo Yuji Himoro - 6426580
   */

#include<stdlib.h>
#include"bmp.h"
// Carrega o arquivo bmp nas estruturas de headers e na matrix de pixels.
int loadBMP(char *filename, FileHeader* fH, InfoHeader* iH, PixelMatrix* pM)
{
	FILE *fin; 
	if((fin = fopen(filename,"rb+")) == NULL) return -1; 
	// Leitura dos headers
	fread(fH,sizeof(FileHeader),1,fin);
	fread(iH, sizeof(InfoHeader),1,fin);
	// Alocacao da matriz
	pM->matrix = (Pixel**)malloc(iH->width*sizeof(Pixel*));
	int i = 0; 
	for(; i < iH->width; i++)
		pM->matrix[i] = (Pixel*)malloc(iH->height*sizeof(Pixel));
	// Leitura dos pixels
	int j = 0;
	for(i = iH->height - 1; i >= 0; i--)
		for(j = 0; j < iH->width; j++){
			fread(&pM->matrix[j][i], 3, 1, fin);
		}
	fclose(fin);
	return 0;
}
// Carrega apenas o header do arquivo.
int loadBMPHeader(FILE* fin, FileHeader* fH, InfoHeader* iH)
{
	// Leitura dos headers
	fread(fH,sizeof(FileHeader),1,fin);
	fread(iH, sizeof(InfoHeader),1,fin);
	return 0;
}
// Descreve o conteudo do header.
void describeBMP(FileHeader headfirst,InfoHeader headsecond)
{
	printf("%x\n",headfirst.type); 
	printf("%u\n",headfirst.size); 
	printf("%u\n",headfirst.offset); 
	printf("size = %u\n",headsecond.size);
	printf("w = %d\n",headsecond.width);
	printf("h = %d\n",headsecond.height);
	printf("planes = %x\n",headsecond.planes);
	printf("bC = %x\n",headsecond.bitCount);
	printf("C = %u\n",headsecond.compression);
	printf("iSize = %u\n",headsecond.imageSize);
	printf("x = %d\n",headsecond.xResolution);
	printf("y = %d\n",headsecond.yResolution);
	printf("nC = %u\n",headsecond.nColors);
	printf("iC = %u\n",headsecond.importantColors);
}
// Salva um arquivo bmp com os headers e a matrix de pixels.
void saveBMP(char filename[], FileHeader headfirst, InfoHeader headsecond, PixelMatrix pM)
{
	FILE *fout; 
	fout = fopen(filename, "wb+");
	int i, j;
	fwrite(&headfirst, sizeof(headfirst),1,fout);
	fwrite(&headsecond, sizeof(headsecond),1,fout);
	for(i = headsecond.height - 1; i >= 0; i--)
		for(j = 0; j < headsecond.width; j++)
		{
			fwrite(&pM.matrix[j][i].blue, 1, 1, fout);
			fwrite(&pM.matrix[j][i].green, 1, 1, fout);
			fwrite(&pM.matrix[j][i].red, 1, 1, fout);
		}
	fclose(fout);
}
// Salva em um arquivo apenas o header.
void saveBMPHeader(FILE* fout, FileHeader headfirst, InfoHeader headsecond)
{
	fwrite(&headfirst, sizeof(headfirst),1,fout);
	fwrite(&headsecond, sizeof(headsecond),1,fout);
}
