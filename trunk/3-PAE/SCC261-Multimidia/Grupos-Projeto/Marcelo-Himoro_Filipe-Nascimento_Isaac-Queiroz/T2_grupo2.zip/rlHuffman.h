/*
   Filipe de Carvalho Nascimento - 6427021
   Marcelo Yuji Himoro - 6426580
   */

#include<stdlib.h>
#include<stdio.h>
#include<string.h>

// No da arvore de huffman feita em cima dos ACs
typedef struct rlNode{ 
	unsigned char s, sss, f;
	unsigned char code[64]; int size;
	struct rlNode *l, *r; 
	int index;
}RLNode;

// Par (skip, value)
typedef struct pair_skip_value{
	char v;
	unsigned char s, sss, f;
	RLNode *leaf;
	int indexList;
}Pair_Skip_Value;

// Funcoes de comparacao para as ordenacoes
int rlCompareHuff (const void *a, const void *b);
int rlCompareHuffIndex (const void *a, const void *b);
void rlCodeHuffTree(RLNode* root, int size, int stack[], int dir);

unsigned char huffmanRunlength(Pair_Skip_Value svs[3][63], int size[], FILE *fout, unsigned char lastByte, int *fs);
