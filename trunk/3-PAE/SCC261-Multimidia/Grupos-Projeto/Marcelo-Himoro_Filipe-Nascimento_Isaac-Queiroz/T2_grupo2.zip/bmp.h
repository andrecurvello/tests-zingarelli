/*
   Filipe de Carvalho Nascimento - 6427021
   Marcelo Yuji Himoro - 6426580
   */

#include<stdio.h>
// Estruturas para o header do formato BMP.
#pragma pack(2) /*packing de 2 bytes*/
typedef struct 
{ 
	unsigned short type; 
	unsigned int size; 
	unsigned short reserved1,reserved2; 
	unsigned int offset; 
} FileHeader; 
#pragma pack(2) /*packing de 2 bytes*/
typedef struct 
{ 
	unsigned int size;
	int width,height;
	unsigned short planes, bitCount;
	unsigned int compression; 
	unsigned int imageSize; 
	int xResolution,yResolution; 
	unsigned int nColors; 
	unsigned int importantColors; 

} InfoHeader; 
// Estrutura do nosso pixel.
#pragma pack(2) /*packing de 2 bytes*/
typedef struct
{
	char blue;
	char green;
	char red;
} Pixel;
// Nossa matriz de pixels.
#pragma pack() /*packing de 4 bytes(normal)*/
typedef struct
{
	Pixel** matrix;
} PixelMatrix;
// Carrega o arquivo bmp nas estruturas de headers e na matrix de pixels.
int loadBMP(char *filename, FileHeader* fH, InfoHeader* iH, PixelMatrix* pM);
// Carrega apenas o header do arquivo.
int loadBMPHeader(FILE* fin, FileHeader* fH, InfoHeader* iH);
// Descreve o conteudo do header.
void describeBMP(FileHeader headfirst, InfoHeader headsecond);
// Salva um arquivo bmp com os headers e a matrix de pixels.
void saveBMP(char filename[], FileHeader headfirst, InfoHeader headsecond, PixelMatrix pM);
// Salva em um arquivo apenas o header.
void saveBMPHeader(FILE* fout, FileHeader headfirst, InfoHeader headsecond);
