/*

	Authors
	-------
	Aline Abreu Santos		6552035
	Diogo Ferrari Meletto	5890201
	Flávio Heleno Batista	5890027

*/

#ifndef __LIST_H__
#define __LIST_H__

#include <stdio.h>
#include <stdlib.h>

#include "tree.h"

typedef struct list_item {
	node *data;
	struct list_item *next;
} list;

void list_clean(list **head);
void list_add(list **head, node *data);
void list_del(list **head, int pos);
node *list_pop(list **head);
void list_push(list **head, node *data);
void list_print(list *head);
void list_sort(list **head);
int list_size(list *head);
void list_clone(list **target, list *source);

#endif
