/*

	Authors
	-------
	Aline Abreu Santos		6552035
	Diogo Ferrari Meletto	5890201
	Flávio Heleno Batista	5890027

*/

#ifndef __VECTOR_H__
#define __VECTOR_H__

#include <stdint.h>

#include "pixel.h"
#include "block.h"

/* defines return values */
#define VEC_OK 0x00
#define VEC_MERR 0x01

/* defines structure to hold vector data */
typedef struct {
	int size;
	pixel_int32 **data;
	pixel_int32 *dc;
} vector_data;

int vector_init(vector_data *target, uint32_t width, uint32_t height);
int vector_from_block(bmp_block block, vector_data *target);
int vector_to_block(vector_data source, bmp_block *block);

/*
	This function prints error messages
	Parameters:
		code: error code
	Return values:
		none
*/
void vector_error(int code);

#endif
