/*

	Authors
	-------
	Aline Abreu Santos		6552035
	Diogo Ferrari Meletto	5890201
	Flávio Heleno Batista	5890027

*/

#include "de.h"

void de_print(de_table *table, int size) {
	int i;
	printf("printing de table (%d items)\n", size);
	printf("diff\tbits\tcode\tbits\n");
	for (i = 0; i < size; i++)
		printf("%d\t%d\t%d\t%d\n", table[i].diff, table[i].diff_bits, table[i].code, table[i].code_bits);
	printf("\n");
}

int de_encode(FILE *handler, pixel_int32 *vector, int size) {
	int i, j, k, max = 0;
	int *freq = NULL;
	list *huff = NULL;
	huffman *huff_table = NULL;
	int huff_tbl_size;
	uint8_t num_items;
	uint32_t code = 0;
	uint32_t de_size = 0;
	float align;
	for (k = 0; k < 3; k++) {
		/* allocates memory to hold DE table */
		de_table *tbl = (de_table *)malloc(sizeof(de_table) * size);
		if (tbl == NULL)
			return DE_MERR;
		max = 0;
		/* generates DE table */
		for (i = (size - 1); i > 0; i--) {
			switch (k) {
				case 0:
					tbl[i].diff = (vector[i].r - vector[(i - 1)].r);
					break;
				case 1:
					tbl[i].diff = (vector[i].g - vector[(i - 1)].g);
					break;
				case 2:
					tbl[i].diff = (vector[i].b - vector[(i - 1)].b);
					break;
			}
			if (tbl[i].diff == 0)
				tbl[i].diff_bits = 0;
			else
				tbl[i].diff_bits = binary_size32(tbl[i].diff);
			if (max < tbl[i].diff_bits)
				max = tbl[i].diff_bits;
		}
		/* DE table entry for first item */
		switch (k) {
			case 0:
				tbl[0].diff = vector[0].r;
				break;
			case 1:
				tbl[0].diff = vector[0].g;
				break;
			case 2:
				tbl[0].diff = vector[0].b;
				break;
		}
		if (tbl[0].diff == 0)
			tbl[0].diff_bits = 0;
		else
			tbl[0].diff_bits = binary_size32(tbl[0].diff);
		if (max < tbl[0].diff_bits)
			max = tbl[0].diff_bits;
		max++;
		/* allocates memory to be used in frequency count */
		freq = (int *)malloc(sizeof(int) * max);
		if (freq == NULL)
			return DE_MERR;
		for (i = 0; i < max; i++)
			freq[i] = 0;
		/* calculates frequency for every diff_bits field */
		for (i = 0; i < size; i++)
			freq[tbl[i].diff_bits]++;
		/* generates huffman code for each value on DE table */
		num_items = 0;
		for (i = 0; i < max; i++)
			if (freq[i] > 0)
				num_items++;
		/* writes to file the number of items */
		if (file_write8(handler, num_items) != FILE_OK)
			return DE_WERR;
		for (i = 0; i < max; i++)
			if (freq[i] > 0) {
				if (file_write8(handler, i) != FILE_OK)
					return DE_WERR;
				if (file_write16(handler, freq[i]) != FILE_OK)
					return DE_WERR;
				huff_add(&huff, i, freq[i]);
			}
		free(freq);
		/* creates huffman tree based on huffman list */
		huff_tbl_size = huff_code(huff, &huff_table);
		de_size = 0;
		/* for each item in table, calculates its final code */
		for (j = 0; j < size; j++)
			for (i = 0; i < huff_tbl_size; i++)
				if (tbl[j].diff_bits == huff_table[i].value) {
					code = huff_table[i].code;
					if (tbl[j].diff != 0) {
						code <<= tbl[j].diff_bits;
						code |= (binary_reduce32(tbl[j].diff) & binary_mask32(tbl[j].diff_bits));
					}
					tbl[j].code = code;
					tbl[j].code_bits = (huff_table[i].bits + tbl[j].diff_bits);
					de_size += tbl[j].code_bits;
				}
		/* calculates alignment size */
		align = ceil((float)de_size / 32.0);
		/* writes alignment to file */
		if (file_write16(handler, (uint16_t)align) != FILE_OK)
			return DE_WERR;
		/* for each table entry, writes it to file using a buffer */
		for (j = 0; j < size; j++)
			if (file_write_buffered(handler, tbl[j].code, tbl[j].code_bits, 0) != FILE_OK)
				return DE_WERR;
		/* flushes buffer to file */
		if (file_write_buffered(handler, 0, 0, 1) != FILE_OK)
			return DE_WERR;
		/* cleans huffman list */
		list_clean(&huff);
		/* cleans huffman table */
		huff_clean(&huff_table, huff_tbl_size);
		free(tbl);
	}
	return DE_OK;
}

int de_decode(FILE *handler, pixel_int32 *vector, int size) {
	int i, k;
	uint8_t num_items, item;
	uint16_t align;
	uint16_t freq;
	list *huff = NULL;
	huffman *huff_table = NULL;
	int huff_tbl_size;
	uint32_t *data;
	int flag = 1, value, extracted;
	uint8_t buffer, code_bits, offset;
	uint32_t code, content;
	int diff;
	for (k = 0; k < 3; k++) {
		/* reads huffman items */
		if (file_read8(handler, &num_items) != FILE_OK)
			return DE_RERR;
		/* for each item, reads item value and item frequency */
		for (i = 0; i < num_items; i++) {
			if (file_read8(handler, &item) != FILE_OK)
				return DE_RERR;
			if (file_read16(handler, &freq) != FILE_OK)
				return DE_RERR;
			/* adds item and frequency to huffman list */
			huff_add(&huff, item, freq);
		}
		/* creates huffman tree based on huffman list */
		huff_tbl_size = huff_code(huff, &huff_table);
		/* cleans huffman list */
		list_clean(&huff);
		/* reads alignment size */
		if (file_read16(handler, &align) != FILE_OK)
			return DE_RERR;
		/* reads (align * 32) bits from file */
		if (file_read_buffered(handler, &data, align) != FILE_OK)
			return DE_RERR;
		/* decodes data read from file */
		flag = 1;
		i = 0;
		offset = 0;
		buffer = 0;
		code_bits = 0;
		extracted = 0;
		diff = 0;
		while (flag) {
			code_bits++;
			/* code is splited into two different chunks */
			if ((offset + code_bits) > 0x20) {
				buffer = (0x20 - offset);
				code = binary_extract32(data[i], offset, buffer);
				code_bits -= buffer;
				code <<= code_bits;
				offset = 0;
				i++;
				code |= binary_extract32(data[i], offset, code_bits);
			} else {
				if (buffer == 0)
					code = binary_extract32(data[i], offset, code_bits);
				else {
					code = binary_extract32(data[(i - 1)], (32 - buffer), buffer);
					code <<= code_bits;
					code |= binary_extract32(data[i], offset, code_bits);
				}
			}
			if (huff_check(huff_table, huff_tbl_size, code, (code_bits + buffer), &value)) {
				offset += code_bits;
				code_bits = 0;
				/* data is splited into two different chunks */
				if ((offset + value) > 0x20) {
					buffer = (0x20 - offset);
					content = binary_extract32(data[i], offset, buffer);
					value -= buffer;
					content <<= value;
					offset = 0;
					i++;
					content |= binary_extract32(data[i], offset, value);
					content = binary_expand32(content, (buffer + value));
				} else {
					content = binary_extract32(data[i], offset, value);
					content = binary_expand32(content, value);
				}
				buffer = 0;
				offset += value;
				diff += content;
				switch (k) {
					case 0:
						vector[extracted].r = diff;
						break;
					case 1:
						vector[extracted].g = diff;
						break;
					case 2:
						vector[extracted].b = diff;
						break;
				}
				extracted++;
			}
			if (i >= align)
				return DE_FERR;
			/* checks if data was fully extracted */
			if (extracted == size)
				flag = 0;
		}
		/* cleans data buffer */
		free(data);
		/* cleans huffman table */
		huff_clean(&huff_table, huff_tbl_size);
	}
	return DE_OK;
}

void de_error(int code) {
	switch (code) {
		case DE_MERR:
			printf("DE: malloc error\n");
			break;
		case DE_WERR:
			printf("DE: write error\n");
			break;
		case DE_RERR:
			printf("DE: read error\n");
			break;
		case DE_FERR:
			printf("DE: fatal error\n");
			break;
	}
}
