/*

	Authors
	-------
	Aline Abreu Santos		6552035
	Diogo Ferrari Meletto	5890201
	Flávio Heleno Batista	5890027

*/

#ifndef __RLE_H__
#define __RLE_H__

#include <stdio.h>
#include <stdlib.h>

#include "pixel.h"
#include "file.h"
#include "huffman.h"

/* defines return values */
#define RLE_OK 0x00
#define RLE_MERR 0x01
#define RLE_WERR 0x02
#define RLE_FERR 0x03
#define RLE_RERR 0x04

/* defines structure to hold rle pre-table */
typedef struct {
	uint8_t repeat;
	int32_t value;
} rle;

/* defines structure to hold rle table */
typedef struct {
	uint16_t info;
	uint8_t info_bits;
	uint32_t code;
	uint8_t code_bits;
} rle_table;


void rle_print(rle_table **table, int *size);
int rle_encode(FILE *handler, pixel_int32 **vector, int size);
int rle_decode(FILE *handler, pixel_int32 **vector, int size);
void rle_clean(rle **table, int size);

/*
	This function prints error messages
	Parameters:
		code: error code
	Return values:
		none
*/
void rle_error(int code);

#endif
