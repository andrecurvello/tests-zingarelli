/*

	Authors
	-------
	Aline Abreu Santos		6552035
	Diogo Ferrari Meletto	5890201
	Flávio Heleno Batista	5890027

*/

#include "rle.h"

int rle_pre_encode(pixel_int32 vector[64], rle *table[3], int size[3]) {
	int i, k, f, count;
	for (k = 0; k < 3; k++) {
		table[k] = NULL;
		size[k] = 0;
		count = 0;
		for (i = 2; i < 64; i++) {
			switch (k) {
				case 0:
					f = (vector[i].r != vector[(i - 1)].r);
					break;
				case 1:
					f = (vector[i].g != vector[(i - 1)].g);
					break;
				case 2:
					f = (vector[i].b != vector[(i - 1)].b);
					break;
			}
			if (f) {
				table[k] = (rle *)realloc(table[k], sizeof(rle) * (size[k] + 1));
				if (table[k] == NULL)
					return RLE_MERR;
				table[k][size[k]].repeat = count;
				switch (k) {
					case 0:
						table[k][size[k]].value = vector[(i - 1)].r;
						break;
					case 1:
						table[k][size[k]].value = vector[(i - 1)].g;
						break;
					case 2:
						table[k][size[k]].value = vector[(i - 1)].b;
						break;
				}
				count = 0;
				size[k]++;
			} else
				count++;
		}
		/* last red element */
		table[k] = (rle *)realloc(table[k], sizeof(rle) * (size[k] + 1));
		if (table[k] == NULL)
			return RLE_MERR;
		table[k][size[k]].repeat = count;
		switch (k) {
			case 0:
				table[k][size[k]].value = vector[(i - 1)].r;
				break;
			case 1:
				table[k][size[k]].value = vector[(i - 1)].g;
				break;
			case 2:
				table[k][size[k]].value = vector[(i - 1)].b;
				break;
		}
		size[k]++;
	}
	return RLE_OK;
}

int rle_pre_decode(pixel_int32 vector[64], rle *table[3], int size[3]) {
	int i, j, k, pos;
	for (k = 0; k < 3; k++) {
		pos = 1;
		for (i = 0; i < size[k]; i++)
			for (j = 0; j <= table[k][i].repeat; j++) {
				switch (k) {
					case 0:
						vector[pos].r = table[k][i].value;
						break;
					case 1:
						vector[pos].g = table[k][i].value;
						break;
					case 2:
						vector[pos].b = table[k][i].value;
						break;
				}
				pos++;
			}
	}
	return RLE_OK;
}

void rle_print(rle_table *table[3], int size[3]) {
	/*
	int i, j;
	for (i = 0; i < 3; i++)
		for (j = 0; j < size[i]; j++) {
			printf("table[%d][%d].repeat = %d\n", i, j, table[i][j].repeat);
			printf("table[%d][%d].value = %d\n", i, j, table[i][j].value);
		}
	*/
}

int rle_encode(FILE *handler, pixel_int32 **vector, int size) {
	rle *info[3] = {NULL, NULL, NULL};
	int i, j, k, w, info_size[3];
	int ret, *freq = NULL;
	list *huff = NULL;
	huffman *huff_table = NULL;
	int huff_tbl_size;
	uint8_t num_items;
	uint16_t value, max;
	rle_table *tbl;
	uint32_t rle_size = 0;
	float align;
	for (i = 0; i < size; i++) {
		ret = rle_pre_encode(vector[i], info, info_size);
		if (ret != RLE_OK)
			return ret;
		for (k = 0; k < 3; k++) {
			max = 0;
			tbl = (rle_table *)malloc(sizeof(rle_table) * info_size[k]);
			for (j = 0; j < info_size[k]; j++) {
				value = ((uint16_t)(info[k][j].repeat) & 0x00FF);
				value <<= 8;
				value |= (((uint16_t)binary_reduce8(info[k][j].value)) & 0x00FF);
				tbl[j].info = value;
				if (value == 0)
					tbl[j].info_bits = 0;
				else
					tbl[j].info_bits = binary_size32(value);
				if (max < value)
					max = (value + 1);
			}
			freq = (int *)malloc(sizeof(int) * max);
			if (freq == NULL)
				return RLE_MERR;
			for (j = 0; j < max; j++)
				freq[j] = 0;
			for (j = 0; j < info_size[k]; j++)
				freq[tbl[j].info]++;
			num_items = 0;
			for (j = 0; j < max; j++)
				if (freq[j] > 0)
					num_items++;
			printf("huff items: %u\n", num_items);
			if (file_write8(handler, num_items) != FILE_OK)
				return RLE_WERR;
			for (j = 0; j < max; j++)
				if (freq[j] > 0) {
					if (file_write16(handler, j) != FILE_OK)
						return RLE_WERR;
					if (file_write8(handler, freq[j]) != FILE_OK)
						return RLE_WERR;
					huff_add(&huff, j, freq[j]);
				}
			/*
			free(freq);
			freq = NULL;
			*/
			huff_tbl_size = huff_code(huff, &huff_table);
			/* for each item calculates its final code */
			rle_size = 0;
			for (j = 0; j < info_size[k]; j++)
				for (w = 0; w < huff_tbl_size; w++)
					if (tbl[j].info == huff_table[w].value) {
						tbl[j].code = huff_table[w].code;
						tbl[j].code_bits = huff_table[w].bits;
						rle_size += tbl[j].code_bits;
					}
			/* calculates alignment size */
			align = ceil((float)rle_size / 32.0);
			/* writes alignment to file */
			if (file_write16(handler, (uint16_t)align) != FILE_OK)
				return RLE_WERR;
			/* for each table entry, writes it to file using a buffer */
			for (j = 0; j < info_size[k]; j++) {
				if (file_write_buffered(handler, tbl[j].code, tbl[j].code_bits, 0) != FILE_OK)
					return RLE_WERR;
			}
			/* flushes buffer to file */
			if (file_write_buffered(handler, 0, 0, 1) != FILE_OK)
				return RLE_WERR;
			free(tbl);
			list_clean(&huff);
			huff_clean(&huff_table, huff_tbl_size);
			free(info[k]);
			info[k] = NULL;
		}
	}
	

	return RLE_OK;
}

int rle_decode(FILE *handler, pixel_int32 **vector, int size) {
	int i, j, k, ret;
	uint8_t num_items, freq;
	uint16_t item, align;
	list *huff = NULL;
	huffman *huff_table = NULL;
	int huff_tbl_size;
	uint32_t *data;
	int flag = 1, value, extracted, qt;
	uint8_t buffer, code_bits, offset;
	uint32_t code;
	rle *tbl[3];
	int tbl_size[3];
	for (j = 0; j < size; j++) {
		for (k = 0; k < 3; k++) {
			/* reads huffman items */
			if (file_read8(handler, &num_items) != FILE_OK)
				return RLE_RERR;
			/* gambs */
			if (num_items == 0) {
				while (num_items == 0) {
					if (file_read8(handler, &num_items) != FILE_OK)
						return RLE_RERR;
				}
			}
			qt = 0;
			/* for each item, reads item value and item frequency */
			for (i = 0; i < num_items; i++) {
				if (file_read16(handler, &item) != FILE_OK)
					return RLE_RERR;
				if (file_read8(handler, &freq) != FILE_OK)
					return RLE_RERR;
				qt += freq;
				/* adds item and frequency to huffman list */
				huff_add(&huff, item, freq);
			}
			/* creates huffman tree based on huffman list */
			huff_tbl_size = huff_code(huff, &huff_table);
			/* cleans huffman list */
			list_clean(&huff);
			/* reads alignment size */
			if (file_read16(handler, &align) != FILE_OK)
				return RLE_RERR;
			/* reads (align * 32) bits from file */
			if (file_read_buffered(handler, &data, align) != FILE_OK)
				return RLE_RERR;
			/* decodes data read from file */
			tbl[k] = (rle *)malloc(sizeof(rle) * qt);
			tbl_size[k] = qt;
			flag = 1;
			i = 0;
			offset = 0;
			buffer = 0;
			code_bits = 0;
			extracted = 0;
			while (flag) {
				code_bits++;
				/* code is splited into two different chunks */
				if ((offset + code_bits) > 0x20) {
					buffer = (0x20 - offset);
					code = binary_extract32(data[i], offset, buffer);
					code_bits -= buffer;
					code <<= code_bits;
					offset = 0;
					i++;
					code |= binary_extract32(data[i], offset, code_bits);
				} else {
					if (buffer == 0)
						code = binary_extract32(data[i], offset, code_bits);
					else {
						code = binary_extract32(data[(i - 1)], (32 - buffer), buffer);
						code <<= code_bits;
						code |= binary_extract32(data[i], offset, code_bits);
					}
				}
				if (huff_check(huff_table, huff_tbl_size, code, (code_bits + buffer), &value)) {
					tbl[k][extracted].repeat = ((value >> 8) & 0xFF);
					tbl[k][extracted].value = binary_expand8((uint8_t)(value & 0x00FF), 8);
					offset += code_bits;
					code_bits = 0;
					buffer = 0;
					extracted++;
				}
				if (i >= align)
					return RLE_FERR;
				/* checks if data was fully extracted */
				if (extracted == qt)
					flag = 0;
			}
			/* cleans data buffer */
			free(data);
			/* cleans huffman table */
			huff_clean(&huff_table, huff_tbl_size);
		}
		ret = rle_pre_decode(vector[j], tbl, tbl_size);
		if (ret != RLE_OK)
			return ret;
		/* cleans rle table */
		free(tbl[0]);
		free(tbl[1]);
		free(tbl[2]);
	}
	return RLE_OK;
}

void rle_clean(rle **table, int size) {
	
}

void rle_error(int code) {
	switch (code) {
		case RLE_MERR:
			printf("RLE: malloc error\n");
			break;
		case RLE_WERR:
			printf("RLE: write error\n");
			break;
		case RLE_FERR:
			printf("RLE: file format error\n");
			break;
		case RLE_RERR:
			printf("RLE: read error\n");
			break;
	}
}
