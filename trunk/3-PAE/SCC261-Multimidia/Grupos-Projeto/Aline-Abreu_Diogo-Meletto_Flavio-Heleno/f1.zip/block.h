#ifndef __BLOCK_H__
#define __BLOCK_H__

#include <math.h>

#include "bmp.h"

/* struct for block pixel (value range: [-128,127]) */
typedef struct {
	int8_t r;
	int8_t g;
	int8_t b;
} pixel_block;

/* struct for block (8x8 array) */
typedef struct {
	pixel_block data[8][8];
} data_block;

/* struct for image blocks */
typedef struct {
	uint32_t width;
	uint32_t height;
	data_block **block;
} bmp_block;

/* defines return values */
#define BLK_OK 0x00
#define BLK_MERR 0x01

/*
	This function frees the memory used by block data
	Parameters:
		blocks: variable that holds block data
	Return values:
		none
*/
void free_block_data(bmp_block *blocks);

/*
	This function creates 8x8 block from bitmap data
	Parameters:
		blocks: variable that will hold block data
		bmp: variable that holds bitmap file data
	Return values:
		BLK_OK: blocks created
		BLK_MERR: malloc error
*/
int create_block(bmp_block *blocks, bmp_file bmp);

/*
	This function recreates bitmap imagem based on block data
	Parameters:
		blocks: variable that holds block data
		bmp: variable that will hold bitmap file data
	Return values:
		BLK_OK: image recreated
		BLK_MERR: malloc error
*/
int recreate_image(bmp_block blocks, bmp_file *bmp);

#endif
