#include "table.h"

/* defines for pseudo helper functions */
#define pos(x, y, w) (x + (y * w))
#define idx(x, y) ((x * 3) + (y * 24))
#define error_handler(f, v)	{ if (f) fclose(f); return v; }

void free_table_data(uint8_t **data, int size) {
	int i;
	/* for each line, free its memory */
	for (i = 0; i < size; i++)
		free(data[i]);
	/* free initial vector */
	free(data);
}

int create_table(const char *filename, bmp_block blocks) {
	FILE *file = NULL;
	int x, y, w, h, i, size;
	uint8_t **data = NULL;
	file = fopen(filename, "wb");
	if (!file)
		return TBL_FERR;

	/* writes block width */
	if (fwrite(&blocks.width, sizeof(uint32_t), (size_t)1, file) != 1)
		error_handler(file, TBL_WERR);
	/* writes block height */
	if (fwrite(&blocks.height, sizeof(uint32_t), (size_t)1, file) != 1)
		error_handler(file, TBL_WERR);

	/* calculates table size */
	size = blocks.width * blocks.height;
	/* memory allocation for table contents */
	data = (uint8_t **)malloc(sizeof(uint8_t *) * size);
	if (data == NULL)
		return TBL_MERR;
	for (i = 0; i < size; i++) {
		data[i] = (uint8_t *)malloc(sizeof(uint8_t) * 192);
		if (data[i] == NULL)
			return TBL_MERR;
	}

	/* calculates block item's size and stores at table */
	for (w = 0; w < blocks.width; w++)
		for (h = 0; h < blocks.height; h++)
			for (x = 0; x < 8; x++)
				for (y = 0; y < 8; y++) {
					data[pos(w, h, blocks.width)][idx(x, y)] = binary_size(blocks.block[w][h].data[x][y].r);
					data[pos(w, h, blocks.width)][idx(x, y) + 1] = binary_size(blocks.block[w][h].data[x][y].g);
					data[pos(w, h, blocks.width)][idx(x, y) + 2] = binary_size(blocks.block[w][h].data[x][y].b);
				}
			
	/* writes table data to file */
	for (i = 0; i < size; i++)
		if (fwrite(data[i], sizeof(uint8_t), (size_t)192, file) != 192)
			error_handler(file, TBL_WERR);

	free_table_data(data, size);

	fclose(file);
	return TBL_OK;
}

int load_table(const char *filename, uint8_t ***data, uint32_t *width, uint32_t *height) {
	FILE *file = NULL;
	int i, size;
	file = fopen(filename, "rb");
	if (!file)
		return TBL_FERR;

	/* reads block width from file */
	if (fread(width, sizeof(uint32_t), (size_t)1, file) != 1)
		error_handler(file, TBL_RERR);
	/* reads block height from file */
	if (fread(height, sizeof(uint32_t), (size_t)1, file) != 1)
		error_handler(file, TBL_RERR);
	/* calculates table size */
	size = ((*width) * (*height));

	/* memory allocation for table contents */
	(*data) = (uint8_t **)malloc(sizeof(uint8_t *) * size);
	if ((*data) == NULL)
		return TBL_MERR;
	for (i = 0; i < size; i++) {
		(*data)[i] = (uint8_t *)malloc(sizeof(uint8_t) * 192);
		if ((*data)[i] == NULL)
			return TBL_MERR;
	}

	/* reads table contents from file */
	for (i = 0; i < size; i++)
		if (fread((*data)[i], sizeof(uint8_t), (size_t)192, file) != 192)
			error_handler(file, TBL_RERR);

	fclose(file);
	return TBL_OK;
}
