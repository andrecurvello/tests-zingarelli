#ifndef __BINARY_H__
#define __BINARY_H__

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

/* 8 bits conversion from reduced representation */
int8_t binary_expand(uint8_t value, uint8_t size);
/* 8 bits conversion to reduced representation */
uint8_t binary_reduce(int8_t value);
/* 8 bits size (bit count) for reduced representation */
int binary_size(int8_t value);
/* 8 bits binary representation printer */
void binary_print(uint8_t value);
/* 8 bits binary mask creation */
uint8_t binary_mask(uint8_t size);

#endif
