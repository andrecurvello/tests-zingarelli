#ifndef __TABLE_H__
#define __TABLE_H__

#include <stdio.h>

#include "block.h"
#include "binary.h"

/* defines return values */
#define TBL_OK 0x00
#define TBL_FERR 0x01
#define TBL_MERR 0x02
#define TBL_WERR 0x03
#define TBL_RERR 0x04

/*
	This function frees the memory used by data array
	Parameters:
		data: variable that holds table values
		size: table width
	Return values:
		none
*/
void free_table_data(uint8_t **data, int size);

/*
	This function creates bit size table and writes it to file
	Parameters:
		filename: full path to the file to be written
		blocks: bitmap block data
	Return values:
		TBL_OK: file written
		TBL_FERR: file error
		TBL_WERR: write error
		TBL_MERR: malloc error
*/
int create_table(const char *filename, bmp_block blocks);

/*
	This function loads bit size table from file
	Parameters:
		filename: full path to the file to be loaded
		data: variable that will hold table data
		width: variable that will hold block width
		height: variable that will hold block height
	Return values:
		TBL_OK: load ok
		TBL_FERR: file error
		TBL_RERR: read error
		TBL_MERR: malloc error
*/
int load_table(const char *filename, uint8_t ***data, uint32_t *width, uint32_t *height);

#endif
