#ifndef __FILE_H__
#define __FILE_H__

#include <stdio.h>
#include <stdint.h>
#include <string.h>

#include "block.h"
#include "binary.h"

/* defines return values */
#define FILE_OK 0x00
#define FILE_FERR 0x01
#define FILE_WERR 0x02
#define FILE_IFF 0x03
#define FILE_MERR 0x04
#define FILE_RERR 0x05
#define FILE_SERR 0x06

/*
	This function compresses block data and writes it to file
	Parameters:
		filename: full path to the file to be written
		blocks: block data
	Return values:
		FILE_OK: file written
		FILE_FERR: file error
		FILE_WERR: write error
*/
int file_write(const char *filename, bmp_block blocks);

/*
	This function reads compressed block data from file and decompress it
	Parameters:
		filename: full path to the file to be read
		blocks: block data
		table: bit size table
		width: block width (bitmap width / 8)
		height: block height (bitmap height / 8)
	Return values:
		FILE_OK: load ok
		FILE_FERR: file error
		FILE_RERR: read error
		FILE_IFF: invalid file format
		FILE_MERR: malloc error
		FILE_SERR: seek error
*/
int file_read(const char *filename, bmp_block *blocks, uint8_t **table, uint32_t width, uint32_t height);

#endif
