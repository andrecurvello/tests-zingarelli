#include "binary.h"

int8_t binary_expand(uint8_t value, uint8_t size) {
	uint8_t mask = 0x00;
	int i;
	/* creates bit mask */
	for (i = size; i > 0; i--) {
		mask <<= 1;
		mask |= 0x01;
	}
	/* if the value is a positive representation */
	if (((value >> (size - 1)) & 0x01) == 0x01)
		return (int8_t)(value & mask);
	/* if the value is a negative representation */
	else
		return (int8_t)((~value) & mask);
}

uint8_t binary_reduce(int8_t value) {
	/* reduced 0 representation */
	if (value == 0)
		return (uint8_t)0x80;
	/* negative representation */
	if (value < 0)
		return (uint8_t)~abs(value);
	/* positive representation */
	else
		return (uint8_t)value;
}

int binary_size(int8_t value) {
	int r = 0;
	int f = 0;
	int c = 0;
	/* converts negative values into positive values */
	if (value < 0)
		r = (uint8_t)abs(value);
	else
		r = (uint8_t)value;
	/* loop to check first 1 bit */
	while ((!f) && (c < 8)) {
		if ((value & 0x80) == 0x80) {
			r = (8 - c);
			f = 1;
		}
		c++;
		value <<= 1;
	}
	return r;
}

void binary_print(uint8_t value) {
	char s[9];
	int i;
	s[8] = 0;
	for (i = 0; i < 8; i++) {
		if ((value & 0x01) == 0x01)
			s[(7 - i)] = '1';
		else
			s[(7 - i)] = '0';
		value >>= 1;
	}
	printf("%s\n", s);
}

uint8_t binary_mask(uint8_t size) {
	uint8_t mask = 0x00;
	uint8_t i;
	for (i = size; i > 0; i--) {
		mask <<= 1;
		mask |= 0x01;
	}
	return mask;
}
