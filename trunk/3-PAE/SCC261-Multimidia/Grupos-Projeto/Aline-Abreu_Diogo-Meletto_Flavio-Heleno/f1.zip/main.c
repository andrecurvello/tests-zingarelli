#include "bmp.h"
#include "block.h"
#include "table.h"
#include "file.h"

/* sets debug mode to on */
#define DEBUG 1
/* prints messages if debug mode is on */
#define DBGMS(x) if (DEBUG) printf(x);

/* print help options */
void print_help(const char *app) {
	printf("Usage: %s mode input output\n", app);
	printf("	modes:\n");
	printf("		-e [--encode]: encodes the given input file\n");
	printf("		-d [--decode]: decodes the given input file\n");
}

/* main function */
int main(int argc, char *argv[]) {
	bmp_file bmp;
	bmp_block blocks;
	uint8_t **table = NULL;
	int primary, secondary;
	uint32_t w, h;

	/* if the number of arguments is not 4, prints help options */
	if (argc != 4)
		print_help(argv[0]);
	else {
		/* encode */
		if ((!strcmp(argv[1], "-e")) || (!strcmp(argv[1], "--encode"))) {
			/* load bitmap file */
			primary = load_bmp(argv[2], &bmp);
			switch (primary) {
				case BMP_OK:
					DBGMS("BMP: load ok\n");
					/* creates 8x8 block from bitmap data */
					secondary = create_block(&blocks, bmp);
					switch (secondary) {
						case BLK_OK:
							/* creates bit size table */
							secondary = create_table("bit_table.tbl", blocks);
							switch (secondary) {
								case TBL_OK:
									DBGMS("TBL: success\n");
									/* write compressed file */
									secondary = file_write(argv[3], blocks);
									switch (secondary) {
										case FILE_OK:
											DBGMS("FILE: success\n");
											break;
										case FILE_FERR:
											DBGMS("FILE: file error\n");
											break;
										case FILE_WERR:
											DBGMS("FILE: write error\n");
											break;
									}
									break;
								case TBL_FERR:
									DBGMS("TBL: file error\n");
									break;
								case TBL_MERR:
									DBGMS("TBL: malloc error\n");
									break;
								case TBL_WERR:
									DBGMS("TBL: write error\n");
									break;
							}
							free_block_data(&blocks);
							break;
						case BLK_MERR:
							DBGMS("BLK: malloc error\n");
							break;
					}
					free_bmp_data(&bmp);
					break;
				case BMP_FERR:
					DBGMS("BMP: file error\n");
					break;
				case BMP_RERR:
					DBGMS("BMP: read error\n");
					break;
				case BMP_IFF:
					DBGMS("BMP: invalid file format\n");
					break;
				case BMP_SERR:
					DBGMS("BMP: seek error\n");
					break;
				case BMP_MERR:
					DBGMS("BMP: malloc error\n");
					break;
			}
		/* decode */
		} else if ((!strcmp(argv[1], "-d")) || (!strcmp(argv[1], "--decode"))) {
			/* loads bit size table */
			primary = load_table("bit_table.tbl", &table, &w, &h);
			switch (primary) {
				case TBL_OK:
					DBGMS("TBL: load ok\n");
					/* reads compressed file and recreate blocks */
					secondary = file_read(argv[2], &blocks, table, w, h);
					switch (secondary) {
						case FILE_OK:
							DBGMS("FILE: load ok\n");
							/* recreates bitmap file from blocks */
							secondary = recreate_image(blocks, &bmp);
							switch (secondary) {
								case BLK_OK:
									/* saves bitmap file */
									secondary = save_bmp(argv[3], bmp);
									switch (secondary) {
										case BMP_OK:
											DBGMS("BMP: success\n");
											break;
										case BMP_FERR:
											DBGMS("BMP: file error\n");
											break;
										case BMP_WERR:
											DBGMS("BMP: write error\n");
											break;
									}
									break;
								case BLK_MERR:
									DBGMS("BLK: malloc error\n");
									break;
							}
							break;
						case FILE_FERR:
							DBGMS("FILE: file error\n");
							break;
						case FILE_RERR:
							DBGMS("FILE: read error\n");
							break;
						case FILE_IFF:
							DBGMS("FILE: invalid file format\n");
							break;
						case FILE_MERR:
							DBGMS("FILE: malloc error\n");
							break;
						case FILE_SERR:
							DBGMS("FILE: seek error\n");
							break;
					}
					break;
				case TBL_FERR:
					DBGMS("TBL: file error\n");
					break;
				case TBL_RERR:
					DBGMS("TBL: read error\n");
					break;
				case TBL_MERR:
					DBGMS("TBL: malloc error\n");
					break;
			}
		/* invalid option */
		} else {
			print_help(argv[0]);
		}
	}
	return 0;
}
