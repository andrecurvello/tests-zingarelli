#include <stdio.h>
#include <string.h>
#include "codec.h"
#include "parte1.h"

char* itob(int value, int size, char buffer[]) {
	int bit, mask, p = 0;
	for(mask = 1 << size - 1; mask > 0; mask >>= 1) {
		if(p % 8 == 0 && p > 0) buffer[p++] = ' ';
		bit = value & mask;
		buffer[p++] = (bit == 0)? '0': '1';
		value = ~mask & value;
	}
	buffer[p] = 0;
	return buffer;
}

/* codifica o arquivo bitmap em um bin�rio comprimido */
int encode(FILE* bmp, FILE* bin, FILE* meta) {
	BITMAP_FILE_HEADER fh;
	BITMAP_INFO_HEADER ih;
	ColorMatrices img;
	ColorBlocks cb;
	
	short *raw_data; int n;
	EncodedPixel *enc_data;
	
	/* lendo e verificando headers */
	read_bmp_headers(bmp, &fh, &ih);
	if(strcmp(fh.type, "BM") != 0 || fh.offBits != 54) {
		return CD_FILE_TYPE_ERROR;
	} else if(ih.size != 40) {
		return CD_FILE_TYPE_ERROR;
	} else if(ih.width % 8 != 0 || ih.height % 8 != 0) {
		return CD_FILE_FORMAT_ERROR;
	} else if(ih.width < 8 || ih.height < 8) {
		return CD_FILE_FORMAT_ERROR;
	} else if(ih.width > 1280 || ih.height > 800) {
		return CD_FILE_FORMAT_ERROR;
	} else if(ih.bitCount != 24 || ih.compression != 0) {
		return CD_FILE_FORMAT_ERROR;
	}
	
	ih.sizeImage = 3 * ih.width * ih.height;
	
	/* lendo a imagem */
	raw_data = (short*) malloc(ih.sizeImage * sizeof(short));
	read_bitmap_data(bmp, raw_data, ih.sizeImage);
	
	/* separando as cores */
	CM_init(ih.width, ih.height, &img);
	separate_colors(raw_data, &img);
	free(raw_data);
	
	/*CM_print(img);*/
	
	/* separando os blocos */
	CB_init(img.width, img.height, &cb);
	separate_blocks(img, &cb);
	CM_free(img);
	
	/* normalizando e codificando os pixels */
	enc_data = (EncodedPixel*) malloc(ih.sizeImage * sizeof(EncodedPixel));
	normalize_colors(&cb);
	encode_pixels(cb, enc_data);
	
	/*CB_print(cb);*/
	
	n = 3 * CB_BLOCK_SIZE * CB_BLOCK_SIZE * cb.width * cb.height;
	/*EP_print(enc_data, n);*/
	
	/* escrevendo os arquivos */
	write_metafile(meta, cb, enc_data);
	write_binary(enc_data, n, bin);
	
	/* limpeza */
	CB_free(cb);
	free(enc_data);
	
	return CD_SUCCESSFUL;
}

/* decodifica o arquivo bitmap de um bin�rio comprimido */
int decode(FILE* bmp, FILE* bin, FILE* meta) {
	BITMAP_FILE_HEADER fh;
	BITMAP_INFO_HEADER ih;
	ColorMatrices img;
	ColorBlocks cb;
	
	short *raw_data;
	int *binary_data, n;
	EncodedPixel *enc_data;
	
	/* lendo os arquivos */
	read_metafile(meta, &cb, &enc_data);
	n = 3 * CB_BLOCK_SIZE * CB_BLOCK_SIZE * cb.width * cb.height;
	read_binary(bin, enc_data, n);

//	EP_print(enc_data, n);
	
	/* normalizando e codificando os pixels */
	decode_pixels(cb, enc_data);
	denormalize_colors(&cb);
	
	free(enc_data);
	
//	CB_print(cb);
	
	/* juntando os blocos */
	CM_init(cb.width * CB_BLOCK_SIZE, cb.height * CB_BLOCK_SIZE, &img);
	join_blocks(img, &cb);
	CB_free(cb);
	
//	CM_print(img);
	
	/* juntando as cores */
	raw_data = (short*) malloc(n * sizeof(short));
	merge_colors(raw_data, img);

	/* escrevendo o bitmap */
	strcpy(fh.type, "BM");
	fh.offBits = 54;
	fh.reserved1 = fh.reserved2 = 0;
	
	ih.size = 40;
	ih.width = img.width;
	ih.height = img.height;
	ih.bitCount = 24;
	ih.compression = 0;
	ih.sizeImage = n;
	ih.planes = 1;
	ih.colorUsed = ih.colorImportant = 0;
	ih.xPixelsPerMeter = 4000;
	ih.yPixelsPerMeter = 4000;
	
	fh.size = ih.sizeImage + fh.offBits;
	write_bmp_headers(bmp, fh, ih);
	write_bitmap_data(bmp, raw_data, n);

	/* limpeza */
	free(raw_data);
	CM_free(img);
	
	return CD_SUCCESSFUL;
}

/* traduz os c�digos de erro para linguagem humana 
 * code - o c�digo de erro
 * buffer - uma string pr�-alocada
 * retorna o pr�prio buffer
 */
char* get_error_message(int code, char buffer[]) {
	switch(code) {
		case CD_SUCCESSFUL: 
			sprintf(buffer, "Sem erro"); 
			break;
		case CD_FILE_TYPE_ERROR: 
			sprintf(buffer, "O arquivo fornecido nao eh um bitmap");
			break;
		case CD_FILE_FORMAT_ERROR: 
			sprintf(buffer, "O arquivo bitmap fornecido nao pode ser processado");
			break;
		default:
			sprintf(buffer, "Erro desconhecido");
			break;
	}
	return buffer;
}
