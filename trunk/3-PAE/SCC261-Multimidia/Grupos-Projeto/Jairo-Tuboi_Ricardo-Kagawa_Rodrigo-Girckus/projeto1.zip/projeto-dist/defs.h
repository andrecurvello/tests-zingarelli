#ifndef CODEC_VERSION
#define CODEC_VERSION "1.0"

#define TRUE	1
#define FALSE	0

#define OL_QUIET	0
#define OL_NORMAL	1
#define OL_VERBOSE	2
#define OL_DEBUG	3

#define ERR_MSG_MAX 255

#endif
