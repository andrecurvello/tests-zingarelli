#ifndef BMP_CODEC
#define BMP_CODEC

#include <stdio.h>

#define BF_TYPE 0x4D42             /* "MB" */

typedef struct {	/**** BMP file header structure ****/
	char type[3];				/* Magic number for file */
	unsigned int	size;		/* Size of file */
	unsigned short	reserved1;	/* Reserved */
	unsigned short	reserved2;	/* ... */
	unsigned int	offBits;	/* Offset to bitmap data */
} BITMAP_FILE_HEADER;

typedef struct {	/**** BMP file info structure ****/
	unsigned int	size;				/* Size of info header */
	int				width;				/* Width of image */
	int				height;				/* Height of image */
	unsigned short	planes;				/* Number of color planes */
	unsigned short	bitCount;			/* Number of bits per pixel */
	unsigned int	compression;		/* Type of compression to use */
	unsigned int	sizeImage;			/* Size of image data */
	int				xPixelsPerMeter;	/* X pixels per meter */
	int				yPixelsPerMeter;	/* Y pixels per meter */
	unsigned int	colorUsed;			/* Number of colors used */
	unsigned int	colorImportant;		/* Number of important colors */
} BITMAP_INFO_HEADER;

#define CD_SUCCESSFUL 0
#define CD_FILE_TYPE_ERROR (-1)
#define CD_FILE_FORMAT_ERROR (-2)

int encode(FILE* bitmap, FILE* binary, FILE* metafile);
int decode(FILE* bitmap, FILE* binary, FILE* metafile);

char* get_error_message(int code, char buffer[]);

void read_bmp_headers(FILE* bmp, BITMAP_FILE_HEADER* fh, BITMAP_INFO_HEADER* ih);

#include "defs.h"
#endif
