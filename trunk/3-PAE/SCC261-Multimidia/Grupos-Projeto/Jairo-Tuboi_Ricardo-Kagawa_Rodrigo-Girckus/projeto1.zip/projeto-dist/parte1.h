#ifndef CODEC_PT1
#define CODEC_PT1

#include <stdio.h>
#include "codec.h"

/* imagem separada por cores */
typedef struct {
	short **red, **green, **blue;
	int width, height; //pixels
} ColorMatrices;

/* cria a estrutura de codifica��o/decodifica��o */
void CM_init(int width, int height, ColorMatrices* img);

/* libera os recursos da estrutura */
void CM_free(ColorMatrices img);

/* exibe as matrizes de cores na sa�da padr�o para depura��o */
void CM_print(ColorMatrices img);

#define CB_BLOCK_SIZE 8

/* imagem dividida em blocos */
typedef struct {
	short ***red, ***green, ***blue;
	int width, height; //blocks
} ColorBlocks;

/* cria a estrutura de codifica��o/decodifica��o */
void CB_init(int width, int height, ColorBlocks* cb);

/* libera os recursos da estrutura */
void CB_free(ColorBlocks cb);

/* exibe as matrizes de cores na sa�da padr�o para depura��o */
void CB_print(ColorBlocks cb);

/* pixel codificado */
typedef struct {
	short value;
	short size;
} EncodedPixel;

/* imprime um vetor de pixels codificados */
void EP_print(EncodedPixel a[], int n);


/* ===== CODIFICA��O ===== */

/* l� o cabe�alho do arquivo bitmap */
void read_bmp_headers(FILE* in, BITMAP_FILE_HEADER* fheader, BITMAP_INFO_HEADER* iheader);

/* l� o corpo do arquivo bitmap, pixel a pixel */
void read_bitmap_data(FILE* in, short data[], int n);

/* separa as cores dos pixels lidos */
void separate_colors(short raw[], ColorMatrices* img);

/* separa os pixels em blocos de 8 x 8 */
void separate_blocks(ColorMatrices cm, ColorBlocks *cb);

/* normaliza os valores dos pixels */
void normalize_colors(ColorBlocks *cb);

/* codifica o valor de uma cor de um pixel (1 byte) */
EncodedPixel encode_pixel(short value);

/* codifica a imagem separada em blocos */
void encode_pixels(ColorBlocks cb, EncodedPixel ep[]);

/* escreve o metarquivo */
void write_metafile(FILE* file, ColorBlocks cb, EncodedPixel img[]);

/* escreve o arquivo bin�rio */
void write_binary(EncodedPixel data[], int size, FILE* file);


/* ===== DECODIFICA��O ===== */

/* l� o metarquivo */
void read_metafile(FILE* file, ColorBlocks *cb, EncodedPixel **pixels);

/* l� o arquivo bin�rio */
void read_binary(FILE* file, EncodedPixel data[], int size);

/* decodifica o valor de uma cor de um pixel (1 byte) */
short decode_pixel(EncodedPixel pixel);

/* decodifica os pixels */
void decode_pixels(ColorBlocks cb, EncodedPixel p[]);

/* desnormaliza os valores dos pixels */
void denormalize_colors(ColorBlocks *cb);

/* junta os blocos de pixels */
void join_blocks(ColorMatrices cm, ColorBlocks *cb);

/* junta as cores dos pixels lidos */
void merge_colors(short raw[], ColorMatrices img);

/* escreve o cabe�alho do arquivo bitmap */
void write_bmp_headers(FILE* out, BITMAP_FILE_HEADER fheader, BITMAP_INFO_HEADER iheader);

/* escreve o corpo do arquivo bitmap, pixel a pixel */
void write_bitmap_data(FILE* out, short data[], int size);

#endif
