#include<stdio.h>
#include<math.h>

#include"cg_structures.h"
#include"cg_primitives.h"
#include"cg_print_svg.h"

int main(void){
    int numberOfPoints , i;
    scanf("%d", &numberOfPoints );

    point2d* pointsCloud=(point2d*) malloc(numberOfPoints * sizeof(point2d));

    for( i = 0 ; i < numberOfPoints ; ++i){
        scanf("%f %f", &pointsCloud[i].x , &pointsCloud[i].y);
    }

    qsort(pointsCloud , numberOfPoints , sizeof pointsCloud[0] , Point_Comp);

    NodeBi* head = NULL;
    head = Alloc_NodeBi( head , pointsCloud[0] );
    NodeBi* tail = head;
    head = Alloc_NodeBi( head , pointsCloud[1] );
    int test, aux = 2;
    i = 2;
    NodeBi* lastPointAdd = (NodeBi*) malloc(sizeof(NodeBi));
    while ( aux < 3 && i < numberOfPoints ){
        test = Point_Position (pointsCloud[i] , pointsCloud[i-1] , pointsCloud[0]);
        if( test == 1 ){
            head = Alloc_NodeBi( head , pointsCloud[i] );
            ++i;
            lastPointAdd = head;
            ++aux;
        } else
            if( test == 2 ) {
                lastPointAdd -> pointNode = pointsCloud[i];
                lastPointAdd -> nextPtr = head;
                lastPointAdd -> priorPtr = tail;
                tail -> nextPtr = lastPointAdd;
                head -> priorPtr = lastPointAdd;
                ++i;
                ++aux;
            }
            else ++i;
    }
    if (aux == 2){
        fprintf( stderr , "Inline points, the extreme are ( %f , %f ) and ( %f , %f )\n", pointsCloud[0].x , pointsCloud[0].y ,
                 pointsCloud[numberOfPoints].x , pointsCloud[numberOfPoints].y);
        return 0;
    }

    tail -> priorPtr = head;
    head -> nextPtr = tail;

    for (; i < numberOfPoints ; ++i ){
        NodeBi* pointL = (NodeBi*) malloc(sizeof (NodeBi));
        pointL -> pointNode = pointsCloud[i];
        lastPointAdd = Find_Edge( pointL , lastPointAdd );
    }

    i = Min_x(pointsCloud , numberOfPoints);
    float xMin = pointsCloud[i].x;

    i = Min_y(pointsCloud , numberOfPoints);
    float yMin = pointsCloud[i].y;

    i = Max_x(pointsCloud , numberOfPoints);
    float xMax = pointsCloud[i].x;

    i = Max_y(pointsCloud , numberOfPoints);
    float yMax = pointsCloud[i].y;

    float w = xMax - xMin;
    float h = yMax - yMin;

    Print_Head( xMin , yMin , w , h);
    Print_Polygons_ListBi( lastPointAdd , "grey" , "blue" , 0.7f );
    if(numberOfPoints <= 10000) Print_Points(pointsCloud , numberOfPoints , "Aquamarine" , 0.5f);
    Print_Points_ListBi( lastPointAdd , "red" , 0.7f );
    Print_Tail();

    return 0;
}

