#ifndef __CG_PRIMITIVES__
#define __CG_PRIMITIVES__

#include"cg_structures.h"
#include<math.h>
#include<stdlib.h>

int Min_x( point2d pointCloud[] ,int nunberOfPoints );
int Min_y( point2d pointCloud[] ,int nunberOfPoints );
int Max_x( point2d pointCloud[] ,int nunberOfPoints );
int Max_y( point2d pointCloud[] ,int nunberOfPoints );
int Point_Position( point2d origem , point2d final , point2d test );
NodeSimple* Alloc_NodeSimple( NodeSimple* list , point2d point );
NodeBi* Alloc_NodeBi( NodeBi* list , point2d points );
int Point_Comp( const void* p1 , const void* p2 );
NodeBi* Find_Edge( NodeBi* pointL , NodeBi* tmp );
void Free_Garbage(NodeBi* leftB , NodeBi* rightB );

int Min_x( point2d pointCloud[] , int numberOfPoints ){
    int auxMin , i;
    auxMin = 0;
    for( i = 0 ; i < numberOfPoints ; ++i){
        if(( pointCloud[i].x == pointCloud[auxMin].x) &&
           ( pointCloud[i].y <  pointCloud[auxMin].y)) auxMin=i;
        if( pointCloud[i].x < pointCloud[auxMin].x) auxMin=i;
    }
    return auxMin;
}

int Min_y( point2d pointCloud[] , int numberOfPoints ){
    int auxMin , i;
    auxMin = 0;
    for( i = 0 ; i < numberOfPoints ; ++i){
        if(( pointCloud[i].y == pointCloud[auxMin].y) &&
           ( pointCloud[i].x >  pointCloud[auxMin].x)) auxMin=i;
        if( pointCloud[i].y < pointCloud[auxMin].y) auxMin=i;
    }
    return auxMin;
}

int Max_x( point2d pointCloud[] , int numberOfPoints ){
    int auxMax , i;
    auxMax = 0;
    for( i = 0 ; i < numberOfPoints ; ++i){
        if(( pointCloud[i].x == pointCloud[auxMax].x) &&
           ( pointCloud[i].y >  pointCloud[auxMax].y)) auxMax=i;
        if( pointCloud[i].x > pointCloud[auxMax].x) auxMax=i;
    }
    return auxMax;
}

int Max_y( point2d pointCloud[] , int numberOfPoints ){
    int auxMax , i;
    auxMax = 0;
    for( i = 0 ; i < numberOfPoints ; ++i){
        if(( pointCloud[i].y == pointCloud[auxMax].y) &&
           ( pointCloud[i].x <  pointCloud[auxMax].x)) auxMax=i;
        if( pointCloud[i].y > pointCloud[auxMax].y) auxMax=i;
    }
    return auxMax;
}

int Point_Position( point2d origem , point2d final , point2d test ){
    float vectorProduct;
    vectorProduct = ((final.x-origem.x)*(test.y-origem.y))-((final.y-origem.y)*(test.x-origem.x));
    if ( vectorProduct < -1.0E-18 ) return 1; /*Right*/
    if ( vectorProduct >  1.0E-18 ) return 2; /*Left*/
    if ( (fabs(vectorProduct)) <= 1.0E-18 ) { 
        if ( ( (origem.x <= final.x) && (origem.x > test.x) ) || ( (origem.x >= final.x) && (origem.x < test.x) ) ||
             ( (origem.y <= final.y) && (origem.y > test.y) ) || ( (origem.y >= final.y) && (origem.y < test.y) )) return 3; /*Before*/
        if ( ( (origem.x <= final.x) && (final.x < test.x) )  || ( (origem.x >= final.x) && (final.x > test.x)  )  ||
             ( (origem.y <= final.y) && (final.y < test.y) )  || ( (origem.y >= final.y) && (final.y > test.y)  )) return 4; /*After*/
        if ( ( (origem.x <= test.x)  && (final.x >= test.x) ) || ( (origem.x >= test.x)  && (final.x <= test.x) )  ||
             ( (origem.y <= test.y)  && (final.y >= test.y) ) || ( (origem.y >= test.y)  && (final.y <= test.y) )) return 5; /*Between*/
    }
    return 0; /*erro*/
}

NodeSimple* Alloc_NodeSimple( NodeSimple* list , point2d point ){
    NodeSimple* tmp = (NodeSimple*) malloc(sizeof(NodeSimple));
    tmp -> pointNode  = point;
    tmp -> nodePtr = list;
    return tmp;
}

NodeBi* Alloc_NodeBi( NodeBi* list , point2d point ){
    NodeBi* tmp = ( NodeBi* ) malloc(sizeof( NodeBi ));
    tmp -> pointNode = point;
    tmp -> priorPtr  = list;
    tmp -> nextPtr   = NULL;
    if( list != NULL ) list -> nextPtr  = tmp;
    return tmp;
}

int Point_Comp( const void* p1 , const void* p2 ){

    const point2d* point1 = (const point2d*) p1;
    const point2d* point2 = (const point2d*) p2;

    if(( point1 -> x == point2 -> x)){
        if  ( (point1->y - point2->y) < 0.0f ) return -1;
        if  ( (point1->y - point2->y) > 0.0f ) return 1;
        if  ( point1->y == point2->y ) return 0;
    } 
    if  ( (point1->x - point2->x) < 0.0f ) return -1;
    return 1;
}

NodeBi* Find_Edge( NodeBi* pointL , NodeBi* tmp ){
        pointL -> nextPtr = tmp;
        int test = 0;
        while ( test != 1 ){
            test = Point_Position ( pointL -> pointNode , tmp -> pointNode , tmp -> priorPtr -> pointNode );
            tmp = tmp -> priorPtr;
        }
        tmp = tmp -> nextPtr;
        pointL -> priorPtr = tmp;
        tmp = pointL -> nextPtr;
        test = 0;
        while  ( test != 2 ) {
            test = Point_Position ( pointL -> pointNode , tmp -> pointNode , tmp -> nextPtr -> pointNode );
            tmp = tmp -> nextPtr;
        }
        tmp = tmp -> priorPtr;
        pointL -> nextPtr = tmp;
        if(pointL -> priorPtr -> nextPtr != pointL -> nextPtr ){
            Free_Garbage( pointL -> priorPtr -> nextPtr , pointL -> nextPtr -> priorPtr );
        }
        pointL -> priorPtr -> nextPtr = pointL;
        pointL -> nextPtr -> priorPtr = pointL;
        return pointL;
}

void Free_Garbage(NodeBi* leftB , NodeBi* rightB ){
    NodeBi* tmp = leftB;
    while( tmp != rightB ){
        tmp = tmp -> nextPtr ;
        free( tmp -> priorPtr ) ;
    }
    free(tmp);
}



#endif //__CG_PRIMITIVES__
