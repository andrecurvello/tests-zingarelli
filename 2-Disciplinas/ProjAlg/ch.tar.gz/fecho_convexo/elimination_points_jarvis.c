#include<math.h>
#include<stdio.h>

#include"cg_structures.h"
#include"cg_primitives.h"
#include"cg_print_svg.h"

int main(void){
    int numberOfPoints , i;
    scanf("%d", &numberOfPoints );

    point2d* pointsCloud=(point2d*) malloc(numberOfPoints * sizeof(point2d));

    for( i = 0 ; i < numberOfPoints ; ++i){
        scanf("%f %f", &pointsCloud[i].x , &pointsCloud[i].y);
    }

    int p1,p2,p3,p4;
    p1 = Min_x(pointsCloud , numberOfPoints);
    p2 = Min_y(pointsCloud , numberOfPoints);
    p3 = Max_x(pointsCloud , numberOfPoints);
    p4 = Max_y(pointsCloud , numberOfPoints); 

    point2d* pointBag = (point2d*)malloc( (numberOfPoints + 3) * sizeof(point2d) );

    pointBag[0] = pointsCloud[p1];
    pointBag[1] = pointsCloud[p2];
    pointBag[2] = pointsCloud[p3];
    pointBag[3] = pointsCloud[p4];

    float xMin = pointBag[0].x;
    float yMin = pointBag[1].y;
    float w = pointBag[2].x - xMin;
    float h = pointBag[3].y - yMin;


    int subNumberOfPoints = 4 ;
    int ptest1 , ptest2 , ptest3 , ptest4;

    for (i = 0 ; i < numberOfPoints ; ++i ){
        ptest1 = Point_Position( pointBag[0] , pointBag[1] , pointsCloud[i]);
        ptest2 = Point_Position( pointBag[1] , pointBag[2] , pointsCloud[i]);
        ptest3 = Point_Position( pointBag[2] , pointBag[3] , pointsCloud[i]);
        ptest4 = Point_Position( pointBag[3] , pointBag[0] , pointsCloud[i]);
        if ( ptest1 == 1 || ptest2 == 1 || ptest3 == 1 || ptest4 == 1){
            pointBag[subNumberOfPoints] = pointsCloud[i];
            ++subNumberOfPoints;
        }
    }
    free(pointsCloud);

    point2d* newPointCloud = (point2d*)malloc( (subNumberOfPoints) * sizeof(point2d) );

    for ( i = 0 ; i < subNumberOfPoints; ++i){
        newPointCloud[i]=pointBag[i];
    }
    free(pointBag);

// aplicando jarvis

    int next = 0;
    int aux  = 1;
    int test , ptest; 

    point2d* convexHull=(point2d*) malloc(subNumberOfPoints * sizeof(point2d));
    convexHull[0] = newPointCloud[0]; 
    int cHnumberOfPoints=0;
    while ( aux != 0 ){
        test = next;
        if( test == 0 ) next = 1;
        else next = 0;
        ++cHnumberOfPoints;
        for( i = 0 ; i < subNumberOfPoints ; ++i ){
                ptest = Point_Position( newPointCloud[test] , newPointCloud[next] , newPointCloud[i]);
                if( ptest == 1 || ptest == 4 ) next = i;
            } 
        convexHull[cHnumberOfPoints] = newPointCloud[next]; 
        aux = next ;
    }

// SVG output
    Print_Head( xMin , yMin , w , h);
    Print_Polygons( convexHull , cHnumberOfPoints , "silver" , "blue" , 0.7f );
    if( subNumberOfPoints <= 10000 ) Print_Points( newPointCloud , subNumberOfPoints , "Aquamarine" , 0.5f );
    Print_Points( convexHull , cHnumberOfPoints , "red" , 0.7f );
    Print_Tail();

    return 0;
}
