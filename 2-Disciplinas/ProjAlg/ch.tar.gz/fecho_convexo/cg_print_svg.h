#ifndef __CG_PRINT_SVG__
#define __CG_PRINT_SVG__

#include"cg_structures.h"
#include"cg_primitives.h"
#include<math.h>

void Print_Head(float xMin , float yMin , float w , float h);
void Print_Points(point2d pointCloud[], int numberOfPoints , char color[] , float pointRadius);
void Print_Points_List(NodeSimple* list ,char color[] , float pointRadius);
void Print_Polygons(point2d pointCloud[], int numberOfPoints , char colorFill[] , char colorStroke[] , float stroke);
void Print_Polygons_List( NodeSimple* list , char colorFill[] , char colorStroke[] , float stroke );
void Print_Points_ListBi(NodeBi* list,char color[] , float pointRadius);
void Print_Polygons_ListBi(NodeBi* list , char colorFill[] , char colorStroke[] , float stroke );
void Print_Tail(void);

void Print_Head(float xMin , float yMin , float w , float h){
    float eps = 2.0f;
    xMin = xMin - eps;
    yMin = yMin - eps;
    w    =  w   + 2*eps;
    h    =  h   + 2*eps;

    printf("<?xml version=\"1.0\" standalone=\"no\"?>\n");
    printf("<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\"\n") ;
    printf("  \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\">\n");
    printf("  <svg width=\"640px\" height =\"480px\" version=\"1.1\"\n");
    printf("     viewBox=\"%0.2f %0.2f %0.2f %0.2f\" preserveAspectRatio=\"meetOrSlice\" ", xMin , yMin , w , h);
    printf("xmlns=\"http://www.w3.org/2000/svg\">\n");
    printf("   <desc>Computacional - Geometry</desc>\n");
    printf("<g>\n");
}

void Print_Points(point2d pointCloud[], int numberOfPoints , char color[] , float pointRadius){
    int i;
    printf("\n <g>");
    for(i=0 ; i<numberOfPoints ; ++i){
        printf("<circle cx=\"%f\" cy=\"%f\" r=\"%0.2f\" fill=\"%s\"/>\n" , pointCloud[i].x , pointCloud[i].y , pointRadius , color );
    }
    printf("\n </g>\n" );
}

void Print_Points_List(NodeSimple* list,char color[] , float pointRadius){
    NodeSimple* tmp = list;
    printf("\n <g>");
    while( tmp != NULL ){
        printf("<circle cx=\"%f\" cy=\"%f\" r=\"%0.2f\" fill=\"%s\"/>\n" , tmp -> pointNode.x , tmp -> pointNode.y , pointRadius , color );
        tmp = tmp -> nodePtr;
    }
    printf("\n </g>\n" );
}

void Print_Points_ListBi(NodeBi* list,char color[] , float pointRadius){
    NodeBi* tmp = list->nextPtr;
    printf("\n <g>");
    while( tmp != list ){
        printf("<circle cx=\"%f\" cy=\"%f\" r=\"%0.2f\" fill=\"%s\"/>\n" , tmp -> pointNode.x , tmp -> pointNode.y , pointRadius , color );
        tmp = tmp -> nextPtr;
    }
    printf("<circle cx=\"%f\" cy=\"%f\" r=\"%0.2f\" fill=\"%s\"/>\n" , list -> pointNode.x , list -> pointNode.y , pointRadius , color );

    printf("\n </g>\n" );
}

void Print_Polygons(point2d pointCloud[], int numberOfPoints , char colorFill[] , char colorStroke[] , float stroke){
    int i;
    printf("\n<polygon fill=\"%s\" stroke=\"%s\" stroke-width=\"%fpt\" points=\"",  colorFill , colorStroke , stroke);
    for(i=0 ; i<numberOfPoints ; ++i){
        printf("%f,%f " , pointCloud[i].x , pointCloud[i].y );
    }
    printf("\" /> \n");
}

void Print_Polygons_List(NodeSimple* list , char colorFill[] , char colorStroke[] , float stroke ){
    NodeSimple* tmp = list;
    printf("\n<polygon fill=\"%s\" stroke=\"%s\" stroke-width=\"%fpt\" points=\"",  colorFill , colorStroke , stroke);
    while( tmp != NULL ){
        printf("%f,%f " , tmp -> pointNode.x , tmp -> pointNode.y );
        tmp = tmp -> nodePtr;
    }
    printf("\" /> \n");
}

void Print_Polygons_ListBi(NodeBi* list , char colorFill[] , char colorStroke[] , float stroke ){
    NodeBi* tmp = list -> nextPtr;
    printf("\n<polygon fill=\"%s\" stroke=\"%s\" stroke-width=\"%fpt\" points=\"",  colorFill , colorStroke , stroke);
    while( tmp != list ){
        printf("%f,%f " , tmp -> pointNode.x , tmp -> pointNode.y );
        tmp = tmp -> nextPtr;
    }
    printf("%f,%f " , list -> pointNode.x , list -> pointNode.y );
    printf("\" /> \n");
}

void Print_Tail(void){
    printf("\n</g>\n</svg> \n");
}

#endif // __CG_PRINT_SVG__
