#include<math.h>
#include<stdio.h>

#include"cg_structures.h"
#include"cg_primitives.h"
#include"cg_print_svg.h"

int main(void){
    int numberOfPoints , i;
    scanf("%d", &numberOfPoints );

    point2d* pointsCloud=(point2d*) malloc(numberOfPoints * sizeof(point2d));

    for( i = 0 ; i < numberOfPoints ; ++i){
        scanf("%f %f", &pointsCloud[i].x , &pointsCloud[i].y);
    }

    int p1,p2,p3,p4;
    p1 = Min_x(pointsCloud , numberOfPoints);
    p2 = Min_y(pointsCloud , numberOfPoints);
    p3 = Max_x(pointsCloud , numberOfPoints);
    p4 = Max_y(pointsCloud , numberOfPoints); 

    point2d* pointBag = (point2d*)malloc( (numberOfPoints + 3) * sizeof(point2d) );

    pointBag[0] = pointsCloud[p1];
    pointBag[1] = pointsCloud[p2];
    pointBag[2] = pointsCloud[p3];
    pointBag[3] = pointsCloud[p4];

    float xMin = pointBag[0].x;
    float yMin = pointBag[1].y;
    float w = pointBag[2].x - xMin;
    float h = pointBag[3].y - yMin;

    int subNumberOfPoints = 4 ;
    int ptest1 , ptest2 , ptest3 , ptest4;

    for (i = 0 ; i < numberOfPoints ; ++i ){
        ptest1 = Point_Position( pointBag[0] , pointBag[1] , pointsCloud[i]);
        ptest2 = Point_Position( pointBag[1] , pointBag[2] , pointsCloud[i]);
        ptest3 = Point_Position( pointBag[2] , pointBag[3] , pointsCloud[i]);
        ptest4 = Point_Position( pointBag[3] , pointBag[0] , pointsCloud[i]);
        if ( ptest1 == 1 || ptest2 == 1 || ptest3 == 1 || ptest4 == 1){
            pointBag[subNumberOfPoints] = pointsCloud[i];
            ++subNumberOfPoints;
        }
    }
    free(pointsCloud);

    point2d* newPointCloud = (point2d*)malloc( (subNumberOfPoints) * sizeof(point2d) );
    for ( i = 0 ; i < subNumberOfPoints; ++i){
        newPointCloud[i]=pointBag[i];
    }
    free(pointBag);

// aplicando graham

    qsort(newPointCloud , subNumberOfPoints , sizeof newPointCloud[0] , Point_Comp);

    NodeBi* head = NULL;
    head = Alloc_NodeBi( head , newPointCloud[0] );
    NodeBi* tail = head;
    head = Alloc_NodeBi( head , newPointCloud[1] );

    int gtest, gaux = 2;
    i = 2;
    NodeBi* lastPointAdd = (NodeBi*) malloc(sizeof(NodeBi));
    while ( gaux < 3 && i < subNumberOfPoints ){
        gtest = Point_Position (newPointCloud[i] , newPointCloud[i-1] , newPointCloud[0]);
        if( gtest == 1 ){
            head = Alloc_NodeBi( head , newPointCloud[i] );
            ++i;
            lastPointAdd = head;
            ++gaux;
        } else
            if( gtest == 2 ) {
                lastPointAdd -> pointNode = newPointCloud[i];
                lastPointAdd -> nextPtr = head;
                lastPointAdd -> priorPtr = tail;
                tail -> nextPtr = lastPointAdd;
                head -> priorPtr = lastPointAdd;
                ++i;
                ++gaux;
            }
            else ++i;
    }
    if (gaux == 2){
        Print_Head( xMin , yMin , w , h);
        Print_Polygons_ListBi( lastPointAdd , "grey" , "blue" , 0.7f );
        if(subNumberOfPoints <= 10000) Print_Points(newPointCloud , subNumberOfPoints , "Aquamarine" , 0.5f);
        Print_Points_ListBi( lastPointAdd , "red" , 0.7f );
        Print_Tail();
        return 0;
    }

    tail -> priorPtr = head;
    head -> nextPtr = tail;

    for (; i < subNumberOfPoints ; ++i ){
        NodeBi* pointL = (NodeBi*) malloc(sizeof (NodeBi));
        pointL -> pointNode = newPointCloud[i];
        lastPointAdd = Find_Edge( pointL , lastPointAdd );
    }

// SVG output
    Print_Head( xMin , yMin , w , h);
    Print_Polygons_ListBi( lastPointAdd , "grey" , "blue" , 0.7f );
    if(subNumberOfPoints <= 10000) Print_Points(newPointCloud , subNumberOfPoints , "Aquamarine" , 0.5f);
    Print_Points_ListBi( lastPointAdd , "red" , 0.7f );
    Print_Tail();

    return 0;

}
