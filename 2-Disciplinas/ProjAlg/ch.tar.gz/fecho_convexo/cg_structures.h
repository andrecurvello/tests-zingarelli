#ifndef __CG_STRUCTURES__
#define __CG_STRUCTURES__

typedef struct point2d {
    float x , y;
} point2d;

typedef struct NodeSimple {
    point2d pointNode;
    struct NodeSimple* nodePtr;
 } NodeSimple;

typedef struct NodeBi {
    point2d pointNode;
    struct NodeBi* priorPtr;
    struct NodeBi* nextPtr; 
} NodeBi;

#endif //__CG_STRUCTURES__
