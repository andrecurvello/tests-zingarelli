#include<stdio.h>
#include<math.h>

#include"cg_structures.h"
#include"cg_primitives.h"
#include"cg_print_svg.h"

int main(void){
    int numberOfPoints , i;
    scanf("%d", &numberOfPoints );

    point2d* pointsCloud=(point2d*) malloc(numberOfPoints * sizeof(point2d));

    for( i = 0 ; i < numberOfPoints ; ++i){
        scanf("%f %f", &pointsCloud[i].x , &pointsCloud[i].y);
    }

    int minX = Min_x(pointsCloud , numberOfPoints);
    int next = minX;
    int aux  = minX+1;
    int test , ptest; 

    point2d* convexHull=(point2d*) malloc(numberOfPoints * sizeof(point2d));
    convexHull[0] = pointsCloud[minX]; 
    int convexHullnumberOfPoints=0;
    while (aux != minX){
        test = next;
        if(test == 0) next = 1;
        else next = 0;
        ++convexHullnumberOfPoints;
        for( i = 0 ; i < numberOfPoints ; ++i ){
            ptest=Point_Position( pointsCloud[test] , pointsCloud[next] , pointsCloud[i]);
            if(ptest==1 || ptest==4) next = i;
        } 
        convexHull[convexHullnumberOfPoints] = pointsCloud[next]; 
        aux = next ;
    }

    float xMin = convexHull[0].x;

    i = Min_y(convexHull , convexHullnumberOfPoints);
    float yMin = convexHull[i].y;

    i = Max_x(convexHull , convexHullnumberOfPoints);
    float xMax = convexHull[i].x;

    i = Max_y(convexHull , convexHullnumberOfPoints);
    float yMax = convexHull[i].y;

    float w = xMax - xMin;
    float h = yMax - yMin;

    Print_Head( xMin , yMin , w , h);
    Print_Polygons(convexHull, convexHullnumberOfPoints , "grey" , "blue" , 0.7f );
    if(numberOfPoints <= 10000) Print_Points(pointsCloud , numberOfPoints , "Aquamarine" , 0.5f);
    Print_Points(convexHull, convexHullnumberOfPoints , "red" , 0.7f);
    Print_Tail();

    return 0;
}
