/* SCC0261 MULTIM�DIA - 1� SEMESTRE DE 2011
 * DOCENTE: RUDINEI GOULARTE
 * 
 * PROJETO: COMPRESS�O DE IMAGEM DIGITAL PARTE 2
 * 
 * ALUNOS:
 * 	Jairo Toshio Tuboi 			6427250
 * 	Ricardo Takashi Kagawa		5634712
 * 	Rodrigo Luis Gava Girckus 	5967770
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "codec.h"
#include "parte1.h"
#include "parte2.h"

char* itob(int value, int size, char buffer[]) {
	int bit, mask, i, p, n = size + size / 8;
	if(size % 8 == 0 && size > 0) n--;
	buffer[n] = 0; p = n - 1; mask = 1;
	for(i = 0; i < size; i++) {
		if(i % 8 == 0 && i > 0) buffer[p--] = ' ';
		bit = value & mask;
		buffer[p--] = (bit == 0)? '0': '1';
		value = ~mask & value;
		mask <<= 1;
	}
	return buffer;
}

/* codifica o arquivo bitmap em um bin�rio comprimido */
int encode(FILE* bmp, FILE* bin, FILE* meta) {
	BITMAP_FILE_HEADER fh;
	BITMAP_INFO_HEADER ih;
	ColorMatrices img;
	ColorBlocks cb;
	BlockVectors bv;
	RunLengthBlocks rb;
	
	short *raw_data, *dc;
	EncodedValue *enc_dc;
	HuffmanNode dc_tree, ac_tree;
	HuffmanDictionary dc_map, ac_map;
	
	int n;
	EncodedValue *enc_data;
	
	/* lendo e verificando headers */
	read_bmp_headers(bmp, &fh, &ih);
	if(strcmp(fh.type, "BM") != 0 || fh.offBits != 54) {
		return CD_FILE_TYPE_ERROR;
	} else if(ih.size != 40) {
		return CD_FILE_TYPE_ERROR;
	} else if(ih.width % 8 != 0 || ih.height % 8 != 0) {
		return CD_FILE_FORMAT_ERROR;
	} else if(ih.width < 8 || ih.height < 8) {
		return CD_FILE_FORMAT_ERROR;
	} else if(ih.width > 1280 || ih.height > 800) {
		return CD_FILE_FORMAT_ERROR;
	} else if(ih.bitCount != 24 || ih.compression != 0) {
		return CD_FILE_FORMAT_ERROR;
	}
	
	ih.sizeImage = 3 * ih.width * ih.height;
	
	/* lendo a imagem */
	raw_data = (short*) malloc(ih.sizeImage * sizeof(short));
	read_bitmap_data(bmp, raw_data, ih.sizeImage);
	
	/* separando as cores */
	CM_init(ih.width, ih.height, &img);
	separate_colors(raw_data, &img);
	free(raw_data);
	
//	CM_print(img);
	
	/* separando e normalizando os blocos */
	CB_init(img.width, img.height, &cb);
	separate_blocks(img, &cb);
	normalize_colors(&cb);
	CM_free(img);
	
//	CB_print(cb);

	/* escrevendo o cabe�alho */
	write_header(bin, cb.width, cb.height);
	
	/* vetorizando os blocos */
	BV_init(&bv, 3 * cb.width * cb.height);
	trace_blocks(cb, &bv);
	
//	BV_print(bv);
	
	/* codificando os valores DC
	de cada bloco por diferen�as */
	dc = (short*) malloc(bv.size * sizeof(short));
	encode_dc(bv, dc);
	
//	for(n = 0; n < bv.size; n++)
//		printf("%d ", dc[n]);
//	putchar('\n'); putchar('\n');
	
	/* codificando os valores DCs */
	enc_dc = (EncodedValue*) malloc(bv.size * sizeof(EncodedValue));
	encode_dc_values(dc, enc_dc, bv.size);
	free(dc);
	
//	EV_print(enc_dc, bv.size);
//	putchar('\n'); putchar('\n');
	
	/* gerando os c�digos Huffman dos metadados DCs */
	n = huffman_dc(enc_dc, bv.size, &dc_tree);
	HD_init(&dc_map, n);
	build_encode_dictionary(&dc_tree, &dc_map);
	
//	HN_print(dc_tree);
//	putchar('\n'); putchar('\n');
//	HD_print(dc_map);
	
	/* escrevendo o decodificador Huffman para DCs */
	write_dc_decoder(bin, dc_tree);
	HN_free(dc_tree);
	
	/* codificando os valores AC 
	de cada bloco por run-length */
	RLB_init(&rb, 3 * cb.width * cb.height);
	encode_ac(bv, rb);
	CB_free(cb);
	BV_free(bv);

//	RLB_print(rb, 0);
	
	/* codificando os valores ACs */
	encode_ac_values(rb);
	
//	RLB_print(rb, 1);
	
	/* gerando os c�digos Huffman dos metadados ACs */
	n = huffman_ac(rb, &ac_tree);
	HD_init(&ac_map, n);
	build_encode_dictionary(&ac_tree, &ac_map);

//	HN_print(ac_tree);
//	putchar('\n'); putchar('\n');
//	HD_print(ac_map);
	
	write_ac_decoder(bin, ac_tree);
	
	/* codificando e escrevendo os DCs */
	n = 2 * 3 * cb.width * cb.height;
	enc_data = (EncodedValue*) malloc(n * sizeof(EncodedValue));
	
	encode_dc_data(enc_data, &n, enc_dc, bv.size, dc_map);
	write_data(bin, enc_data, n);
	
//	EV_print(enc_data, n);
//	putchar('\n'); putchar('\n');
	
	HD_free(dc_map);
	free(enc_data);
	free(enc_dc);
	
	/* codificando e escrevendo os ACs */
	n = 2 * 3 * CB_BLOCK_SIZE * CB_BLOCK_SIZE * cb.width * cb.height;
	enc_data = (EncodedValue*) malloc(n * sizeof(EncodedValue));
	
	encode_ac_data(enc_data, &n, rb, ac_map);
	write_data(bin, enc_data, n);
	
//	EV_print(enc_data, n);
//	putchar('\n'); putchar('\n');
	
	HD_free(ac_map);
	HN_free(ac_tree);
	RLB_free(rb);
	free(enc_data);
	
	return CD_SUCCESSFUL;
}

/* decodifica o arquivo bitmap de um bin�rio comprimido */
int decode(FILE* bmp, FILE* bin, FILE* meta) {
	BITMAP_FILE_HEADER fh;
	BITMAP_INFO_HEADER ih;
	ColorMatrices img;
	ColorBlocks cb;
	
	short *raw_data, *dc;
	int n, w, h, i;
	
	HuffmanNode dc_tree, ac_tree;
	RunLengthBlocks rb;
	
	EncodedValue *enc_dc;
	BlockVectors bv;
	
	/* lendo o cabe�alho */
	read_header(bin, &w, &h);
//	printf("%d %d\n\n", w, h);
	
	/* lendo o decodificador Huffman DC */
	read_dc_decoder(bin, &dc_tree);
//	HN_print(dc_tree);
//	putchar('\n'); putchar('\n');
	
	/* lendo o decodificador Huffman AC */
	read_ac_decoder(bin, &ac_tree);
//	HN_print(ac_tree);
//	putchar('\n'); putchar('\n');
	
	/* lendo os dados DC */
	n = 3 * w * h;
	enc_dc = (EncodedValue*) malloc(n * sizeof(EncodedValue));
	read_dc_data(bin, &dc_tree, enc_dc, n);
	HN_free(dc_tree);
	
//	EV_print(enc_dc, n);
//	putchar('\n'); putchar('\n');
	
	/* lendo os dados AC */
	RLB_init(&rb, n);
	read_ac_data(bin, &ac_tree, &rb);
	HN_free(ac_tree);
	
//	RLB_print(rb, 1);
//	putchar('\n'); putchar('\n');
	
	/* decodificando os valores ACs e DCs */
	dc = (short*) malloc(n * sizeof(short));
	decode_dc_values(dc, enc_dc, n);
	decode_ac_values(rb);
	free(enc_dc);
	
//	for(i = 0; i < n; i++)
//		printf("%d ", dc[i]);
//	putchar('\n'); putchar('\n');
	
//	RLB_print(rb, 0);
	
	/* decodificando as diferen�as e carreiras */
	BV_init(&bv, n);
	decode_dc(bv, dc);
	decode_ac(bv, rb);
	RLB_free(rb);
	free(dc);
	
//	BV_print(bv);
	
	/* desvetorizando os blocos */
	CB_init(CB_BLOCK_SIZE * w, CB_BLOCK_SIZE * h, &cb);
	detrace_blocks(cb, bv);
	BV_free(bv);
	
	/* denormalizando os pixels */
	denormalize_colors(&cb);
//	CB_print(cb);
	
	/* juntando os blocos */
	CM_init(CB_BLOCK_SIZE * w, CB_BLOCK_SIZE * h, &img);
	join_blocks(img, &cb);
	CB_free(cb);
	
//	CM_print(img);
	
	/* juntando as cores */
	n = 3 * w * h * CB_BLOCK_SIZE * CB_BLOCK_SIZE;
	raw_data = (short*) malloc(n * sizeof(short));
	merge_colors(raw_data, img);

	/* escrevendo o bitmap */
	strcpy(fh.type, "BM");
	fh.offBits = 54;
	fh.reserved1 = fh.reserved2 = 0;
	
	ih.size = 40;
	ih.width = img.width;
	ih.height = img.height;
	ih.bitCount = 24;
	ih.compression = 0;
	ih.sizeImage = n;
	ih.planes = 1;
	ih.colorUsed = ih.colorImportant = 0;
	ih.xPixelsPerMeter = 4000;
	ih.yPixelsPerMeter = 4000;
	
	fh.size = ih.sizeImage + fh.offBits;
	write_bmp_headers(bmp, fh, ih);
	write_bitmap_data(bmp, raw_data, n);

	/* limpeza */
	free(raw_data);
	CM_free(img);
	
	return CD_SUCCESSFUL;
}

/* traduz os c�digos de erro para linguagem humana 
 * code - o c�digo de erro
 * buffer - uma string pr�-alocada
 * retorna o pr�prio buffer
 */
char* get_error_message(int code, char buffer[]) {
	switch(code) {
		case CD_SUCCESSFUL: 
			sprintf(buffer, "Sem erro"); 
			break;
		case CD_FILE_TYPE_ERROR: 
			sprintf(buffer, "O arquivo fornecido nao eh um bitmap");
			break;
		case CD_FILE_FORMAT_ERROR: 
			sprintf(buffer, "O arquivo bitmap fornecido nao pode ser processado");
			break;
		default:
			sprintf(buffer, "Erro desconhecido");
			break;
	}
	return buffer;
}
