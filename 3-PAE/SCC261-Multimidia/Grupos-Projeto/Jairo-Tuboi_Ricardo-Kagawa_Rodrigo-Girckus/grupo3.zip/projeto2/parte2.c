/* SCC0261 MULTIM�DIA - 1� SEMESTRE DE 2011
 * DOCENTE: RUDINEI GOULARTE
 * 
 * PROJETO: COMPRESS�O DE IMAGEM DIGITAL PARTE 2
 * 
 * ALUNOS:
 * 	Jairo Toshio Tuboi 			6427250
 * 	Ricardo Takashi Kagawa		5634712
 * 	Rodrigo Luis Gava Girckus 	5967770
 */
#include <stdlib.h>
#include "codec.h"
#include "parte1.h"
#include "parte2.h"

void BV_init(BlockVectors *bv, int size) {
	int i, k;
	bv->size = size;
	bv->values = (short**) malloc(size * sizeof(short*));
	for(k = 0; k < size; k++) {
		bv->values[k] = (short*) malloc(CB_BLOCK_SIZE * CB_BLOCK_SIZE * sizeof(short));
		for(i = 0; i < CB_BLOCK_SIZE * CB_BLOCK_SIZE; i++)
			bv->values[k][i] = 0;
	}
}

void BV_free(BlockVectors bv) {
	int k;
	for(k = 0; k < bv.size; k++)
		free(bv.values[k]);
	putchar('\n');
	free(bv.values);
}

void BV_print(BlockVectors bv) {
	int i, k;
	printf("%d\n\n", bv.size);
	for(k = 0; k < bv.size; k++) {
		for(i = 0; i < CB_BLOCK_SIZE * CB_BLOCK_SIZE; i++)
			printf("%4hd ", bv.values[k][i]);
		putchar('\n');
	}
	putchar('\n');
	return;
}

void RLB_init(RunLengthBlocks *rb, int blocks) {
	int i, j;
	rb->blockCount = blocks;
	
	rb->blockSize = (int*) malloc(blocks * sizeof(int));
	for(i = 0; i < blocks; i++)
		rb->blockSize[i] = 0;
	
	rb->values = (RunLengthPair**) malloc(blocks * sizeof(RunLengthPair*));
	for(i = 0; i < blocks; i++) {
		rb->values[i] = (RunLengthPair*) malloc(CB_BLOCK_SIZE * CB_BLOCK_SIZE * sizeof(RunLengthPair));
		for(j = 0; j < CB_BLOCK_SIZE * CB_BLOCK_SIZE; j++) {
			rb->values[i][j].value.value = 0;
			rb->values[i][j].value.size = 8 * sizeof(short);
			rb->values[i][j].repeat = 0;
		}
	}
}

void RLB_free(RunLengthBlocks rb) {
	int i;
	for(i = 0; i < rb.blockCount; i++)
		free(rb.values[i]);
	free(rb.values);
	free(rb.blockSize);
}

void RLB_print(RunLengthBlocks rb, int encoded) {
	int i, j; char str[255];
	EncodedValue v;
	
	printf("%d\n", rb.blockCount);
	for(i = 0; i < rb.blockCount; i++) {
		printf("%3d::", rb.blockSize[i]);
		for(j = 0; j < rb.blockSize[i]; j++) {
			v = rb.values[i][j].value;
			if(encoded) {
				printf("(%8s:%hd;%-2hd) ", itob(v.value, v.size, str), 
					v.size, rb.values[i][j].repeat);
			} else
				printf("%4d:%-2hd ", v.value, rb.values[i][j].repeat);
		}
		putchar('\n');
	}
	putchar('\n');
}

void HN_free(HuffmanNode node) {
	if(node.type == HN_NODE) {
		HN_free(*(node.left));
		HN_free(*(node.right));
		free(node.left);
		free(node.right);
	}
}

void HN_print(HuffmanNode node) {
	if(node.type == HN_NODE) {
		printf("%d:{", node.freq);
		HN_print(*(node.left));
		printf(";");
		HN_print(*(node.right));
		printf("}");
	} else {
		printf("%d:[%d;%d]", node.freq, 
			node.value.size, node.value.repeat);
	}
}

int HN_height(HuffmanNode node) {
	if(node.type == HN_NODE) {
		int l, r;
		l = HN_height(*(node.left)) + 1;
		r = HN_height(*(node.right)) + 1;
		return (l > r)? l: r;
	} else 
		return 1;
}

void HD_init(HuffmanDictionary *hd, int cap) {
	hd->map = (HuffmanMapping*) malloc(cap * sizeof(HuffmanMapping));
	hd->size = 0;
}

void HD_free(HuffmanDictionary hd) {
	free(hd.map);
}

EncodedValue HD_findCode(HuffmanDictionary hd, MetaData value) {
	int i; EncodedValue v;
	for(i = 0; i < hd.size; i++) {
		if(hd.map[i].value.size == value.size &&
				hd.map[i].value.repeat == value.repeat) {
			return hd.map[i].code;
		}
	}
	v.value = 0;
	v.size = -1;
	return v;
}
void HD_print(HuffmanDictionary hd) {
	int i, max; char str[255];
	
	max = ~(1 << (4 * sizeof(int) - 1));
	for(i = 0; i < hd.size; i++) {
		if(hd.map[i].code.size > max)
			max = hd.map[i].code.size;
	}
	max += max / 8 - ((max % 8 == 0)? 1: 0);
	
	for(i = 0; i < hd.size; i++) {
		MetaData value = hd.map[i].value;
		EncodedValue code = hd.map[i].code;
		printf("(%d, %2d) -> %*s\n", value.size, value.repeat, 
			max, itob(code.value, code.size, str));
	}
	putchar('\n');
}

/* ===== CODIFICA��O ===== */

void trace_blocks(ColorBlocks cb, BlockVectors *bv) {
	int map[CB_BLOCK_SIZE][CB_BLOCK_SIZE] = TRACE_MAP;
	int i, j, k, n = 0;
	for(k = 0; k < cb.width * cb.height; k++) {
		for(i = 0; i < CB_BLOCK_SIZE; i++) {
			for(j = 0; j < CB_BLOCK_SIZE; j++)
				bv->values[n + k][map[i][j]] = cb.red[k][i][j];
		}
	}
	n += cb.width * cb.height;
	for(k = 0; k < cb.width * cb.height; k++) {
		for(i = 0; i < CB_BLOCK_SIZE; i++) {
			for(j = 0; j < CB_BLOCK_SIZE; j++)
				bv->values[n + k][map[i][j]] = cb.green[k][i][j];
		}
	}
	n += cb.width * cb.height;
	for(k = 0; k < cb.width * cb.height; k++) {
		for(i = 0; i < CB_BLOCK_SIZE; i++) {
			for(j = 0; j < CB_BLOCK_SIZE; j++)
				bv->values[n + k][map[i][j]] = cb.blue[k][i][j];
		}
	}
	return;
}

void encode_dc(BlockVectors bv, short delta[]) {
	int i, n = 0;
	//copiando os valores de interesse
	delta[n] = bv.values[0][0];
	for(i = 1; i < bv.size; i++)
		delta[n + i] = bv.values[i][0];
	//calculando as diferen�as
	for(i = bv.size - 1; i > 0; i--)
		delta[i] = delta[i] - delta[i - 1];
}

void run_length(short values[], RunLengthPair rl[], int *n) {
	int i, j, count, size = *n; short last;
	last = values[0]; count = 0; j = 0;
	for(i = 1; i < size; i++) {
		if(values[i] != last) {
			rl[j].value.value = last;
			rl[j].repeat = count;
			count = 0; j++;
		} else
			count++;
		last = values[i];
	}
	rl[j].value.value = last;
	rl[j].repeat = count;
	*n = j + 1;
}

void encode_ac(BlockVectors bv, RunLengthBlocks rb) {
	int i, size;
	for(i = 0; i < bv.size; i++) {
		size = CB_BLOCK_SIZE * CB_BLOCK_SIZE - 1;
		run_length(bv.values[i] + 1, rb.values[i], &size);
		rb.blockSize[i] = size;
	}
}

void encode_dc_values(short values[], EncodedValue enc_values[], int n) {
	int i;
	for(i = 0; i < n; i++)
		enc_values[i] = encode_value(values[i]);
	return;
}

void encode_ac_values(RunLengthBlocks rb) {
	int i, j; short v;
	for(i = 0; i < rb.blockCount; i++) {
		for(j = 0; j < rb.blockSize[i]; j++) {
			v = rb.values[i][j].value.value;
			rb.values[i][j].value = encode_value(v);
		}
	}
	return;
}

void mergesort(HuffmanNode a[], int n) {
	int i, l, r; HuffmanNode *buffer;
	
	if(n == 1) return;
	
	mergesort(a, n / 2);
	mergesort(a + n / 2, n - n / 2);
	
	buffer = (HuffmanNode*) malloc(n * sizeof(HuffmanNode));
	
	l = 0; r = n / 2; i = 0;
	while(l < n / 2 && r < n) {
		buffer[i++] = 
			(a[l].freq >= a[r].freq)? 
			a[l++]: a[r++];
	}
	while(l < n / 2) buffer[i++] = a[l++];
	while(r < n) buffer[i++] = a[r++];
	
	for(i = 0; i < n; i++)
		a[i] = buffer[i];
	
	free(buffer);
	return;
}

void count_frequencies(MetaData data[], int m, HuffmanNode nodes[], int *n) {
	int i, j, found;
	HuffmanNode node;
	
	*n = 0;
	for(i = 0; i < m; i++) {
		found = 0;
		for(j = 0; j < *n && !found; j++) {
			if(!found && nodes[j].value.size == data[i].size && 
					nodes[j].value.repeat == data[i].repeat) {
				nodes[j].freq++;
				found = 1;
			}
		}
		if(!found) {
			node.type = HN_LEAF;
			node.freq = 1;
			node.parent = NULL;
			node.is_left = FALSE;
			node.value = data[i];
			nodes[(*n)++] = node;
		}
	}
	
	return;
}

void huffman(HuffmanNode data[], int n, HuffmanNode* root) {
	HuffmanNode na, nb, nc;
	
	mergesort(data, n);
	while(n > 1) {
		na = data[n - 1];
		nb = data[n - 2];
		nc.type = HN_NODE;
		nc.freq = na.freq + nb.freq;
		nc.left = (HuffmanNode*) malloc(sizeof(HuffmanNode));
		nc.right = (HuffmanNode*) malloc(sizeof(HuffmanNode));
		nc.parent = NULL; nc.is_left = FALSE;
		*(nc.left) = na; *(nc.right) = nb;
		data[n - 2] = nc; n--;
		mergesort(data, n);
	}
	
	*root = data[0];
	return;
}

int huffman_dc(EncodedValue data[], int n, HuffmanNode *root) {
	HuffmanNode nodes[10]; /* valores: 0-8 */
	MetaData *meta; int i, m;
	
	//extrair os metadados
	meta = (MetaData*) malloc(n * sizeof(MetaData));
	for(i = 0; i < n; i++) {
		meta[i].size = data[i].size;
		meta[i].repeat = 0;
	}
	
	//gerar �rvore de Huffman
	count_frequencies(meta, n, nodes, &m);
	huffman(nodes, m, root);
	
	free(meta);
	return m;
}

int huffman_ac(RunLengthBlocks data, HuffmanNode* root) {
	HuffmanNode nodes[600]; /* valores: (0-8)x(0-62) */
	MetaData *meta; int i, j, k, m, n;
	
	//contando o n�mero de pares run-length
	m = 0; k =0;
	for(i = 0; i < data.blockCount; i++)
		m += data.blockSize[i];
	
	//extrair os metadados
	meta = (MetaData*) malloc(m * sizeof(MetaData));
	for(i = 0; i < data.blockCount; i++) {
		for(j = 0; j < data.blockSize[i]; j++) {
			meta[k].size = data.values[i][j].value.size;
			meta[k].repeat = data.values[i][j].repeat; k++;
		}
	}
	
	//gerar �rvore de Huffman
	count_frequencies(meta, m, nodes, &n);
	huffman(nodes, n, root);
	
	free(meta);
	return n;
}

void build_encode_dictionary(HuffmanNode *tree, HuffmanDictionary *hd) {
	HuffmanNode *node; int i;
	EncodedValue code;
	
	//left = 0, right = 1
	code.value = 0;
	code.size = 0;
	i = 0;
	
	node = tree; 
	node->parent = NULL;
	node->is_left = FALSE;
	do {
		if(node->type == HN_LEAF) {
			hd->map[i].value = node->value;
			hd->map[i].code = code; i++;
			hd->size++;
			
			if(node->is_left) {
				node = node->parent->right;
				code.value = (code.value & ~1) | 1;
			} else {
				int found = FALSE;
				node = node->parent;
				code.value >>= 1;
				code.size--;
				while(node != NULL && !found) {
					if(node->is_left) {
						found = TRUE;
					} else {
						node = node->parent;
						code.value >>= 1;
						code.size--;
					}
				}
				if(found) {
					node = node->parent->right;
					code.value = (code.value & ~1) | 1;
				}
			}
		} else {
			node->left->parent = node;
			node->left->is_left = TRUE;
			node->right->parent = node;
			node->right->is_left = FALSE;
			
			node = node->left;
			code.value <<= 1;
			code.size++;
		}
	} while(node != NULL);
	return;
}

void encode_dc_data(EncodedValue out[], int *out_size, 
		EncodedValue in[], int in_size, 
		HuffmanDictionary hd) {
	int i; MetaData d;
	d.repeat = 0;
	(*out_size) = 0;
	for(i = 0; i < in_size; i++) {
		d.size = in[i].size;
		out[(*out_size)++] = HD_findCode(hd, d);
		out[(*out_size)++] = in[i];
	}
	return;
}

void encode_ac_data(EncodedValue out[], int *out_size, 
		RunLengthBlocks rb, HuffmanDictionary hd) {
	int i, j; MetaData d;
	(*out_size) = 0;
	for(i = 0; i < rb.blockCount; i++) {
		for(j = 0; j < rb.blockSize[i]; j++) {
			d.size = rb.values[i][j].value.size;
			d.repeat = rb.values[i][j].repeat;
			out[(*out_size)++] = HD_findCode(hd, d);
			out[(*out_size)++] = rb.values[i][j].value;
		}
	}
	return;
}

void write_header(FILE* out, int width, int height) {
	char w, h;
	w = (char) width;
	h = (char) height;
	fwrite(&w, 1, 1, out);
	fwrite(&h, 1, 1, out);
	return;
}

/* Obt�m o tamanho do decodificador huffman para os 
 * metadados dos valores DC, em n�mero de valores a
 * serem escritos. */
int dc_decoder_size(HuffmanNode node) {
	if(node.type == HN_NODE) {
		int l, r;
		l = dc_decoder_size(*(node.left));
		r = dc_decoder_size(*(node.right));
		return l + r + 1; //left, right, type
	} else 
		return 2; //type, size
}

void encode_dc_node(HuffmanNode node, EncodedValue data[], int *n) {
	EncodedValue type;
	type.value = node.type;
	type.size = 1;
	data[(*n)++] = type;
	if(node.type == HN_NODE) {
		encode_dc_node(*(node.left), data, n);
		encode_dc_node(*(node.right), data, n);
	} else {
		EncodedValue v;
		v.value = node.value.size;
		v.size = 4; /* values: 0-8 */
		data[(*n)++] = v;
	}
	return;
}

void write_dc_decoder(FILE* out, HuffmanNode tree) {
	EncodedValue* data; int n;
	
	n = dc_decoder_size(tree);
	data = (EncodedValue*) malloc(n * sizeof(EncodedValue));
	
	n = 0;
	encode_dc_node(tree, data, &n);
	
//	EV_print(data, n);
//	puts("\n-----");
	
	write_data(out, data, n);
	
	free(data);
	return;
}

/* Obt�m o tamanho do decodificador huffman para os 
 * metadados dos valores DC, em n�mero de valores a
 * serem escritos. */
int ac_decoder_size(HuffmanNode node) {
	if(node.type == HN_NODE) {
		int l, r;
		l = ac_decoder_size(*(node.left));
		r = ac_decoder_size(*(node.right));
		return l + r + 1; //left, right, type
	} else 
		return 3; //type, size, repeat
}

void encode_ac_node(HuffmanNode node, EncodedValue data[], int *n) {
	EncodedValue type;
	type.value = node.type;
	type.size = 1;
	data[(*n)++] = type;
	if(node.type == HN_NODE) {
		encode_ac_node(*(node.left), data, n);
		encode_ac_node(*(node.right), data, n);
	} else {
		EncodedValue vs, vr;
		vs.value = node.value.size;
		vs.size = 4; /* values: 0-8 */
		data[(*n)++] = vs;
		vr.value = node.value.repeat;
		vr.size = 6; /* values: 0-62 */
		data[(*n)++] = vr;
	}
	return;
}

void write_ac_decoder(FILE* out, HuffmanNode tree) {
	EncodedValue* data; int n;
	
	n = ac_decoder_size(tree);
	data = (EncodedValue*) malloc(n * sizeof(EncodedValue));
	
	n = 0;
	encode_ac_node(tree, data, &n);
	
//	EV_print(data, n);
//	puts("\n-----");
	
	write_data(out, data, n);
	
	free(data);
	return;
}

void write_data(FILE * out, EncodedValue data[], int size) {
	int i, buffer, p, n, value, bit, mask;
	/* gravar 1 byte por vez, problemas com endianess */
	
	n = 8; buffer = 0; p = 0;
	for(i = 0; i < size; i++) {
		mask = 1 << (data[i].size - 1);
		value = data[i].value;
		while(mask > 0) {
			bit = value & mask;
			if(bit != 0)
				buffer = buffer | (1 << (n - p - 1));
			value = ~mask & value;
			mask = mask >> 1;
			p++;
			if(p == n) {
				fwrite(&buffer, 1, 1, out);
				buffer = 0; p = 0;
			}
		}
	}
	if(p > 0)
		fwrite(&buffer, 1, 1, out);
	return;
}

/* ===== DECODIFICA��O ===== */

void read_header(FILE* in, int *width, int *height) {
	*width = 0; *height = 0;
	fread(width, 1, 1, in);
	fread(height, 1, 1, in);
	return;
}

int read_bits(FILE* file, int count, int *buffer, int *mask) {
	int p, n, value, bit;
	n = 8; value = 0; p = 0;
	while(p < count) {
		bit = (*buffer) & (*mask);
		if(bit != 0)
			value |= 1 << (count - p - 1);
		(*buffer) = ~(*mask) & (*buffer);
		(*mask) >>= 1; p++;
		if((*mask) == 0) {
			fread(buffer, 1, 1, file);
			(*mask) = 1 << (n - 1);
		}
	}
	return value;
}

HuffmanNode* next_node_from_leaf(HuffmanNode* node) {
	if(node->is_left) {
		node = node->parent->right;
	} else {
		int found = FALSE;
		node = node->parent;
		while(node != NULL && !found) {
			if(node->is_left)
				found = TRUE;
			else
				node = node->parent;
		}
		if(found) node = node->parent->right;
	}
	return node;
}

void set_node(HuffmanNode* node) {
	node->type = HN_NODE;
	
	node->left = (HuffmanNode*) malloc(sizeof(HuffmanNode));
	node->right = (HuffmanNode*) malloc(sizeof(HuffmanNode));
	node->left->freq = 0;
	node->right->freq = 0;
	
	node->left->parent = node;
	node->left->is_left = TRUE;
	node->right->parent = node;
	node->right->is_left = FALSE;
	
	return;
}

void read_dc_decoder(FILE* file, HuffmanNode *tree) {
	int buffer, mask, n, value;
	HuffmanNode *node;
	
	/* ler 1 byte por vez, problemas com endianess */
	
	fread(&buffer, 1, 1, file);
	n = 8; mask = 1 << (n - 1);
	
	node = tree; 
	node->parent = NULL;
	node->is_left = FALSE;
	node->freq = 0; 
	
	/* come�a lendo o tipo do primeiro n� (1 bit) */
	do {
		value = read_bits(file, 1, &buffer, &mask);
		if(value == HN_LEAF) {
			/* n� folha */
			node->type = HN_LEAF;
			
			/* ler dados do n� filho */
			node->value.size = read_bits(file, 4, &buffer, &mask);
			node->value.repeat = 0;
			
			node = next_node_from_leaf(node);
		} else {
			/* n� intermedi�rio */
			set_node(node);
			node = node->left;
		}
	} while(node != NULL);
	return;
}

void read_ac_decoder(FILE* file, HuffmanNode *tree) {
	int buffer, mask, n, value;
	HuffmanNode *node;
	
	/* ler 1 byte por vez, problemas com endianess */
	
	fread(&buffer, 1, 1, file);
	n = 8; mask = 1 << (n - 1);
	
	node = tree; 
	node->parent = NULL;
	node->is_left = FALSE;
	node->freq = 0; 
	
	/* come�a lendo o tipo do primeiro n� (1 bit) */
	do {
		value = read_bits(file, 1, &buffer, &mask);
		if(value == 1) {
			/* n� folha */
			node->type = HN_LEAF;
			
			/* ler dados do n� filho */
			node->value.size = read_bits(file, 4, &buffer, &mask);
			node->value.repeat = read_bits(file, 6, &buffer, &mask);
			
			node = next_node_from_leaf(node);
		} else {
			/* n� intermedi�rio */
			set_node(node);
			node = node->left;
		}
	} while(node != NULL);
	return;
}

void read_dc_data(FILE * file, HuffmanNode *root, EncodedValue data[], int size) {
	int i, buffer, n, mask, bit;
	HuffmanNode* node;
	
	/* ler 1 byte por vez, problemas com endianess */
	
	fread(&buffer, 1, 1, file);
	n = 8; mask = 1 << (n - 1);
	
	for(i = 0; i < size; i++) {
		//left = 0, right = 1
		node = root;
		while(node->type != HN_LEAF) {
			bit = read_bits(file, 1, &buffer, &mask);
			node = !bit? node->left: node->right;
		}
		data[i].size = node->value.size;
		data[i].value = read_bits(file, 
			data[i].size, &buffer, &mask);
	}
	return;
}

void read_ac_data(FILE * file, HuffmanNode *root, RunLengthBlocks *rb) {
	int i, j, bit, count;
	int buffer, n, mask;
	HuffmanNode* node;
	
	/* ler 1 byte por vez, problemas com endianess */
	
	fread(&buffer, 1, 1, file);
	n = 8; mask = 1 << (n - 1);
	
	for(i = 0; i < rb->blockCount; i++) {
		count = 0; rb->blockSize[i] = 0;
		for(j = 0; count < CB_BLOCK_SIZE * CB_BLOCK_SIZE - 1; j++) {
			//left = 0, right = 1
			node = root;
			while(node->type != HN_LEAF) {
				bit = read_bits(file, 1, &buffer, &mask);
				node = !bit? node->left: node->right;
			}
			rb->values[i][j].repeat = node->value.repeat;
			rb->values[i][j].value.size = node->value.size;
			rb->values[i][j].value.value = read_bits(file, 
					node->value.size, &buffer, &mask);
			count += node->value.repeat + 1;
			rb->blockSize[i]++;
		}
	}
	return;
}

void decode_dc_values(short values[], EncodedValue enc_values[], int n) {
	int i;
	for(i = 0; i < n; i++)
		values[i] = decode_value(enc_values[i]);
	return;
}

void decode_ac_values(RunLengthBlocks rb) {
	int i, j; EncodedValue v;
	for(i = 0; i < rb.blockCount; i++) {
		for(j = 0; j < rb.blockSize[i]; j++) {
			v = rb.values[i][j].value;
			rb.values[i][j].value.value = decode_value(v);
			rb.values[i][j].value.size = 8 * sizeof(short);
		}
	}
	return;
}

void decode_dc(BlockVectors bv, short delta[]) {
	int i;
	for(i = 0; i < bv.size - 1; i++) {
		delta[i + 1] = delta[i] + delta[i + 1];
		bv.values[i][0] = delta[i];
	}
	bv.values[i][0] = delta[i];
}

void decode_ac(BlockVectors bv, RunLengthBlocks rb) {
	int i, j, k, p, value;
	for(i = 0; i < rb.blockCount; i++) {
		p = 1;
		for(j = 0; j < rb.blockSize[i]; j++) {
			value = rb.values[i][j].value.value;
			bv.values[i][p++] = value;
			for(k = 0; k < rb.values[i][j].repeat; k++)
				bv.values[i][p++] = value;
		}
	}
}

void detrace_block(short** block, short* vector) {
	int i, j; short map[CB_BLOCK_SIZE][CB_BLOCK_SIZE] = TRACE_MAP;
	for(i = 0; i < CB_BLOCK_SIZE; i++) {
		for(j = 0; j < CB_BLOCK_SIZE; j++) {
			block[i][j] = vector[map[i][j]];
		}
	}
	return;
}

void detrace_blocks(ColorBlocks cb, BlockVectors bv) {
	int i, n = 0;
	
	for(i = 0; i < cb.width * cb.height; i++) //vermelho
		detrace_block(cb.red[i], bv.values[n + i]);
	
	n += cb.width * cb.height;
	for(i = 0; i < cb.width * cb.height; i++) //verde
		detrace_block(cb.green[i], bv.values[n + i]);
	
	n += cb.width * cb.height;
	for(i = 0; i < cb.width * cb.height; i++) //azul
		detrace_block(cb.blue[i], bv.values[n + i]);
	return;
}
