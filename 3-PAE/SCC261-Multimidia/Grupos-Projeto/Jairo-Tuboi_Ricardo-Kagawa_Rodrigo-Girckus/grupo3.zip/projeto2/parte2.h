/* SCC0261 MULTIM�DIA - 1� SEMESTRE DE 2011
 * DOCENTE: RUDINEI GOULARTE
 * 
 * PROJETO: COMPRESS�O DE IMAGEM DIGITAL PARTE 2
 * 
 * ALUNOS:
 * 	Jairo Toshio Tuboi 			6427250
 * 	Ricardo Takashi Kagawa		5634712
 * 	Rodrigo Luis Gava Girckus 	5967770
 */
#ifndef CODEC_PT2
#define CODEC_PT2

/* == Lista de blocos vetorizados == */
typedef struct _BlockVectors {
	int size; //n�mero de blocos
	short** values; //blocos vetorizados
} BlockVectors;

/* inicializador/finalizador/debug */
void BV_init(BlockVectors *bv, int size);
void BV_free(BlockVectors bv);
void BV_print(BlockVectors bv);

/* == Par (valor, repeti��o) da codifica��o run-length == */
typedef struct _RunLengthPair {
	EncodedValue value;
	int repeat;
} RunLengthPair;

/* == Lista de pares (valor, repeti��o) da codifica��o 
 * run-length, agrupada por blocos == */
typedef struct _RunLengthBlocks {
	int blockCount; //n�mero de blocos
	int* blockSize; //tamanho de cada bloco
	RunLengthPair** values; //representa��o de cada bloco
} RunLengthBlocks;


/* inicializador/finalizador/debug */
void RLB_init(RunLengthBlocks *rb, int blocks);
void RLB_free(RunLengthBlocks rb);
void RLB_print(RunLengthBlocks rb, int encoded);

#define HN_NODE 0
#define HN_LEAF 1

/* == metadados que ser�o gravados no 
 * decodificador huffman == */
typedef struct _MetaData {
	short size;
	int repeat;
} MetaData;

/* == n� da �rvore de huffman, usado na constru��o
 * e na decodifica��o dos c�digos huffman == */
typedef struct _HuffmanNode {
	short type;
	int freq;
	short is_left;
	struct _HuffmanNode* parent;
	union {
		struct { //n� folha
			MetaData value;
		};
		struct { //n� intermedi�rio
			struct _HuffmanNode* left;
			struct _HuffmanNode* right;
		};
	};
} HuffmanNode;

/* finalizador/debug */
void HN_free(HuffmanNode node);
void HN_print(HuffmanNode node);
int HN_height(HuffmanNode node);

/* == mapeamento do valor para o 
 * respectivo c�digo huffman == */
typedef struct _HuffmanMapping {
	MetaData value;
	EncodedValue code;
} HuffmanMapping;

/* == dicion�rio de codifica��o huffman == */
typedef struct _HuffmanDictionary {
	HuffmanMapping* map;
	int size;
} HuffmanDictionary;

/* inicializador/finalizador/debug */
void HD_init(HuffmanDictionary *hd, int cap);
void HD_free(HuffmanDictionary hd);
void HD_print(HuffmanDictionary hd);

/* vetoriza os blocos da imagem */
void trace_blocks(ColorBlocks cb, BlockVectors *bv);

/* codifica os valores DC (codifica��o por diferen�as) */
void encode_dc(BlockVectors bv, short delta[]);

/* codifica os valores AC (codifica��o por carreiras) */
void encode_ac(BlockVectors bv, RunLengthBlocks rb);

/* codifica os valores DC (complemento de 1, da parte 1) */
void encode_dc_values(short values[], EncodedValue enc_values[], int n);

/* codifica os valores AC (complemento de 1, da parte 1) */
void encode_ac_values(RunLengthBlocks rb);



/* gera a �rvore de huffman para os valores SSS dos valores DC */
int huffman_dc(EncodedValue data[], int n, HuffmanNode *root);

/* gera a �rvore de huffman para os valores (SSS, repeat) dos valores AC */
int huffman_ac(RunLengthBlocks data, HuffmanNode* root);

/* constr�i o dicion�rio de codifica��o huffman a partir da �rvore huffman */
void build_encode_dictionary(HuffmanNode *tree, HuffmanDictionary *map);



/* codifica os valores DC usando o dicion�rio huffman */
void encode_dc_data(EncodedValue out[], int *out_size, 
		EncodedValue in[], int in_size, HuffmanDictionary map);

/* codifica os valores AC usando o dicion�rio huffman */
void encode_ac_data(EncodedValue out[], int *out_size, 
		RunLengthBlocks rb, HuffmanDictionary map);



/* escreve os cabe�alhos do arquivo bin�rio */
void write_header(FILE* out, int width, int height);

/* escreve o decodificador huffman dos valores DC */
void write_dc_decoder(FILE* out, HuffmanNode tree);

/* escreve o decodificador huffman dos valores AC */
void write_ac_decoder(FILE* out, HuffmanNode tree);

/* escreve os dados codificados no arquivo */
void write_data(FILE * out, EncodedValue data[], int size);



/* l� o cabe�alho do arquivo bin�rio */
void read_header(FILE* in, int *width, int *height);

/* l� o decodificador huffman dos valores DC */
void read_dc_decoder(FILE* in, HuffmanNode *tree);

/* l� o decodificador huffman dos valores AC */
void read_ac_decoder(FILE* in, HuffmanNode *tree);

/* l� os valores DC do arquivo */
void read_dc_data(FILE * file, HuffmanNode *root, EncodedValue data[], int size);

/* l� os valores AC do arquivo */
void read_ac_data(FILE * file, HuffmanNode *root, RunLengthBlocks *rb);



/* decodifica os valores DC (do complemento de 1) */
void decode_dc_values(short values[], EncodedValue enc_values[], int n);

/* decodifica os valores AC (do complemento de 1) */
void decode_ac_values(RunLengthBlocks rb);

/* decodifica os valores DC (da codifica��o por diferen�as) */
void decode_dc(BlockVectors bv, short delta[]);

/* decodifica os valores AC (da codifica��o por carreira) */
void decode_ac(BlockVectors bv, RunLengthBlocks rb);

/* desfaz a vetoriza��o dos blocos da imagem */
void detrace_blocks(ColorBlocks cb, BlockVectors bv);

//mapa de vetoriza��o
#define TRACE_MAP \
{ \
	{ 0,  1,  5,  6, 14, 15, 27, 28},	\
	{ 2,  4,  7, 13, 16, 26, 29, 42},	\
	{ 3,  8, 12, 17, 25, 30, 41, 43},	\
	{ 9, 11, 18, 24, 31, 40, 44, 53},	\
	{10, 19, 23, 32, 39, 45, 52, 54},	\
	{20, 22, 33, 38, 46, 51, 55, 60},	\
	{21, 34, 37, 47, 50, 56, 59, 61},	\
	{35, 36, 48, 49, 57, 58, 62, 63}	\
}

#endif
