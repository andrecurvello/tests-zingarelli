/* SCC0261 MULTIM�DIA - 1� SEMESTRE DE 2011
 * DOCENTE: RUDINEI GOULARTE
 * 
 * PROJETO: COMPRESS�O DE IMAGEM DIGITAL PARTE 2
 * 
 * ALUNOS:
 * 	Jairo Toshio Tuboi 			6427250
 * 	Ricardo Takashi Kagawa		5634712
 * 	Rodrigo Luis Gava Girckus 	5967770
 */
#include <stdio.h>
#include <stdlib.h>
#include "codec.h"
#include "parte1.h"

/* cria a estrutura de codifica��o/decodifica��o */
void CM_init(int width, int height, ColorMatrices* img) {
	int i, j;
	
	img->width = width; img->height = height;
	
	img->red = (short**) malloc(height * sizeof(short*));
	img->green = (short**) malloc(height * sizeof(short*));
	img->blue = (short**) malloc(height * sizeof(short*));
	
	for(i = 0; i < height; i++) {
		img->red[i] = (short*) malloc(width * sizeof(short));
		img->green[i] = (short*) malloc(width * sizeof(short));
		img->blue[i] = (short*) malloc(width * sizeof(short));
		
		for(j = 0; j < width; j++) {
			img->red[i][j] = 0;
			img->green[i][j] = 0;
			img->blue[i][j] = 0;
		}
	}
	return;
}

/* libera os recursos da estrutura */
void CM_free(ColorMatrices img) {
	int i;
	for(i = 0; i < img.height; i++) {
		free(img.red[i]); free(img.green[i]); free(img.blue[i]);
	}
	free(img.red); free(img.green); free(img.blue);
}

/* exibe as matrizes de cores na sa�da padr�o para depura��o */
void CM_print(ColorMatrices img) {
	int i, j;
	
	puts("Matriz Vermelha:");
	for(i = 0; i < img.height; i++) {
		for(j = 0; j < img.width; j++) {
			printf("%02x ", img.red[i][j]);
		}
		putchar('\n');
	}
	putchar('\n');
	
	puts("Matriz Verde:");
	for(i = 0; i < img.height; i++) {
		for(j = 0; j < img.width; j++) {
			printf("%02x ", img.green[i][j]);
		}
		putchar('\n');
	}
	putchar('\n');
	
	puts("Matriz Azul:");
	for(i = 0; i < img.height; i++) {
		for(j = 0; j < img.width; j++) {
			printf("%02x ", img.blue[i][j]);
		}
		putchar('\n');
	}
	putchar('\n');
	
	return;
}



/* cria a estrutura de codifica��o/decodifica��o */
void CB_init(int width, int height, ColorBlocks* cb) {
	int i, j, k;
	
	cb->width = width / CB_BLOCK_SIZE; cb->height = height / CB_BLOCK_SIZE;
	
	cb->red = (short***) malloc(cb->width * cb->height * sizeof(short**));
	cb->green = (short***) malloc(cb->width * cb->height * sizeof(short**));
	cb->blue = (short***) malloc(cb->width * cb->height * sizeof(short**));
	
	for(k = 0; k < cb->width * cb->height; k++) {
		cb->red[k] = (short**) malloc(CB_BLOCK_SIZE * sizeof(short*));
		cb->green[k] = (short**) malloc(CB_BLOCK_SIZE * sizeof(short*));
		cb->blue[k] = (short**) malloc(CB_BLOCK_SIZE * sizeof(short*));
		
		for(i = 0; i < CB_BLOCK_SIZE; i++) {
			cb->red[k][i] = (short*) malloc(CB_BLOCK_SIZE * sizeof(short));
			cb->green[k][i] = (short*) malloc(CB_BLOCK_SIZE * sizeof(short));
			cb->blue[k][i] = (short*) malloc(CB_BLOCK_SIZE * sizeof(short));
		
			for(j = 0; j < CB_BLOCK_SIZE; j++) {
				cb->red[k][i][j] = 0;
				cb->green[k][i][j] = 0;
				cb->blue[k][i][j] = 0;
			}
		}
	}
	return;
}

/* libera os recursos da estrutura */
void CB_free(ColorBlocks cb) {
	int i, k;
	for(k = 0; k < cb.width * cb.height; k++) {
		for(i = 0; i < CB_BLOCK_SIZE; i++) {
			free(cb.red[k][i]); 
			free(cb.green[k][i]); 
			free(cb.blue[k][i]);
		}
		free(cb.red[k]); 
		free(cb.green[k]); 
		free(cb.blue[k]);
	}
	free(cb.red); 
	free(cb.green); 
	free(cb.blue);
	return;
}

/* exibe as matrizes de cores na sa�da padr�o para depura��o */
void CB_print(ColorBlocks cb) {
	int i, j, k;
	
	puts("Blocos Vermelhos:");
	for(k = 0; k < cb.width * cb.height; k++) {
		for(i = 0; i < CB_BLOCK_SIZE; i++) {
			for(j = 0; j < CB_BLOCK_SIZE; j++) {
				printf("%+4d ", cb.red[k][i][j]);
			}
			putchar('\n');
		}
		putchar('\n');
	}
	
	puts("Blocos Verdes:");
	for(k = 0; k < cb.width * cb.height; k++) {
		for(i = 0; i < CB_BLOCK_SIZE; i++) {
			for(j = 0; j < CB_BLOCK_SIZE; j++) {
				printf("%+4d ", cb.green[k][i][j]);
			}
			putchar('\n');
		}
		putchar('\n');
	}
	
	puts("Blocos Azuis:");
	for(k = 0; k < cb.width * cb.height; k++) {
		for(i = 0; i < CB_BLOCK_SIZE; i++) {
			for(j = 0; j < CB_BLOCK_SIZE; j++) {
				printf("%+4d ", cb.blue[k][i][j]);
			}
			putchar('\n');
		}
		putchar('\n');
	}
	
	return;
}



/* imprime um vetor de pixels codificados */
void EV_print(EncodedValue a[], int n) {
	int i, j, k; char buffer[255];
	for(i = 0, j = 0, k = 0; k < n; k++) {
//		printf("%d:", a[k].size);
		printf("%8s.", itob(a[k].value, a[k].size, buffer));
		if(++j == CB_BLOCK_SIZE) {j = 0; i++; putchar('\n');}
		if(i == CB_BLOCK_SIZE) {i = 0; putchar('\n');}
	}
	return;
}

/* ===== CODIFICA��O ===== */

/* l� o cabe�alho do arquivo bitmap */
void read_bmp_headers(FILE* in, BITMAP_FILE_HEADER* fheader, BITMAP_INFO_HEADER* iheader) {
	
	/* file header */
	fread(fheader->type, sizeof(char), 2, in);
	fheader->type[2] = 0;
	fread(&fheader->size, sizeof(int), 1, in);
	fread(&fheader->reserved1, sizeof(short), 2, in);
	fread(&fheader->offBits, sizeof(int), 1, in);
	
	/* info header */
	fread(&iheader->size, sizeof(int), 1, in);
	fread(&iheader->width, sizeof(int), 1, in);
	fread(&iheader->height, sizeof(int), 1, in);
	fread(&iheader->planes, sizeof(short), 1, in);
	fread(&iheader->bitCount, sizeof(short), 1, in);
	fread(&iheader->compression, sizeof(int), 1, in);
	fread(&iheader->sizeImage, sizeof(int), 1, in);
	fread(&iheader->xPixelsPerMeter, sizeof(int), 1, in);
	fread(&iheader->yPixelsPerMeter, sizeof(int), 1, in);
	fread(&iheader->colorUsed, sizeof(int), 1, in);
	fread(&iheader->colorImportant, sizeof(int), 1, in);
	
	return;
}

/* l� o corpo do arquivo bitmap, pixel a pixel */
void read_bitmap_data(FILE* in, short data[], int n) {
	int i; short buffer = 0;
	for(i = 0; fread(&buffer, 1, 1, in) == 1 && i < n; i++) {
		data[i] = buffer; buffer = 0;
	}
	return;
}

/* separa as cores dos pixels lidos */
void separate_colors(short raw[], ColorMatrices* img) {
	int i, j; /* B, G, R */
	for(i = 0; i < img->height; i++) {
		for(j = 0; j < img->width; j++) {
			img->blue[i][j] = raw[3 * (img->width * i + j) + 0];
			img->green[i][j] = raw[3 * (img->width * i + j) + 1];
			img->red[i][j] = raw[3 * (img->width * i + j) + 2];
		}
	}
	return;
}

/* separa os pixels em blocos de 8 x 8 */
void separate_blocks(ColorMatrices cm, ColorBlocks *cb) {
	int i, j, m, n, k;
	
	/* bloco */
	for(m = 0; m < cb->height; m++) {
		for(n = 0; n < cb->width; n++) {
			k = m * cb->width + n;
			
			/* pixel do bloco */
			for(i = 0; i < CB_BLOCK_SIZE; i++) {
				for(j = 0; j < CB_BLOCK_SIZE; j++) {
					cb->red[k][i][j] = cm.red[m * CB_BLOCK_SIZE + i][n * CB_BLOCK_SIZE + j];
					cb->green[k][i][j] = cm.green[m * CB_BLOCK_SIZE + i][n * CB_BLOCK_SIZE + j];
					cb->blue[k][i][j] = cm.blue[m * CB_BLOCK_SIZE + i][n * CB_BLOCK_SIZE + j];
				}
			}
			
		}
	}
}

/* normaliza os valores dos pixels */
void normalize_colors(ColorBlocks *cb) {
	int i, j, k;
	for(k = 0; k < cb->width * cb->height; k++) {
		for(i = 0; i < CB_BLOCK_SIZE; i++) {
			for(j = 0; j < CB_BLOCK_SIZE; j++) {
				cb->red[k][i][j] -= 128;
				cb->green[k][i][j] -= 128;
				cb->blue[k][i][j] -= 128;
			}
		}
	}
	return;
}

/* codifica o valor de uma cor de um pixel (1 byte) */
EncodedValue encode_value(short value) {
	EncodedValue r; int v; r.size = 0;
	r.value = (value < 0)? -value: value;
	for(v = r.value; v > 0 && r.size < 10; v = v >> 1) r.size++;
	if(value < 0) r.value = ~r.value;
	return r;
}

/* codifica a imagem separada em blocos */
void encode_values(ColorBlocks cb, EncodedValue ep[]) {
	int i, j, k, n = 0;
	
	/* vermelho */
	for(k = 0; k < cb.width * cb.height; k++) {
		for(i = 0; i < CB_BLOCK_SIZE; i++) {
			for(j = 0; j < CB_BLOCK_SIZE; j++) {
				ep[n++] = encode_value(cb.red[k][i][j]);
			}
		}
	}
	
	/* verde */
	for(k = 0; k < cb.width * cb.height; k++) {
		for(i = 0; i < CB_BLOCK_SIZE; i++) {
			for(j = 0; j < CB_BLOCK_SIZE; j++) {
				ep[n++] = encode_value(cb.green[k][i][j]);
			}
		}
	}
	
	/* azul */
	for(k = 0; k < cb.width * cb.height; k++) {
		for(i = 0; i < CB_BLOCK_SIZE; i++) {
			for(j = 0; j < CB_BLOCK_SIZE; j++) {
				ep[n++] = encode_value(cb.blue[k][i][j]);
			}
		}
	}
	
	return;
}


/* escreve o metarquivo */
void write_metafile(FILE* file, ColorBlocks cb, EncodedValue img[]) {
	int i;
	int n = 3 * CB_BLOCK_SIZE * CB_BLOCK_SIZE * cb.width * cb.height;
	fprintf(file, "%d %d", cb.width, cb.height);
	for(i = 0; i < n; i++) {
		if(i % (CB_BLOCK_SIZE * CB_BLOCK_SIZE) == 0) fputc('\n', file);
		if(i % CB_BLOCK_SIZE == 0) fputc('\n', file);
		fprintf(file, "%d ", img[i].size);
	}
	fputc('\n', file);
	return;
}

/* escreve o arquivo bin�rio */
void write_binary(EncodedValue data[], int size, FILE* file) {
	int i, buffer, p, n, value, bit, mask;
	/* gravar 1 byte por vez, problemas com endianess */
	
	n = 8; buffer = 0; p = 0;
	for(i = 0; i < size; i++) {
		mask = 1 << (data[i].size - 1);
		value = data[i].value;
		while(mask > 0) {
			bit = value & mask;
			if(bit != 0)
				buffer = buffer | (1 << (n - p - 1));
			value = ~mask & value;
			mask = mask >> 1;
			p++;
			if(p == n) {
				fwrite(&buffer, 1, 1, file);
				buffer = 0; p = 0;
			}
		}
	}
	if(p > 0)
		fwrite(&buffer, 1, 1, file);
	return;
}

/* ===== DECODIFICA��O ===== */

/* l� o metarquivo */
void read_metafile(FILE* file, ColorBlocks *cb, EncodedValue **values) {
	int i, n, width, height;
	fscanf(file, "%d %d ", &width, &height);
	CB_init(width * CB_BLOCK_SIZE, height * CB_BLOCK_SIZE, cb);
	n = 3 * CB_BLOCK_SIZE * CB_BLOCK_SIZE * width * height;
	*values = (EncodedValue*) malloc((n + 1) * sizeof(EncodedValue));
	for(i = 0; i < n; i++) {
		(*values)[i].value = 0;
		fscanf(file, "%hd ", &((*values)[i].size));
	}
	return;
}

/* l� o arquivo bin�rio */
void read_binary(FILE* file, EncodedValue data[], int size) {
	int i, buffer, p, n, value, bit, mask;
	/* ler 1 byte por vez, problemas com endianess */
	
	fread(&buffer, 1, 1, file);
	n = 8; mask = 1 << (n - 1);
	for(i = 0; i < size; i++) {
		value = 0; p = 0;
		while(p < data[i].size) {
			bit = buffer & mask;
			if(bit != 0)
				value |= 1 << (data[i].size - p - 1);
			buffer = ~mask & buffer;
			mask >>= 1; p++;
			if(mask == 0) {
				fread(&buffer, 1, 1, file);
				mask = 1 << (n - 1);
			}
		}
		data[i].value = value;
	}
	return;
}



/* decodifica o valor de uma cor de um pixel (1 byte) */
short decode_value(EncodedValue value) {
	short mask, i;
	
	if(value.size == 0) return 0;
	
	mask = 1 << (value.size - 1);
	if((value.value & mask) == 0) {
		mask = 0;
		for(i = 0; i < value.size; i++)
			mask = mask | (1 << i);
		return -(~value.value & mask);
	} else
		return value.value;
}

/* decodifica os pixels */
void decode_values(ColorBlocks cb, EncodedValue v[]) {
	int i, j, k, n = 0;
	
	/* vermelho */
	for(k = 0; k < cb.width * cb.height; k++) {
		for(i = 0; i < CB_BLOCK_SIZE; i++) {
			for(j = 0; j < CB_BLOCK_SIZE; j++) {
				cb.red[k][i][j] = decode_value(v[n++]);
			}
		}
	}
	
	/* verde */
	for(k = 0; k < cb.width * cb.height; k++) {
		for(i = 0; i < CB_BLOCK_SIZE; i++) {
			for(j = 0; j < CB_BLOCK_SIZE; j++) {
				cb.green[k][i][j] = decode_value(v[n++]);
			}
		}
	}
	
	/* azul */
	for(k = 0; k < cb.width * cb.height; k++) {
		for(i = 0; i < CB_BLOCK_SIZE; i++) {
			for(j = 0; j < CB_BLOCK_SIZE; j++) {
				cb.blue[k][i][j] = decode_value(v[n++]);
			}
		}
	}
	
	return;
}

/* desnormaliza os valores dos pixels */
void denormalize_colors(ColorBlocks *cb) {
	int i, j, k;
	for(k = 0; k < cb->width * cb->height; k++) {
		for(i = 0; i < CB_BLOCK_SIZE; i++) {
			for(j = 0; j < CB_BLOCK_SIZE; j++) {
				cb->red[k][i][j] += 128;
				cb->green[k][i][j] += 128;
				cb->blue[k][i][j] += 128;
			}
		}
	}
	return;
}

/* junta os blocos de pixels */
void join_blocks(ColorMatrices cm, ColorBlocks *cb) {
	int i, j, m, n, k;
	
	/* bloco */
	for(m = 0; m < cb->height; m++) {
		for(n = 0; n < cb->width; n++) {
			k = m * cb->width + n;
			
			/* pixel do bloco */
			for(i = 0; i < CB_BLOCK_SIZE; i++) {
				for(j = 0; j < CB_BLOCK_SIZE; j++) {
					cm.red[m * CB_BLOCK_SIZE + i][n * CB_BLOCK_SIZE + j] = cb->red[k][i][j];
					cm.green[m * CB_BLOCK_SIZE + i][n * CB_BLOCK_SIZE + j] = cb->green[k][i][j];
					cm.blue[m * CB_BLOCK_SIZE + i][n * CB_BLOCK_SIZE + j] = cb->blue[k][i][j];
				}
			}
			
		}
	}
}

/* junta as cores dos pixels lidos */
void merge_colors(short raw[], ColorMatrices img) {
	int i, j; /* B, G, R */
	for(i = 0; i < img.height; i++) {
		for(j = 0; j < img.width; j++) {
			raw[3 * (img.width * i + j) + 0] = img.blue[i][j];
			raw[3 * (img.width * i + j) + 1] = img.green[i][j];
			raw[3 * (img.width * i + j) + 2] = img.red[i][j];
		}
	}
	return;
}



/* escreve o cabe�alho do arquivo bitmap */
void write_bmp_headers(FILE* out, BITMAP_FILE_HEADER fheader, BITMAP_INFO_HEADER iheader) {
	
	/* file header */
	fwrite(fheader.type, sizeof(char), 2, out);
	fwrite(&fheader.size, sizeof(int), 1, out);
	fwrite(&fheader.reserved1, sizeof(short), 2, out);
	fwrite(&fheader.offBits, sizeof(int), 1, out);
	
	/* info header */
	fwrite(&iheader.size, sizeof(int), 1, out);
	fwrite(&iheader.width, sizeof(int), 1, out);
	fwrite(&iheader.height, sizeof(int), 1, out);
	fwrite(&iheader.planes, sizeof(short), 1, out);
	fwrite(&iheader.bitCount, sizeof(short), 1, out);
	fwrite(&iheader.compression, sizeof(int), 1, out);
	fwrite(&iheader.sizeImage, sizeof(int), 1, out);
	fwrite(&iheader.xPixelsPerMeter, sizeof(int), 1, out);
	fwrite(&iheader.yPixelsPerMeter, sizeof(int), 1, out);
	fwrite(&iheader.colorUsed, sizeof(int), 1, out);
	fwrite(&iheader.colorImportant, sizeof(int), 1, out);
	
	return;
}

/* escreve o corpo do arquivo bitmap, pixel a pixel */
void write_bitmap_data(FILE* out, short data[], int size) {
	int i;
	for(i = 0; i < size; i++)
		fwrite(&data[i], 1, 1, out);
	return;
}

