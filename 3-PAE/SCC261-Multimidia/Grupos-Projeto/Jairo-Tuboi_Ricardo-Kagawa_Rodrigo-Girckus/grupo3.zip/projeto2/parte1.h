/* SCC0261 MULTIM�DIA - 1� SEMESTRE DE 2011
 * DOCENTE: RUDINEI GOULARTE
 * 
 * PROJETO: COMPRESS�O DE IMAGEM DIGITAL PARTE 2
 * 
 * ALUNOS:
 * 	Jairo Toshio Tuboi 			6427250
 * 	Ricardo Takashi Kagawa		5634712
 * 	Rodrigo Luis Gava Girckus 	5967770
 */
#ifndef CODEC_PT1
#define CODEC_PT1

#include <stdio.h>
#include "codec.h"

/* imagem separada por cores */
typedef struct {
	short **red, **green, **blue;
	int width, height; //pixels
} ColorMatrices;

/* cria a estrutura de codifica��o/decodifica��o */
void CM_init(int width, int height, ColorMatrices* img);

/* libera os recursos da estrutura */
void CM_free(ColorMatrices img);

/* exibe as matrizes de cores na sa�da padr�o para depura��o */
void CM_print(ColorMatrices img);

#define CB_BLOCK_SIZE 8

/* imagem dividida em blocos */
typedef struct {
	short ***red, ***green, ***blue;
	int width, height; //blocks
} ColorBlocks;

/* cria a estrutura de codifica��o/decodifica��o */
void CB_init(int width, int height, ColorBlocks* cb);

/* libera os recursos da estrutura */
void CB_free(ColorBlocks cb);

/* exibe as matrizes de cores na sa�da padr�o para depura��o */
void CB_print(ColorBlocks cb);

/* pixel codificado */
typedef struct {
	int value;
	short size;
} EncodedValue;

/* imprime um vetor de pixels codificados */
void EV_print(EncodedValue a[], int n);


/* ===== CODIFICA��O ===== */

/* l� o cabe�alho do arquivo bitmap */
void read_bmp_headers(FILE* in, BITMAP_FILE_HEADER* fheader, BITMAP_INFO_HEADER* iheader);

/* l� o corpo do arquivo bitmap, pixel a pixel */
void read_bitmap_data(FILE* in, short data[], int n);

/* separa as cores dos pixels lidos */
void separate_colors(short raw[], ColorMatrices* img);

/* separa os pixels em blocos de 8 x 8 */
void separate_blocks(ColorMatrices cm, ColorBlocks *cb);

/* normaliza os valores dos pixels */
void normalize_colors(ColorBlocks *cb);

/* codifica o valor de uma cor de um pixel (1 byte) */
EncodedValue encode_value(short value);

/* codifica a imagem separada em blocos */
void encode_values(ColorBlocks cb, EncodedValue ev[]);

/* escreve o metarquivo */
void write_metafile(FILE* file, ColorBlocks cb, EncodedValue img[]);

/* escreve o arquivo bin�rio */
void write_binary(EncodedValue data[], int size, FILE* file);


/* ===== DECODIFICA��O ===== */

/* l� o metarquivo */
void read_metafile(FILE* file, ColorBlocks *cb, EncodedValue **values);

/* l� o arquivo bin�rio */
void read_binary(FILE* file, EncodedValue data[], int size);

/* decodifica o valor de uma cor de um pixel (1 byte) */
short decode_value(EncodedValue value);

/* decodifica os pixels */
void decode_values(ColorBlocks cb, EncodedValue v[]);

/* desnormaliza os valores dos pixels */
void denormalize_colors(ColorBlocks *cb);

/* junta os blocos de pixels */
void join_blocks(ColorMatrices cm, ColorBlocks *cb);

/* junta as cores dos pixels lidos */
void merge_colors(short raw[], ColorMatrices img);

/* escreve o cabe�alho do arquivo bitmap */
void write_bmp_headers(FILE* out, BITMAP_FILE_HEADER fheader, BITMAP_INFO_HEADER iheader);

/* escreve o corpo do arquivo bitmap, pixel a pixel */
void write_bitmap_data(FILE* out, short data[], int size);

#endif
