/* SCC0261 MULTIM�DIA - 1� SEMESTRE DE 2011
 * DOCENTE: RUDINEI GOULARTE
 * 
 * PROJETO: COMPRESS�O DE IMAGEM DIGITAL PARTE 2
 * 
 * ALUNOS:
 * 	Jairo Toshio Tuboi 			6427250
 * 	Ricardo Takashi Kagawa		5634712
 * 	Rodrigo Luis Gava Girckus 	5967770
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "defs.h"
#include "codec.h"

#define PATH_SEPARATOR '\\'

/* Armazena as op��es do programa. */
typedef struct _Options {
	char program_name[FILENAME_MAX];	/* nome do programa (linha de comando) */
	char program_path[FILENAME_MAX];	/* caminho do programa (linha de comando) */
	int encode;			/* codifica a imagem, ao inv�s de decodific�-lo */
	int interactive;	/* executar em modo interativo */
	int message_level;	/* n�vel de informa��o gerado na sa�da padr�o */
	int override;		/* sobrescreve o arquivo de sa�da sem perguntar */
	char bitmap[FILENAME_MAX];		/* nome do arquivo de bitmap */
	char binary[FILENAME_MAX];		/* nome do arquivo bin�rio */
	char metafile[FILENAME_MAX];	/* nome do metarquivo */
}* Options;

/* Constr�i um registro Options com as op��es padr�o. */
Options App_createOptions() {
	Options o = (Options) malloc(sizeof(struct _Options));
	strcpy(o->program_name, "programa.exe");
	strcpy(o->program_path, "");
	strcpy(o->bitmap, "");
	strcpy(o->binary, "");
	strcpy(o->metafile, "");
	o->encode = TRUE;
	o->override = FALSE;
	o->interactive = FALSE;
	o->message_level = OL_NORMAL;
	return o;
}

/* Destr�i o registro Options. */
void App_destroyOptions(Options o) {
	free(o);
	return;
}

/* Define o nome do programa. */
void App_setProgName(Options opt, char filename[]) {
	strcpy(opt->program_name, filename);
	return;
}

/* Define o local do programa. */
void App_setProgPath(Options opt, char filename[]) {
	strcpy(opt->program_path, filename);
	return;
}

/* Define o nome do arquivo de bitmap. */
void App_setBitmap(Options opt, char filename[]) {
	strcpy(opt->bitmap, filename);
	return;
}

/* Define o nome do arquivo bin�rio. */
void App_setBinary(Options opt, char filename[]) {
	strcpy(opt->binary, filename);
	return;
}

/* Define o nome do metarquivo. */
void App_setMetafile(Options opt, char filename[]) {
	strcpy(opt->metafile, filename);
	return;
}

/* Imprime o registro Options. */
void App_printOptions(Options o) {
	if(o->message_level == OL_DEBUG) {
		printf("Nome do programa : %s\n", o->program_name);
		printf("Local do programa: %s\n", o->program_path);
	}
	printf("Arquivo de bitmap: %s\n", o->bitmap);
	printf("Arquivo binario  : %s\n", o->binary);
	printf("Metarquivo       : %s\n", o->metafile);
	if(o->interactive) {
		if(o->message_level > OL_NORMAL) puts("Modo interativo");
		puts(o->override? "Sobrescrever sem perguntar": "Confirmar sobrescrita");
	} else {
		puts("Modo de linha de comando");
		puts(o->encode? "Codificar arquivo": "Decodificar arquivo");
		puts(o->override? "Sobrescrever saida": "Nao sobrescrever saida");
	}
	switch(o->message_level) {
		case OL_NORMAL:		puts("Exibir mensagens.");			break;
		case OL_VERBOSE:	puts("Exibir maix mensagens.");		break;
		case OL_DEBUG:		puts("Exibir todas as mensagens.");	break;
	}
	return;
}

/* Tenta abrir os arquivos de entrada e de sa�da em modo de leitura para codifica��o. 
 * Os arquivos de sa�da s�o abertos assim para verificar sua exist�ncia.
 * Nenhum dos arquivos � fechado pela fun��o.
 * 
 * bitmap (sa�da) - descritor do arquivo bitmap
 * binary (sa�da) - descritor do arquivo bin�rio
 * metafile (sa�da) - descritor do metarquivo
 */
void open_files_encode_read(Options opt, FILE** bitmap, FILE** binary, FILE** metafile) {
	*bitmap = fopen(opt->bitmap, "rb");
	if(!opt->override) {
		*metafile = fopen(opt->metafile, "r");
		*binary = fopen(opt->binary, "rb");
	}
	return;
}

/* Reabre os arquivos de sa�da em modo de escrita para codifica��o. 
 * Esses arquivos j� podem estar abertos. 
 * 
 * bitmap (sa�da) - descritor do arquivo bitmap
 * binary (sa�da) - descritor do arquivo bin�rio
 * metafile (sa�da) - descritor do metarquivo
 */
void open_files_encode_write(Options opt, FILE** bitmap, FILE** binary, FILE** metafile) {
	*metafile = (*metafile != NULL)? freopen(opt->metafile, "w", *metafile): fopen(opt->metafile, "w");
	*binary = (*binary != NULL)? freopen(opt->binary, "wb", *binary): fopen(opt->binary, "wb");
	return;
}

/* Tenta abrir os arquivos de entrada e de sa�da em modo de leitura para decodifica��o. 
 * Os arquivos de sa�da s�o abertos assim para verificar sua exist�ncia.
 * Nenhum dos arquivos � fechado pela fun��o.
 * 
 * bitmap (sa�da) - descritor do arquivo bitmap
 * binary (sa�da) - descritor do arquivo bin�rio
 * metafile (sa�da) - descritor do metarquivo
 */
void open_files_decode_read(Options opt, FILE** bitmap, FILE** binary, FILE** metafile) {
	if(!opt->override) 
		*bitmap = fopen(opt->bitmap, "rb");
	*binary = fopen(opt->binary, "rb");
	*metafile = fopen(opt->metafile, "r");
	return;
}

/* Reabre os arquivos de sa�da em modo de escrita para decodifica��o. 
 * Esses arquivos j� podem estar abertos. 
 * 
 * bitmap (sa�da) - descritor do arquivo bitmap
 * binary (sa�da) - descritor do arquivo bin�rio
 * metafile (sa�da) - descritor do metarquivo
 */
void open_files_decode_write(Options opt, FILE** bitmap, FILE** binary, FILE** metafile) {
	*bitmap = (*bitmap != NULL)? freopen(opt->bitmap, "wb", *bitmap): fopen(opt->bitmap, "wb");
	return;
}

/* Fecha os arquivos abertos pelo programa. */
void close_files(FILE* bitmap, FILE* binary, FILE* metafile) {
	if(bitmap != NULL)		fclose(bitmap);
	if(binary != NULL)		fclose(binary);
	if(metafile != NULL)	fclose(metafile);
	return;
}

/* Verifica os nomes de arquivos. */
void check_filenames(Options opt) {
	char* p;
	
	/* verificando arquivo bin�rio */
	if(strlen(opt->binary) == 0 && strlen(opt->bitmap) > 0) {
		App_setBinary(opt, opt->bitmap);
		p = strstr(opt->binary, ".bmp");
		if(p == NULL) p = strchr(opt->binary, 0);
		strcpy(p, ".bin");
	}
	
	/* obtendo o nome do metarquivo */
	App_setMetafile(opt, opt->binary);
	if(strlen(opt->metafile) > 0) {
		p = strstr(opt->metafile, ".bin");
		if(p == NULL) p = strchr(opt->metafile, 0);
		strcpy(p, ".meta");
	}
	
	return;
}

/* Pausa a execu��o do programa, esperando resposta do usu�rio. */
void pause() {
	printf("Pressione <Enter> para continuar..."); getchar();
	return;
}

/* Exibe a vers�o do programa na sa�da padr�o. */
void display_version(Options opt) {
	printf("Projeto de Multimidia (%s) versao %s\n", opt->program_name, CODEC_VERSION);
	return;
}

/* Exibe um texto de ajuda. */
void display_help(Options opt) {
	char helpname[FILENAME_MAX]; FILE* helpfile;
	char buffer[1024], *b, *p; int n;
	
	/* calculando nome absoluto do arquivo */
	strcpy(helpname, opt->program_path);
	n = strlen(helpname);
	if(n > 0 && helpname[n - 1] != PATH_SEPARATOR) {
		helpname[n] = PATH_SEPARATOR;
		helpname[n + 1] = 0;
	}
	strcat(helpname, "help.txt");
	
	if(opt->message_level == OL_DEBUG)
		printf("Lendo \"%s\"...\n", helpname);
	
	helpfile = fopen(helpname, "r");
	if(helpfile == NULL) {
		puts("Ajuda nao encontrada!");
		return;
	}
	
	putchar('\n');
	while(fgets(buffer, 1000, helpfile) != NULL) {
		/* verificar %s quebrado */
		n = strlen(buffer);
		if(n == 1) {
			if(buffer[n - 1] == '%') {
				buffer[n] = fgetc(helpfile);
				buffer[n + 1] = 0;
			}
		} else if(n > 1) {
			if(buffer[n - 1] == '%' && buffer[n - 2] != '%') {
				buffer[n] = fgetc(helpfile);
				buffer[n + 1] = 0;
			}
		}
		
		/* verificar m�ltiplos %s */
		b = buffer; p = strstr(b, "%s");
		while(p != NULL) {
			p[0] = 0; 
			printf(b, opt->program_name);
			p[0] = '%';
			b = p; p = strstr(b + 1, "%s");
		}
		printf(b, opt->program_name);
	}
	putchar('\n');
	
	fclose(helpfile);
	return;
}

/* Executa o programa em modo de linha de comando para codificar. */
void run_command_line_encode(Options opt) {
	FILE *bitmap = NULL, *binary = NULL, *metafile = NULL;
	int err; char errmsg[ERR_MSG_MAX];
	
	/* mensagens informativas */
	if(opt->message_level > OL_NORMAL) {
		puts("Usando as seguintes opcoes:");
		putchar('\n');
		App_printOptions(opt);
		putchar('\n');
	}
	
	/* abrir e verificar arquivos de entrada */
	if(strlen(opt->bitmap) == 0) {
		puts("Sem arquivo bitmap, nada a fazer.");
		return;
	}
	open_files_encode_read(opt, &bitmap, &binary, &metafile);
	if(bitmap == NULL) {
		printf("Arquivo \"%s\" nao foi encontrado ou nao pode ser lido.\n", opt->bitmap);
		close_files(bitmap, binary, metafile);
		exit(EXIT_FAILURE);
	}
	
	/* abrir e verificar arquivos de sa�da */
	if(!opt->override) {
		if(binary != NULL)		printf("Arquivo binario \"%s\" ja existe.\n", opt->binary);
		if(metafile != NULL)	printf("Metarquivo \"%s\" ja existe.\n", opt->metafile);
		if(binary != NULL || metafile != NULL) {
			close_files(bitmap, binary, metafile);
			exit(EXIT_FAILURE);
		}
	}
	open_files_encode_write(opt, &bitmap, &binary, &metafile);
	if(metafile == NULL || binary == NULL) {
		if(metafile == NULL)
			printf("Arquivo \"%s\" nao pode ser aberto para escrita.\n", opt->metafile);
		if(binary == NULL)
			printf("Arquivo \"%s\" nao pode ser aberto para escrita.\n", opt->binary);
		exit(EXIT_FAILURE);
	}
	
	/* executar tarefa */
	err = encode(bitmap, binary, metafile);
	if(err != CD_SUCCESSFUL)
		puts(get_error_message(err, errmsg));
	
	close_files(bitmap, binary, metafile);
	return;
}

/* Executa o programa em modo de linha de comando para decodificar. */
void run_command_line_decode(Options opt) {
	FILE *bitmap = NULL, *binary = NULL, *metafile = NULL;
	int err; char errmsg[ERR_MSG_MAX];
	
	/* mensagens informativas */
	if(opt->message_level > OL_NORMAL) {
		puts("Usando as seguintes opcoes:");
		putchar('\n');
		App_printOptions(opt);
		putchar('\n');
	}
	
	/* abrir e verificar arquivos de entrada */
	if(strlen(opt->binary) == 0 || strlen(opt->metafile) == 0) {
		puts("Sem arquivo binario ou metarquivo, nada a fazer.");
		exit(EXIT_FAILURE);
	}
	open_files_decode_read(opt, &bitmap, &binary, &metafile);
	if(binary == NULL || metafile == NULL) {
		if(binary == NULL)
			printf("Arquivo \"%s\" nao foi encontrado ou nao pode ser lido.\n", opt->binary);
		if(metafile == NULL)
			printf("Arquivo \"%s\" nao foi encontrado ou nao pode ser lido.\n", opt->metafile);
		close_files(bitmap, binary, metafile);
		exit(EXIT_FAILURE);
	}
	
	/* abrir e verificar arquivos de sa�da */
	if(!opt->override && bitmap != NULL) {
		printf("Arquivo bitmap \"%s\" ja existe.\n", opt->bitmap);
		close_files(bitmap, binary, metafile);
		exit(EXIT_FAILURE);
	}
	open_files_decode_write(opt, &bitmap, &binary, &metafile);
	if(bitmap == NULL)
		printf("Arquivo \"%s\" nao pode ser aberto para escrita.\n", opt->bitmap);
	
	/* executar tarefa */
	err = decode(bitmap, binary, metafile);
	if(err != CD_SUCCESSFUL)
		puts(get_error_message(err, errmsg));
	
	close_files(bitmap, binary, metafile);
	return;
}

/* Executa a tarefa do programa em modo interativo para codifica��o. */
void encode_interactively(Options opt) {
	FILE *bitmap = NULL, *binary = NULL, *metafile = NULL;
	int err; char errmsg[ERR_MSG_MAX];
	
	/* mensagens informativas */
	if(opt->message_level > OL_NORMAL) {
		puts("Usando as seguintes opcoes:");
		putchar('\n');
		App_printOptions(opt);
		putchar('\n');
	}
	
	/* abrir e verificar arquivos de entrada */
	if(strlen(opt->bitmap) == 0) {
		puts("Sem arquivo bitmap, nada a fazer.");
		return;
	}
	open_files_encode_read(opt, &bitmap, &binary, &metafile);
	if(bitmap == NULL) {
		printf("Arquivo \"%s\" nao foi encontrado ou nao pode ser lido.\n", opt->bitmap);
		close_files(bitmap, binary, metafile);
		return;
	}
	
	/* abrir e verificar arquivos de sa�da */
	if(!opt->override) {
		if(binary != NULL)		printf("Arquivo binario \"%s\" ja existe.\n", opt->binary);
		if(metafile != NULL)	printf("Metarquivo \"%s\" ja existe.\n", opt->metafile);
		if(binary != NULL || metafile != NULL) {
			printf("Deseja sobrescrever este(s) arquivo(s) [s/n]? ");
			if(tolower(getchar()) == 's') {
				open_files_encode_write(opt, &bitmap, &binary, &metafile);
			} else {
				close_files(bitmap, binary, metafile);
				return;
			}
		} else
			open_files_encode_write(opt, &bitmap, &binary, &metafile);
	} else
		open_files_encode_write(opt, &bitmap, &binary, &metafile);
	if(metafile == NULL)
		printf("Arquivo \"%s\" nao pode ser aberto para escrita.\n", opt->metafile);
	if(binary == NULL)
		printf("Arquivo \"%s\" nao pode ser aberto para escrita.\n", opt->binary);
	
	/* executar tarefa */
	err = encode(bitmap, binary, metafile);
	if(err != CD_SUCCESSFUL)
		puts(get_error_message(err, errmsg));
	
	close_files(bitmap, binary, metafile);
	return;
}

/* Executa a tarefa do programa em modo interativo para decodifica��o. */
void decode_interactively(Options opt) {
	FILE *bitmap = NULL, *binary = NULL, *metafile = NULL;
	int err; char errmsg[ERR_MSG_MAX];
	
	/* mensagens informativas */
	if(opt->message_level > OL_NORMAL) {
		puts("Usando as seguintes opcoes:");
		putchar('\n');
		App_printOptions(opt);
		putchar('\n');
	}
	
	/* abrir e verificar arquivos de entrada */
	if(strlen(opt->binary) == 0 || strlen(opt->metafile) == 0) {
		puts("Sem arquivo binario ou metarquivo, nada a fazer.");
		return;
	}
	open_files_decode_read(opt, &bitmap, &binary, &metafile);
	if(binary == NULL || metafile == NULL) {
		if(binary == NULL)
			printf("Arquivo \"%s\" nao foi encontrado ou nao pode ser lido.\n", opt->binary);
		if(metafile == NULL)
			printf("Arquivo \"%s\" nao foi encontrado ou nao pode ser lido.\n", opt->metafile);
		close_files(bitmap, binary, metafile);
		return;
	}
	
	/* abrir e verificar arquivos de sa�da */
	if(!opt->override && bitmap != NULL) {
		printf("Arquivo bitmap \"%s\" ja existe.\n", opt->bitmap);
		printf("Deseja sobrescrever este arquivo [s/n]? ");
		if(tolower(getchar()) == 's') {
			open_files_decode_write(opt, &bitmap, &binary, &metafile);
		} else {
			close_files(bitmap, binary, metafile);
			return;
		}
	} else
		open_files_decode_write(opt, &bitmap, &binary, &metafile);
	if(bitmap == NULL)
		printf("Arquivo \"%s\" nao pode ser aberto para escrita.\n", opt->bitmap);
	
	/* executar tarefa */
	err = decode(bitmap, binary, metafile);
	if(err != CD_SUCCESSFUL)
		puts(get_error_message(err, errmsg));
	
	close_files(bitmap, binary, metafile);
	return;
}

/* Executa o programa em modo interativo. */
void run_interactive_mode(Options opt) {
	char line[255], *args, *p; 
	int exit = FALSE;
	
	if(opt->message_level > OL_NORMAL) {
		puts("Foram detectadas as seguintes opcoes:");
		putchar('\n');
		App_printOptions(opt);
		putchar('\n');
	}
	
	/* modo silencioso implica sobrescrever silenciosamente */
	if(opt->message_level == OL_QUIET)
		opt->override = TRUE;
	
	if(opt->encode)
		encode_interactively(opt);
	else
		decode_interactively(opt);
	
	puts("\nPara obter ajuda, digite \"help\".\n");
	
	while(!exit) {
		/* l� um comando */
		printf(">> "); fgets(line, 255, stdin);
		while(strlen(line) == 1)
			fgets(line, 255, stdin);
		p = strchr(line, '\n');
		if(p != NULL) p[0] = 0;
		
		args = strchr(line, ' ');
		if(args == NULL) 
			args = strchr(line, 0);
		else {
			args[0] = 0; args++;
			while(args[0] == ' ') args++;
		}
		
		/* executa o comando */
		if(strcmp(line, "q") == 0) {
			exit = TRUE;
		} else if(strcmp(line, "help") == 0) {
			puts("Os comandos disponiveis sao:");
			putchar('\n');
			puts("\tbmp {arquivo} - define o arquivo bitmap");
			puts("\tbin {arquivo} - define o arquivo binario (o metarquivo tera um nome semelhante)");
			puts("\te [arquivo] - codifica a imagem bitmap especificada ou configurada");
			puts("\td [arquivo] - extrai a imagem bitmap especificada ou configurada");
			puts("\tm {quieto|normal|verboso|depuracao} - define a quantidade de informacao exibida pelo programa.");
			printf("\tf {true|false} - Com \"true\", os arquivos de saida sao sobrescritos sem perguntar; ");
			puts("com \"false\", o programa sempre perguntara antes de sobrescrever");
			puts("\tst - exibe algumas informacoes sobre o estado do programa");
			puts("\tq - fecha o programa");
		} else if(strcmp(line, "st") == 0) {
			App_printOptions(opt);
			putchar('\n');
		} else if(strcmp(line, "bmp") == 0) {
			App_setBitmap(opt, args);
			if(opt->message_level > OL_NORMAL)
				printf("Arquivo bitmap definido para \"%s\".\n", opt->bitmap);
		} else if(strcmp(line, "bin") == 0) {
			App_setBinary(opt, args);
			check_filenames(opt);
			if(opt->message_level > OL_NORMAL)
				printf("Arquivo binario definido para \"%s\".\n", opt->binary);
		} else if(strcmp(line, "e") == 0 || strcmp(line, "d") == 0) {
			if(strlen(args) > 0)
				App_setBitmap(opt, args);
			check_filenames(opt);
			if(strcmp(line, "e") == 0)
				encode_interactively(opt);
			else
				decode_interactively(opt);
		} else if(strcmp(line, "m") == 0) {
			p = strchr(args, ' ');
			if(p != NULL) p[0] = 0;
			if(strcmp(args, "quieto") == 0) {
				opt->message_level = OL_QUIET;
				opt->override = TRUE;
			} else if(strcmp(args, "verboso") == 0) {
				opt->message_level = OL_VERBOSE;
				puts("Agora exibindo mais mensagens.");
			} else if(strcmp(args, "depuracao") == 0) {
				opt->message_level = OL_DEBUG;
				puts("Agora exibindo todas as mensagens.");
			} else {
				opt->message_level = OL_NORMAL;
				puts("Agora exibindo mensagens.");
			}
		} else if(strcmp(line, "f") == 0) {
			p = strchr(args, ' ');
			if(p != NULL) p[0] = 0;
			if(strcmp(args, "true") == 0) {
				opt->override = TRUE;
				if(opt->message_level > OL_NORMAL)
					puts("Sobrescrever arquivos sem perguntar.");
			} else if(strcmp(args, "false") == 0 && opt->message_level > OL_QUIET) {
				opt->override = FALSE;
				if(opt->message_level > OL_NORMAL)
					puts("Perguntar antes de sobrescrever arquivos.");
			}
		}
	}
	
	if(opt->message_level > OL_QUIET)
		puts("Programa encerrado.");
	return;
}

/*
Fun��o main. Aceita argumentos da linha de comando, e pode
executar de forma interativa. Linha de comando:
	
	programa [-op��es] [-o arquivo_binario] [arquivo_bitmap]
	
Op��es

	-i Executa o programa em modo interativo. O programa poder� 
		pausar antes de encerrar.
	-q N�o exibe mensagens, a n�o ser que ocorra algum erro.
	-v Exibe mais mensagens que o normal.
	-d Exibe mensagens de depura��o.
	-f For�a a sobrescrita do arquivo de sa�da, caso ele j� exista.
		Sem essa op��o, o programa falhar� em modo de linha de 
		comando, ou perguntar� o que fazer em modo interativo.
	-x Executa decodifica��o, ao inv�s de codifica��o.
	-o arquivo_binario
		Especifica um arquivo bin�rio. Opcional em modo interativo.
	arquivo_bitmap
		Especifica um arquivo bitmap. Opcional em modo interativo.
	
	--version
		Exibe a vers�o do programa.
	--help
		Exibe esta ajuda.
	
V�rios arquivos bitmaps e bin�rios podem ser especificados pela
linha de comando, mas apenas o �ltimo de cada ser�o usados, mesmo em 
modo interativo. Caso n�o sejam especificados em modo de linha de
comando, o programa poder� falhar.

As op��es -q, -v e -d podem ser especificadas v�rias vezes e 
simultaneamente. O modo mais verboso especificado ser� escolhido
nesse caso.

--version e --help n�o executam o programa, apenas exibem suas
respectivas informa��es. A maioria das demais op��es ser� ignorada
nesse caso, exceto -i para que o programa pause ao exibir as informa��es.
*/
int main(int argc, char *argv[]) {
	int i; char* p;
	int help_flag = FALSE;
	int version_flag = FALSE;
	Options options = App_createOptions(); 

	/* nome do programa */
	p = strrchr(argv[0], PATH_SEPARATOR);
	if(p != NULL) {
		if(strlen(p) > 0)
			App_setProgName(options, p + 1);
		p[0] = 0;
		App_setProgPath(options, argv[0]);
	} else {
		App_setProgName(options, argv[0]);
		App_setProgPath(options, "");
	}
	
	/* configurando o programa */
	for(i = 1; i < argc; i++) {
		if(strcmp(argv[i], "-o") == 0)
			App_setBinary(options, argv[++i]);
		else if(strcmp(argv[i], "--version") == 0) {
			version_flag = TRUE;
		} else if(strcmp(argv[i], "--help") == 0) {
			help_flag = TRUE;
		} else if(argv[i][0] == '-') {
			if(strchr(argv[i], 'i') != NULL)
				options->interactive = TRUE;
			if(strchr(argv[i], 'q') != NULL)
				options->message_level = OL_QUIET;
			if(strchr(argv[i], 'v') != NULL)
				options->message_level = OL_VERBOSE;
			if(strchr(argv[i], 'd') != NULL)
				options->message_level = OL_DEBUG;
			if(strchr(argv[i], 'f') != NULL)
				options->override = TRUE;
			if(strchr(argv[i], 'x') != NULL)
				options->encode = FALSE;
		} else
			App_setBitmap(options, argv[i]);
	}
	
	check_filenames(options);
	
	/* executando a tarefa */
	if(version_flag || help_flag) {
		if(version_flag)	display_version(options);
		if(help_flag)		display_help(options);
		if(options->interactive) pause();
	} else if(options->interactive) {
		run_interactive_mode(options);
	} else {
		if(options->encode)
			run_command_line_encode(options);
		else
			run_command_line_decode(options);
	}
	
	/* limpeza */
	App_destroyOptions(options);
	return EXIT_SUCCESS;
}
