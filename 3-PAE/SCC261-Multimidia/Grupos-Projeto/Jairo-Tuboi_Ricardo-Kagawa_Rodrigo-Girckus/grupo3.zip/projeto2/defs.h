/* SCC0261 MULTIMÍDIA - 1º SEMESTRE DE 2011
 * DOCENTE: RUDINEI GOULARTE
 * 
 * PROJETO: COMPRESSÃO DE IMAGEM DIGITAL PARTE 2
 * 
 * ALUNOS:
 * 	Jairo Toshio Tuboi 			6427250
 * 	Ricardo Takashi Kagawa		5634712
 * 	Rodrigo Luis Gava Girckus 	5967770
 */
#ifndef CODEC_VERSION
#define CODEC_VERSION "2.0"

#define TRUE	1
#define FALSE	0

#define OL_QUIET	0
#define OL_NORMAL	1
#define OL_VERBOSE	2
#define OL_DEBUG	3

#define ERR_MSG_MAX 255

char str[255];
char* itob(int value, int size, char buffer[]); //debug

#endif
