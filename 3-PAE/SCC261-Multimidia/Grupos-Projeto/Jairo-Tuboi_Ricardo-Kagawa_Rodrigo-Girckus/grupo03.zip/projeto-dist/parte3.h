/*
SCC0261 MULTIM�DIA - 1� SEMESTRE DE 2011
DOCENTE: RUDINEI GOULARTE

PROJETO: COMPRESS�O DE IMAGEM DIGITAL PARTE 3


ALUNOS:
	Jairo Toshio Tuboi 		6427250
	Ricardo Takashi Kagawa		5634712
	Rodrigo Luis Gava Girckus 	5967770
*/
#ifndef CODEC_PT3
#define CODEC_PT3

#include <stdio.h>
#include "defs.h"
#include "parte1.h"

//http://en.wikipedia.org/wiki/JPEG#Discrete_cosine_transform

#define QUANTIZATION_TABLE { \
	{ 16,  11,  10,  16,  24,  40,  51,  61}, \
	{ 12,  12,  14,  19,  26,  58,  60,  55}, \
	{ 14,  13,  16,  24,  40,  57,  69,  56}, \
	{ 14,  17,  22,  29,  51,  87,  80,  62}, \
	{ 18,  22,  37,  56,  68, 109, 103,  77}, \
	{ 24,  35,  55,  64,  81, 104, 113,  92}, \
	{ 49,  64,  78,  87, 103, 121, 120, 101}, \
	{ 72,  92,  95,  98, 112, 100, 103,  99}  \
}



/* == bloco da imagem em ponto flutuante == */

typedef struct {
	double data[BLOCK_SIZE][BLOCK_SIZE];
} FloatingPointBlock;

/* exibe o bloco no relat�rio de depura��o */
void FPBlock_log(FloatingPointBlock block, int index, int view);

/* copia o bloco */
void FPBlock_copy(FloatingPointBlock *dest, FloatingPointBlock src);

/* copia os valores de um bloco, convertendo para double */
FloatingPointBlock FPBlock_copyFromBlock(ImageBlocks blocks, int index);

/* copia os valores para um bloco, convertendo e arredondando */
void FPBlock_copyToBlock(FloatingPointBlock block, ImageBlocks blocks, int index);

/* aplica a DCT-II (DCT direta) no bloco */
void FPBlock_applyDCT2(FloatingPointBlock *block);

/* aplica a DCT-II (DCT inversa) no bloco */
void FPBlock_applyDCT3(FloatingPointBlock *block);

/* aplica a quantiza��o no bloco (irrevers�vel) */
void FPBlock_quantize(FloatingPointBlock *block);

/* reverte a quantiza��o no bloco (aproximado) */
void FPBlock_dequantize(FloatingPointBlock *block);



/* == extens�es de ImageBlocks == */

/* converte os dados da imagem para o dom�nio das frequ�ncias */
void ImageBlocks_toFrequencyDomain(ImageBlocks blocks);

/* reverte os dados da imagem no dom�nio das frequ�ncias */
void ImageBlocks_fromFrequencyDomain(ImageBlocks blocks);


/* == estrutura auxiliar da DCT == */

typedef struct {
	//outer: (u, v), inner: (x, y)
	FloatingPointBlock data[BLOCK_SIZE][BLOCK_SIZE];
} DCTMultipliers;

/* obt�m um multiplicador do termo da DCT (constante) */
double DCTMultipliers_DCT2BuildValue(int u, int v, int x, int y);

/* const�i uma matriz de multiplicadores para o coeficiente (u, v) */
FloatingPointBlock DCTMultipliers_DCT2BuildMatrix(int u, int v);

/* obt�m os multiplicadores dos termos da DCT (constantes) */
FloatingPointBlock DCTMultipliers_DCT2Get(int u, int v);
FloatingPointBlock DCTMultipliers_DCT3Get(int x, int y);

/* obt�m um coeficiente da transformada DCT */
double FPBlock_getDCT2Coefficient(int u, int v, FloatingPointBlock g);
double FPBlock_getDCT3Coefficient(int x, int y, FloatingPointBlock g);

#endif
