/*
SCC0261 MULTIM�DIA - 1� SEMESTRE DE 2011
DOCENTE: RUDINEI GOULARTE

PROJETO: COMPRESS�O DE IMAGEM DIGITAL PARTE 3


ALUNOS:
	Jairo Toshio Tuboi 		6427250
	Ricardo Takashi Kagawa		5634712
	Rodrigo Luis Gava Girckus 	5967770
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "util.h"
#include "codec.h"
#include "parte1.h"
#include "parte2.h"
#include "parte3.h"

/* codifica o arquivo bitmap em um bin�rio comprimido */
void encode(FILE* bmp, FILE* bin) {
	
	/* vari�veis da parte 1 */
	BITMAP_FILE_HEADER fh;
	BITMAP_INFO_HEADER ih;
	BinaryFileInfo info;
	BitArray raw_data;
	BitStream in, out;
	RGB_Image image;
	ImageBlocks blocks;
	
	/* vari�veis da parte 2 */
	BlockVectors vectors;
	DCValues dc; EncDCValues edc;
	ACValues ac; EncACValues eac;
	HuffmanTree dc_tree, ac_tree;
	BitArray data;


	
	Log_open("encoder.log");
	
	Log_puts("== INICIO ==");
	Log_nl();
	
	/* bitmap headers */
	
	fseek(bmp, 0, SEEK_SET);
	
	fh = BFH_init(0);
	fh = BFH_read(bmp);
	BFH_log(fh);
	
	ih = BIH_init(0, 0);
	ih = BIH_read(bmp);
	BIH_log(ih);
	
	if(Error_isSet()) {
		Log_puts("== ERRO ==");
		Log_nl();
		Log_close();
		return;
	}
	
	if(fh.type[0] != 'B' || fh.type[1] != 'M' || fh.offBytes != 54) {
		Error_set(ERROR, "Nao eh um arquivo de bitmap.");
	} else if(ih.size != 40) {
		Error_set(ERROR, "Nao eh um arquivo de bitmap.");
	} else if(ih.width % BLOCK_SIZE != 0 || ih.height % BLOCK_SIZE != 0) {
		Error_set(ERROR, "O arquivo de bitmap nao possui formato adequado.");
	} else if(ih.width < 8 || ih.height < 8) {
		Error_set(ERROR, "O arquivo de bitmap nao possui formato adequado.");
	} else if(ih.width > 1280 || ih.height > 800) {
		Error_set(ERROR, "O arquivo de bitmap nao possui formato adequado.");
	} else if(ih.bitCount != 24 || ih.compression != 0) {
		Error_set(ERROR, "O arquivo de bitmap nao possui formato adequado.");
	}
	
	if(Error_isSet()) {
		Log_puts("== ERRO ==");
		Log_nl();
		Log_close();
		return;
	}
	
	info = Info_init();
	Info_setDimensions(&info, ih);
	
	
	
	/* leitura da imagem */
	
	in = BitStream_init(bmp, 'r');
	raw_data = BitStream_read(in, ih.bitCount * ih.width * ih.height);
	BitStream_free(in);
	
	if(Error_isSet()) {
		Info_free(&info);
		BitArray_free(&raw_data);
		Log_puts("== ERRO ==");
		Log_nl();
		Log_close();
		return;
	}
	
	if(Config_getItemOutput(LOG_BITMAP_DATA)) {
		Log_puts("== Bitmap Data ==");
		Log_nl();
		BitArray_log(raw_data, -8, 8);
		Log_nl();
	}
	
	
	
	/* prepara��o da imagem */
	
	image = RGB_Image_fromRaw(raw_data, ih.width, ih.height);
	BitArray_free(&raw_data);
	RGB_Image_log(image);
	
	if(Error_isSet()) {
		Info_free(&info);
		RGB_Image_free(&image);
		Log_puts("== ERRO ==");
		Log_nl();
		Log_close();
		return;
	}
	
	blocks = ImageBlocks_fromRGB(image, info);
	ImageBlocks_log(blocks, LOG_IMAGE_BLOCKS);
	RGB_Image_free(&image);
	
	if(Error_isSet()) {
		Info_free(&info);
		ImageBlocks_free(&blocks);
		Log_puts("== ERRO ==");
		Log_nl();
		Log_close();
		return;
	}
	
	ImageBlocks_levelShift(blocks, -128);
	ImageBlocks_log(blocks, LOG_SHIFTED_BLOCKS);
	
	ImageBlocks_toFrequencyDomain(blocks);
	ImageBlocks_log(blocks, LOG_FD_BLOCKS);
	
	vectors = BlockVectors_fromBlocks(blocks);
	BlockVectors_log(vectors);
	ImageBlocks_free(&blocks);
	
	if(Error_isSet()) {
		Info_free(&info);
		BlockVectors_free(&vectors);
		Log_puts("== ERRO ==");
		Log_nl();
		Log_close();
		return;
	}
	
	
	
	/* codificando os ACs e DCs (carreiras e diferen�as) */
	
	dc = DC_fromVectors(vectors);
	DC_log(dc, FALSE);
	
	if(Error_isSet()) {
		Info_free(&info);
		BlockVectors_free(&vectors);
		DC_free(&dc);
		Log_puts("== ERRO ==");
		Log_nl();
		Log_close();
		return;
	}
	
	ac = AC_fromVectors(vectors);
	AC_log(ac, FALSE);
	
	if(Error_isSet()) {
		Info_free(&info);
		BlockVectors_free(&vectors);
		DC_free(&dc);
		AC_free(&ac);
		Log_puts("== ERRO ==");
		Log_nl();
		Log_close();
		return;
	}
	
	BlockVectors_free(&vectors);
	
	DC_encode(dc);
	DC_log(dc, TRUE);
	
	AC_encode(ac);
	AC_log(ac, TRUE);



	//dados do arquivo bin�rio
	raw_data = BitArray_init(60 + 6700 + //decoders, pior caso
		3 * ih.bitCount * ih.width * ih.height); //dados, pior caso
	
	if(Error_isSet()) {
		Info_free(&info);
		BlockVectors_free(&vectors);
		DC_free(&dc);
		AC_free(&ac);
		BitArray_free(&raw_data);
		Log_puts("== ERRO ==");
		Log_nl();
		Log_close();
		return;
	}
	
	
	
	/* codificando os DCs (complemento e huffman) */
	
	edc = EDC_fromDC(dc);
	EDC_log(edc);
	DC_free(&dc);
	
	if(Error_isSet()) {
		Info_free(&info);
		AC_free(&ac);
		BitArray_free(&raw_data);
		EDC_free(&edc);
		Log_puts("== ERRO ==");
		Log_nl();
		Log_close();
		return;
	}
	
	dc_tree = HTree_fromDC(edc);
	
	if(Config_getItemOutput(LOG_DC_HUFFMAN)) {
		Log_puts("== Arvore Huffman DC ==");
		Log_nl();
		HTree_log(dc_tree, TRUE);
		Log_nl();
	}
	
	if(Error_isSet()) {
		Info_free(&info);
		AC_free(&ac);
		BitArray_free(&raw_data);
		EDC_free(&edc);
		HTree_free(&dc_tree);
		Log_puts("== ERRO ==");
		Log_nl();
		Log_close();
		return;
	}
	
	data = HTree_packageDCDecoder(dc_tree);
	
	if(Config_getItemOutput(LOG_DC_DECODER)) {
		Log_puts("== Decodificador DC ==");
		Log_nl();
		BitArray_log(data, -8, 8);
		Log_nl();
	}
	
	if(Error_isSet()) {
		Info_free(&info);
		AC_free(&ac);
		BitArray_free(&raw_data);
		EDC_free(&edc);
		HTree_free(&dc_tree);
		BitArray_free(&data);
		Log_puts("== ERRO ==");
		Log_nl();
		Log_close();
		return;
	}
	
	BitArray_append(&raw_data, data);
	BitArray_free(&data);
	
	/* codificando os ACs (complemento e huffman) */
	
	eac = EAC_fromAC(ac);
	AC_free(&ac);
	EAC_log(eac);
	
	if(Error_isSet()) {
		Info_free(&info);
		BitArray_free(&raw_data);
		EDC_free(&edc);
		EAC_free(&eac);
		HTree_free(&dc_tree);
		Log_puts("== ERRO ==");
		Log_nl();
		Log_close();
		return;
	}
	
	ac_tree = HTree_fromAC(eac);
	
	if(Config_getItemOutput(LOG_AC_HUFFMAN)) {
		Log_puts("== Arvore Huffman AC ==");
		Log_nl();
		HTree_log(ac_tree, TRUE);
		Log_nl();
	}
	
	if(Error_isSet()) {
		Info_free(&info);
		BitArray_free(&raw_data);
		EDC_free(&edc);
		EAC_free(&eac);
		HTree_free(&dc_tree);
		HTree_free(&ac_tree);
		Log_puts("== ERRO ==");
		Log_nl();
		Log_close();
		return;
	}
	
	data = HTree_packageACDecoder(ac_tree);
	
	if(Config_getItemOutput(LOG_AC_DECODER)) {
		Log_puts("== Decodificador AC ==");
		Log_nl();
		BitArray_log(data, -8, 8);
		Log_nl();
	}
	
	if(Error_isSet()) {
		Info_free(&info);
		BitArray_free(&raw_data);
		EDC_free(&edc);
		EAC_free(&eac);
		HTree_free(&dc_tree);
		HTree_free(&ac_tree);
		BitArray_free(&data);
		Log_puts("== ERRO ==");
		Log_nl();
		Log_close();
		return;
	}
	
	BitArray_append(&raw_data, data);
	BitArray_free(&data);
	
	
	
	/* codificando arquivo bin�rio */
	
	data = HTree_encodeDC(dc_tree, edc);
	HTree_free(&dc_tree);
	EDC_free(&edc);
	
	if(Config_getItemOutput(LOG_DC_BINARY)) {
		Log_puts("== Valores DC (binario) ==");
		Log_nl();
		BitArray_log(data, -8, 8);
		Log_nl();
	}
	
	if(Error_isSet()) {
		Info_free(&info);
		BitArray_free(&raw_data);
		EAC_free(&eac);
		HTree_free(&ac_tree);
		BitArray_free(&data);
		Log_puts("== ERRO ==");
		Log_nl();
		Log_close();
		return;
	}
	
	BitArray_append(&raw_data, data);
	BitArray_free(&data);
	
	data = HTree_encodeAC(ac_tree, eac);
	HTree_free(&ac_tree);
	EAC_free(&eac);
	
	if(Config_getItemOutput(LOG_AC_BINARY)) {
		Log_puts("== Valores AC (binario) ==");
		Log_nl();
		BitArray_log(data, -8, 8);
		Log_nl();
	}
	
	if(Error_isSet()) {
		Info_free(&info);
		BitArray_free(&raw_data);
		BitArray_free(&data);
		Log_puts("== ERRO ==");
		Log_nl();
		Log_close();
		return;
	}
	
	BitArray_append(&raw_data, data);
	BitArray_free(&data);
	
	/* escrevendo o arquivo */
	
	out = BitStream_init(bin, 'w');
	
	Info_setFileSize(&info, raw_data);
	Info_log(info);
	
	Info_write(info, out);
	Info_free(&info);
	
	if(Error_isSet()) {
		BitArray_free(&raw_data);
		BitStream_free(out);
		Log_puts("== ERRO ==");
		Log_nl();
		Log_close();
		return;
	}
	
	if(Config_getItemOutput(LOG_BINARY_DATA)) {
		Log_puts("== Arquivo Binario (payload) ==");
		Log_nl();
		BitArray_log(raw_data, -8, 8);
		Log_nl();
	}
	
	BitStream_write(out, raw_data);
	BitArray_free(&raw_data);
	BitStream_free(out);
	
	if(Error_isSet()) {
		Log_puts("== ERRO ==");
		Log_nl();
		Log_close();
		return;
	}
	
	Log_puts("== FIM ==");
	Log_nl();
	
	Log_close();
	return;
}

/* decodifica o arquivo bitmap de um bin�rio comprimido */
void decode(FILE* bmp, FILE* bin) {
	
	/* vari�veis da parte 1 */
	BinaryFileInfo info;
	ImageBlocks blocks;
	RGB_Image image;
	BitArray raw_data;
	BITMAP_FILE_HEADER fh;
	BITMAP_INFO_HEADER ih;
	BitStream in, out;
	
	/* vari�veis da parte 2 */
	BlockVectors vectors;
	DCValues dc;
	ACValues ac;
	EncDCValues edc;
	EncACValues eac;
	HuffmanTree dc_tree, ac_tree;
	
	Log_open("decoder.log");
	
	
	
	/* lendo o cabe�alho */
	
	in = BitStream_init(bin, 'r');
	info = Info_read(in);
	Info_log(info);
	
	if(Error_isSet()) {
		BitStream_free(in);
		Info_free(&info);
		Log_puts("== ERRO ==");
		Log_nl();
		Log_close();
		return;
	}
	
	/* lendo os dados do arquivo */
	
	raw_data = BitStream_read(in, 8 * info.file_size);
	BitStream_free(in);
	
	if(Error_isSet()) {
		Info_free(&info);
		BitArray_free(&raw_data);
		Log_puts("== ERRO ==");
		Log_nl();
		Log_close();
		return;
	}
	
	if(Config_getItemOutput(LOG_BINARY_DATA)) {
		Log_puts("== Dados lidos do arquivo (payload) ==");
		Log_nl();
		BitArray_log(raw_data, -8, 8);
		Log_nl();
	}
	
	
	
	/* extraindo os decodificadores AC e DC */
	
	dc_tree = HTree_extractDCDecoder(&raw_data);
	
	if(Error_isSet()) {
		Info_free(&info);
		BitArray_free(&raw_data);
		HTree_free(&dc_tree);
		Log_puts("== ERRO ==");
		Log_nl();
		Log_close();
		return;
	}
	
	if(Config_getItemOutput(LOG_DC_HUFFMAN)) {
		Log_puts("== Arvore Huffman DC ==");
		Log_nl();
		HTree_log(dc_tree, FALSE);
		Log_nl();
	}
	
	ac_tree = HTree_extractACDecoder(&raw_data);
	
	if(Error_isSet()) {
		Info_free(&info);
		BitArray_free(&raw_data);
		HTree_free(&dc_tree);
		HTree_free(&ac_tree);
		Log_puts("== ERRO ==");
		Log_nl();
		Log_close();
		return;
	}
	
	if(Config_getItemOutput(LOG_AC_HUFFMAN)) {
		Log_puts("== Arvore Huffman AC ==");
		Log_nl();
		HTree_log(ac_tree, FALSE);
		Log_nl();
	}
	
	
	
	/* decodificando DCs (huffman e complemento) */
	
	edc = HTree_decodeDC(dc_tree, &raw_data, info);
	HTree_free(&dc_tree);
	EDC_log(edc);
	
	if(Error_isSet()) {
		Info_free(&info);
		BitArray_free(&raw_data);
		HTree_free(&ac_tree);
		EDC_free(&edc);
		Log_puts("== ERRO ==");
		Log_nl();
		Log_close();
		return;
	}
	
	dc = EDC_toDC(edc);
	DC_log(dc, TRUE);
	EDC_free(&edc);
	
	if(Error_isSet()) {
		Info_free(&info);
		BitArray_free(&raw_data);
		HTree_free(&ac_tree);
		DC_free(&dc);
		Log_puts("== ERRO ==");
		Log_nl();
		Log_close();
		return;
	}
	
	
	
	/* decodificando ACs (huffman e complemento) */
	
	eac = HTree_decodeAC(ac_tree, &raw_data, info);
	BitArray_free(&raw_data);
	HTree_free(&ac_tree);
	EAC_log(eac);
	
	if(Error_isSet()) {
		Info_free(&info);
		DC_free(&dc);
		EAC_free(&eac);
		Log_puts("== ERRO ==");
		Log_nl();
		Log_close();
		return;
	}
	
	ac = EAC_toAC(eac);
	AC_log(ac, TRUE);
	EAC_free(&eac);
	
	if(Error_isSet()) {
		Info_free(&info);
		AC_free(&ac);
		DC_free(&dc);
		Log_puts("== ERRO ==");
		Log_nl();
		Log_close();
		return;
	}
	
	
	
	/* decodificando ACs e DCs (carreiras e diferen�as) */
	
	DC_decode(dc);
	DC_log(dc, FALSE);
	
	AC_decode(ac);
	AC_log(ac, FALSE);
	
	vectors = BlockVectors_init(3 * info.width * info.height);
	if(Error_isSet()) {
		Info_free(&info);
		AC_free(&ac);
		DC_free(&dc);
		BlockVectors_free(&vectors);
		Log_puts("== ERRO ==");
		Log_nl();
		Log_close();
		return;
	}
	
	AC_toVectors(ac, vectors);
	DC_toVectors(dc, vectors);
	BlockVectors_log(vectors);
	AC_free(&ac);
	DC_free(&dc);
	
	
	
	/* restaurando os blocos */
	
	blocks = BlockVectors_toBlocks(vectors, info);
	ImageBlocks_log(blocks, LOG_FD_BLOCKS);
	BlockVectors_free(&vectors);
	
	if(Error_isSet()) {
		Info_free(&info);
		ImageBlocks_free(&blocks);
		Log_puts("== ERRO ==");
		Log_nl();
		Log_close();
		return;
	}
	
	ImageBlocks_fromFrequencyDomain(blocks);
	ImageBlocks_log(blocks, LOG_SHIFTED_BLOCKS);
	
	ImageBlocks_levelShift(blocks, +128);
	ImageBlocks_log(blocks, LOG_IMAGE_BLOCKS);
	
	/* recomposi��o da imagem */
	
	image = ImageBlocks_toRGB(blocks, info);
	ImageBlocks_free(&blocks);
	Info_free(&info);
	RGB_Image_log(image);
	
	if(Error_isSet()) {
		RGB_Image_free(&image);
		Log_puts("== ERRO ==");
		Log_nl();
		Log_close();
		return;
	}
	
	
	
	/* bitmap headers */
	
	ih = BIH_init(image.width, image.height);
	fh = BFH_init(ih.sizeImage);
	
	BFH_log(fh);
	BIH_log(ih);
	
	fseek(bmp, 0, SEEK_SET);
	BFH_write(fh, bmp);
	BIH_write(ih, bmp);
	
	if(Error_isSet()) {
		RGB_Image_free(&image);
		Log_puts("== ERRO ==");
		Log_nl();
		Log_close();
		return;
	}
	
	/* grava��o da imagem */
	
	raw_data = RGB_Image_toRaw(image);
	RGB_Image_free(&image);
	
	if(Config_getItemOutput(LOG_BITMAP_DATA)) {
		Log_puts("== Bitmap Image Data ==");
		Log_nl();
		BitArray_log(raw_data, -8, 8);
		Log_nl();
	}
	
	if(Error_isSet()) {
		BitArray_free(&raw_data);
		Log_puts("== ERRO ==");
		Log_nl();
		Log_close();
		return;
	}
	
	out = BitStream_init(bmp, 'w');
	BitStream_write(out, raw_data);
	BitStream_free(out);
	BitArray_free(&raw_data);
	
	if(Error_isSet()) {
		Log_puts("== ERRO ==");
		Log_nl();
		Log_close();
		return;
	}
	
	Log_puts("== FIM ==");
	Log_nl();
	
	Log_close();
	return;
}
