/*
SCC0261 MULTIM�DIA - 1� SEMESTRE DE 2011
DOCENTE: RUDINEI GOULARTE

PROJETO: COMPRESS�O DE IMAGEM DIGITAL PARTE 3


ALUNOS:
	Jairo Toshio Tuboi 		6427250
	Ricardo Takashi Kagawa		5634712
	Rodrigo Luis Gava Girckus 	5967770
*/

#include <stdlib.h>
#include <string.h>

#include "defs.h"
#include "util.h"
#include "parte1.h"
#include "parte2.h"



/* ==== blocos vetorizados ==== */

BlockVectors BlockVectors_init(int size) {
	int i, j;
	BlockVectors vectors;
	
	vectors.size = size;
	vectors.data = (char**) malloc(size * sizeof(char*));
	if(vectors.data == NULL) {
		Error_set(ERROR, "Memoria insuficiente.");
		vectors.size = 0;
		return vectors;
	}
	
	for(i = 0; i < size; i++) //prepara��o para erros
		vectors.data[i] = NULL;
	
	for(i = 0; i < size; i++) {
		vectors.data[i] = (char*) malloc(BLOCK_SIZE * BLOCK_SIZE * sizeof(char));
		if(vectors.data[i] == NULL) {
			Error_set(ERROR, "Memoria insuficiente.");
			BlockVectors_free(&vectors);
			return vectors;
		}
		
		for(j = 0; j < BLOCK_SIZE * BLOCK_SIZE; j++)
			vectors.data[i][j] = 0;
	}
	
	return vectors;
}

void BlockVectors_free(BlockVectors *vectors) {
	int i;
	if(vectors->data != NULL) {
		for(i = 0; i < vectors->size; i++) {
			if(vectors->data[i] != NULL)
				free(vectors->data[i]);
		}
		free(vectors->data);
	}
	vectors->data = NULL;
	vectors->size = 0;
	return;
}

void BlockVectors_log(BlockVectors vectors) {
	int i, j;
	if(!Config_getItemOutput(LOG_TRACED_BLOCKS))
		return;
	
	Log_puts("== Blocos Vetorizados ==");
	Log_nl();
	for(i = 0; i < vectors.size; i++) {
		for(j = 0; j < BLOCK_SIZE * BLOCK_SIZE; j++) {
			Log_printf("%+.3d ", vectors.data[i][j]);
			if((j + 1) % BLOCK_SIZE == 0) Log_nl();
		}
		Log_nl();
	}
	Log_nl();
	return;
}

BlockVectors BlockVectors_fromBlocks(ImageBlocks blocks) {
	int i, j, k;
	int map[BLOCK_SIZE][BLOCK_SIZE] = TRACE_MAP;
	BlockVectors vectors = BlockVectors_init(blocks.size);
	if(Error_isSet()) return vectors;
	
	for(k = 0; k < blocks.size; k++) {
		for(i = 0; i < BLOCK_SIZE; i++) {
			for(j = 0; j < BLOCK_SIZE; j++)
				vectors.data[k][map[i][j]] = blocks.data[k][i][j];
		}
	}
	return vectors;
}

ImageBlocks BlockVectors_toBlocks(BlockVectors vectors, BinaryFileInfo info) {
	int i, j, k; 
	short map[BLOCK_SIZE][BLOCK_SIZE] = TRACE_MAP;
	ImageBlocks blocks = ImageBlocks_init(info);
	if(Error_isSet()) return blocks;
	
	for(k = 0; k < vectors.size; k++) {
		for(i = 0; i < BLOCK_SIZE; i++) {
			for(j = 0; j < BLOCK_SIZE; j++)
				blocks.data[k][i][j] = vectors.data[k][map[i][j]];
		}
	}
	return blocks;
}



/* ==== valores DC ==== */

DCValues DC_init(int size) {
	DCValues dc;
	dc.data = (short*) malloc(size * sizeof(short));
	if(dc.data == NULL) {
		dc.size = 0;
		Error_set(ERROR, "Memoria insuficiente.");
	} else
		dc.size = size;
	return dc;
}

void DC_free(DCValues *dc) {
	if(dc->data != NULL)
		free(dc->data);
	dc->data = NULL;
	dc->size = 0;
	return;
}

void DC_log(DCValues dc, int encoded) {
	int i;
	if(!encoded && !Config_getItemOutput(LOG_DC_RAW)) return;
	if(encoded && !Config_getItemOutput(LOG_DC_DELTA)) return;
	
	Log_puts(encoded? 
			"== Valores DC (diferencas) ==": 
			"== Valores DC ==");
	Log_nl();
	
	for(i = 0; i < dc.size; i++) {
		Log_printf("%+.3d ", dc.data[i]);
		if((i + 1) % 10 == 0) Log_nl();
	}
	if(i % 10 != 0) Log_nl();
	Log_nl();
}

DCValues DC_fromVectors(BlockVectors vectors) {
	int i;
	DCValues dc = DC_init(vectors.size);
	if(Error_isSet()) return dc;
	for(i = 0; i < vectors.size; i++)
		dc.data[i] = vectors.data[i][0];
	return dc;
}

/* insere os valores DC nos blocos vetorizados */
void DC_toVectors(DCValues dc, BlockVectors vectors) {
	int i;
	for(i = 0; i < dc.size; i++)
		vectors.data[i][0] = dc.data[i];
	return;
}

/* codifica os valores DC por diferen�as */
void DC_encode(DCValues dc) {
	int i;
	for(i = dc.size - 1; i > 0; i--)
		dc.data[i] = dc.data[i] - dc.data[i - 1];
	return;
}

/* decodifica os valores DC codificados por diferen�as */
void DC_decode(DCValues dc) {
	int i;
	for(i = 0; i < dc.size - 1; i++)
		dc.data[i + 1] = dc.data[i] + dc.data[i + 1];
	return;
}



/* ==== valores AC ==== */

ACValues AC_init(int block_count) {
	int i, j, n;
	ACValues ac;
	
	ac.nb = block_count;
	
	ac.np = (int*) malloc(ac.nb * sizeof(int));
	if(ac.np == NULL) {
		Error_set(ERROR, "Memoria insuficiente.");
		AC_free(&ac);
		return ac;
	}
	
	ac.data = (ACValue**) malloc(ac.nb * sizeof(ACValue*));
	if(ac.data == NULL) {
		Error_set(ERROR, "Memoria insuficiente.");
		AC_free(&ac);
		return ac;
	}
	
	for(i = 0; i < ac.nb; i++) {
		ac.data[i] = NULL; //prepara��o para erros
		ac.np[i] = 0;
	}
	
	n = BLOCK_SIZE * BLOCK_SIZE - 1;
	for(i = 0; i < ac.nb; i++) {
		ac.data[i] = (ACValue*) malloc(n * sizeof(ACValue));
		if(ac.data[i] == NULL) {
			Error_set(ERROR, "Memoria insuficiente.");
			AC_free(&ac);
			return ac;
		}
		
		for(j = 0; j < n; j++) {
			ac.data[i][j].value = 0;
			ac.data[i][j].repeat = 0;
		}
	}
	
	return ac;
}

void AC_free(ACValues *ac) {
	int i;
	if(ac->np != NULL) {
		if(ac->data != NULL) {
			for(i = 0; i < ac->nb; i++) {
				if(ac->data[i] != NULL)
					free(ac->data[i]);
			}
			free(ac->data);
		}
		free(ac->np);
	}
	ac->data = NULL;
	ac->np = NULL;
	ac->nb = 0;
	return;
}

void AC_log(ACValues ac, int encoded) {
	int i, j;
	if(!encoded && !Config_getItemOutput(LOG_AC_RAW)) return;
	if(encoded && !Config_getItemOutput(LOG_AC_RLE)) return;
	
	Log_puts(encoded? 
			"== Valores AC (carreira) ==": 
			"== Valores AC ==");
	Log_nl();
	
	for(i = 0; i < ac.nb; i++) {
		for(j = 0; j < ac.np[i]; j++) {
			if(encoded) {
				Log_printf("%+.3d:%-2d ", 
						ac.data[i][j].value, 
						ac.data[i][j].repeat);
			} else
				Log_printf("%+.3d ", ac.data[i][j].value);
			if((j + 1) % BLOCK_SIZE == 0) Log_nl();
		}
		
		if(j % BLOCK_SIZE != 0) 
			Log_nl();
		Log_nl();
	}
	Log_nl();
	return;
}

ACValues AC_fromVectors(BlockVectors vectors) {
	int i, j;
	ACValues ac = AC_init(vectors.size);
	if(Error_isSet()) return ac;
	for(i = 0; i < vectors.size; i++) {
		ac.np[i] = BLOCK_SIZE * BLOCK_SIZE - 1;
		for(j = 0; j < ac.np[i]; j++) {
			ac.data[i][j].value = vectors.data[i][j + 1];
			ac.data[i][j].repeat = 1;
		}
	}
	return ac;
}

void AC_toVectors(ACValues ac, BlockVectors vectors) {
	int i, j;
	for(i = 0; i < ac.nb; i++) {
		for(j = 0; j < ac.np[i]; j++)
			vectors.data[i][j + 1] = ac.data[i][j].value;
	}
	return;
}

void AC_encode(ACValues ac) {
	int i, j, k;
	ACValue r[BLOCK_SIZE * BLOCK_SIZE - 1];
	
	for(i = 0; i < ac.nb; i++) {
		k = 0; 
		r[k].value = ac.data[i][0].value;
		r[k].repeat = 0;
		
		for(j = 0; j < ac.np[i]; j++) {
			if(ac.data[i][j].value != r[k].value) {
				k++;
				r[k].value = ac.data[i][j].value;
				r[k].repeat = 1;
			} else
				r[k].repeat++;
		}
		
		ac.np[i] = k + 1;
		for(j = 0; j < ac.np[i]; j++)
			ac.data[i][j] = r[j];
	}
	return;
}

void AC_decode(ACValues ac) {
	char vector[BLOCK_SIZE * BLOCK_SIZE - 1];
	int i, j, k, p; ACValue v;
	
	for(i = 0; i < ac.nb; i++) {
		p = 0;
		for(j = 0; j < ac.np[i]; j++) {
			v = ac.data[i][j];
			for(k = 0; k < v.repeat; k++)
				vector[p++] = v.value;
		}
		ac.np[i] = p;
		
		for(j = 0; j < ac.np[i]; j++) {
			ac.data[i][j].value = vector[j];
			ac.data[i][j].repeat = 1;
		}
	}
	return;
}



/* ==== Valores DC (complemento) == */

EncDCValues EDC_init(int size) {
	EncDCValues edc;
	edc.data = (BitArray*) malloc(size * sizeof(BitArray));
	if(edc.data == NULL) {
		edc.size = 0;
		Error_set(ERROR, "Memoria insuficiente.");
	} else
		edc.size = size;
	return edc;
}

void EDC_free(EncDCValues *edc) {
	if(edc->data != NULL)
		free(edc->data);
	edc->data = NULL;
	edc->size = 0;
	return;
}

void EDC_log(EncDCValues edc) {
	int i, value, size;
	if(!Config_getItemOutput(LOG_DC_ENCODED)) return;
	
	Log_puts("== Valores DC (complemento) ==");
	Log_nl();
	for(i = 0; i < edc.size; i++) {
		size = edc.data[i].size;
		value = BitArray_get(edc.data[i], 0, size);
		Log_printf("%8s", btoa(value, size, 0));
		Log_printf((i + 1) % 8 == 0? "\n": ".");
	}
	if(i % 8 != 0) Log_nl();
	Log_nl();
	return;
}

EncDCValues EDC_fromDC(DCValues dc) {
	int i;
	EncDCValues edc = EDC_init(dc.size);
	if(Error_isSet()) return edc;
	
	for(i = 0; i < dc.size; i++)
		edc.data[i] = BitArray_encode(dc.data[i]);
	return edc;
}

DCValues EDC_toDC(EncDCValues edc) {
	int i;
	DCValues dc = DC_init(edc.size);
	if(Error_isSet()) return dc;
	
	for(i = 0; i < edc.size; i++)
		dc.data[i] = BitArray_decode(edc.data[i]);
	return dc;
}



/* ==== Valores AC (complemento) == */

EncACValues EAC_init(int block_count) {
	int i, j, n;
	EncACValues eac;
	
	eac.nb = block_count;
	
	eac.np = (int*) malloc(eac.nb * sizeof(int));
	if(eac.np == NULL) {
		Error_set(ERROR, "Memoria insuficiente.");
		EAC_free(&eac);
		return eac;
	}
	
	eac.data = (EncACValue**) malloc(eac.nb * sizeof(EncACValue*));
	if(eac.data == NULL) {
		Error_set(ERROR, "Memoria insuficiente.");
		EAC_free(&eac);
		return eac;
	}
	
	for(i = 0; i < eac.nb; i++) {
		eac.data[i] = NULL; //prepara��o para erros
		eac.np[i] = 0;
	}
	
	n = BLOCK_SIZE * BLOCK_SIZE - 1;
	for(i = 0; i < eac.nb; i++) {
		eac.data[i] = (EncACValue*) malloc(n * sizeof(EncACValue));
		if(eac.data[i] == NULL) {
			Error_set(ERROR, "Memoria insuficiente.");
			EAC_free(&eac);
			return eac;
		}
		
		for(j = 0; j < n; j++) {
			eac.data[i][j].value = BitArray_init(8);
			eac.data[i][j].repeat = 0;
		}
	}
	
	return eac;
}

void EAC_free(EncACValues *eac) {
	int i, j, n;
	if(eac->np != NULL) {
		if(eac->data != NULL) {
			
			n = BLOCK_SIZE * BLOCK_SIZE - 1;
			for(i = 0; i < eac->nb; i++) {
				if(eac->data[i] != NULL) {
					for(j = 0; j < n; j++)
						BitArray_free(&(eac->data[i][j].value));
					free(eac->data[i]);
				}
			}
			
			free(eac->data);
		}
		free(eac->np);
	}
	eac->data = NULL;
	eac->np = NULL;
	eac->nb = 0;
	return;
}

void EAC_log(EncACValues eac) {
	int i, j;
	if(!Config_getItemOutput(LOG_AC_ENCODED)) return;
	
	Log_puts("== Valores AC (complemento) ==");
	Log_nl();
	for(i = 0; i < eac.nb; i++) {
		for(j = 0; j < eac.np[i]; j++) {
			short n = eac.data[i][j].value.size;
			short v = BitArray_get(eac.data[i][j].value, 0, n);
			short r = eac.data[i][j].repeat;
			Log_printf("%8s:%-2d", btoa(v, n, 0), r);
			Log_printf(((j + 1) % BLOCK_SIZE == 0)? "\n": "  ");
		}
		
		if(j % BLOCK_SIZE != 0) 
			Log_nl();
		Log_nl();
	}
	Log_nl();
	return;
}

EncACValues EAC_fromAC(ACValues ac) {
	int i, j;
	EncACValues eac = EAC_init(ac.nb);
	if(Error_isSet()) return eac;
	for(i = 0; i < ac.nb; i++) {
		eac.np[i] = ac.np[i];
		for(j = 0; j < ac.np[i]; j++) {
			BitArray_free(&(eac.data[i][j].value));
			eac.data[i][j].value = BitArray_encode(ac.data[i][j].value);
			eac.data[i][j].repeat = ac.data[i][j].repeat;
		}
	}
	return eac;
}

ACValues EAC_toAC(EncACValues eac) {
	int i, j;
	ACValues ac = AC_init(eac.nb);
	if(Error_isSet()) return ac;
	for(i = 0; i < eac.nb; i++) {
		ac.np[i] = eac.np[i];
		for(j = 0; j < eac.np[i]; j++) {
			ac.data[i][j].value = BitArray_decode(eac.data[i][j].value);
			ac.data[i][j].repeat = eac.data[i][j].repeat;
		}
	}
	return ac;
}




/* ==== Metadados AC/DC ==== */

MetaDataArray MDArray_init(int cap) {
	MetaDataArray a;
	a.size = 0;
	a.data = (MetaData*) malloc(cap * sizeof(MetaData));
	if(a.data == NULL)
		Error_set(ERROR, "Memoria insuficiente.");
	return a;
}

void MDArray_free(MetaDataArray* a) {
	if(a->data != NULL)
		free(a->data);
	a->data = NULL;
	a->size = 0;
	return;
}

MetaDataArray MDArray_fromDC(EncDCValues edc) {
	int i; 
	MetaDataArray a = MDArray_init(edc.size);
	for(i = 0; i < edc.size; i++) {
		a.data[i].size = edc.data[i].size;
		a.data[i].repeat = 0;
	}
	a.size = edc.size;
	return a;
}

MetaDataArray MDArray_fromAC(EncACValues eac) {
	int i, j, n = 0;
	MetaDataArray a;
	
	for(i = 0; i < eac.nb; i++)
		n += eac.np[i];
	a = MDArray_init(n);
	a.size = n;
	
	n = 0;
	for(i = 0; i < eac.nb; i++) {
		for(j = 0; j < eac.np[i]; j++) {
			a.data[n].size = eac.data[i][j].value.size;
			a.data[n].repeat = eac.data[i][j].repeat;
			n++;
		}
	}
	return a;
}



/* ==== N� da �rvore de Huffman ==== */

HuffmanNode HNode_init(short type) {
	HuffmanNode node;
	node.type = type;
	node.count = 0;
	node.is_left = FALSE;
	node.parent = NULL;
	if(type == TREE_LEAF) {
		node.value.repeat = 0;
		node.value.size = 0;
	} else {
		node.left = NULL;
		node.right = NULL;
	}
	return node;
}

HuffmanNode* HNode_create(short type) {
	HuffmanNode* node = (HuffmanNode*) 
			malloc(sizeof(struct _HuffmanNode));;
	if(node == NULL) {
		Error_set(ERROR, "Memoria insuficiente.");
		return NULL;
	}
	
	node->type = type;
	node->count = 0;
	node->is_left = FALSE;
	node->parent = NULL;
	if(type == TREE_LEAF) {
		node->value.repeat = 0;
		node->value.size = 0;
	} else {
		node->left = NULL;
		node->right = NULL;
	}
	return node;
}

void HNode_free(HuffmanNode* node) {
	if(node->type == TREE_NODE) {
		HNode_free(node->left);
		HNode_free(node->right);
		free(node->left);
		free(node->right);
	}
	return;
}

void HNode_log(HuffmanNode* node, char prefix[], short encoder) {
	int p = strlen(prefix);
	if(encoder) {
		if(node->type == TREE_NODE) {
			Log_printf("%s%d\n", prefix, node->count);
			if(p > 0) {
				prefix[p - 3] = 0;
				strcat(prefix, node->is_left? "|  ": "   ");
			}
			
			prefix[p] = 0; strcat(prefix, "+->");
			HNode_log(node->left, prefix, encoder);
			
			prefix[p] = 0; strcat(prefix, "+->");
			HNode_log(node->right, prefix, encoder);
		} else {
			Log_printf("%s%d:(%d; %2d)\n", prefix, node->count, 
					node->value.size, node->value.repeat);
		}
	} else {
		if(node->type == TREE_NODE) {
			Log_printf("%s*\n", prefix);
			if(p > 0) {
				prefix[p - 2] = 0;
				strcat(prefix, node->is_left? "| ": "  ");
			}
			
			prefix[p] = 0; strcat(prefix, "+-");
			HNode_log(node->left, prefix, encoder);
			
			prefix[p] = 0; strcat(prefix, "+-");
			HNode_log(node->right, prefix, encoder);
		} else {
			Log_printf("%s(%d; %2d)\n", prefix, 
					node->value.size, node->value.repeat);
		}
	}
	return;
}

void HNode_encodeDC(HuffmanNode* node, BitArray* data) {
	if(node->type == TREE_NODE) {
		BitArray_add(data, 0, 1);
		HNode_encodeDC(node->left, data);
		HNode_encodeDC(node->right, data);
	} else {
		BitArray_add(data, 1, 1);
		BitArray_add(data, node->value.size, 4);
	}
	return;
}

void HNode_encodeAC(HuffmanNode* node, BitArray* data) {
	if(node->type == TREE_NODE) {
		BitArray_add(data, 0, 1);
		HNode_encodeAC(node->left, data);
		HNode_encodeAC(node->right, data);
	} else {
		BitArray_add(data, 1, 1);
		BitArray_add(data, node->value.size, 4);
		BitArray_add(data, node->value.repeat, 6);
	}
}



/* ==== Frequ�ncias de Metadados ==== */

FrequencyTable FTable_init(int size) {
	FrequencyTable table; int i;
	
	table.data = (HuffmanNode*) malloc(size * sizeof(HuffmanNode));
	if(table.data == NULL) {
		Error_set(ERROR, "Memoria insuficiente.");
		table.size = 0;
		return table;
	}
	
	table.size = 0;
	for(i = 0; i < size; i++)
		table.data[i] = HNode_init(TREE_LEAF);
	
	return table;
}

void FTable_free(FrequencyTable *table) {
	if(table->data != NULL)
		free(table->data);
	table->data = NULL;
	table->size = 0;
	return;
}

void FTable_log(FrequencyTable table) {
	int i;
	if(!Config_getItemOutput(LOG_FREQUENCIES)) 
		return;
	
	Log_puts("== Tabela de Frequencias ==");
	Log_nl();
	if(table.size > 0) {
		for(i = 0; i < table.size; i++) {
			HuffmanNode e = table.data[i];
			Log_printf("(%d; %2d) -- %d\n", 
				e.value.size, e.value.repeat, e.count);
		}
	} else
		Log_puts("(vazia)");
	Log_nl();
	return;
}

void FTable_count(FrequencyTable* table, MetaDataArray a) {
	int i, j, found; HuffmanNode node;
	
	table->size = 0;
	for(i = 0; i < a.size; i++) {
		found = FALSE;
		for(j = 0; j < table->size && !found; j++) {
			node = table->data[j];
			if(node.value.size == a.data[i].size && 
					node.value.repeat == a.data[i].repeat) {
				table->data[j].count++;
				found = TRUE;
			}
		}
		
		if(!found) {
			node = HNode_init(TREE_LEAF);
			node.value = a.data[i];
			node.count = 1;
			table->data[(table->size)++] = node;
		}
	}
	
	return;
}

FrequencyTable FTable_clone(FrequencyTable src) {
	int i;
	FrequencyTable dest = FTable_init(src.size);
	if(Error_isSet()) return dest;
	
	for(i = 0; i < src.size; i++) 
		dest.data[i] = src.data[i];
	dest.size = src.size;
	return dest;
}



/* ==== �rvore de Huffman ==== */

void mergesort(HuffmanNode a[], int n) {
	int i, l, r; HuffmanNode *buffer;
	
	if(n == 1) return;
	if(Error_isSet()) return;
	
	mergesort(a, n / 2);
	mergesort(a + n / 2, n - n / 2);
	
	buffer = (HuffmanNode*) malloc(n * sizeof(HuffmanNode));
	if(buffer == NULL) {
		Error_set(ERROR, "Memoria insuficiente.");
		return;
	}
	
	l = 0; r = n / 2; i = 0;
	while(l < n / 2 && r < n) {
		buffer[i++] = 
			(a[l].count >= a[r].count)? 
			a[l++]: a[r++];
	}
	while(l < n / 2) buffer[i++] = a[l++];
	while(r < n) buffer[i++] = a[r++];
	
	for(i = 0; i < n; i++)
		a[i] = buffer[i];
	
	free(buffer);
	return;
}

HuffmanTree HTree_init() {
	HuffmanTree tree;
	tree.nleaves = 0;
	tree.root = NULL;
	return tree;
}

void HTree_free(HuffmanTree* tree) {
	if(tree->root != NULL) {
		HNode_free(tree->root);
		free(tree->root);
	}
	tree->root = NULL;
	tree->nleaves = 0;
	return;
}

void HTree_log(HuffmanTree tree, short encoder) {
	char prefix[LINE_MAX];
	prefix[0] = 0;
	if(tree.root != NULL) {
		HNode_log(tree.root, prefix, encoder);
		Log_nl();
	}
	Log_printf("(%d folhas)\n", tree.nleaves);
	Log_nl();
	return;
}

HuffmanTree HTree_fromDC(EncDCValues edc) {
	MetaDataArray a = MDArray_fromDC(edc);
	FrequencyTable table = FTable_init(9);
	HuffmanTree tree = HTree_init();
	
	if(Error_isSet()) {
		MDArray_free(&a);
		FTable_free(&table);
		return tree;
	}
	
	//contar frequ�ncias
	FTable_count(&table, a);
	FTable_log(table);
	MDArray_free(&a);
	
	//montar �rvore
	tree = HTree_fromCount(table);
	FTable_free(&table);
	return tree;
}

HuffmanTree HTree_fromAC(EncACValues eac) {
	MetaDataArray a = MDArray_fromAC(eac);
	FrequencyTable table = FTable_init(500);
	HuffmanTree tree = HTree_init();

	if(Error_isSet()) {
		MDArray_free(&a);
		FTable_free(&table);
		return tree;
	}
	
	//contar frequ�ncias
	FTable_count(&table, a);
	FTable_log(table);
	MDArray_free(&a);
	
	//montar �rvore
	tree = HTree_fromCount(table);
	FTable_free(&table);
	return tree;
}

HuffmanTree HTree_fromCount(FrequencyTable table) {
	HuffmanNode na, nb, nc;
	HuffmanTree tree = HTree_init();
	FrequencyTable ft = FTable_clone(table);
	if(Error_isSet()) return tree;
	
	tree.nleaves = ft.size;
	mergesort(ft.data, ft.size);
	while(ft.size > 1) {
		na = ft.data[ft.size - 1];
		nb = ft.data[ft.size - 2];
		nc = HNode_init(TREE_NODE);
		
		nc.count = na.count + nb.count;
		nc.left = HNode_create(TREE_LEAF);
		nc.right = HNode_create(TREE_LEAF);
		na.is_left = TRUE;	*(nc.left) = na;
		nb.is_left = FALSE;	*(nc.right) = nb;
		
		ft.data[ft.size - 2] = nc; ft.size--;
		mergesort(ft.data, ft.size);
	}
	
	tree.root = HNode_create(TREE_LEAF);
	if(Error_isSet())
		tree.nleaves = 0;
	else
		*(tree.root) = ft.data[0];
	FTable_free(&ft);
	return tree;
}

int HTree_getACDecoderSize(HuffmanNode* node) {
	return 0;
}

BitArray HTree_packageDCDecoder(HuffmanTree decoder) {
	BitArray data = BitArray_init(60);
	if(Error_isSet()) return data;
	HNode_encodeDC(decoder.root, &data);
	return data;
}

BitArray HTree_packageACDecoder(HuffmanTree decoder) {
	BitArray data = BitArray_init(6700);
	if(Error_isSet()) return data;
	HNode_encodeAC(decoder.root, &data);
	return data;
}

HuffmanNode* HTree_next(HuffmanNode* leaf) {
	HuffmanNode* node = leaf;
	if(node->is_left) {
		node = node->parent->right;
	} else {
		int found = FALSE;
		node = node->parent;
		while(node != NULL && !found) {
			if(node->is_left)
				found = TRUE;
			else
				node = node->parent;
		}
		if(found) node = node->parent->right;
	}
	return node;
}

HuffmanTree HTree_extractDCDecoder(BitArray* data) {
	unsigned value, p = 0;
	HuffmanTree tree = HTree_init();
	HuffmanNode *node;
	
	tree.root = HNode_create(TREE_LEAF);
	node = tree.root;
	do {
		/* come�a lendo o tipo do n� (1 bit) */
		value = BitArray_get(*data, p, 1); p += 1;
		if(value == TREE_LEAF) {
			/* n� folha */
			node->type = TREE_LEAF;
			tree.nleaves++;
			
			/* ler dados do n� filho */
			node->value.size = BitArray_get(*data, p, 4); p += 4;
			node->value.repeat = 0;
			
			node = HTree_next(node);
		} else {
			/* n� intermedi�rio */
			node->type = TREE_NODE;
			
			node->left = HNode_create(TREE_LEAF);
			node->left->parent = node;
			node->left->is_left = TRUE;
			
			node->right = HNode_create(TREE_LEAF);
			node->right->parent = node;
			node->right->is_left = FALSE;
			
			node = node->left;
		}
	} while(node != NULL);

	BitArray_remove(data, 0, p);
	return tree;
}

HuffmanTree HTree_extractACDecoder(BitArray* data) {
	unsigned value, p = 0;
	HuffmanTree tree = HTree_init();
	HuffmanNode *node;
	
	tree.root = HNode_create(TREE_LEAF);
	node = tree.root;
	do {
		/* come�a lendo o tipo do n� (1 bit) */
		value = BitArray_get(*data, p, 1); p += 1;
		
		if(value == TREE_LEAF) {
			/* n� folha */
			node->type = TREE_LEAF;
			tree.nleaves++;
			
			/* ler dados do n� filho */
			node->value.size = BitArray_get(*data, p, 4); p += 4;
			node->value.repeat = BitArray_get(*data, p, 6); p += 6;
			
			node = HTree_next(node);
		} else {
			/* n� intermedi�rio */
			node->type = TREE_NODE;
			
			node->left = HNode_create(TREE_LEAF);
			node->left->parent = node;
			node->left->is_left = TRUE;
			
			node->right = HNode_create(TREE_LEAF);
			node->right->parent = node;
			node->right->is_left = FALSE;
			
			node = node->left;
		}
	} while(node != NULL);

	BitArray_remove(data, 0, p);
	return tree;
}



/* ==== Dicion�rio de Codifica��o ==== */

EncoderDictionary Dictionary_init(int size) {
	EncoderDictionary map;
	map.data = (EncoderMapping*) malloc(size * sizeof(struct _EncoderMapping));
	if(map.data == NULL)
		Error_set(ERROR, "Memoria insuficiente.");
	map.size = 0;
	return map;
}

void Dictionary_free(EncoderDictionary* map) {
	if(map->data != NULL) {
		int i;
		for(i = 0; i < map->size; i++)
			BitArray_free(&(map->data[i].value));
		free(map->data);
	}
	map->data = NULL;
	map->size = 0;
	return;
}

void Dictionary_log(EncoderDictionary map) {
	int i;
	if(!Config_getItemOutput(LOG_DICTIONARY)) return;
	Log_puts("== Dicionario de Codificacao Huffman ==");
	Log_nl();
	if(map.size == 0) {
		Log_puts("(vazio)");
	} else {
		for(i = 0; i < map.size; i++) {
			MetaData key = map.data[i].key;
			Log_printf("(%d; %2d) --> ", key.size, key.repeat);
			BitArray_log(map.data[i].value, -8, 0);
		}
	}
	Log_nl();
	return;
}

EncoderDictionary Dictionary_fromTree(HuffmanTree tree) {
	HuffmanNode *node; BitArray code;
	EncoderDictionary map = Dictionary_init(tree.nleaves);
	
	if(Error_isSet()) return map;
	
	//left = 0, right = 1
	code = BitArray_init(8 * sizeof(unsigned));
	
	node = tree.root; 
	node->parent = NULL;
	node->is_left = FALSE;
	do {
		if(node->type == TREE_LEAF) {
			map.data[map.size].key = node->value;
			map.data[map.size].value = BitArray_clone(code);
			map.size++;
			
			if(code.size > 0)
				BitArray_remove(&code, code.size - 1, 1);
			if(node->is_left) {
				node = node->parent->right;
				BitArray_add(&code, 1, 1);
			} else {
				int found = FALSE;
				node = node->parent;
				while(node != NULL && !found) {
					if(node->is_left) {
						found = TRUE;
					} else {
						node = node->parent;
						if(node != NULL) {
							BitArray_remove(&code, 
								code.size - 1, 1);
						}
					}
				}
				if(found) {
					node = node->parent->right;
					BitArray_remove(&code, code.size - 1, 1);
					BitArray_add(&code, 1, 1);
				}
			}
		} else {
			node->left->parent = node;
			node->right->parent = node;
			node = node->left;
			BitArray_add(&code, 0, 1);
		}
	} while(node != NULL);
	
	BitArray_free(&code);
	return map;
}

BitArray Dictionary_get(EncoderDictionary map, MetaData key) {
	int i; BitArray value;
	for(i = 0; i < map.size; i++) {
		if(map.data[i].key.size == key.size &&
				map.data[i].key.repeat == key.repeat) {
			return map.data[i].value;
		}
	}
	Error_set(ERROR, "Valor nao mapeado.");
	return value;
}



/* ==== Arquivo Bin�rio ==== */

BitArray HTree_encodeDC(HuffmanTree encoder, EncDCValues edc) {
	int i; BitArray code; MetaData meta;
	BitArray data = BitArray_init(2 * 8 * edc.size * sizeof(unsigned));
	EncoderDictionary map = Dictionary_fromTree(encoder);
	
	if(Error_isSet()) {
		Dictionary_free(&map);
		BitArray_free(&data);
		return data;
	}
	Dictionary_log(map);
	
	for(i = 0; i < edc.size; i++) {
		meta.size = edc.data[i].size;
		meta.repeat = 0;
		code = Dictionary_get(map, meta);
		BitArray_append(&data, code);
		BitArray_append(&data, edc.data[i]);
	}
	
	Dictionary_free(&map);
	return data;
}

BitArray HTree_encodeAC(HuffmanTree encoder, EncACValues eac) {
	int i, j, size;
	BitArray data; BitArray code; MetaData meta;
	EncoderDictionary map = Dictionary_fromTree(encoder);
	
	if(Error_isSet()) {
		Dictionary_free(&map);
		BitArray_free(&data);
		return data;
	}
	Dictionary_log(map);
	
	size = 0;
	for(i = 0; i < eac.nb; i++)
		size += eac.np[i];
	
	data = BitArray_init(2 * 8 * size * sizeof(unsigned));
	for(i = 0; i < eac.nb; i++) {
		for(j = 0; j < eac.np[i]; j++) {
			meta.size = eac.data[i][j].value.size;
			meta.repeat = eac.data[i][j].repeat;
			code = Dictionary_get(map, meta);
			BitArray_append(&data, code);
			BitArray_append(&data, eac.data[i][j].value);
		}
	}
	
	Dictionary_free(&map);
	return data;
}

EncDCValues HTree_decodeDC(HuffmanTree decoder, BitArray *data, BinaryFileInfo info) {
	EncDCValues edc = EDC_init(3 * info.width * info.height);
	int i, p, n, v, bit;
	HuffmanNode* node;
	
	p = 0;
	for(i = 0; i < edc.size; i++) {
		//left = 0, right = 1
		node = decoder.root;
		while(node->type != TREE_LEAF) {
			bit = BitArray_get(*data, p, 1); p += 1;
			node = !bit? node->left: node->right;
		}
		
		n = node->value.size;
		v = BitArray_get(*data, p, n); p += n;
		edc.data[i] = BitArray_init(n);
		BitArray_add(edc.data + i, v, n);
	}
	BitArray_remove(data, 0, p);
	return edc;
}

EncACValues HTree_decodeAC(HuffmanTree decoder, BitArray* data, BinaryFileInfo info) {
	EncACValues eac = EAC_init(3 * info.width * info.height);
	int i, j, p, v, n, bit, count;
	HuffmanNode* node;
	
	p = 0;
	for(i = 0; i < eac.nb; i++) {
		count = 0; eac.np[i] = 0;
		for(j = 0; count < BLOCK_SIZE * BLOCK_SIZE - 1; j++) {
			//left = 0, right = 1
			node = decoder.root;
			while(node->type != TREE_LEAF) {
				bit = BitArray_get(*data, p, 1); p += 1;
				node = !bit? node->left: node->right;
			}
			
			n = node->value.size;
			v = BitArray_get(*data, p, n); p += n;
			eac.data[i][j].value = BitArray_init(n);
			BitArray_add(&(eac.data[i][j].value), v, n);
			
			eac.data[i][j].repeat = node->value.repeat;
			count += node->value.repeat;
			
			eac.np[i]++;
		}
	}
	BitArray_remove(data, 0, p);
	return eac;
}
