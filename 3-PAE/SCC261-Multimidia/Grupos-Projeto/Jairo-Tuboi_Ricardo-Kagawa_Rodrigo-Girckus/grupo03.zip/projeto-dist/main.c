/*
SCC0261 MULTIM�DIA - 1� SEMESTRE DE 2011
DOCENTE: RUDINEI GOULARTE

PROJETO: COMPRESS�O DE IMAGEM DIGITAL PARTE 3


ALUNOS:
	Jairo Toshio Tuboi 		6427250
	Ricardo Takashi Kagawa		5634712
	Rodrigo Luis Gava Girckus 	5967770
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "defs.h"
#include "util.h"
#include "codec.h"

#define PATH_SEPARATOR '\\'



/* carrega as configura��es de depura��o */
void load_log_config() {
	char line[LINE_MAX], item[LINE_MAX], *p; int value;
	FILE* file = fopen("log_config.txt", "r");
	fgets(line, LINE_MAX, file);
	while(!feof(file)) {
		p = strchr(line, ':');
		if(p != NULL) {
			p[0] = '\0'; p++;
			sscanf(line, " %s ", item);
			sscanf(p, " %d ", &value);
			value = (value == 0)? FALSE: TRUE;
			
			if(strcmp(item, "bmp_file_header") == 0)
				Config_setItemOutput(LOG_BMP_FILE_HEADER, value);
			else if(strcmp(item, "bmp_info_header") == 0)
				Config_setItemOutput(LOG_BMP_INFO_HEADER, value);
			else if(strcmp(item, "bin_file_header") == 0)
				Config_setItemOutput(LOG_BIN_FILE_HEADER, value);
			else if(strcmp(item, "bitmap_data") == 0)
				Config_setItemOutput(LOG_BITMAP_DATA, value);
			else if(strcmp(item, "rgb_image") == 0)
				Config_setItemOutput(LOG_RGB_IMAGE, value);
			else if(strcmp(item, "image_blocks") == 0)
				Config_setItemOutput(LOG_IMAGE_BLOCKS, value);
			else if(strcmp(item, "shifted_blocks") == 0)
				Config_setItemOutput(LOG_SHIFTED_BLOCKS, value);
				
			else if(strcmp(item, "traced_blocks") == 0)
				Config_setItemOutput(LOG_TRACED_BLOCKS, value);
			else if(strcmp(item, "dc_values") == 0)
				Config_setItemOutput(LOG_DC_RAW, value);
			else if(strcmp(item, "dc_delta_encoded") == 0)
				Config_setItemOutput(LOG_DC_DELTA, value);
			else if(strcmp(item, "dc_cpl_encoded") == 0)
				Config_setItemOutput(LOG_DC_ENCODED, value);
			else if(strcmp(item, "dc_huffman") == 0)
				Config_setItemOutput(LOG_DC_HUFFMAN, value);
			else if(strcmp(item, "dc_binary") == 0)
				Config_setItemOutput(LOG_DC_BINARY, value);
			else if(strcmp(item, "dc_decoder") == 0)
				Config_setItemOutput(LOG_DC_DECODER, value);
				
			else if(strcmp(item, "ac_values") == 0)
				Config_setItemOutput(LOG_AC_RAW, value);
			else if(strcmp(item, "ac_rle_encoded") == 0)
				Config_setItemOutput(LOG_AC_RLE, value);
			else if(strcmp(item, "ac_cpl_encoded") == 0)
				Config_setItemOutput(LOG_AC_ENCODED, value);
			else if(strcmp(item, "ac_huffman") == 0)
				Config_setItemOutput(LOG_AC_HUFFMAN, value);
			else if(strcmp(item, "ac_binary") == 0)
				Config_setItemOutput(LOG_AC_BINARY, value);
			else if(strcmp(item, "ac_decoder") == 0)
				Config_setItemOutput(LOG_AC_DECODER, value);
				
			else if(strcmp(item, "metadata_frequencies") == 0)
				Config_setItemOutput(LOG_FREQUENCIES, value);
			else if(strcmp(item, "encoder_dictionary") == 0)
				Config_setItemOutput(LOG_DICTIONARY, value);
			else if(strcmp(item, "binary_data") == 0)
			
				Config_setItemOutput(LOG_BINARY_DATA, value);
			else if(strcmp(item, "freq_domain_blocks") == 0)
				Config_setItemOutput(LOG_FD_BLOCKS, value);
			else if(strcmp(item, "dct_transformation") == 0)
				Config_setItemOutput(LOG_TRANSFORMATION, value);
			else if(strcmp(item, "dct_quantization") == 0) {
				Config_setItemOutput(LOG_QUANTIZATION, value);
				Config_setItemOutput(LOG_DEQUANTIZATION, value);
			}
		}
		fgets(line, LINE_MAX, file);
	}
	fclose(file);
	return;
}



/* Armazena as op��es do programa. */
struct {
	char program_name[FILENAME_MAX];	/* nome do programa (linha de comando) */
	char program_path[FILENAME_MAX];	/* caminho do programa (linha de comando) */
	short encode;		/* codifica a imagem, ao inv�s de decodific�-lo */
	short override;		/* sobrescreve o arquivo de sa�da sem perguntar */
	short interactive;	/* executar em modo interativo */
	char bitmap[FILENAME_MAX];	/* nome do arquivo de bitmap */
	char binary[FILENAME_MAX];	/* nome do arquivo bin�rio */
} _options;

/* Inicializa as op��es com valores padr�o. */
void Options_init() {
	strcpy(_options.program_name, "programa.exe");
	strcpy(_options.program_path, "");
	strcpy(_options.bitmap, "");
	strcpy(_options.binary, "");
	_options.encode = TRUE;
	_options.override = FALSE;
	_options.interactive = FALSE;
	return;
}

/* Destr�i as op��es. */
void Options_free() {
	return;
}

/* Define o nome do programa. */
void Options_setProgramName(char filename[]) {
	strcpy(_options.program_name, filename);
	return;
}

/* Obt�m o nome do programa. */
char* Options_getProgramName() {
	strcpy(_tmpstr, _options.program_name);
	return _tmpstr;
}

/* Define o local do programa. */
void Options_setProgramPath(char filename[]) {
	strcpy(_options.program_path, filename);
	return;
}

/* Obt�m o nome do programa. */
char* Options_getProgramPath() {
	strcpy(_tmpstr, _options.program_path);
	return _tmpstr;
}

/* Define o nome do arquivo de bitmap. */
void Options_setBitmapFile(char filename[]) {
	strcpy(_options.bitmap, filename);
	return;
}

/* Obt�m o nome do programa. */
char* Options_getBitmapFile() {
	strcpy(_tmpstr, _options.bitmap);
	return _tmpstr;
}

/* Define o nome do arquivo bin�rio. */
void Options_setBinaryFile(char filename[]) {
	strcpy(_options.binary, filename);
	return;
}

/* Obt�m o nome do programa. */
char* Options_getBinaryFile() {
	strcpy(_tmpstr, _options.binary);
	return _tmpstr;
}

/* Define o modo de opera��o (codificar/decodificar). */
void Options_setExtractMode(short value) {
	_options.encode = !value;
	return;
}

/* Obt�m o modo de opera��o. */
short Options_isExtractMode() {
	return !_options.encode;
}

/* Define o modo de sobrecrita (sobrescrever/perguntar). */
void Options_setOverrideMode(short value) {
	_options.override = value;
	return;
}

/* Obt�m o modo de sobrescrita. */
short Options_isOverrideMode() {
	return _options.override;
}

/* Define o modo interativo. */
void Options_setInteractiveMode(short value) {
	_options.interactive = value;
	return;
}

/* Obt�m o modo interativo. */
short Options_isInteractiveMode() {
	return _options.interactive;
}

/* Imprime o registro Options. */
void Options_print() {
	if(Config_hasOutputLevel(OL_DEBUG)) {
		printf(" Nome do programa: %s\n", Options_getProgramName());
		printf("Local do programa: %s\n", Options_getProgramPath());
	}
	printf("   Arquivo bitmap: %s\n", Options_getBitmapFile());
	printf("  Arquivo binario: %s\n", Options_getBinaryFile());
	putchar('\n');
	if(Options_isInteractiveMode()) {
		if(Config_hasOutputLevel(OL_VERBOSE)) puts("Modo interativo");
		puts(Options_isOverrideMode()? "Sobrescrever sem perguntar": "Confirmar sobrescrita");
	} else {
		puts("Modo de linha de comando");
		puts(Options_isExtractMode()? "Decodificar arquivo": "Codificar arquivo");
		puts(Options_isOverrideMode()? "Sobrescrever saida": "Nao sobrescrever saida");
	}
	switch(Config_getOutputLevel()) {
		case OL_NORMAL:		puts("Exibir mensagens.");			break;
		case OL_VERBOSE:	puts("Exibir maix mensagens.");		break;
		case OL_DEBUG:		puts("Exibir todas as mensagens.");	break;
	}
	return;
}



/* Tenta abrir os arquivos de entrada e de sa�da em modo de leitura para 
 * codifica��o. O arquivo de sa�da � aberto assim para verificar sua 
 * exist�ncia.
 * 
 * bitmap (sa�da) - descritor do arquivo bitmap
 * binary (sa�da) - descritor do arquivo bin�rio
 */
void open_files_encode_read(FILE** bitmap, FILE** binary) {
	*bitmap = fopen(Options_getBitmapFile(), "rb");
	if(!Options_isOverrideMode())
		*binary = fopen(Options_getBinaryFile(), "rb");
	return;
}

/* Reabre o arquivo de sa�da em modo de escrita para codifica��o. 
 * 
 * bitmap (sa�da) - descritor do arquivo bitmap
 * binary (sa�da) - descritor do arquivo bin�rio
 */
void open_files_encode_write(FILE** bitmap, FILE** binary) {
	//o arquivo j� pode estar aberto
	*binary = (*binary != NULL)? 
		freopen(Options_getBinaryFile(), "wb", *binary): 
		fopen(Options_getBinaryFile(), "wb");
	return;
}

/* Tenta abrir os arquivos de entrada e de sa�da em modo de leitura 
 * para decodifica��o. O arquivo de sa�da � aberto assim para verificar 
 * sua exist�ncia.
 * 
 * bitmap (sa�da) - descritor do arquivo bitmap
 * binary (sa�da) - descritor do arquivo bin�rio
 */
void open_files_decode_read(FILE** bitmap, FILE** binary) {
	if(!Options_isOverrideMode()) 
		*bitmap = fopen(Options_getBitmapFile(), "rb");
	*binary = fopen(Options_getBinaryFile(), "rb");
	return;
}

/* Reabre o arquivo de sa�da em modo de escrita para decodifica��o. 
 * 
 * bitmap (sa�da) - descritor do arquivo bitmap
 * binary (sa�da) - descritor do arquivo bin�rio
 */
void open_files_decode_write(FILE** bitmap, FILE** binary) {
	//o arquivo j� pode estar aberto 
	*bitmap = (*bitmap != NULL)? 
		freopen(Options_getBitmapFile(), "wb", *bitmap): 
		fopen(Options_getBitmapFile(), "wb");
	return;
}

/* Fecha os arquivos abertos pelo programa. */
void close_files(FILE* bitmap, FILE* binary) {
	if(bitmap != NULL) fclose(bitmap);
	if(binary != NULL) fclose(binary);
	return;
}



/* Verifica os nomes de arquivos. */
void check_filenames() {
	char* p, name[FILENAME_MAX];
	
	/* verificando arquivo bin�rio */
	if(strlen(Options_getBinaryFile()) == 0 && 
			strlen(Options_getBitmapFile()) > 0) {
		strcpy(name, Options_getBitmapFile());
		p = strstr(name, ".bmp");
		if(p == NULL) 
			p = strchr(name, 0);
		strcpy(p, ".bin");
		Options_setBinaryFile(name);
	}
	
	return;
}

/* Pausa a execu��o do programa, esperando resposta do usu�rio. */
void pause() {
	printf("Pressione <Enter> para continuar..."); getchar();
	return;
}

/* Exibe a vers�o do programa na sa�da padr�o. */
void display_version() {
	printf("Projeto de Multimidia (%s) versao %s\n", 
			Options_getProgramName(), CODEC_VERSION);
	return;
}

/* Exibe um texto de ajuda. */
void display_help() {
	char helpname[FILENAME_MAX]; FILE* helpfile;
	char buffer[1024], *b, *p; int n;
	
	/* calculando nome absoluto do arquivo */
	strcpy(helpname, Options_getProgramPath());
	n = strlen(helpname);
	if(n > 0 && helpname[n - 1] != PATH_SEPARATOR) {
		helpname[n] = PATH_SEPARATOR;
		helpname[n + 1] = 0;
	}
	strcat(helpname, "help.txt");
	
	if(Config_hasOutputLevel(OL_DEBUG))
		printf("Lendo \"%s\"...\n", helpname);
	
	helpfile = fopen(helpname, "r");
	if(helpfile == NULL) {
		puts("Ajuda nao encontrada!");
		return;
	}
	
	putchar('\n');
	while(fgets(buffer, 1000, helpfile) != NULL) {
		/* verificar %s quebrado */
		n = strlen(buffer);
		if(n == 1) {
			if(buffer[n - 1] == '%') {
				buffer[n] = fgetc(helpfile);
				buffer[n + 1] = 0;
			}
		} else if(n > 1) {
			if(buffer[n - 1] == '%' && buffer[n - 2] != '%') {
				buffer[n] = fgetc(helpfile);
				buffer[n + 1] = 0;
			}
		}
		
		/* verificar m�ltiplos %s */
		b = buffer; p = strstr(b, "%s");
		while(p != NULL) {
			p[0] = 0; 
			printf(b, Options_getProgramName());
			p[0] = '%';
			b = p; p = strstr(b + 1, "%s");
		}
		printf(b, Options_getProgramName());
	}
	putchar('\n');
	
	fclose(helpfile);
	return;
}



/* Executa o programa em modo de linha de comando para codificar. */
void run_command_line_encode() {
	FILE *bitmap = NULL, *binary = NULL;
	
	/* mensagens informativas */
	if(Config_hasOutputLevel(OL_VERBOSE)) {
		puts("Usando as seguintes opcoes:");
		putchar('\n');
		Options_print();
		putchar('\n');
	}
	
	/* abrir e verificar arquivos de entrada */
	if(strlen(Options_getBitmapFile()) == 0) {
		puts("Sem arquivo bitmap, nada a fazer.");
		return;
	}
	open_files_encode_read(&bitmap, &binary);
	if(bitmap == NULL) {
		printf("Arquivo \"%s\" nao foi encontrado ou nao pode ser lido.\n", 
				Options_getBitmapFile());
		close_files(bitmap, binary);
		exit(EXIT_FAILURE);
	}
	
	/* abrir e verificar arquivos de sa�da */
	if(!Options_isOverrideMode() && binary != NULL) {
		printf("Arquivo binario \"%s\" ja existe.\n", Options_getBinaryFile());
		close_files(bitmap, binary);
		exit(EXIT_FAILURE);
	}
	open_files_encode_write(&bitmap, &binary);
	if(binary == NULL) {
		printf("Arquivo \"%s\" nao pode ser aberto para escrita.\n", 
				Options_getBinaryFile());
		close_files(bitmap, binary);
		exit(EXIT_FAILURE);
	}
	
	/* executar tarefa */
	encode(bitmap, binary);
	if(Error_isSet()) {
		remove(Options_getBinaryFile());
		puts(Error_getMessage());
		Error_clear();
	}
	
	close_files(bitmap, binary);
	return;
}

/* Executa o programa em modo de linha de comando para decodificar. */
void run_command_line_decode() {
	FILE *bitmap = NULL, *binary = NULL;
	
	/* mensagens informativas */
	if(Config_hasOutputLevel(OL_VERBOSE)) {
		puts("Usando as seguintes opcoes:");
		putchar('\n');
		Options_print();
		putchar('\n');
	}
	
	/* abrir e verificar arquivos de entrada */
	if(strlen(Options_getBinaryFile()) == 0) {
		puts("Sem arquivo binario, nada a fazer.");
		exit(EXIT_FAILURE);
	}
	open_files_decode_read(&bitmap, &binary);
	if(binary == NULL) {
		printf("Arquivo \"%s\" nao foi encontrado ou nao pode ser lido.\n", 
				Options_getBinaryFile());
		close_files(bitmap, binary);
		exit(EXIT_FAILURE);
	}
	
	/* abrir e verificar arquivos de sa�da */
	if(!Options_isOverrideMode() && bitmap != NULL) {
		printf("Arquivo bitmap \"%s\" ja existe.\n", Options_getBitmapFile());
		close_files(bitmap, binary);
		exit(EXIT_FAILURE);
	}
	open_files_decode_write(&bitmap, &binary);
	if(bitmap == NULL) {
		printf("Arquivo \"%s\" nao pode ser aberto para escrita.\n", 
				Options_getBitmapFile());
		close_files(bitmap, binary);
		exit(EXIT_FAILURE);
	}
	
	/* executar tarefa */
	decode(bitmap, binary);
	if(Error_isSet()) {
		remove(Options_getBitmapFile());
		puts(Error_getMessage());
		Error_clear();
	}
	
	close_files(bitmap, binary);
	return;
}



/* Executa a tarefa do programa em modo interativo para codifica��o. */
void encode_interactively() {
	FILE *bitmap = NULL, *binary = NULL;
	
	/* mensagens informativas */
	if(Config_hasOutputLevel(OL_VERBOSE)) {
		puts("Usando as seguintes opcoes:");
		putchar('\n');
		Options_print();
		putchar('\n');
	}
	
	/* abrir e verificar arquivos de entrada */
	if(strlen(Options_getBitmapFile()) == 0) {
		Error_set(ERROR, "Sem arquivo de bitmap, nada a fazer.");
		return;
	}
	open_files_encode_read(&bitmap, &binary);
	if(bitmap == NULL) {
		Error_set(ERROR, format(
			"Arquivo \"%s\" nao foi encontrado ou nao pode ser lido.\n", 
			Options_getBitmapFile()));
		close_files(bitmap, binary);
		return;
	}
	
	/* abrir e verificar arquivos de sa�da */
	if(!Options_isOverrideMode()) {
		if(binary != NULL) {
			printf("Arquivo binario \"%s\" ja existe.\n", 
					Options_getBinaryFile());
			printf("Deseja sobrescrever este(s) arquivo(s) [s/n]? ");
			if(tolower(getchar()) == 's') {
				open_files_encode_write(&bitmap, &binary);
			} else {
				close_files(bitmap, binary);
				return;
			}
		} else
			open_files_encode_write(&bitmap, &binary);
	} else
		open_files_encode_write(&bitmap, &binary);
	if(binary == NULL) {
		Error_set(ERROR, format(
			"Arquivo \"%s\" nao pode ser aberto para escrita.\n", 
			Options_getBinaryFile()));
		close_files(bitmap, binary);
		return;
	}
	
	/* executar tarefa */
	encode(bitmap, binary);
	close_files(bitmap, binary);
	return;
}

/* Executa a tarefa do programa em modo interativo para decodifica��o. */
void decode_interactively() {
	FILE *bitmap = NULL, *binary = NULL;
	
	/* mensagens informativas */
	if(Config_hasOutputLevel(OL_VERBOSE)) {
		puts("Usando as seguintes opcoes:");
		putchar('\n');
		Options_print();
		putchar('\n');
	}
	
	/* abrir e verificar arquivos de entrada */
	if(strlen(Options_getBinaryFile()) == 0) {
		Error_set(ERROR, "Sem arquivo binario, nada a fazer.");
		return;
	}
	open_files_decode_read(&bitmap, &binary);
	if(binary == NULL) {
		Error_set(ERROR, format(
			"Arquivo \"%s\" nao foi encontrado ou nao pode ser lido.\n", 
			Options_getBinaryFile()));
		close_files(bitmap, binary);
		return;
	}
	
	/* abrir e verificar arquivos de sa�da */
	if(!Options_isOverrideMode() && bitmap != NULL) {
		printf("Arquivo bitmap \"%s\" ja existe.\n", Options_getBitmapFile());
		printf("Deseja sobrescrever este arquivo [s/n]? ");
		if(tolower(getchar()) == 's') {
			open_files_decode_write(&bitmap, &binary);
		} else {
			close_files(bitmap, binary);
			return;
		}
	} else
		open_files_decode_write(&bitmap, &binary);
	if(bitmap == NULL) {
		Error_set(ERROR, format(
			"Arquivo \"%s\" nao pode ser aberto para escrita.\n", 
			Options_getBitmapFile()));
		close_files(bitmap, binary);
		return;
	}
	
	/* executar tarefa */
	decode(bitmap, binary);
	close_files(bitmap, binary);
	return;
}

/* Executa o programa em modo interativo. */
void run_interactive_mode() {
	char line[LINE_MAX], *args, *p; 
	int exit = FALSE;
	
	if(Config_hasOutputLevel(OL_VERBOSE)) {
		puts("Foram detectadas as seguintes opcoes:");
		putchar('\n');
		Options_print();
		putchar('\n');
	}
	
	/* modo silencioso implica sobrescrever silenciosamente */
	if(Config_getOutputLevel() == OL_QUIET)
		Options_setOverrideMode(TRUE);
	
	if(Options_isExtractMode())
		decode_interactively();
	else
		encode_interactively();
	
	puts("\nPara obter ajuda, digite \"help\".\n");
	
	while(!exit) {
		/* l� um comando */
		printf(">> "); fgets(line, 255, stdin);
		while(strlen(line) == 1)
			fgets(line, 255, stdin);
		p = strchr(line, '\n');
		if(p != NULL) p[0] = 0;
		
		args = strchr(line, ' ');
		if(args == NULL) 
			args = strchr(line, 0);
		else {
			args[0] = 0; args++;
			while(args[0] == ' ') args++;
		}
		
		/* executa o comando */
		if(strcmp(line, "q") == 0) {
			exit = TRUE;
		} else if(strcmp(line, "help") == 0) {
			puts("Os comandos disponiveis sao:");
			putchar('\n');
			puts("\tbmp {arquivo} - define o arquivo bitmap");
			puts("\tbin {arquivo} - define o arquivo binario");
			puts("\te [arquivo] - codifica a imagem bitmap especificada ou configurada");
			puts("\td [arquivo] - extrai a imagem bitmap especificada ou configurada");
			puts("\tm {quieto|normal|verboso|depuracao} - define a quantidade de informacao exibida pelo programa.");
			printf("\tf {true|false} - Com \"true\", os arquivos de saida sao sobrescritos sem perguntar; ");
			puts("com \"false\", o programa sempre perguntara antes de sobrescrever");
			puts("\tst - exibe algumas informacoes sobre o estado do programa");
			if(Config_hasOutputLevel(OL_DEBUG)) {
				puts("\trl - recarrega as configuracoes do relatorio de depuracao");
				puts("\tl2f - gera o relatorio de depuracao em arquivo");
				puts("\tl2c - gera o relatorio de depuracao no console");
				puts("\tq - fecha o programa");
			}
		} else if(strcmp(line, "st") == 0) {
			Options_print();
			putchar('\n');
		} else if(strcmp(line, "rl") == 0) {
			load_log_config();
			if(Config_hasOutputLevel(OL_DEBUG))
				puts("Relatorio reconfigurado.");
		} else if(strcmp(line, "l2f") == 0) {
			Config_setDebugToFile(TRUE);
			if(Config_hasOutputLevel(OL_DEBUG))
				puts("Relatando no arquivo.");
		} else if(strcmp(line, "l2c") == 0) {
			Config_setDebugToFile(FALSE);
			if(Config_hasOutputLevel(OL_DEBUG))
				puts("Relatando no console.");
		} else if(strcmp(line, "bmp") == 0) {
			Options_setBitmapFile(args);
			if(Config_hasOutputLevel(OL_VERBOSE))
				printf("Arquivo bitmap definido para \"%s\".\n", Options_getBitmapFile());
		} else if(strcmp(line, "bin") == 0) {
			Options_setBinaryFile(args);
			check_filenames();
			if(Config_hasOutputLevel(OL_VERBOSE))
				printf("Arquivo binario definido para \"%s\".\n", Options_getBinaryFile());
		} else if(strcmp(line, "e") == 0 || strcmp(line, "d") == 0) {
			if(strlen(args) > 0)
				Options_setBitmapFile(args);
			check_filenames();
			
			if(strcmp(line, "e") == 0)
				encode_interactively();
			else
				decode_interactively();
			
			if(Error_isSet()) {
				puts(Error_getMessage());
				Error_clear();
			}
		} else if(strcmp(line, "m") == 0) {
			p = strchr(args, ' ');
			if(p != NULL) p[0] = 0;
			if(strcmp(args, "quieto") == 0) {
				Config_setOutputLevel(OL_QUIET);
				Options_setOverrideMode(TRUE);
			} else if(strcmp(args, "verboso") == 0) {
				Config_setOutputLevel(OL_VERBOSE);
				puts("Agora exibindo mais mensagens.");
			} else if(strcmp(args, "depuracao") == 0) {
				Config_setOutputLevel(OL_DEBUG);
				puts("Agora exibindo todas as mensagens.");
			} else {
				Config_setOutputLevel(OL_NORMAL);
				puts("Agora exibindo mensagens.");
			}
		} else if(strcmp(line, "f") == 0) {
			p = strchr(args, ' ');
			if(p != NULL) p[0] = 0;
			if(strcmp(args, "true") == 0) {
				Options_setOverrideMode(TRUE);
				if(Config_hasOutputLevel(OL_VERBOSE))
					puts("Sobrescrever arquivos sem perguntar.");
			} else if(strcmp(args, "false") == 0 && Config_hasOutputLevel(OL_NORMAL)) {
				Options_setOverrideMode(FALSE);
				if(Config_hasOutputLevel(OL_VERBOSE))
					puts("Perguntar antes de sobrescrever arquivos.");
			}
		}
	}
	
	if(Config_hasOutputLevel(OL_NORMAL))
		puts("Programa encerrado.");
	return;
}



/*
Fun��o main. Aceita argumentos da linha de comando, e pode
executar de forma interativa. Linha de comando:
	
	programa [-op��es] [-o arquivo_binario] [arquivo_bitmap]
	
Op��es

	-i Executa o programa em modo interativo. O programa poder� 
		pausar antes de encerrar.
	-q N�o exibe mensagens, a n�o ser que ocorra algum erro.
	-v Exibe mais mensagens que o normal.
	-d Exibe mensagens de depura��o.
	-f For�a a sobrescrita do arquivo de sa�da, caso ele j� exista.
		Sem essa op��o, o programa falhar� em modo de linha de 
		comando, ou perguntar� o que fazer em modo interativo.
	-x Executa decodifica��o, ao inv�s de codifica��o.
	-l Gera o relat�rio de depura��o em arquivo (apenas com a op��o -d)
	-o arquivo_binario
		Especifica um arquivo bin�rio. Opcional em modo interativo.
	arquivo_bitmap
		Especifica um arquivo bitmap. Opcional em modo interativo.
	
	--version
		Exibe a vers�o do programa.
	--help
		Exibe esta ajuda.
	
V�rios arquivos bitmaps e bin�rios podem ser especificados pela
linha de comando, mas apenas o �ltimo de cada ser�o usados, mesmo em 
modo interativo. Caso n�o sejam especificados em modo de linha de
comando, o programa poder� falhar.

As op��es -q, -v e -d podem ser especificadas v�rias vezes e 
simultaneamente. O modo mais verboso especificado ser� escolhido
nesse caso.

--version e --help n�o executam o programa, apenas exibem suas
respectivas informa��es. A maioria das demais op��es ser� ignorada
nesse caso, exceto -i para que o programa pause ao exibir as informa��es.
*/
int main(int argc, char *argv[]) {
	int i; char* p;
	int help_flag = FALSE;
	int version_flag = FALSE;
	
	Errors_init();
	Config_init();
	Options_init();
	
	load_log_config();
	
	/* nome do programa */
	p = strrchr(argv[0], PATH_SEPARATOR);
	if(p != NULL) {
		if(strlen(p) > 0)
			Options_setProgramName(p + 1);
		p[0] = 0;
		Options_setProgramPath(argv[0]);
	} else {
		Options_setProgramName(argv[0]);
		Options_setProgramPath("");
	}
	
	/* configurando o programa */
	for(i = 1; i < argc; i++) {
		if(strcmp(argv[i], "-o") == 0)
			Options_setBinaryFile(argv[++i]);
		else if(strcmp(argv[i], "--version") == 0) {
			version_flag = TRUE;
		} else if(strcmp(argv[i], "--help") == 0) {
			help_flag = TRUE;
		} else if(argv[i][0] == '-') {
			if(strchr(argv[i], 'i') != NULL)
				Options_setInteractiveMode(TRUE);
			if(strchr(argv[i], 'q') != NULL)
				Config_setOutputLevel(OL_QUIET);
			if(strchr(argv[i], 'v') != NULL)
				Config_setOutputLevel(OL_VERBOSE);
			if(strchr(argv[i], 'd') != NULL)
				Config_setOutputLevel(OL_DEBUG);
			if(strchr(argv[i], 'f') != NULL)
				Options_setOverrideMode(TRUE);
			if(strchr(argv[i], 'x') != NULL)
				Options_setExtractMode(TRUE);
			if(strchr(argv[i], 'l') != NULL)
				Config_setDebugToFile(TRUE);
		} else
			Options_setBitmapFile(argv[i]);
	}
	
	check_filenames();
	
	/* executando a tarefa */
	if(version_flag || help_flag) {
		if(version_flag)	display_version();
		if(help_flag)		display_help();
		if(Options_isInteractiveMode()) pause();
	} else if(Options_isInteractiveMode()) {
		run_interactive_mode();
	} else {
		if(Options_isExtractMode())
			run_command_line_decode();
		else
			run_command_line_encode();
	}
	
	Options_free();
	Config_free();
	Errors_free();
	return EXIT_SUCCESS;
}
