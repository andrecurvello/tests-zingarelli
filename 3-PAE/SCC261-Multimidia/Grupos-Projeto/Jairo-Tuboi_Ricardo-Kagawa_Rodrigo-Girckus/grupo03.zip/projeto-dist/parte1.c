/*
SCC0261 MULTIM�DIA - 1� SEMESTRE DE 2011
DOCENTE: RUDINEI GOULARTE

PROJETO: COMPRESS�O DE IMAGEM DIGITAL PARTE 3


ALUNOS:
	Jairo Toshio Tuboi 		6427250
	Ricardo Takashi Kagawa		5634712
	Rodrigo Luis Gava Girckus 	5967770
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "defs.h"
#include "util.h"
#include "parte1.h"



/* ==== bitmap file header ==== */

BITMAP_FILE_HEADER BFH_init(unsigned data_size) {
	BITMAP_FILE_HEADER h;
	h.type[0] = 'B'; h.type[1] = 'M';
	h.offBytes = 54;
	h.size = data_size + h.offBytes;
	h.reserved1 = 0; h.reserved2 = 0;
	return h;
}

BITMAP_FILE_HEADER BFH_read(FILE* file) {
	BITMAP_FILE_HEADER h; int r = 0;
	
	r += fread(h.type + 0, sizeof(char), 1, file);
	r += fread(h.type + 1, sizeof(char), 1, file);
	r += fread(&(h.size), sizeof(int), 1, file);
	r += fread(&(h.reserved1), sizeof(short), 1, file);
	r += fread(&(h.reserved2), sizeof(short), 1, file);
	r += fread(&(h.offBytes), sizeof(int), 1, file);
	
	if(r < 6) Error_set(ERROR, feof(file)? 
		"Fim de arquivo inesperado.": 
		"Erro ao ler arquivo.");
	return h;
}

void BFH_write(BITMAP_FILE_HEADER h, FILE* file) {
	int r = 0;
	r += fwrite(h.type, sizeof(char), 2, file);
	r += fwrite(&h.size, sizeof(int), 1, file);
	r += fwrite(&h.reserved1, sizeof(short), 1, file);
	r += fwrite(&h.reserved2, sizeof(short), 1, file);
	r += fwrite(&h.offBytes, sizeof(int), 1, file);
	if(r < 6) Error_set(ERROR, "Erro ao gravar arquivo.");
	return;
}

void BFH_log(BITMAP_FILE_HEADER h) {
	int cols[] = {20, 0};
	if(!Config_getItemOutput(LOG_BMP_FILE_HEADER)) return;
	
	Log_puts("== Bitmap File Header ==");
	Log_nl();
	Log_printf("%*s: %c%c\n", cols[0], "Magic Number", h.type[0], h.type[1]);
	Log_printf("%*s: %*d bytes\n", cols[0], "File Size", cols[1], h.size);
	Log_printf("%*s: %04x\n", cols[0], "Reserved Field 1", h.reserved1);
	Log_printf("%*s: %04x\n", cols[0], "Reserved Field 2", h.reserved2);
	Log_printf("%*s: %*d bytes\n", cols[0], "Offset to Data", cols[1], h.offBytes);
	Log_nl();
	return;
}



/* ==== bitmap information header ==== */

BITMAP_INFO_HEADER BIH_init(unsigned width, unsigned height) {
	BITMAP_INFO_HEADER h;
	
	h.size = 40; h.width = width; h.height = height;
	h.planes = 1; h.bitCount = 24; h.compression = 0;
	h.sizeImage = (h.bitCount / 8) * width * height;

	//sem informa��o
	h.xPixelsPerMeter = h.yPixelsPerMeter = 0;
	h.colorUsed = h.colorImportant = 0;
	
	return h;
}

BITMAP_INFO_HEADER BIH_read(FILE* file) {
	BITMAP_INFO_HEADER h; int r = 0;
	
	r += fread(&(h.size), sizeof(int), 1, file);
	r += fread(&(h.width), sizeof(int), 1, file);
	r += fread(&(h.height), sizeof(int), 1, file);
	
	r += fread(&(h.planes), sizeof(short), 1, file);
	r += fread(&(h.bitCount), sizeof(short), 1, file);
	r += fread(&(h.compression), sizeof(int), 1, file);
	r += fread(&(h.sizeImage), sizeof(int), 1, file);
	
	r += fread(&(h.xPixelsPerMeter), sizeof(int), 1, file);
	r += fread(&(h.yPixelsPerMeter), sizeof(int), 1, file);
	r += fread(&(h.colorUsed), sizeof(int), 1, file);
	r += fread(&(h.colorImportant), sizeof(int), 1, file);
	
	if(r < 11) Error_set(ERROR, feof(file)? 
		"Fim de arquivo inesperado.": 
		"Erro ao ler arquivo.");
	return h;
}

void BIH_write(BITMAP_INFO_HEADER h, FILE* file) {
	int r = 0;
	
	r += fwrite(&h.size, sizeof(int), 1, file);
	r += fwrite(&h.width, sizeof(int), 1, file);
	r += fwrite(&h.height, sizeof(int), 1, file);
	
	r += fwrite(&h.planes, sizeof(short), 1, file);
	r += fwrite(&h.bitCount, sizeof(short), 1, file);
	r += fwrite(&h.compression, sizeof(int), 1, file);
	r += fwrite(&h.sizeImage, sizeof(int), 1, file);
	
	r += fwrite(&h.xPixelsPerMeter, sizeof(int), 1, file);
	r += fwrite(&h.yPixelsPerMeter, sizeof(int), 1, file);
	r += fwrite(&h.colorUsed, sizeof(int), 1, file);
	r += fwrite(&h.colorImportant, sizeof(int), 1, file);
	
	if(r < 11) Error_set(ERROR, "Erro ao gravar arquivo.");
	return;
}

void BIH_log(BITMAP_INFO_HEADER h) {
	int cols[] = {24, 0};
	if(!Config_getItemOutput(LOG_BMP_INFO_HEADER)) return;
	
	Log_puts("== Bitmap Information Header ==");
	Log_nl();
	
	Log_printf("%*s: %*d bytes\n", cols[0], "Header Size", cols[1], h.size);
	Log_printf("%*s: %*d pixels\n", cols[0], "Image Width", cols[1], h.width);
	Log_printf("%*s: %*d pixels\n", cols[0], "Image Height", cols[1], h.height);
	
	Log_printf("%*s: %*d\n", cols[0], "Color Planes", cols[1], h.planes);
	Log_printf("%*s: %*d bits\n", cols[0], "Bits Per Pixel", cols[1], h.bitCount);
	Log_printf("%*s: %*d\n", cols[0], "Compression Level", cols[1], h.compression);
	Log_printf("%*s: %*d bytes\n", cols[0], "Image Size", cols[1], h.sizeImage);
	
	Log_printf("%*s: %*d pixels/meter\n", cols[0], 
		"Horizontal Resolution", cols[1], h.xPixelsPerMeter);
	Log_printf("%*s: %*d pixels/meter\n", cols[0], 
		"Vertical Resolution", cols[1], h.yPixelsPerMeter);
	Log_printf("%*s: %*d\n", cols[0], "Colors Used", cols[1], h.colorUsed);
	Log_printf("%*s: %*d\n", cols[0], "Important Colors", cols[1], h.colorImportant);
	
	Log_nl();
	return;
}



/* ==== vetor de bits ==== */

BitArray BitArray_init(unsigned capacity) {
	BitArray a;
	int n = capacity / (8 * sizeof(unsigned)) + 
		((capacity % (8 * sizeof(unsigned)) == 0)? 0: 1);
	if(capacity < 1) {
		a.data = NULL;
		a.size = 0;
		a.capacity = 0;
	} else {
		a.data = (unsigned*) malloc(n * sizeof(unsigned));
		a.size = 0;
		if(a.data == NULL) {
			Error_set(ERROR, "Memoria insuficiente.");
			a.capacity = 0;
		} else
			a.capacity = n;
	}
	return a;
}

void BitArray_free(BitArray *a) {
	if(a->data == NULL) return;
	free(a->data);
	a->capacity = 0;
	a->data = NULL;
	a->size = 0;
	return;
}

void BitArray_log(BitArray a, int group, unsigned cols) {
	unsigned const buffer_size = 8 * sizeof(unsigned);
	unsigned i, j, k, n, buffer, addr;
	
	if(a.size == 0) {
		Log_puts("(vazio)");
		return;
	}
	
	if(group != 0) {
		j = 0; k = 0; addr = FALSE;
		
		if(group > 0) { //agrupar da direita para a esquerda
		
			//preenchimento � esquerda
			if(a.size % group > 0) 
				Log_printf("%*s", group - a.size % group, "");
			
			//bits do primeiro grupo
			for(i = 0; i < a.size % group; i += n) {
				n = (i + buffer_size > a.size % group)? 
					a.size % group - i: buffer_size;
				buffer = BitArray_get(a, i, n);
				Log_printf("%s", btoa(buffer, n, 0));
			}
			
			//primeiro separador
			if(a.size % group > 0 && i < a.size) {
				if(cols > 0 && ++k % cols == 0)
					Log_nl();
				else
					Log_printf(" ");
			}
		} else {
			//agrupar da esquerda para a direita
			if(-group % 8 == 0 && cols > 0)
				addr = TRUE;
			i = 0; group = -group;
		}
		
		for(; i < a.size; i += n) {
			n = (i + buffer_size > a.size)? 
				a.size - i: buffer_size;
			
			if(addr && (j == 0) && (k % cols == 0))
				Log_printf("% 6x: ", i / 8); //exibe posi��o
			
			if(j + n > group) {
				n -= j + n - group;
				j = 0;
			} else
				j += n;
			
			buffer = BitArray_get(a, i, n);
			Log_printf(btoa(buffer, n, 0));
			
			//separador ou nova linha
			if(j == 0) {
				if((cols > 0) && (++k % cols == 0)) {
					Log_nl();
				} else
					Log_printf(" ");
			}
		}
	} else {
		//n�o agrupar
		j = 0;
		for(i = 0; i < a.size; i += n) {
			n = (i + buffer_size > a.size)? 
				a.size - i: buffer_size;
			if(j + n > cols && cols > 0) {
				n -= j + n - cols;
				j = 0;
			} else
				j += n;
			buffer = BitArray_get(a, i, n);
			Log_printf(btoa(buffer, n, 0));
			if(j == 0) Log_nl();
		}
	}
	Log_nl();
	return;
}

BitArray BitArray_clone(BitArray src) {
	int i;
	BitArray dest = BitArray_init(src.size);
	for(i = 0; i < dest.capacity; i++)
		dest.data[i] = src.data[i];
	dest.size = src.size;
	return dest;
}

unsigned BitArray_get(BitArray a, unsigned start, unsigned count) {
	const unsigned block_size = 8 * sizeof(unsigned);
	unsigned value, i, mask, p, n;
	
	if(start > a.size || start + count > a.size) {
		Error_set(ERROR, "Indice de vetor fora dos limites.");
		return 0;
	}
	if(count < 1) return 0;
	if(count > block_size) 
		count = block_size;
	
	i = start / block_size;
	p = start % block_size;
	mask = ((unsigned) ~0) >> p;
	if(block_size - p < count) {
		//algo ser� lido do pr�ximo bloco
		value = a.data[i] & mask;
		n = count - (block_size - p);
		mask = ~(((unsigned) ~0) >> n);
		mask = a.data[i + 1] & mask;
		value = (value << n) | (mask >> (block_size - n));
	} else {
		//tudo ser� lido neste bloco
		n = block_size - (count + p);
		mask = mask & (((unsigned) ~0) << n);
		value = a.data[i] & mask;
		value >>= n;
	}
	
	return value;
}

void BitArray_add(BitArray *a, unsigned bits, unsigned rcount) {
	const unsigned block_size = 8 * sizeof(unsigned);
	unsigned i, n, mask;
	
	if(rcount + a->size > a->capacity * block_size) {
		Error_set(ERROR, "Indice de vetor fora dos limites.");
		return;
	}
	
	if(rcount < 1) return;
	if(rcount > block_size) 
		rcount = block_size;
	
	i = a->size / block_size;
	n = a->size % block_size;
	mask = (n % block_size == 0)? 0: 
		((unsigned) ~0) << (block_size - n);
	a->data[i] &= mask; //limpa o bloco
	
	if(rcount + n > block_size) {
		//algo ser� escrito no pr�ximo bloco
		bits <<= block_size - rcount;
		a->data[i] |= bits >> n;
		a->data[i + 1] = bits << (block_size - n);
	} else {
		//tudo ser� escrito neste bloco
		bits <<= (block_size - n - rcount);
		a->data[i] |= bits;
	}
	a->size += rcount;
	return;
}

void BitArray_remove(BitArray* a, unsigned start, unsigned count) {
	const unsigned block_size = 8 * sizeof(unsigned);
	unsigned mask, value, size, i, j, p, q;
	
	if(start > a->size || start + count > a->size) {
		Error_set(ERROR, "Indice de vetor fora dos limites.");
		return;
	}
	if(count < 1) return;
	
	i = start / block_size; 
	j = start % block_size;
	p = (start + count) / block_size;
	q = (start + count) % block_size;
	
	if(j > 0) {
		//primeiro bloco desalinhado,
		//alinhar com bits do pr�ximo bloco
		
		//obter peda�o do pr�ximo bloco
		mask = ((unsigned) ~0) << (block_size - j);
		mask = (~mask << j) >> q;
		value = a->data[p] & mask;
		value = (value << q) >> j;
		
		//mesclar com este bloco
		mask = ((unsigned) ~0) << (block_size - j);
		a->data[i] = (a->data[i] & mask) | value;
		start += block_size - ((j < q)? q: j); //bits obtidos
		
		//recalcular �ndices
		i = start / block_size; 
		j = start % block_size;
		p = (start + count) / block_size;
		q = (start + count) % block_size;
	}
	
	if(j > 0) {
		//primeiro bloco ainda desalinhado
		//(bloco usado n�o tinha bits suficientes),
		//alinhar com bits do pr�ximo bloco mais adiante
		
		//obter peda�o do pr�ximo bloco
		mask = ((unsigned) ~0) << (block_size - j);
		mask = (~mask << j) >> q;
		value = a->data[p] & mask;
		value = (value << q) >> j;
		
		//mesclar com este bloco
		mask = ((unsigned) ~0) << (block_size - j);
		a->data[i] = (a->data[i] & mask) | value;
		start += block_size - ((j < q)? q: j); //bits obtidos
		
		//recalcular �ndices
		i = start / block_size; 
		j = start % block_size;
		p = (start + count) / block_size;
		q = (start + count) % block_size;
	}
	
	//calculando tamanho em blocos
	size = (a->size / block_size);
	if(a->size % block_size > 0)
		size++;
	
	//trazer pr�ximos blocos
	while(p < size) {
		a->data[i] = a->data[p++] << q;
		if(p < size) {
			value = a->data[p] >> (block_size - q);
			a->data[i++] |= value;
		}
	}
	a->size -= count;
	return;
}

void BitArray_append(BitArray* dest, BitArray src) {
	const unsigned block_size = 8 * sizeof(unsigned);
	unsigned mask, value, i, j, p, q, m, n;
	
	if(src.size + dest->size > block_size * dest->capacity) {
		Error_set(ERROR, "Tamanho insuficiente no vetor.");
		return;
	}
	if(src.size < 1) return;
	
	n = 0;
	i = dest->size / block_size;
	j = dest->size % block_size;
	p = n / block_size;
	q = n % block_size;
	
	if(j > 0) {
		//primeiro bloco do dest desalinhado
		//alinhar com bits do primeiro bloco de src
		
		//obter peda�o do pr�ximo bloco
		mask = ((unsigned) ~0) << (block_size - j);
		mask = (~mask << j) >> q;
		value = src.data[p] & mask;
		value = (value << q) >> j;
		
		//mesclar com este bloco
		mask = ((unsigned) ~0) << (block_size - j);
		dest->data[i] = (dest->data[i] & mask) | value;
		m = block_size - ((j < q)? q: j);
		n += m; dest->size += m;
		
		//recalcular �ndices
		i = dest->size / block_size;
		j = dest->size % block_size;
		p = n / block_size;
		q = n % block_size;
	}
	
	//calculando tamanho em blocos
	m = (src.size / block_size);
	if(src.size % block_size > 0)
		m++;
	
	//trazer pr�ximos blocos
	while(p < m) {
		dest->data[i] = src.data[p++] << q;
		value = (p < m && q > 0)? 
			src.data[p] >> (block_size - q): 0;
		dest->data[i++] |= value;
	}
	dest->size += src.size - n;
	return;
}

BitArray BitArray_encode(short value) {
	short v, cp, n;
	BitArray array = BitArray_init(8);
	if(Error_isSet()) return array;
	
	v = (value < 0)? -value: +value; cp = v;
	for(n = 0; cp > 0 && n < 8 * sizeof(short); n++)
		cp = cp >> 1;
	if(value < 0) v = ~v;
	
	BitArray_add(&array, v, n);
	return array;
}

short BitArray_decode(BitArray array) {
	short value, mask, n;
	if(array.size == 0) return 0;

	n = array.size;
	mask = 1 << (n - 1);
	value = BitArray_get(array, 0, n);
	if((value & mask) == 0) {
		mask = ~(((unsigned) ~0) << n);
		return -(~value & mask);
	} else
		return value;
}



/* ==== manipulador de arquivo bin�rio ==== */

BitStream BitStream_init(FILE* file, char mode) {
	BitStream st = (BitStream) malloc(sizeof(struct _BitStream));
	if(st == NULL) {
		Error_set(ERROR, "Memoria insuficiente.");
		return NULL;
	}
	st->file = file;
	st->mode = mode;
	st->buffer = 0;
	st->pos = -1;
	st->eof = -1;
	st->error = -1;
	return st;
}

void BitStream_free(BitStream st) {
	if(st->mode == 'w' && st->pos > 0) { 
		//dados pendentes no buffer, escrever
		const unsigned buffer_size = 8 * sizeof(unsigned);
		st->buffer >>= (buffer_size - st->pos) / 8 * 8;
		if(fwrite(&(st->buffer), 1, 1, st->file) < 1)
			Error_set(ERROR, "Falha ao gravar arquivo.");
	}
	free(st);
	return;
}

BitArray BitStream_read(BitStream st, unsigned bit_count) {
	const unsigned buffer_size = 8 * sizeof(unsigned);
	unsigned buffer, mask, i, j, m, n;
	BitArray data = BitArray_init(bit_count);
	if(Error_isSet()) return data;
	
	if(st->mode != 'r') {
		Error_set(ERROR, "BitStream em estado invalido.");
		BitArray_free(&data);
		return data;
	}
	
	if(bit_count < 1) return data;
	
	/* ler 1 byte por vez, problemas com endianess */
	
	if(st->pos < 0) { 
		//primeira leitura, carregar buffer
		st->buffer = 0; 
		for(i = 0; i < sizeof(unsigned); i++) {
			st->buffer <<= 8; buffer = 0;
			if(fread(&buffer, 1, 1, st->file) < 1) {
				if(feof(st->file) && st->eof < 0) 
					st->eof = i;
				else if(ferror(st->file) && st->error < 0)
					st->error = i;
			}
			st->buffer |= buffer;
		}
	} else if(st->pos > 0) {
		//posi��o do marcador est� desalinhado
		//ler bits desalinhados para alinhar
		if((st->eof >= 0) && (st->pos / 8 >= st->eof)) {
			//n�o permitir pr�ximas leituras
			st->eof = 0; st->buffer = 0; st->pos = 0;
			Error_set(ERROR, "Fim inesperado de arquivo.");
			return data;
		}
		if((st->error >= 0) && (st->pos / 8 >= st->error)) {
			Error_set(ERROR, "Falha na leitura do arquivo.");
			return data;
		}
		
		mask = ((unsigned) ~0) >> st->pos;
		m = (buffer_size - st->pos) % 8;
		n = (buffer_size - st->pos) / 8;
		buffer = (st->buffer & mask) >> 8 * n;
		BitArray_add(&data, buffer, m);
		bit_count -= m;
		
		for(i = n; i < sizeof(unsigned); i++) {
			st->buffer <<= 8; buffer = 0;
			if(fread(&buffer, 1, 1, st->file) < 1) {
				if(feof(st->file) && st->eof < 0) 
					st->eof = i;
				else if(ferror(st->file) && st->error < 0)
					st->error = i;
			}
			st->buffer |= buffer;
		}
	} else {
		if((st->eof >= 0) && (st->pos / 8 >= st->eof)) {
			//n�o permitir pr�ximas leituras
			st->eof = 0; st->buffer = 0; st->pos = 0;
			Error_set(ERROR, "Fim inesperado de arquivo.");
			return data;
		}
		if((st->error >= 0) && (st->pos / 8 >= st->error)) {
			Error_set(ERROR, "Falha na leitura do arquivo.");
			return data;
		}
	}
	st->pos = 0;
	
	//lendo 4 bytes por vez
	for(i = 0; i < bit_count / buffer_size; i++) {
		if(st->eof >= 0) {
			//n�o permitir pr�ximas leituras
			st->eof = 0; st->buffer = 0; st->pos = 0;
			Error_set(ERROR, "Fim inesperado de arquivo1.");
			return data;
		}
		if(st->error >= 0) {
			Error_set(ERROR, "Falha na leitura do arquivo.");
			return data;
		}
		
		BitArray_add(&data, st->buffer, buffer_size);
		for(j = 0; j < sizeof(unsigned); j++) {
			st->buffer <<= 8; buffer = 0;
			if(fread(&buffer, 1, 1, st->file) < 1) {
				if(feof(st->file) && st->eof < 0)
					st->eof = j;
				else if(ferror(st->file) && st->error < 0)
					st->error = j;
			}
			st->buffer |= buffer;
		}
	}
	
	//lendo restante dos bits
	bit_count -= buffer_size * i;
	if(bit_count > 0) {
		n = bit_count / 8 - ((bit_count % 8 == 0)? 1: 0);
		if((st->eof >= 0) && (n >= st->eof)) {
			//n�o permitir pr�ximas leituras
			st->eof = 0; st->buffer = 0; st->pos = 0;
			Error_set(ERROR, "Fim inesperado de arquivo2.");
			return data;
		}
		if((st->error >= 0) && (n >= st->error)) {
			Error_set(ERROR, "Falha na leitura do arquivo.");
			return data;
		}
		
		mask = ((unsigned) ~0) << (buffer_size - bit_count);
		buffer = (st->buffer & mask) >> (buffer_size - bit_count);
		BitArray_add(&data, buffer, bit_count);
		st->pos = bit_count;
	}
	return data;
}

void BitStream_write(BitStream st, BitArray data) {
	const unsigned buffer_size = 8 * sizeof(unsigned);
	unsigned buffer, mask, i, n;
	
	if(st->mode != 'w') {
		Error_set(ERROR, "BitStream em estado invalido.");
		return;
	}
	
	/* escrever 1 byte por vez, problemas com endianess */
	
	i = 0;
	if(st->pos > 0) {
		//posi��o do marcador est� desalinhado
		//escrever alguns bits para alinhar
		
		mask = ((unsigned) ~0) << (buffer_size - st->pos);
		st->buffer &= mask;
		
		i = 8 - st->pos % 8;
		n = (buffer_size - st->pos) / 8;
		buffer = BitArray_get(data, 0, i);
		st->buffer >>= 8 * n;
		
		buffer |= st->buffer;
		if(fwrite(&(st->buffer), 1, 1, st->file) < 1)
			Error_set(ERROR, "Falha ao gravar arquivo.");
		st->buffer = 0; st->pos = 0;
	} else if(st->pos < 0) {
		//nada ainda foi escrito, inicializar
		st->pos = 0;
	}
	n = data.size - (data.size % 8);
	
	//encher buffer, e ent�o gravar
	for(; i < n; i += 8) {
		buffer = BitArray_get(data, i, 8);
		if(fwrite(&buffer, 1, 1, st->file) < 1)
			Error_set(ERROR, "Falha ao gravar arquivo.");
	}
	
	//deixar os bits restantes n�o alinhados
	//para a pr�xima chamada ou finaliza��o
	st->pos = data.size - i;
	st->buffer = BitArray_get(data, i, data.size - i);
	st->buffer <<= buffer_size - (data.size - i);
	return;
}

void BitStream_log(BitStream st) {
	unsigned size; char mode[10], state[10];
	size = 8 * sizeof(unsigned);
	
	if(st->mode == 'r' || st->mode == 'w')
		strcpy(mode, (st->mode == 'r')? "read": "write");
	else
		strcpy(mode, "null");
	
	if(st->eof >= 0)
		strcpy(state, format("EOF@%d", st->eof));
	else if(st->error >= 0)
		strcpy(state, format("error@%d", st->error));
	else
		strcpy(state, "clear");
	
	Log_printf("BitStream(%s:%s:%2d:%s)\n", 
		mode, btoa(st->buffer, size, 8), st->pos, state);
	return;
}



/* ==== informa��es do arquivo bin�rio ==== */

BinaryFileInfo Info_init() {
	BinaryFileInfo info;
	info.file_size = 0;
	info.width = info.height = 0;
	return info;
}

void Info_free(BinaryFileInfo *info) {
	info->file_size = 0;
	info->width = info->height = 0;
	return;
}

void Info_log(BinaryFileInfo info) {
	if(!Config_getItemOutput(LOG_BIN_FILE_HEADER)) return;
	
	Log_puts("== Binary File Header ==");
	Log_nl();
	Log_printf("%20s: %d bytes\n", "File Data Size", info.file_size);
	Log_printf("%20s: %d x %d blocks (w x h)\n", "Image Dimensions", 
			info.width, info.height);
	Log_nl();
	return;
}

void Info_setFileSize(BinaryFileInfo *info, BitArray data) {
	info->file_size = data.size / 8;
	if(data.size % 8 > 0)
		info->file_size++;
	return;
}

void Info_setDimensions(BinaryFileInfo *info, BITMAP_INFO_HEADER h) {
	info->width = h.width / BLOCK_SIZE;
	info->height = h.height / BLOCK_SIZE;
	return;
}

void Info_write(BinaryFileInfo info, BitStream out) {
	BitArray data = BitArray_init(2 * 8 * sizeof(unsigned));
	if(Error_isSet()) return;
	
	BitArray_add(&data, info.file_size, 8 * sizeof(unsigned));
	BitArray_add(&data, info.width, 8);
	BitArray_add(&data, info.height, 8);
	
	BitStream_write(out, data);
	BitArray_free(&data);
	return;
}

BinaryFileInfo Info_read(BitStream in) {
	BinaryFileInfo info = Info_init();
	BitArray data = BitStream_read(in, 6 * 8);
	if(Error_isSet()) return info;
	
	info.file_size = BitArray_get(data, 0, 32);
	info.width = BitArray_get(data, 32, 8);
	info.height = BitArray_get(data, 40, 8);
	
	BitArray_free(&data);
	return info;
}



/* ==== imagem preparada em RGB ==== */

RGB_Image RGB_Image_init(unsigned width, unsigned height) {
	RGB_Image image; int i, j;
	
	image.width = width; image.height = height;
	
	image.r = (unsigned char**) malloc(height * sizeof(unsigned char*));
	image.g = (unsigned char**) malloc(height * sizeof(unsigned char*));
	image.b = (unsigned char**) malloc(height * sizeof(unsigned char*));
	
	if(image.r == NULL || image.g == NULL || image.b == NULL)  {
		RGB_Image_free(&image);
		Error_set(ERROR, "Memoria insuficiente.");
		return image;
	}
	
	for(i = 0; i < height; i++) //prepara��o para falha
		image.r[i] = image.g[i] = image.b[i] = NULL;
	
	for(i = 0; i < height; i++) {
		image.r[i] = (unsigned char*) malloc(width * sizeof(unsigned char));
		image.g[i] = (unsigned char*) malloc(width * sizeof(unsigned char));
		image.b[i] = (unsigned char*) malloc(width * sizeof(unsigned char));
		
		if(image.r[i] == NULL || image.g[i] == NULL || image.b[i] == NULL)  {
			RGB_Image_free(&image);
			Error_set(ERROR, "Memoria insuficiente.");
			return image;
		}
		
		for(j = 0; j < width; j++) {
			image.r[i][j] = 0;
			image.g[i][j] = 0;
			image.b[i][j] = 0;
		}
	}
	
	return image;
}

void RGB_Image_free(RGB_Image *image) {
	int i;
	
	if(image->r != NULL) {
		for(i = 0; i < image->height; i++) {
			if(image->r[i] != NULL) 
				free(image->r[i]); 
		}
	}
	
	if(image->g != NULL) {
		for(i = 0; i < image->height; i++) {
			if(image->g[i] != NULL) 
				free(image->g[i]); 
		}
	}
	
	if(image->b != NULL) {
		for(i = 0; i < image->height; i++) {
			if(image->b[i] != NULL) 
				free(image->b[i]);
		}
	}
	
	free(image->r); image->r = NULL;
	free(image->g); image->g = NULL;
	free(image->b); image->b = NULL;
	
	image->width = 0;
	image->height = 0;
	return;
}

void RGB_Image_log(RGB_Image image) {
	int i, j;
	if(!Config_getItemOutput(LOG_RGB_IMAGE)) return;
	
	Log_puts("== Imagem em RGB ==");
	Log_nl();
	
	Log_puts("-- Matriz Vermelha --");
	for(i = 0; i < image.height; i++) {
		for(j = 0; j < image.width; j++)
			Log_printf("%02x ", image.r[i][j]);
		Log_nl();
	}
	Log_nl();
	
	Log_puts("-- Matriz Verde --");
	for(i = 0; i < image.height; i++) {
		for(j = 0; j < image.width; j++)
			Log_printf("%02x ", image.g[i][j]);
		Log_nl();
	}
	Log_nl();
	
	Log_puts("-- Matriz Azul --");
	for(i = 0; i < image.height; i++) {
		for(j = 0; j < image.width; j++)
			Log_printf("%02x ", image.b[i][j]);
		Log_nl();
	}
	
	Log_nl();
	return;
}

RGB_Image RGB_Image_fromRaw(BitArray raw_data, unsigned width, unsigned height) {
	int i, j, k; 
	RGB_Image image = RGB_Image_init(width, height);
	if(Error_isSet()) return image;
	
	for(i = 0; i < image.height; i++) {
		for(j = 0; j < image.width; j++) {
			k = 24 * (image.width * i + j); /* B, G, R */
			image.b[i][j] = BitArray_get(raw_data, k + 0, 8);
			image.g[i][j] = BitArray_get(raw_data, k + 8, 8);
			image.r[i][j] = BitArray_get(raw_data, k + 16, 8);
		}
	}
	
	return image;
}

BitArray RGB_Image_toRaw(RGB_Image image) {
	int i, j;
	BitArray raw_data = BitArray_init(24 * image.width * image.height);
	if(Error_isSet()) return raw_data;
	
	for(i = 0; i < image.height; i++) {
		for(j = 0; j < image.width; j++) { /* B, G, R */
			BitArray_add(&raw_data, image.b[i][j], 8);
			BitArray_add(&raw_data, image.g[i][j], 8);
			BitArray_add(&raw_data, image.r[i][j], 8);
		}
	}
	
	return raw_data;
}



/* ==== imagem dividida em blocos ==== */

ImageBlocks ImageBlocks_init(BinaryFileInfo info) {
	ImageBlocks blocks; int i, j, k;
	
	blocks.size = 3 * info.width * info.height; //3 cores
	
	blocks.data = (short***) malloc(blocks.size * sizeof(short**));
	if(blocks.data == NULL) {
		Error_set(ERROR, "Memoria insuficiente.");
		ImageBlocks_free(&blocks);
		return blocks;
	}
	
	//prepara��o para erros
	for(k = 0; k < blocks.size; k++) 
		blocks.data[k] = NULL;
	
	//blocos
	for(k = 0; k < blocks.size; k++) {
		blocks.data[k] = (short**) malloc(BLOCK_SIZE * sizeof(short*));
		if(blocks.data[k] == NULL) {
			Error_set(ERROR, "Memoria insuficiente.");
			ImageBlocks_free(&blocks);
			return blocks;
		}
		
		//prepara��o para erros
		for(i = 0; i < BLOCK_SIZE; i++) 
			blocks.data[k][i] = NULL;
		
		//linhas do bloco
		for(i = 0; i < BLOCK_SIZE; i++) {
			blocks.data[k][i] = (short*) malloc(BLOCK_SIZE * sizeof(short));
			if(blocks.data[k][i] == NULL) {
				Error_set(ERROR, "Memoria insuficiente.");
				ImageBlocks_free(&blocks);
				return blocks;
			}
			
			//colunas do bloco
			for(j = 0; j < BLOCK_SIZE; j++)
				blocks.data[k][i][j] = 0;
		}
	}
	return blocks;
}

void ImageBlocks_free(ImageBlocks* blocks) {
	int i, k;
	if(blocks->data != NULL) {
		
		for(k = 0; k < blocks->size; k++) {
			if(blocks->data[k] != NULL) {
				
				for(i = 0; i < BLOCK_SIZE; i++) {
					if(blocks->data[k][i] != NULL)
						free(blocks->data[k][i]); 
				}
				
				free(blocks->data[k]); 
			}
		}
		
		free(blocks->data); 
	}
	blocks->data = NULL;
	blocks->size = 0;
	return;
}

void ImageBlocks_log(ImageBlocks blocks, int view) {
	int n, i, j, k;
	if(!Config_getItemOutput(view)) return;
	
	switch(view) {
	case LOG_IMAGE_BLOCKS:
		Log_puts("== Blocos da Imagem ==");
		break;
	case LOG_SHIFTED_BLOCKS:
		Log_puts("== Blocos da Imagem (Deslocado) ==");
		break;
	case LOG_FD_BLOCKS:
		Log_puts("== Blocos da Imagem (Transformado) ==");
		break;
	default:
		return;
	}
	Log_nl();
	
	n = blocks.size / 3;
	
	Log_puts("-- Vermelho --");
	for(k = 0; k < n; k++) {
		for(i = 0; i < BLOCK_SIZE; i++) {
			for(j = 0; j < BLOCK_SIZE; j++)
				Log_printf("%+.3d ", blocks.data[k][i][j]);
			Log_nl();
		}
		Log_nl();
	}
	
	Log_puts("-- Verde --");
	for(k = n; k < 2 * n; k++) {
		for(i = 0; i < BLOCK_SIZE; i++) {
			for(j = 0; j < BLOCK_SIZE; j++)
				Log_printf("%+.3d ", blocks.data[k][i][j]);
			Log_nl();
		}
		Log_nl();
	}
	
	Log_puts("-- Azul --");
	for(k = 2 * n; k < 3 * n; k++) {
		for(i = 0; i < BLOCK_SIZE; i++) {
			for(j = 0; j < BLOCK_SIZE; j++)
				Log_printf("%+.3d ", blocks.data[k][i][j]);
			Log_nl();
		}
		Log_nl();
	}
	
	return;
}

ImageBlocks ImageBlocks_fromRGB(RGB_Image image, BinaryFileInfo info) {
	int ib, jb, b, i, j, m, n, k;
	ImageBlocks blocks = ImageBlocks_init(info);
	if(Error_isSet()) return blocks;
	
	//blocos
	m = image.height / BLOCK_SIZE; 
	n = image.width / BLOCK_SIZE;
	b = BLOCK_SIZE;
	
	//vermelho
	for(ib = 0; ib < m; ib++) {
		for(jb = 0; jb < n; jb++) {
			k = n * ib + jb;
			
			//pixels do bloco
			for(i = 0; i < b; i++) {
				for(j = 0; j < b; j++) {
					blocks.data[k][i][j] = 
						image.r[b * ib + i][b * jb + j];
				}
			}
		}
	}
	
	//verde
	for(ib = 0; ib < m; ib++) {
		for(jb = 0; jb < n; jb++) {
			k = (m * n) + (n * ib + jb);
			
			//pixels do bloco
			for(i = 0; i < b; i++) {
				for(j = 0; j < b; j++) {
					blocks.data[k][i][j] = 
						image.g[b * ib + i][b * jb + j];
				}
			}
		}
	}
	
	//azul
	for(ib = 0; ib < m; ib++) {
		for(jb = 0; jb < n; jb++) {
			k = (2 * m * n) + (n * ib + jb);
			
			//pixels do bloco
			for(i = 0; i < b; i++) {
				for(j = 0; j < b; j++) {
					blocks.data[k][i][j] = 
						image.b[b * ib + i][b * jb + j];
				}
			}
		}
	}
	
	return blocks;
}

/* obt�m uma imagem em RGB a partir dos blocos de imagem */
RGB_Image ImageBlocks_toRGB(ImageBlocks blocks, BinaryFileInfo info) {
	int ib, jb, b, i, j, m, n, k;
	RGB_Image image = RGB_Image_init(
		BLOCK_SIZE * info.width, BLOCK_SIZE * info.height);
	if(Error_isSet()) return image;
	
	//blocos
	m = image.height / BLOCK_SIZE; 
	n = image.width / BLOCK_SIZE;
	b = BLOCK_SIZE;
	
	//vermelho
	for(ib = 0; ib < m; ib++) {
		for(jb = 0; jb < n; jb++) {
			k = n * ib + jb;
			
			//pixels do bloco
			for(i = 0; i < b; i++) {
				for(j = 0; j < b; j++) {
					image.r[b * ib + i][b * jb + j] = 
						blocks.data[k][i][j];
				}
			}
		}
	}
	
	//verde
	for(ib = 0; ib < m; ib++) {
		for(jb = 0; jb < n; jb++) {
			k = (m * n) + (n * ib + jb);
			
			//pixels do bloco
			for(i = 0; i < b; i++) {
				for(j = 0; j < b; j++) {
					image.g[b * ib + i][b * jb + j] =
						blocks.data[k][i][j];
				}
			}
		}
	}
	
	//azul
	for(ib = 0; ib < m; ib++) {
		for(jb = 0; jb < n; jb++) {
			k = (2 * m * n) + (n * ib + jb);
			
			//pixels do bloco
			for(i = 0; i < b; i++) {
				for(j = 0; j < b; j++) {
					image.b[b * ib + i][b * jb + j] = 
						blocks.data[k][i][j];
				}
			}
		}
	}
	
	return image;
}

/* desloca os valores da imagem de algum valor */
void ImageBlocks_levelShift(ImageBlocks blocks, short delta) {
	int i, j, k;
	for(k = 0; k < blocks.size; k++) {
		for(i = 0; i < BLOCK_SIZE; i++) {
			for(j = 0; j < BLOCK_SIZE; j++)
				blocks.data[k][i][j] += delta;
		}
	}
	return;
}
