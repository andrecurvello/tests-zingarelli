/*
SCC0261 MULTIMÍDIA - 1º SEMESTRE DE 2011
DOCENTE: RUDINEI GOULARTE

PROJETO: COMPRESSÃO DE IMAGEM DIGITAL PARTE 2


ALUNOS:
	Jairo Toshio Tuboi 		6427250
	Ricardo Takashi Kagawa		5634712
	Rodrigo Luis Gava Girckus 	5967770
*/
#ifndef UTIL_H
#define UTIL_H

#include "defs.h"

#define OL_QUIET	0
#define OL_NORMAL	1
#define OL_VERBOSE	2
#define OL_DEBUG	3

//buffer para retornar texto (conveniência)
char _tmpstr[LINE_MAX];

/* inicializa as configurações globais */
void Config_init();

/* destrói as configurações globais */
void Config_free();

/* verifica se o nível de exibição de mensagens é igual
 * ou superior ao especificado
 * 
 * level: OL_QUIET, OL_NORMAL, OL_VERBOSE ou OL_DEBUG
 * 
 * return: TRUE caso o nível de mensagens atual seja
 * no mínimo o nível especificado
 */
short Config_hasOutputLevel(short level);

/* obtém o nível de exibição de mensagens atual
 * 
 * return: OL_QUIET, OL_NORMAL, OL_VERBOSE ou OL_DEBUG
 */
short Config_getOutputLevel();

/* define o nível de exibição de mensagens 
 * 
 * level: OL_QUIET, OL_NORMAL, OL_VERBOSE ou OL_DEBUG
 */
void Config_setOutputLevel(short level);

/* define se um item deve ser exibido na depuração
 * 
 * index: o índice do item a ser exibido ou não
 * display: TRUE para exibir na depuração
 */
void Config_setItemOutput(short index, short display);

/* verifica se um item deve ser exibido no relatório 
 * de depuração
 * 
 * index: o índice do item a ser verificado
 * 
 * return: TRUE caso o item deva ser exibido (caso
 * o nível de mensagem seja inferior a OL_DEBUG,
 * retornará FALSE para qualquer item).
 */
short Config_getItemOutput(short index);

/* Define se a depuração deve ser escrita em arquivo
 * ao invés de na saída padrão. Caso a escrita da 
 * depuração já esteja em uso, a função não faz nada.
 * 
 * value: TRUE escreve a depuração em um arquivo
 */
void Config_setDebugToFile(short value);



/* abre o arquivo de relatório de depuração para escrita
 * 
 * filename: o nome do arquivo (será ignorado se estiver
 * configurado para exibir na saída padrão)
 * 
 * LOG_ERROR: se não conseguir abrir o arquivo especificado
 */
void Log_open(char filename[]);

/* fecha o arquivo de relatório de depuração */
void Log_close();

/* Imprime uma mensagem no relatório ao estilo printf.
 * 
 * format: o mesmo do printf.
 * ...: o mesmo do printf.
 */
void Log_printf(char* format, ...);

/* imprime uma mensagem no relatório ao estilo puts.
 * 
 * str: o mesmo do puts.
 */
void Log_puts(char* str);

/* insere um terminador de linha no relatório */
void Log_nl();



#define NO_ERROR	0
#define ERROR		1

/* inicializador/finalizador */
void Errors_init();
void Errors_free();

/* obtém o código do erro */
int Error_getCode();

/* obtém a mensagem de erro */
char* Error_getMessage();

/* define um erro com código e mensagem 
 * 
 * code: algum código de erro que pode ser usado 
 *   pelo programa para identificá-lo (o código 
 *   ERROR é um código genérico, caso não seja 
 *   interessante atribuir um código específico)
 * msg: uma mensagem descritiva do erro
 */
void Error_set(int code, char msg[]);

/* limpa o código de erro */
void Error_clear();

/* verifica se algum erro foi lançado */
short Error_isSet();



/* representa um inteiro como uma cadeia de bits 
 * 
 * value: o valor a ser representado
 * size: o número de bits a ser representado (max. 32)
 * group: o número de bits a ser agrupado por grupo
 *   (separados por espaço, 0 significa não agrupar,
 *   negativo significa agrupar pela esquerda)
 */
char* btoa(unsigned value, unsigned size, int group);

/* retorna o resultado de sprintf no buffer padrão */
char* format(char format[], ...);

/* arredonda o número fracionário para o inteiro mais próximo */
int round_half_even(double x);

#endif
