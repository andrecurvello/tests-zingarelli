/*
SCC0261 MULTIM�DIA - 1� SEMESTRE DE 2011
DOCENTE: RUDINEI GOULARTE

PROJETO: COMPRESS�O DE IMAGEM DIGITAL PARTE 3


ALUNOS:
	Jairo Toshio Tuboi 		6427250
	Ricardo Takashi Kagawa		5634712
	Rodrigo Luis Gava Girckus 	5967770
*/
#ifndef CODEC_PT1
#define CODEC_PT1

#include <stdio.h>
#include "codec.h"



/* ==== bitmap file header ==== */

/* inicializa a estrutura com dados pr�-definidos 
 * 
 * data_size: o tamanho do campo de dados, em bytes
 */
BITMAP_FILE_HEADER BFH_init(unsigned data_size);

/* l� os dados da estrutura a partir de um arquivo */
BITMAP_FILE_HEADER BFH_read(FILE* file);

/* escreve os dados da estrutura para um arquivo */
void BFH_write(BITMAP_FILE_HEADER h, FILE* file);

/* exibe os dados da estrutura no relat�rio de depura��o */
void BFH_log(BITMAP_FILE_HEADER h);



/* ==== bitmap information header ==== */

/* inicializa a estrutura com dados pr�-definidos 
 * 
 * width, height: as dimens�es da imagem, em pixels
 */
BITMAP_INFO_HEADER BIH_init(unsigned width, unsigned height);

/* l� os dados da estrutura a partir de um arquivo */
BITMAP_INFO_HEADER BIH_read(FILE* file);

/* escreve os dados da estrutura para um arquivo */
void BIH_write(BITMAP_INFO_HEADER h, FILE* file);

/* exibe os dados da estrutura no relat�rio de depura��o */
void BIH_log(BITMAP_INFO_HEADER h);



/* ==== vetor de bits ==== */

typedef struct {
	unsigned capacity;	//words
	unsigned size;		//bits
	unsigned *data;
} BitArray;

/* inicializador/finalizador 
 * 
 * capacity: n�mero m�nimo de bits que o vetor
 * dever� ser capaz de armazenar (a capacidade
 * real ser� igual ou um pouco maior)
 */
BitArray BitArray_init(unsigned capacity);
void BitArray_free(BitArray *a);

/* Exibe o vetor no relat�rio. Caso group seja negativo
 * e m�ltiplo de 8, e cols n�o seja zero, a fun��o ir� 
 * exibir tamb�m a posi��o em bytes do primeiro byte de
 * cada linha (em hexadecimal).
 * 
 * group: o n�mero de bits que deve ser agrupado
 * (grupos s�o separados por espa�o, 0 significa
 * que n�o devem ser agrupados e negativo agrupa
 * no sentido inverso)
 * 
 * cols: o n�mero m�ximo de grupos que deve ser 
 * exibido por linha (zero significa n�o pular
 * linha; se cols n�o for zero mas group for, 
 * cols contar� bits ao inv�s de grupos)
 */
void BitArray_log(BitArray a, int group, unsigned cols);

/* cria uma c�pia do vetor */
BitArray BitArray_clone(BitArray src);

/* adiciona uma sequ�ncia de bits ao vetor */
void BitArray_append(BitArray* dest, BitArray src);

/* adiciona uma sequ�ncia de bits ao vetor
 * 
 * bits: o valor inteiro que fornecer� os novos bits
 * rcount: o n�mero de bits a extrair de bits
 *   (apenas os bits menos significativos ser�o usados)
 */
void BitArray_add(BitArray *a, unsigned bits, unsigned rcount);

/* remove uma sequencia de bits do vetor
 * 
 * start: �ndice do primeiro bit a ser removido
 * count: n�mero de bits a remover
 */
void BitArray_remove(BitArray* a, unsigned start, unsigned count);

/* obt�m uma sequencia de bits do vetor 
 * 
 * start: �ndice do primeiro bit a ser extra�do
 * count: n�mero de bits a extrair (n�o deve ultrapassar
 *   o tamanho em bits do tipo de retorno)
 * 
 * retorno: a sequ�ncia de bits nas posi��es menos
 *   significativas do valor de retorno (preenchido
 *   com zeros � esquerda)
 */
unsigned BitArray_get(BitArray a, unsigned start, unsigned count);

/* codifica um valor por complemento, criando um novo vetor de bits
 * 
 * value: o valor a ser codificado, entre -255 e +255 (inclusive)
 * 
 * return: um novo vetor de bits com o resultado da codifica��o
 */
BitArray BitArray_encode(short value);

/* decodifica um valor codificado por complemento
 * 
 * value: o valor a ser decodificado
 * 
 * retorno: o valor decodificado, entre -255 e +255 (inclusive)
 */
short BitArray_decode(BitArray array);



/* ==== manipulador de arquivo bin�rio ==== */

typedef struct _BitStream {
	FILE* file;
	char mode;			//'r' ou 'w'
	unsigned buffer;
	int pos;			//bit-indexed
	int eof, error;		//byte-indexed
}* BitStream;

/* inicializador/finalizador */
BitStream BitStream_init(FILE* file, char mode);
void BitStream_free(BitStream st);

/* l� o n�mero especificado de bits do arquivo */
BitArray BitStream_read(BitStream st, unsigned bit_count);

/* Grava a sequ�ncia de bits no arquivo. Alguns bits podem ficar
 * com escrita pendente no buffer (para permitir que v�rias chamadas 
 * sucessivas a esta fun��o escrevam de forma cont�nua), portanto
 * a fun��o BitStream_free deve ser chamada para concluir a grava��o.
 * O �ltimo byte pode ser preenchido com zeros � direita, se necess�rio.
 */
void BitStream_write(BitStream st, BitArray data);

/* exibe a estrutura no relat�rio de depura��o */
void BitStream_log(BitStream st);



/* ==== informa��es do arquivo bin�rio ==== */

typedef struct {
	unsigned file_size;		//bytes (exceto este header)
	unsigned width, height;	//blocos
} BinaryFileInfo;

/* inicializador, finalizador */
BinaryFileInfo Info_init();
void Info_free(BinaryFileInfo *info);

/* exibe o header no relat�rio de depura��o */
void Info_log(BinaryFileInfo info);

/* calcula e armazena o tamanho do arquivo bin�rio */
void Info_setFileSize(BinaryFileInfo *info, BitArray data);

/* calcula e armazena as dimens�es da imagem */
void Info_setDimensions(BinaryFileInfo *info, BITMAP_INFO_HEADER h);

/* escreve este header no arquivo */
void Info_write(BinaryFileInfo info, BitStream out);

/* l� este header do arquivo */
BinaryFileInfo Info_read(BitStream in);



/* ==== imagem preparada em RGB ==== */

typedef struct {
	unsigned width, height;			//pixels
	unsigned char **r, **g, **b;	//0 ~ 255
} RGB_Image;

/* inicializa��o/finaliza��o 
 * 
 * width: largura da imagem em pixels
 * height: altura da imagem em pixels
 */
RGB_Image RGB_Image_init(unsigned width, unsigned height);
void RGB_Image_free(RGB_Image *image);

/* Exibe a imagem no relat�rio de depura��o.
 * Cada pixel ser� representado por um byte em hexadecimal.
 */
void RGB_Image_log(RGB_Image image);

/* obt�m a imagem a partir da se��o de dados do arquivo 
 * (as matrizes de cores s�o separadas)
 * 
 * width: largura da imagem em pixels (dispon�vel no header)
 * height: altura da imagem em pixels (dispon�vel no header)
 */
RGB_Image RGB_Image_fromRaw(BitArray raw_data, unsigned width, unsigned height);

/* obt�m uma se��o de dados de um arquivo bitmap 
 * a partir da imagem (as matrizes de cores s�o
 * recombinadas) */
BitArray RGB_Image_toRaw(RGB_Image image);



/* ==== imagem dividida em blocos ==== */

#define BLOCK_SIZE 8

typedef struct {
	unsigned size;	//blocks
	short ***data;	//0 ~ 255 ou -128 ~ +127
} ImageBlocks;

/* inicializador/finalizador */
ImageBlocks ImageBlocks_init(BinaryFileInfo info);
void ImageBlocks_free(ImageBlocks *blocks);

/* exibe os blocos de imagem no relat�rio de depura��o */
void ImageBlocks_log(ImageBlocks blocks, int view);

/* obt�m os blocos de imagem a partir da imagem em RGB */
ImageBlocks ImageBlocks_fromRGB(RGB_Image image, BinaryFileInfo info);

/* obt�m uma imagem em RGB a partir dos blocos de imagem 
 * 
 * width: largura da imagem, em blocos
 * height: altura da imagem, em blocos
 */
RGB_Image ImageBlocks_toRGB(ImageBlocks blocks, BinaryFileInfo info);

/* desloca os valores da imagem de algum valor */
void ImageBlocks_levelShift(ImageBlocks blocks, short delta);

#endif
