/*
SCC0261 MULTIM�DIA - 1� SEMESTRE DE 2011
DOCENTE: RUDINEI GOULARTE

PROJETO: COMPRESS�O DE IMAGEM DIGITAL PARTE 3


ALUNOS:
	Jairo Toshio Tuboi 		6427250
	Ricardo Takashi Kagawa		5634712
	Rodrigo Luis Gava Girckus 	5967770
*/
#ifndef CODEC_PT2
#define CODEC_PT2

#define TRACE_MAP { \
	{ 0,  1,  5,  6, 14, 15, 27, 28},	\
	{ 2,  4,  7, 13, 16, 26, 29, 42},	\
	{ 3,  8, 12, 17, 25, 30, 41, 43},	\
	{ 9, 11, 18, 24, 31, 40, 44, 53},	\
	{10, 19, 23, 32, 39, 45, 52, 54},	\
	{20, 22, 33, 38, 46, 51, 55, 60},	\
	{21, 34, 37, 47, 50, 56, 59, 61},	\
	{35, 36, 48, 49, 57, 58, 62, 63}	\
}



/* ==== blocos vetorizados ==== */

typedef struct _BlockVectors {
	int size; 		//n�mero de blocos
	char** data;	//blocos vetorizados
} BlockVectors;

/* inicializador/finalizador 
 * 
 * size: n�mero total de blocos
 */
BlockVectors BlockVectors_init(int size);
void BlockVectors_free(BlockVectors *vectors);

/* exibe os vetores no relat�rio de depura��o */
void BlockVectors_log(BlockVectors vectors);

/* cria a estrutura vetorizada a partir dos blocos. */
BlockVectors BlockVectors_fromBlocks(ImageBlocks blocks);

/* cria os blocos a partir da estrutura vetorizada. */
ImageBlocks BlockVectors_toBlocks(BlockVectors vectors, BinaryFileInfo info);



/* ==== valores DC ==== */

typedef struct {
	short* data;	//-127 ~ +128 (decoded) / -255 ~ +255 (encoded)
	int size;		//values (mesmo que o n�mero de blocos)
} DCValues;

/* inicializador/finalizador */
DCValues DC_init(int size);
void DC_free(DCValues *dc);

/* exibe os valores no relat�rio de depura��o */
void DC_log(DCValues dc, int encoded);

/* cria um vetor de valores DC a partir dos vetores */
DCValues DC_fromVectors(BlockVectors vectors);

/* insere os valores DC nos blocos vetorizados */
void DC_toVectors(DCValues dc, BlockVectors vectors);

/* codifica os valores DC por diferen�as */
void DC_encode(DCValues dc);

/* decodifica os valores DC codificados por diferen�as */
void DC_decode(DCValues dc);



/* ==== valores AC ==== */

typedef struct {
	char value;		//-128 ~ +127
	char repeat;	//0 ~ 62
} ACValue;

typedef struct {
	int nb;			//n�mero de blocos
	int* np;		//n�mero de pares RL no bloco
	ACValue** data;	//pares run-length (RL)
} ACValues;

/* inicializador/finalizador */
ACValues AC_init(int block_count);
void AC_free(ACValues *ac);

/* exibe os valores no relat�rio de depura��o */
void AC_log(ACValues ac, int encoded);

/* cria um vetor de valores AC a partir dos vetores */
ACValues AC_fromVectors(BlockVectors vectors);

/* insere os valores AC nos blocos vetorizados */
void AC_toVectors(ACValues ac, BlockVectors vectors);

/* codifica os valores AC por carreira */
void AC_encode(ACValues ac);

/* decodifica os valores AC codificados por carreira */
void AC_decode(ACValues ac);



/* ==== Valores DC (complemento) == */

typedef struct {
	BitArray *data;
	int size;
} EncDCValues;

/* inicializador/finalizador */
EncDCValues EDC_init(int size);
void EDC_free(EncDCValues *edc);

/* exibe os valores no relat�rio de depura��o */
void EDC_log(EncDCValues edc);

/* cria um vetor de valores DC complementados a partir dos valores DC */
EncDCValues EDC_fromDC(DCValues dc);

/* cria um vetor de valores DC a partir dos valores DC complementados */
DCValues EDC_toDC(EncDCValues edc);



/* ==== Valores AC (complemento) == */

typedef struct {
	BitArray value;	//-128 ~ +127
	char repeat;	//0 ~ 62
} EncACValue;

typedef struct {
	int nb;				//n�mero de blocos
	int* np;			//n�mero de pares RL no bloco
	EncACValue** data;	//pares run-length (RL) com SSS
} EncACValues;

/* inicializador/finalizador */
EncACValues EAC_init(int block_count);
void EAC_free(EncACValues *eac);

/* exibe os valores no relat�rio de depura��o */
void EAC_log(EncACValues eac);

/* cria ACs complementados a partir dos ACs */
EncACValues EAC_fromAC(ACValues ac);

/* cria ACs a partir dos ACs complementados */
ACValues EAC_toAC(EncACValues eac);



/* ==== Metadados AC/DC ==== */

typedef struct {
	short size;		//0 ~ 8 bits (both)
	short repeat;	//0 ~ 62 (AC only)
} MetaData;

typedef struct {
	MetaData *data;
	int size;
} MetaDataArray;

/* inicializador/finalizador */
MetaDataArray MDArray_init(int size);
void MDArray_free(MetaDataArray* a);

/* lista todas as inst�ncias dos metadados DC */
MetaDataArray MDArray_fromDC(EncDCValues edc);

/* lista todas as inst�ncias dos metadados AC */
MetaDataArray MDArray_fromAC(EncACValues eac);



/* ==== N� da �rvore de Huffman ==== */

#define TREE_NODE 0
#define TREE_LEAF 1

typedef struct _HuffmanNode {
	short type;
	int count;
	short is_left;
	struct _HuffmanNode* parent;
	union {
		struct { //n� folha
			MetaData value;
		};
		struct { //n� intermedi�rio
			struct _HuffmanNode* left;
			struct _HuffmanNode* right;
		};
	};
} HuffmanNode;

/* inicializador/finalizador */
HuffmanNode HNode_init(short type);
HuffmanNode* HNode_create(short type);
void HNode_free(HuffmanNode* node);

/* exibe a estrutura no relat�rio de depura��o */
void HNode_log(HuffmanNode* node, char prefix[], short encoder);

/* codifica um n� do decodificador DC (recursivo)
 * 
 * node: o n� a ser codificado
 */
void HNode_encodeDC(HuffmanNode* node, BitArray* data);

/* codifica um n� do decodificador AC (recursivo)
 * 
 * node: o n� a ser codificado
 */
void HNode_encodeAC(HuffmanNode* node, BitArray* data);

/* obt�m o pr�ximo n� partindo de uma folha (pr�-ordem) */
HuffmanNode* HNode_next(HuffmanNode* leaf);



/* ==== Frequ�ncias de Metadados ==== */

typedef struct {
	HuffmanNode *data;
	int size;
} FrequencyTable;

/* inicializador/finalizador */
FrequencyTable FTable_init(int size);
void FTable_free(FrequencyTable *table);

/* exibe os valores no relat�rio de depura��o */
void FTable_log(FrequencyTable table);

/* conta as freq�encias dos valores de uma lista */
void FTable_count(FrequencyTable* table, MetaDataArray a);

/* clona a tabela de freq�encias */
FrequencyTable FTable_clone(FrequencyTable src);



/* ==== �rvore de Huffman ==== */

typedef struct {
	HuffmanNode* root;
	int nleaves;
} HuffmanTree;

/* inicializador/finalizador */
HuffmanTree HTree_init();
void HTree_free(HuffmanTree* tree);

/* exibe a estrutura no relat�rio de depura��o */
void HTree_log(HuffmanTree tree, short encoder);


/* cria uma �rvore de Huffman a partir dos valores DC */
HuffmanTree HTree_fromDC(EncDCValues edc);

/* cria uma �rvore de Huffman a partir dos valores AC */
HuffmanTree HTree_fromAC(EncACValues eac);

/* cria uma �rvore de Huffman a partir da contagem de valores */
HuffmanTree HTree_fromCount(FrequencyTable table);


/* codifica o decodificador Huffman para os valores DC */
BitArray HTree_packageDCDecoder(HuffmanTree decoder);

/* codifica o decodificador Huffman para os valores AC */
BitArray HTree_packageACDecoder(HuffmanTree decoder);

/* extrai o decodificador DC do in�cio do vetor de bits */
HuffmanTree HTree_extractDCDecoder(BitArray* data);

/* extrai o decodificador AC do in�cio do vetor de bits */
HuffmanTree HTree_extractACDecoder(BitArray* data);



/* ==== Dicion�rio de Codifica��o ==== */

typedef struct _EncoderMapping {
	MetaData key;
	BitArray value;
} EncoderMapping;

typedef struct _EncoderDictionary {
	EncoderMapping* data;
	int size;
} EncoderDictionary;

/* inicializador/finalizador */
EncoderDictionary Dictionary_init(int size);
void Dictionary_free(EncoderDictionary* map);

/* exibe a estrutura no relat�rio de depura��o */
void Dictionary_log(EncoderDictionary map);

/* cria um dicion�rio de codifica��o a partir de uma �rvore Huffman */
EncoderDictionary Dictionary_fromTree(HuffmanTree tree);

/* obt�m o c�digo mapeado para um metadado */
BitArray Dictionary_get(EncoderDictionary map, MetaData key);



/* ==== Arquivo Bin�rio ==== */

/* codifica os valores DC usando a �rvore de Huffman */
BitArray HTree_encodeDC(HuffmanTree encoder, EncDCValues edc);

/* codifica os valores AC usando a �rvore de Huffman */
BitArray HTree_encodeAC(HuffmanTree encoder, EncACValues eac);

/* decodifica os valores DC usando a �rvore de Huffman */
EncDCValues HTree_decodeDC(HuffmanTree decoder, BitArray* data, BinaryFileInfo info);

/* decodifica os valores AC usando a �rvore de Huffman */
EncACValues HTree_decodeAC(HuffmanTree decoder, BitArray* data, BinaryFileInfo info);

#endif
