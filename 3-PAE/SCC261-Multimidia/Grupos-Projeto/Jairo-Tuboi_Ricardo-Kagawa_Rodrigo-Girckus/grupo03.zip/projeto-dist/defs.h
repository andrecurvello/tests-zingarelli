/*
SCC0261 MULTIMÍDIA - 1º SEMESTRE DE 2011
DOCENTE: RUDINEI GOULARTE

PROJETO: COMPRESSÃO DE IMAGEM DIGITAL PARTE 3


ALUNOS:
	Jairo Toshio Tuboi 		6427250
	Ricardo Takashi Kagawa		5634712
	Rodrigo Luis Gava Girckus 	5967770
*/
#ifndef CODEC_VERSION
#define CODEC_VERSION "3.0"



//-- definições comuns --

#define TRUE	1
#define FALSE	0

#define LINE_MAX 256

#define PI acos(-1.0)

//não utilizado
#define QUALITY		 25
#define MAX_QUALITY	100



#define MAX_DEBUG_ITEMS 27



//-- itens reportáveis --

//arquivos bitmap e binário
#define LOG_BMP_FILE_HEADER	0
#define LOG_BMP_INFO_HEADER	1
#define LOG_BIN_FILE_HEADER	2
#define LOG_BITMAP_DATA		3
#define LOG_BINARY_DATA		4

//representações intermediárias
#define LOG_RGB_IMAGE		5
#define LOG_IMAGE_BLOCKS	6
#define LOG_SHIFTED_BLOCKS	7
#define LOG_FD_BLOCKS		8
#define LOG_TRACED_BLOCKS	9

//representações dos valores DC
#define LOG_DC_RAW		10
#define LOG_DC_DELTA	11
#define LOG_DC_ENCODED	12
#define LOG_DC_HUFFMAN	13
#define LOG_DC_BINARY	14

//representações dos valores AC
#define LOG_AC_RAW		15
#define LOG_AC_RLE		16
#define LOG_AC_ENCODED	17
#define LOG_AC_HUFFMAN	18
#define LOG_AC_BINARY	19

//outras representações intermediárias
#define LOG_FREQUENCIES		20
#define LOG_DICTIONARY		21
#define LOG_DC_DECODER		22
#define LOG_AC_DECODER		23
#define LOG_TRANSFORMATION	24
#define LOG_QUANTIZATION	25
#define LOG_DEQUANTIZATION	26

#endif
