/*
SCC0261 MULTIMÍDIA - 1º SEMESTRE DE 2011
DOCENTE: RUDINEI GOULARTE

PROJETO: COMPRESSÃO DE IMAGEM DIGITAL PARTE 2


ALUNOS:
	Jairo Toshio Tuboi 		6427250
	Ricardo Takashi Kagawa		5634712
	Rodrigo Luis Gava Girckus 	5967770
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <math.h>

#include "util.h"



//configurações globais da aplicação
struct {
	short output_level;				//nível de exibição de mensagens
	short debug[MAX_DEBUG_ITEMS];	//estágios a exibir na depuração
	short debug_to_file;	//gera arquivos ao invés de exibir na saída padrão
	FILE* log_file;			//arquivo onde escrever os dados da depuração
} _config;

void Config_init() {
	int i;
	
	_config.output_level = OL_NORMAL;
	for(i = 0; i < MAX_DEBUG_ITEMS; i++)
		_config.debug[i] = FALSE;
	
	_config.debug_to_file = FALSE;
	_config.log_file = NULL;
	
	return;
}

void Config_free() {
	return;
}

void Config_setOutputLevel(short level) {
	_config.output_level = level;
	return;
}

short Config_getOutputLevel() {
	return _config.output_level;
}

short Config_hasOutputLevel(short level) {
	return (_config.output_level >= level);
}

void Config_setItemOutput(short index, short display) {
	_config.debug[index] = display;
	return;
}

short Config_getItemOutput(short index) {
	return _config.debug[index] && Config_hasOutputLevel(OL_DEBUG);
}

void Config_setDebugToFile(short value) {
	if(_config.log_file == NULL)
		_config.debug_to_file = value;
	return;
}



void Log_open(char filename[]) {
	Log_close();
	
	_config.log_file = _config.debug_to_file? 
			fopen(filename, "w"): stdout;
	
	if(_config.log_file == NULL)
		Error_set(0, "Arquivo de relatorio nao pode ser aberto.");
	return;
}

void Log_close() {
	if(_config.log_file == NULL)
		return;
	
	fflush(_config.log_file);
	if(_config.debug_to_file) {
		if(_config.log_file != NULL)
			fclose(_config.log_file);
	}
	_config.log_file = NULL;
	return;
}

void Log_printf(char* format, ...) {
	va_list args;
	
	if(_config.log_file == NULL)
		return;
	
	va_start(args, format);
	vfprintf(_config.log_file, format, args);
	va_end(args);
	return;
}

void Log_puts(char* str) {
	if(_config.log_file == NULL)
		return;
	
	fputs(str, _config.log_file);
	fputc('\n', _config.log_file);
	return;
}

void Log_nl() {
	if(_config.log_file == NULL)
		return;
	
	fputc('\n', _config.log_file);
	return;
}


//último erro lançado
struct {
	int code;
	char message[LINE_MAX];
} _error;

void Errors_init() {
	strcpy(_error.message, "Nenhum erro ocorrido.");
	_error.code = NO_ERROR;
	return;
}

void Errors_free() {
	return;
}

char* Error_getMessage() {
	return _error.message;
}

int Error_getCode() {
	return _error.code;
}

void Error_set(int code, char msg[]) {
	strcpy(_error.message, msg);
	_error.code = code;
	return;
}

void Error_clear() {
	strcpy(_error.message, "Nenhum erro ocorrido.");
	_error.code = NO_ERROR;
	return;
}

short Error_isSet() {
	return (_error.code != NO_ERROR);
}



char* btoa(unsigned value, unsigned size, int group) {
	unsigned bit, mask, i, p;
	char str[LINE_MAX];
	
	//gerando a string básica
	p = 0; mask = 1 << (size - 1);
	for(i = 0; i < size; i++) {
		bit = value & mask;
		str[p++] = (bit == 0)? '0': '1';
		mask >>= 1;
	}
	str[p] = '\0';
	
	if(group < 0) {
		//agrupar da direita para a esquerda
		p = 0;
		for(i = 0; i < size; i++) {
			if((i % -group == 0) && (i > 0))
				_tmpstr[p++] = ' ';
			_tmpstr[p++] = str[i];
		}
		_tmpstr[p] = str[i];
	} else if(group > 0) {
		//agrupar da esquerda para a direita
		p = 0;
		for(i = 0; i < size; i++) {
			if(((size - i) % group == 0) && (i > 0))
				_tmpstr[p++] = ' ';
			_tmpstr[p++] = str[i];
		}
		_tmpstr[p] = str[i];
	} else {
		//não agrupar
		strcpy(_tmpstr, str);
	}
	return _tmpstr;
}

char* format(char format[], ...) {
	va_list args;
	
	va_start(args, format);
	vsprintf(_tmpstr, format, args);
	va_end(args);
	
	return _tmpstr;
}

int round_half_even(double x) {
	double i, f, r;
	f = modf(x, &i);
	if(fabs(fabs(f) - 0.5) < 1.0e-14) {
		if(((int) i) % 2 == 0) 
			r = i;
		else
			r = (x > 0)? i + 1: i - 1;
	} else
		r = (x > 0)? floor(x + 0.5): ceil(x - 0.5);
	return (int) r;
}
