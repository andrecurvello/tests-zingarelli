/*
SCC0261 MULTIMÍDIA - 1º SEMESTRE DE 2011
DOCENTE: RUDINEI GOULARTE

PROJETO: COMPRESSÃO DE IMAGEM DIGITAL PARTE 2


ALUNOS:
	Jairo Toshio Tuboi 		6427250
	Ricardo Takashi Kagawa		5634712
	Rodrigo Luis Gava Girckus 	5967770
*/
#ifndef CODEC_H
#define CODEC_H

#include <stdio.h>
#include "defs.h"



#define BF_TYPE 0x4D42             /* "MB" */

typedef struct {	/**** BMP file header structure ****/
	char type[2];				/* Magic number for file */
	unsigned int	size;		/* Size of file */
	unsigned short	reserved1;	/* Reserved */
	unsigned short	reserved2;	/* ... */
	unsigned int	offBytes;	/* Offset to bitmap data */
} BITMAP_FILE_HEADER;

typedef struct {	/**** BMP file info structure ****/
	unsigned int	size;				/* Size of info header */
	int				width;				/* Width of image */
	int				height;				/* Height of image */
	unsigned short	planes;				/* Number of color planes */
	unsigned short	bitCount;			/* Number of bits per pixel */
	unsigned int	compression;		/* Type of compression to use */
	unsigned int	sizeImage;			/* Size of image data */
	int				xPixelsPerMeter;	/* X pixels per meter */
	int				yPixelsPerMeter;	/* Y pixels per meter */
	unsigned int	colorUsed;			/* Number of colors used */
	unsigned int	colorImportant;		/* Number of important colors */
} BITMAP_INFO_HEADER;



void encode(FILE* bitmap, FILE* binary);
void decode(FILE* bitmap, FILE* binary);

#endif
