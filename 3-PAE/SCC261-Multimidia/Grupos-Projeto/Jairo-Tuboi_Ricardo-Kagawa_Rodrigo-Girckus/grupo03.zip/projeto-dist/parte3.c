/*
SCC0261 MULTIM�DIA - 1� SEMESTRE DE 2011
DOCENTE: RUDINEI GOULARTE

PROJETO: COMPRESS�O DE IMAGEM DIGITAL PARTE 3


ALUNOS:
	Jairo Toshio Tuboi 		6427250
	Ricardo Takashi Kagawa		5634712
	Rodrigo Luis Gava Girckus 	5967770
*/

#include <math.h>

#include "defs.h"
#include "util.h"
#include "parte1.h"
#include "parte3.h"

/* == bloco da imagem em ponto flutuante == */

void FPBlock_log(FloatingPointBlock block, int index, int view) {
	int i, j;
	if(!Config_getItemOutput(view)) return;
	
	switch(view) {
	case LOG_TRANSFORMATION:
		Log_printf("== Bloco Transformado %d ==\n", index);
		break;
	case LOG_QUANTIZATION:
		Log_printf("== Bloco Quantizado %d ==\n", index);
		break;
	case LOG_DEQUANTIZATION:
		Log_printf("== Bloco Desquantizado %d ==\n", index);
		break;
	default: 
		return;
	}
	Log_nl();
	
	for(i = 0; i < BLOCK_SIZE; i++) {
		for(j = 0; j < BLOCK_SIZE; j++) {
			Log_printf("%+07.2f ", block.data[i][j]);
		}
		Log_nl();
	}
	Log_nl();
	return;
}

void FPBlock_copy(FloatingPointBlock *dest, FloatingPointBlock src) {
	int i, j;
	for(i = 0; i < BLOCK_SIZE; i++) {
		for(j = 0; j < BLOCK_SIZE; j++)
			dest->data[i][j] = src.data[i][j];
	}
}

FloatingPointBlock FPBlock_copyFromBlock(ImageBlocks blocks, int index) {
	int i, j; FloatingPointBlock block;
	for(i = 0; i < BLOCK_SIZE; i++) {
		for(j = 0; j < BLOCK_SIZE; j++)
			block.data[i][j] = blocks.data[index][i][j];
	}
	return block;
}

void FPBlock_copyToBlock(FloatingPointBlock block, ImageBlocks blocks, int index) {
	int i, j; double value;
	for(i = 0; i < BLOCK_SIZE; i++) {
		for(j = 0; j < BLOCK_SIZE; j++) {
			//valor transformado pode estar fora de escala
			value = block.data[i][j];
			if(value > 127) value = 127;
			if(value < -128) value = -128;
			
			//round-half-even distribui melhor os 
			//arredondamentos, estatisticamente
			blocks.data[index][i][j] = 
				round_half_even(value);
		}
	}
	return;
}

void FPBlock_applyDCT2(FloatingPointBlock *block) {
	int i, j; FloatingPointBlock b;
	FPBlock_copy(&b, *block);
	for(i = 0; i < BLOCK_SIZE; i++) {
		for(j = 0; j < BLOCK_SIZE; j++) {
			block->data[i][j] = 
				FPBlock_getDCT2Coefficient(j, i, b);
		}
	}
	return;
}

void FPBlock_applyDCT3(FloatingPointBlock *block) {
	int i, j; FloatingPointBlock b;
	FPBlock_copy(&b, *block);
	for(i = 0; i < BLOCK_SIZE; i++) {
		for(j = 0; j < BLOCK_SIZE; j++) {
			block->data[i][j] = 
				FPBlock_getDCT3Coefficient(j, i, b);
		}
	}
	return;
}

void FPBlock_quantize(FloatingPointBlock *block) {
	int q[BLOCK_SIZE][BLOCK_SIZE] = QUANTIZATION_TABLE;
	int i, j;
	
	for(i = 0; i < BLOCK_SIZE; i++) {
		for(j = 0; j < BLOCK_SIZE; j++)
			block->data[i][j] = (block->data[i][j] / q[i][j]);
	}
	return;
}

void FPBlock_dequantize(FloatingPointBlock *block) {
	int q[BLOCK_SIZE][BLOCK_SIZE] = QUANTIZATION_TABLE;
	int i, j;
	
	for(i = 0; i < BLOCK_SIZE; i++) {
		for(j = 0; j < BLOCK_SIZE; j++) {
			block->data[i][j] = (block->data[i][j] * q[i][j]);
		}
	}
	return;
}



/* == extens�es de ImageBlocks == */

void ImageBlocks_toFrequencyDomain(ImageBlocks blocks) {
	int i; FloatingPointBlock b;
	for(i = 0; i < blocks.size; i++) {
		b = FPBlock_copyFromBlock(blocks, i);
		FPBlock_applyDCT2(&b);
		FPBlock_log(b, i, LOG_TRANSFORMATION);
		FPBlock_quantize(&b);
		FPBlock_log(b, i, LOG_QUANTIZATION);
		FPBlock_copyToBlock(b, blocks, i);
	}
	return;
}

void ImageBlocks_fromFrequencyDomain(ImageBlocks blocks) {
	int i; FloatingPointBlock b;
	for(i = 0; i < blocks.size; i++) {
		b = FPBlock_copyFromBlock(blocks, i);
		FPBlock_dequantize(&b);
		FPBlock_log(b, i, LOG_DEQUANTIZATION);
		FPBlock_applyDCT3(&b);
		FPBlock_log(b, i, LOG_TRANSFORMATION);
		FPBlock_copyToBlock(b, blocks, i);
	}
	return;
}



/* == fun��es auxiliares da DCT == */

double DCTMultipliers_DCT2BuildValue(int u, int v, int x, int y) {
	double au, av, cx, cy;
	au = (u == 0)? 1.0 / sqrt(8): 0.5; //ortogonaliza��o
	av = (v == 0)? 1.0 / sqrt(8): 0.5; //ortogonaliza��o
	cx = cos((x + 0.5) * u * PI / 8);
	cy = cos((y + 0.5) * v * PI / 8);
	return au * av * cx * cy;
}

FloatingPointBlock DCTMultipliers_DCT2BuildMatrix(int u, int v) {
	int x, y;
	FloatingPointBlock b;
	for(y = 0; y < BLOCK_SIZE; y++) {
		for(x = 0; x < BLOCK_SIZE; x++)
			b.data[y][x] = DCTMultipliers_DCT2BuildValue(u, v, x, y);
	}
	return b;
}

FloatingPointBlock DCTMultipliers_DCT2Get(int u, int v) {
	int i, j;
	static int computed = FALSE;
	static DCTMultipliers r;
	if(computed) return r.data[v][u];
	
	//computando as matrizes de multiplicadores
	for(i = 0; i < BLOCK_SIZE; i++) {
		for(j = 0; j < BLOCK_SIZE; j++)
			r.data[i][j] = DCTMultipliers_DCT2BuildMatrix(j, i);
	}
	computed = TRUE; //n�o computar novamente
	return r.data[v][u];
}

FloatingPointBlock DCTMultipliers_DCT3Get(int x, int y) {
	int i, j, u, v; DCTMultipliers t;
	static int computed = FALSE;
	static DCTMultipliers r;
	if(computed) return r.data[y][x];
	
	//computando as matrizes de multiplicadores
	for(i = 0; i < BLOCK_SIZE; i++) {
		for(j = 0; j < BLOCK_SIZE; j++)
			t.data[i][j] = DCTMultipliers_DCT2BuildMatrix(j, i);
	}
	
	//como a transforma��o foi normalizada,
	//a transforma��o transposta � sua inversa
	//(a transforma��o � ortogonal)
	
	//transpondo os multiplicadores
	for(i = 0; i < BLOCK_SIZE; i++) {
		for(j = 0; j < BLOCK_SIZE; j++) {
			for(v = 0; v < BLOCK_SIZE; v++) {
				for(u = 0; u < BLOCK_SIZE; u++) {
					r.data[i][j].data[v][u] = t.data[v][u].data[i][j];
				}
			}
		}
	}
	computed = TRUE; //n�o computar novamente
	return r.data[y][x];
}

double FPBlock_getDCT2Coefficient(int u, int v, FloatingPointBlock g) {
	FloatingPointBlock m = DCTMultipliers_DCT2Get(u, v);
	double r = 0; int x, y;
	for(y = 0; y < BLOCK_SIZE; y++) {
		for(x = 0; x < BLOCK_SIZE; x++)
			r += m.data[y][x] * g.data[y][x];
	}
	return r;
}

double FPBlock_getDCT3Coefficient(int x, int y, FloatingPointBlock g) {
	FloatingPointBlock m = DCTMultipliers_DCT3Get(x, y);
	double r = 0; int u, v;
	for(v = 0; v < BLOCK_SIZE; v++) {
		for(u = 0; u < BLOCK_SIZE; u++)
			r += m.data[v][u] * g.data[v][u];
	}
	return r;
}
