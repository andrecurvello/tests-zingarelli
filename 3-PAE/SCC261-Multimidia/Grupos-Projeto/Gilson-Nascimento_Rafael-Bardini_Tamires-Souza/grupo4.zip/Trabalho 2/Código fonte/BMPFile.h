#ifndef _BMPFILE_H_
#define _BMPFILE_H_

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

// Estrutura do Macrobloco, matriz 8x8 de inteiros
typedef struct mBlock {
	char r[8][8];
	char g[8][8];
	char b[8][8];
} MBlock;

typedef MBlock HCode;

typedef struct { /**** BMP file header structure ****/
	unsigned char bfType[2];
	unsigned int bfSize;
	unsigned short bfReserved1; /* Reserved */
	unsigned short bfReserved2; /* ... */
	unsigned int bfOffBits; /* Offset to bitmap data */
} BMPFILEHEADER;

typedef struct { /**** BMP file info structure ****/
	unsigned int biSize; /* Size of info header */
	int biWidth; /* Width of image */
	int biHeight; /* Height of image */
	unsigned short biPlanes; /* Number of color planes */
	unsigned short biBitCount; /* Number of bits per pixel */
	unsigned int biCompression; /* Type of compression to use */
	unsigned int biSizeImage; /* Size of image data */
	int biXPelsPerMeter; /* X pixels per meter */
	int biYPelsPerMeter; /* Y pixels per meter */
	unsigned int biClrUsed; /* Number of colors used */
	unsigned int biClrImportant; /* Number of important colors */
} BMPINFOHEADER;

typedef struct triple {
	char skip;
	char sss;
	char value;
	struct triple *next;
} Triple;

typedef struct pair {
	char sss;
	char value;
	int diff;
} Pair;

typedef struct tree {
	int freq;
	int sss;
	int skip;
	struct tree *esq;
	struct tree *dir;
} Tree;

MBlock *alocaMB(int size);
HCode *alocaHC(int size);
unsigned char tobinary(char x, char *h);
unsigned char tobinary2(int x, char *h);
char tonumber(unsigned char x, unsigned char h);
void printFile(BMPFILEHEADER *fh, BMPINFOHEADER *ih, MBlock *blocks, int nBlocks, char *name);
int readHeaders(BMPFILEHEADER *fh, BMPINFOHEADER *ih, FILE *fp);
unsigned char readnum(unsigned char h, unsigned char *buf, unsigned char *mbuff, unsigned char *mvall, FILE *in);
void decode(Pair *DCs, Triple **ACs, char *MVector, MBlock *mblocks, int n);
void readfiles(BMPFILEHEADER *fh, BMPINFOHEADER *ih, Pair *huffcodesD, Pair **huffcodesA, Pair *DCs, Triple **ACs, int *n);
void writenum(unsigned char x, unsigned char h, unsigned char *buf, unsigned char *mbuff, unsigned char *mvall, FILE *out);
void writenum2(unsigned int x, unsigned char h, unsigned char *buf, unsigned char *mbuff, unsigned int *mvall, FILE *out);
void writefiles(BMPFILEHEADER *fh, BMPINFOHEADER *ih, Pair *huffcodesD, Pair **huffcodesA, Pair *DCs, Triple **ACs, int n);
void Diff(Pair *V, int size);
void Vetoriza(char M[8][8], char MVector[], int ind);
void matrifica(char MVector[],char M[8][8],int ind);
void Insere(Triple **ACs, int pos, char skip, char sss, char value);
void SplitMVector(char *MVector, Pair *DCs, Triple **ACs, int n);
void CalculateSSS(Triple **ACs, int n);
void HuffD(Pair *DCs,Pair *huffcodes,int n);
void HuffA(Triple **ACs,Pair **huffcodes,int n);
void traverseD(Tree *node, Pair *huffcodes, unsigned char *str, int n);
void traverseA(Tree *node, Pair **huffcodes, int *str, int n);
int percorreD(Tree *node, unsigned char *buf, unsigned char *mbuff, FILE *in);
void percorreA(Tree *node, unsigned char *buf, unsigned char *mbuff, FILE *in, char *skip, char *sss);

#endif
