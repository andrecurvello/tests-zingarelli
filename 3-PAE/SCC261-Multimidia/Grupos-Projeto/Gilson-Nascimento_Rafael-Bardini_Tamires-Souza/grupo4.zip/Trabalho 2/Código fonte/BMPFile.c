#include "BMPFile.h"


// Aloca um vetor de Macroblocos, com tamanho <size>
MBlock *alocaMB(int size) {
	MBlock *blocks;
	blocks = (MBlock *)malloc(sizeof(MBlock) * size);
	return blocks;
}

// Aloca um vetor de HCodes, com tamanho <size>
HCode *alocaHC(int size) {
	HCode *codes;
	codes = (HCode *)malloc(sizeof(HCode) * size);
	return codes;
}

// Calcula o numero de bits necessarios para se representar o valor fornecido e 
// armazena em h. Al�m disso, retorna um unsigned char com o pr�prio valor no
// caso desse ser positivo ou com o complemento de um, no caso de ser negativo
unsigned char tobinary(char x, char *h) {
	unsigned char ret;
	// Calcula a quantidade de bits para se representar o valor
	if (x != 0) *h = log2(abs(x)) + 1;
	else *h = 0;
	ret = abs(x);
	// No caso de numeros negativos faz o complemento de um
	if (x < 0) {
		ret = ~ret;
		ret = ret << (8-*h);
		ret = ret >> (8-*h);
	}
	return ret;
}

// Funcao semelhante a tobinary, ou seja, que calcula o numero de bits necessarios
// para representar o valor e retorna o proprio valor ou o complemento de um.
// Porem recebe um numero inteiro e nao um char como na tobinary.
unsigned char tobinary2(int x, char *h) {
	unsigned char ret;
	ret = (unsigned char)abs(x);
	// Calcula a quantidade de bits para representar o valor
	if (x != 0) *h = log2(abs(x)) + 1;
	else *h = 0;
	// No caso de numeros negativos, faz o complemento de um
	if (x < 0) {
		ret = ~ret;
		ret = ret << (8-*h);
		ret = ret >> (8-*h);
	}
	return ret;
}

// Faz a operacao inversa da funcao tobinary, ou seja, caso o valor seja positivo
// retorna ele mesmo e caso seja negativo, faz o complemento de um e recupera o valor
char tonumber(unsigned char x, unsigned char h) {
	if (h == 0) return 0;
	// Obtem uma mascara com valor correspondente ao bit mais significativo do numero
	unsigned char mask = pow(2,h-1);
	char ret = x;
	// Isola o bit mais significativo do valor
	unsigned char m = ret & mask;
	unsigned char y;
	// Caso o bit mais significativo seja 0, significa que o valor era originalmente
	// negativo
	if (m == 0) {
		// Faz o complemento de um e recupera o valor negativo
		ret = ~ret;
		ret = ret << (8-h);
		ret = ret >> (8-h);
		ret = pow(2,h) + ret;
		ret = -ret;
	}
	return ret;
}

// Faz a operacao inversa da tobinary2, ou seja, recupera valores negativos que
// estavam representados em complemento de um. Semelhante a funcao tonumber, porem
// retorna um numero inteiro
int tonumber2(int x, unsigned char h) {
	unsigned char mask;
	int ret = x;
	// Obtem uma mascara com valor correspondente ao bit mais significativo do numero
	if (h != 0) mask = pow(2,h-1);
	else return 0;
	// Isola o bit mais significativo do numero
	int m = ret & mask;
	unsigned char y;
	// Se o bit mais significativo for 0, significa que o numero era negativo
	if (m == 0) {
		// Faz o complemento de um e recupera o valor negativo
		ret = ~ret;
		ret = ret << (32-h);
		ret = ret >> (32-h);
		ret = pow(2,h) + ret;
		ret = -ret;
	}
	return ret;
}

// Funcao que escreve um arquivo .bmp, visando obter a imagem decodificada
void printFile(BMPFILEHEADER *fh, BMPINFOHEADER *ih, MBlock *blocks, int nBlocks, char *name) {
     int i,j,k,l;
	 int bytes = (*ih).biBitCount/8;
     char *nome = (char *)malloc(sizeof(char)*strlen(name) + 4);
	 // Buffer para auxiliar a escrita dos valores no arquivo
	 unsigned char buf[4];
     nome[0] = '\0';
     strncat(nome,name,strlen(name)-4);
     strcat(nome,"_out.bmp");
     // Abre o arquivo .bmp para escrita
     FILE *out = fopen(nome,"wb+");
     // Escreve o header de arquivo
     fwrite(&((*fh).bfType),2,1,out);
     fwrite(&((*fh).bfSize),4,1,out);
     fwrite(&((*fh).bfReserved1),2,1,out);
     fwrite(&((*fh).bfReserved1),2,1,out);
     fwrite(&((*fh).bfOffBits),4,1,out);
     // Escreve o header de informacao
     fwrite(ih,sizeof(BMPINFOHEADER),1,out);
     // Para todos os macroblocos
	 for (l=0;l<(ih->biHeight/8);l++)
		for (j=7;j>=0;j--) {
			for (i=(ih->biWidth/8)-1;i>=0;i--) {
				for (k=0;k<8;k++) {
					// Soma 128 aos valores b, g e r armazenados no macrobloco,
					// de forma a obter os valores originais da imagem e os 
					// atribui ao buffer
					buf[0] = blocks[i+l*(ih->biWidth/8)].b[j][k] + 128;
					buf[1] = blocks[i+l*(ih->biWidth/8)].g[j][k] + 128;
					buf[2] = blocks[i+l*(ih->biWidth/8)].r[j][k] + 128;
					// Grava o buffer no arquivo .bmp
					fwrite(&buf,sizeof(unsigned char),bytes,out);
					memset(&buf,0,4);
				}
			}
		}
	// Fecha o arquivo	
	fclose(out);
	printf(" - Arquivo de saida decodificado \"%s\" escrito\n",nome);
}

// Le os headers da imagem e verifica se ela atende as especificacoes
int readHeaders(BMPFILEHEADER *fh, BMPINFOHEADER *ih, FILE *fp) {
	// Le o header de arquivo
	fread(&((*fh).bfType),2,1,fp);
	fread(&((*fh).bfSize),4,1,fp);
	fread(&((*fh).bfReserved1),2,1,fp);
	fread(&((*fh).bfReserved2),2,1,fp);
	fread(&((*fh).bfOffBits),4,1,fp);
	// Le o header de informacao
	fread(ih,sizeof(BMPINFOHEADER),1,fp);
	// Verifica se a imagem eh de fato BMP
	if ((*fh).bfType[0] != 'B' || (*fh).bfType[1] != 'M') return -1;
	// Verifica se a imagem possui 24 bits para cor
	if ((*ih).biBitCount != 24) return -2;
	// Verifica se a imagem nao tem compressao
	if ((*ih).biCompression != 0) return -3;
	// Verifica se a altura e a largura sao multiplos de 8 e se as dimensoes estao entre 8x8 e 1280x800 pixels 
	if ((*ih).biWidth % 8 != 0 || (*ih).biHeight % 8 != 0 || (*ih).biWidth < 8 || (*ih).biWidth > 1280 || (*ih).biHeight < 8 || (*ih).biHeight > 800) return -4;
	return 1;
}

// Le um numero do buffer buf, caso ele esteja parcialmente no buffer e a outra parte no arquivo, recarrega o buffer
// com mais 8 bits e continua ate ler todos os bits correspondentes a esse numero
unsigned char readnum(unsigned char h, unsigned char *buf, unsigned char *mbuff, unsigned char *mvall, FILE *in) {
int l;
unsigned char m,n,ret = 0;
// Buffers auxiliares para armazenar os valores originais de mbuff e mvall
unsigned char mbuf = *mbuff;
unsigned char mval = *mvall;
	for (l=0;l<h;l++) { // Enquanto nao terminou de ler os h bits do numero
		// Se foi lido todo o buffer (mbuf == 0), carrega outro conjunto de bits do arquivo e coloca-os no buffer
		if (mbuf == 0) {
			fread(buf,sizeof(unsigned char),1,in);
			mbuf = 128; // Atualiza mascara do buffer
		}
		m = *buf & mbuf; // Copia bit da posicao indicada por mbuff na variavel temporaria m
		// Desloca bit que foi copiado para m ate a posicao onde ele devera ser inserido no numero de retorno
		if (mbuf > mval) {
			n = log2(mbuf) - log2(mval);
			m = m >> n;
		}
		else {
			n = log2(mval) - log2(mbuf);
			m = m << n;
		}
		ret = ret | m; // Coloca bit na posicao correta
		// Atualiza mascaras
		mbuf = mbuf >> 1;
		mval = mval >> 1;
	}
	// Coloca de volta os novos valores das mascaras para que as alteracoes reflitam onde houve a chamada desta funcao
	*mbuff = mbuf;
	*mvall = mval;
	return ret; // retorna numero lido
}

// Monta a arvore para os codigos de Huffman dos sss dos DCs. Dado um codigo de 
// Huffman e o valor de sss correspondente a ele, percorre a arvore e insere o sss
// no n� folha adequado
void montaArvD(Tree *treeD, char mask, char huff, char val) {
	char aux;
	// Mask inicialmente contem o valor correspondente ao bit mais significativo do
	// codigo de Huffman, por isso quando eh 0 significa que terminou-se de percorrer
	// todo o codigo e o valor de sss correspondente a ele pode ser inserido em um 
	// no folha
	if (mask == 0) {
		treeD->sss = val;
	// Se ainda ha bits no codigo de Huffman	
	} else {
		// Isola o bit atual
		aux = huff & mask;
		// Faz um shift na mascara de forma que ela fique na posicao correspondente
		// ao bit seguinte
		mask = mask >> 1;
		// Se o bit atual do codigo de Huffman eh 0, ira andar na arvore pela esquerda
		if (aux == 0) {
			// Se a arvore nao tem filhos a esquerda, cria um
			if (treeD->esq == NULL) {
				treeD->esq = (Tree *)malloc(sizeof(Tree));
				treeD->esq->esq = NULL;
				treeD->esq->dir = NULL;
				treeD->esq->sss = -1;
			}
			// Chama a funcao recursivamente a partir do filho a esquerda
			montaArvD(treeD->esq,mask,huff,val);
		// No caso do bit do codigo de Huffman ser 1, ira andar na arvore pela direita	
		} else {
			// Se a arvore nao tem filhos a direita, cria um
			if (treeD->dir == NULL) {
				treeD->dir = (Tree *)malloc(sizeof(Tree));
				treeD->dir->esq = NULL;
				treeD->dir->dir = NULL;
				treeD->dir->sss = -1;
			}
			// Chama a funcao recursivamente a partir do filho a direita
			montaArvD(treeD->dir,mask,huff,val);
		}
	}
}

// Monta a arvore para os codigos de Huffman dos (skip, sss) dos ACs. Dado um codigo
// de Huffman e o valor de (skip, sss) correspondente a ele, percorre a arvore e 
// insere o (skip, sss) no n� folha adequado
void montaArvA(Tree *treeA, int mask, int huff, char skip, char sss) {
	int aux;
	// Mask inicialmente contem o valor correspondente ao bit mais significativo do
	// codigo de Huffman, por isso quando eh 0 significa que terminou-se de percorrer
	// todo o codigo e o valor de (skip, sss) correspondente a ele pode ser inserido
	// em um no folha
	if (mask == 0) {
		treeA->skip = skip;
		treeA->sss = sss;
	// Se ainda ha bits no codigo de Huffman	
	} else {
		// Isola o bit atual
		aux = huff & mask;
		// Faz um shift na mascara de forma que ela fique na posicao correspondente
		// ao bit seguinte
		mask = mask >> 1;
		// Se o bit atual do codigo de Huffman eh 0, ira andar na arvore pela esquerda
		if (aux == 0) {
			// Se a arvore nao tem filhos a esquerda, cria um
			if (treeA->esq == NULL) {
				treeA->esq = (Tree *)malloc(sizeof(Tree));
				treeA->esq->esq = NULL;
				treeA->esq->dir = NULL;
				treeA->esq->sss = -1;
			}
			// Chama a funcao recursivamente a partir do filho a esquerda
			montaArvA(treeA->esq,mask,huff,skip,sss);
		// No caso do bit do codigo de Huffman ser 1, ira andar na arvore pela direita	
		} else {
			// Se a arvore nao tem filhos a direita, cria um
			if (treeA->dir == NULL) {
				treeA->dir = (Tree *)malloc(sizeof(Tree));
				treeA->dir->esq = NULL;
				treeA->dir->dir = NULL;
				treeA->dir->sss = -1;
			}
			// Chama a funcao recursivamente a partir do filho a direita
			montaArvA(treeA->dir,mask,huff,skip,sss);
		}
	}
}

// Desfaz a codificacao por diferenca dos DCs e a por carreira dos ACs, colocando
// os valores em um vetor e, em seguida, recuperando o macrobloco
void decode(Pair *DCs, Triple **ACs, char *MVector, MBlock *mblocks, int n) {
	int i,y,k,j;
	Triple *temp;
	// Primeiros valores de DCs sao desconvertidos, caso estivessem representados
	// com complemento de um
	DCs[0].value = (char)tonumber2(DCs[0].diff,DCs[0].sss);
	DCs[1].value = (char)tonumber2(DCs[1].diff,DCs[1].sss);
	DCs[2].value = (char)tonumber2(DCs[2].diff,DCs[2].sss);
	// A codificacao por diferenca eh desfeita de modo a se recuperar os valores
	// dos DCs
	for (i=3;i<3*n;i+=3) {
		DCs[i].value = (char)(DCs[i-3].value + tonumber2(DCs[i].diff,DCs[i].sss));
	}
	for (i=4;i<3*n;i+=3) {
		DCs[i].value = (char)(DCs[i-3].value + tonumber2(DCs[i].diff,DCs[i].sss));
	}
	for (i=5;i<3*n;i+=3) {
		DCs[i].value = (char)(DCs[i-3].value + tonumber2(DCs[i].diff,DCs[i].sss));
	}
    printf(" - Codificacao por diferenca dos coeficientes DC desfeita\n");
	int count;
	// A codificacao por carreira dos ACs eh desfeita
	for (i=0;i<n;i++) {
		count = 1;
		y = 3*i;
		temp = ACs[y];
		// O DC da componente B eh colocado no vetor
		MVector[0] = DCs[y].value;
		// Os ACs da componente B sao recuperados
		while (count < 64 && !(temp->skip == 0 && temp->sss == 0)) {
			// Acrescenta no vetor a quantidade de zeros indicada no skip
			for (k=0;k<temp->skip;k++) {
				MVector[count] = 0;
				count++;
			}
			// Acrescenta o valor no vetor
			MVector[count] = temp->value;
			count++;
			temp = temp->next;
		}
		// Caso o vetor ainda nao possua os 63 ACs da componente B significa que
		// o par (skip, sss) = (0, 0) foi encontrado, indicando que as posicoes 
		// restantes devem ser preenchidas com 0
		while (count < 64) {
			MVector[count] = 0;
			count++;
		}
		count = 65;
		temp = ACs[y+1];
		// O DC da componente G eh colocado no vetor
		MVector[64] = DCs[y+1].value;
		// Os ACs da componente G sao recuperados
		while (count < 128 && !(temp->skip == 0 && temp->sss == 0)) {
			// Acrescenta no vetor a quantidade de zeros indicada no skip
			for (k=0;k<temp->skip;k++) {
				MVector[count] = 0;
				count++;
			}
			// Acrescenta o valor no vetor
			MVector[count] = temp->value;
			count++;
			temp = temp->next;
		}
		// Caso o vetor ainda nao possua os 63 ACs da componente G significa que
		// o par (skip, sss) = (0, 0) foi encontrado, indicando que as posicoes 
		// restantes devem ser preenchidas com 0
		while (count < 128) {
			MVector[count] = 0;
			count++;
		}
		count = 129;
		temp = ACs[y+2];
		// O DC da componente R eh colocado no vetor
		MVector[128] = DCs[y+2].value;
		// Os ACs da componente R sao recuperados
		while (count < 192 && !(temp->skip == 0 && temp->sss == 0)) {
			// Acrescenta no vetor a quantidade de zeros indicada no skip
			for (k=0;k<temp->skip;k++) {
				MVector[count] = 0;
				count++;
			}
			// Acrescenta o valor no vetor
			MVector[count] = temp->value;
			count++;
			temp = temp->next;
		}
		// Caso o vetor ainda nao possua os 63 ACs da componente R significa que
		// o par (skip, sss) = (0, 0) foi encontrado, indicando que as posicoes 
		// restantes devem ser preenchidas com 0
		while (count < 192) {
			MVector[count] = 0;
			count++;
		}
		// Faz a operacao inversa da vetorizacao, ou seja, coloca no macrobloco
		// os valores que estao no vetor
		matrifica(MVector,mblocks[i].b,0);
		matrifica(MVector,mblocks[i].g,64);
		matrifica(MVector,mblocks[i].r,128);
	}
    printf(" - Codificacao por carreira dos coeficientes AC desfeita\n");
    printf(" - Macroblocos remontados\n");
}

// Faz a leitura do arquivo codificado: le os headers da imagem BMP, os codigos de Huffman dos sss dos DCs e dos pares
// (skip, sss) dos ACs, montando as respectivas arvores e tambem le os valores dos DCs (codificados por diferenca) e 
// dos ACs (codificados por carreira), se utilizando das arvores montadas para obter as informacoes necessarias
void readfiles(BMPFILEHEADER *fh, BMPINFOHEADER *ih, Pair *huffcodesD, Pair **huffcodesA, Pair *DCs, Triple **ACs, int *n) {
	// Abre o arquivo codificado para leitura em binario
	FILE *in = fopen("out.dat","rb");
	int i,j,k;
	unsigned char h,x=0;
	char buf, buf2,buf3;
	int buf4;
	char mask;
	unsigned char mbuf = 128;
	unsigned char mval = 128;
	// Le os headers da imagem BMP salvos no arquivo
	readHeaders(fh,ih,in);
	printf(" - Cabecalhos do arquivo temporario \"out.dat\" lidos\n");
	// Calcula a quantidade de macroblocos
	*n = (ih->biWidth*ih->biHeight)/64;
	// Le os codigos de Huffman para os sss dos DCs
	fread(&buf,sizeof(char),1,in);
	while (buf != -1) {
		fread(&buf2,sizeof(char),1,in);
		fread(&buf3,sizeof(char),1,in);
		huffcodesD[buf].sss = buf2;
		huffcodesD[buf].diff = (int)buf3;
		fread(&buf,sizeof(char),1,in);
	}
	// Aloca o primeiro no da arvore dos codigos de Huffman dos sss dos DCs que 
	// sera montada
	Tree *treeD = (Tree *)malloc(sizeof(Tree));
	treeD->esq = NULL;
	treeD->dir = NULL;
	treeD->sss = -1;
	// Monta a arvore dos codigos de Huffman dos sss dos DCs
	for (i=0;i<9;i++)
		if (huffcodesD[i].sss != -1) {
			mask = pow(2,huffcodesD[i].sss - 1);
			montaArvD(treeD,mask,huffcodesD[i].diff,i);
		}
	printf(" - Codigos de Huffman dos coeficientes DC lidos\n");
	// Le os codigos de Huffman dos pares (skip, sss) dos ACs	
	fread(&buf,sizeof(char),1,in);
	while (buf != -1) {
		fread(&buf2,sizeof(char),1,in);
		fread(&buf3,sizeof(char),1,in);
		fread(&buf4,sizeof(int),1,in);
		huffcodesA[buf][buf2].sss = buf3;
		huffcodesA[buf][buf2].diff = buf4;
		fread(&buf,sizeof(char),1,in);
	}
	printf(" - Codigos de Huffman dos coeficientes AC lidos\n");
	// Le os DCs
	fread(&buf,sizeof(char),1,in);
	char huff;
	for (i=0;i<3*(*n);i++) {
		// Percorre a arvore dos codigos de Huffman dos sss dos DCs, a fim de
		// obter o sss correspondente ao codigo de Huffman lido
		huff = percorreD(treeD, &buf, &mbuf, in);
		if (huff == 0) {
			DCs[i].sss = DCs[i].diff = 0;
		// Faz a leitura do DC com base no sss obtido ao se percorrer a arvore	
		} else {
			DCs[i].sss = huff;
			DCs[i].diff = readnum(huff, &buf, &mbuf, &mval, in);
			DCs[i].diff = DCs[i].diff >> (8-DCs[i].sss);
			mval = 128;
		}
	}
	printf(" - Coeficientes DC lidos\n");
	int mask2;
	// Aloca o primeiro no da arvore dos codigos de Huffman dos pares (skip, sss)
	// dos ACs que sera montada
	Tree *treeA = (Tree *)malloc(sizeof(Tree));
	treeA->esq = NULL;
	treeA->dir = NULL;
	treeA->sss = -1;
	// Monta a arvore dos codigos de Huffman dos pares (skip, sss) dos ACs
	for (i=0;i<62;i++)
		for (j=0;j<9;j++)
			if (huffcodesA[i][j].sss != -1) {
				mask2 = pow(2,huffcodesA[i][j].sss - 1);
				montaArvA(treeA,mask2,huffcodesA[i][j].diff,(char)i,(char)j);
			}
	char skip,sss,value;
	int count;
	// Le os ACs
	for (i=0;i<3*(*n);i++) {
		count = 0;
		do {
			// Percorre a arvore dos codigos de Huffman dos pares (skip, sss) dos
			// ACs a fim de obter os valores de skip e sss correspondentes ao
			// codigo de Huffman lido
			percorreA(treeA,&buf,&mbuf,in,&skip,&sss);
			mval = 128;
			// Le o valor de AC com base no sss obtido ao se percorrer a arvore
			value = (readnum(sss,&buf,&mbuf,&mval,in)) >> (8 - sss);
			value = tonumber((unsigned char)value,(unsigned char)sss);
			// Insere o AC lido na lista encadeada 
			Insere(ACs,i,skip,sss,value);
			count += skip;
			count++;
		} while ((count < 63) && !(skip == 0 && sss == 0));
	}
	printf(" - Coeficientes AC lidos\n");
}

// Escreve um numero do buffer buf, caso ele esteja ultrapasse a capacidade do buffer, grava buffer no arquivo e zera-o para que
// possa ser preenchido novamente com o que faltar do numero (ou outro numero) que precisa ser escrito
void writenum(unsigned char x, unsigned char h, unsigned char *buf, unsigned char *mbuff, unsigned char *mvall, FILE *out) {
int l;
unsigned char m,n;
// Buffers auxiliares para armazenar os valores originais de mbuff e mvall
unsigned char mbuf = *mbuff;
unsigned char mval = *mvall;
	for (l=0;l<h;l++) { // Enquanto nao terminou de escrever os h bits do numero
		// Se foi preenchido todo o buffer (mbuf == 0), grava buffer no arquivo e prepara-o para receber mais bits
		if (mbuf == 0) {
			fwrite(buf,sizeof(unsigned char),1,out);
			mbuf = 128; // Atualiza mascara do buffer
			*buf = 0; // Zera buffer
		}
		m = x & mval; // Copia bit da posicao indicada por mval na variavel temporaria m
		// Desloca bit que foi copiado para m ate a posicao onde ele devera ser inserido buffer
		if (mbuf > mval) {
			n = log2(mbuf) - log2(mval);
			m = m << n;
		} else {
			n = log2(mval) - log2(mbuf);
			m = m >> n;
		}
		*buf = *buf | m; // Coloca bit na posicao correta
		// Atualiza mascaras
		mbuf = mbuf >> 1;
		mval = mval >> 1;
	}
	// Coloca de volta os novos valores das mascaras para que as alteracoes reflitam onde houve a chamada desta funcao
	*mbuff = mbuf;
	*mvall = mval;
}

// Escreve um numero do buffer buf, caso ele esteja ultrapasse a capacidade do buffer, grava buffer no arquivo e zera-o para que
// possa ser preenchido novamente com o que faltar do numero (ou outro numero) que precisa ser escrito
void writenum2(unsigned int x, unsigned char h, unsigned char *buf, unsigned char *mbuff, unsigned int *mvall, FILE *out) {
int l;
unsigned char n;
unsigned int m;
// Buffers auxiliares para armazenar os valores originais de mbuff e mvall
unsigned char mbuf = *mbuff;
unsigned int mval = *mvall;
	for (l=0;l<h;l++) { // Enquanto nao terminou de escrever os h bits do numero
		// Se foi preenchido todo o buffer (mbuf == 0), grava buffer no arquivo e prepara-o para receber mais bits
		if (mbuf == 0) {
			fwrite(buf,sizeof(unsigned char),1,out);
			mbuf = 128; // Atualiza mascara do buffer
			*buf = 0; // Zera buffer
		}
		m = x & mval; // Copia bit da posicao indicada por mval na variavel temporaria m
		// Desloca bit que foi copiado para m ate a posicao onde ele devera ser inserido buffer
		if (mbuf > mval) {
			n = log2(mbuf) - log2(mval);
			m = m << n;
		} else {
			n = log2(mval) - log2(mbuf);
			m = m >> n;
		}
		*buf = *buf | m; // Coloca bit na posicao correta
		// Atualiza mascaras
		mbuf = mbuf >> 1;
		mval = mval >> 1;
	}
	// Coloca de volta os novos valores das mascaras para que as alteracoes reflitam onde houve a chamada desta funcao
	*mbuff = mbuf;
	*mvall = mval;
}

// Escreve o arquivo out.dat, contendo os headers, as arvores de huffman e os bits da imagem
void writefiles(BMPFILEHEADER *fh, BMPINFOHEADER *ih, Pair *huffcodesD, Pair **huffcodesA, Pair *DCs, Triple **ACs, int n) {
	FILE *out = fopen("out.dat","wb+"); // Arquivo out.dat (padrao)
	int i,j,k,h;
	unsigned char x,buf = 0; // Buffer de escrita buf
	char num; // Numero a ser escrito, apos o shift que colocara o valor a ser representado nos bits mais significativos
	unsigned int num2, mval2;
	char index; // Variavel que servira durante a escrita da arvore de huffman, alem de insercao de "-1" como separadores
	unsigned char mbuf = 128, mval; // Mascaras do buffer e do numero a ser escrito, respectivamente

	// Escreve os headers BMP
    fwrite(&((*fh).bfType),2,1,out);
    fwrite(&((*fh).bfSize),4,1,out);
    fwrite(&((*fh).bfReserved1),2,1,out);
    fwrite(&((*fh).bfReserved1),2,1,out);
    fwrite(&((*fh).bfOffBits),4,1,out);
    fwrite(ih,sizeof(BMPINFOHEADER),1,out);
	// Escreve os codigos de huffman dos SSS dos DCS (somente os valores que possuirem valor valido, ou seja, diferente de -1)
	for (i=0;i<9;i++)
		if (huffcodesD[i].sss != -1) {
			index = (char)i;
			fwrite(&index,sizeof(char),1,out);
			fwrite(&(huffcodesD[i].sss),sizeof(char),1,out);
			fwrite(&(huffcodesD[i].diff),sizeof(char),1,out);
		}
	// Insere um separador para indicar fim dos codigos que compoem os DCs e inicio dos ACs
	index = -1;
	fwrite(&index,sizeof(char),1,out);
	// Escreve os codigos de huffman dos SSS+diferencas dos ACS (somente os valores que possuirem valor valido, ou seja, diferente de -1)
	for (i=0;i<62;i++)
		for (j=0;j<9;j++)
			if (huffcodesA[i][j].sss != -1) {
				index = (char)i;
				fwrite(&index,sizeof(char),1,out);
				index = (char)j;
				fwrite(&index,sizeof(char),1,out);
				fwrite(&(huffcodesA[i][j].sss),sizeof(char),1,out);
				fwrite(&(huffcodesA[i][j].diff),sizeof(int),1,out);
			}
	// Insere um separador para indicar fim dos codigos que compoem os ACs e inicio dos codigos DCs
	index = -1;
	fwrite(&index,sizeof(char),1,out);
	// Para cada coeficiente DC
	for (i=0;i<n;i++) {
		mval = 128; // Inicializa a mascara do valor a ser escrito a cada iteracao (codigo de huffman), um bit 1 seguido de 7 zeros
		num = ((unsigned char)huffcodesD[DCs[i].sss].diff) << (8 - huffcodesD[DCs[i].sss].sss); // Coloca os bits nas posicoes mais significativas de num
		writenum(num,huffcodesD[DCs[i].sss].sss,&buf,&mbuf,&mval,out); // Escreve o codigo de huffman
		mval = 128; // Inicializa a mascara do valor a ser escrito a cada iteracao (valor correspondente ao codigo escrito anteriormente)
		num = ((unsigned char)DCs[i].diff) << (8 - DCs[i].sss); // Coloca os bits nas posicoes mais significativas de num
		writenum(num,DCs[i].sss,&buf,&mbuf,&mval,out); // Escreve o valor (gerado pela codificacao por diferenca)
	}
	Triple *temp;
	// Para cada coeficiente AC
	for (i=0;i<n;i++) {
		temp = ACs[i];
		// Percorre a lista encadeada correspondente ao macrobloco da posicao i
		while (temp != NULL) {
			mval2 = 1073741824; // Inicializa a mascara do valor a ser escrito a cada iteracao (representado em um inteiro), um bit 1 seguido de 30 zeros
			num2 = (huffcodesA[temp->skip][temp->sss].diff) << (31 - huffcodesA[temp->skip][temp->sss].sss); // Coloca os bits nas posicoes mais significativas de num2
			writenum2(num2,huffcodesA[temp->skip][temp->sss].sss,&buf,&mbuf,&mval2,out); // Escreve o codigo de huffman
			mval = 128; // Inicializa a mascara do valor a ser escrito a cada iteracao (valor correspondente ao codigo escrito anteriormente)
			num = (temp->value) << (8 - temp->sss);// Coloca os bits nas posicoes mais significativas de num
			writenum(num,temp->sss,&buf,&mbuf,&mval,out); // Escreve o valor (gerado pela codificacao por carreira
			temp = temp->next; // Vai para o proximo valor da lista encadeada
		}
	}
	// Caso haja alguma "sobra" no buffer, escreve-a no arquivo de saida
	if (mbuf != 128) fwrite(&buf,sizeof(unsigned char),1,out);
	// Fecha arquivo de saida
	fclose(out);
}

// Realiza a codificacao por diferenca nos coeficientes DC, aqui chamados de V
void Diff(Pair *V, int size) {
	int temp,i;
	char h;
	// Armazena os valores anteriores de b, g, r (na primeira iteracao, o primeiro valor).
	// Estes serao usados como referencia para que os proximos apenas armazenem
	// suas diferencas com relacao ao anterior
	int lastb = (int)V[0].value;
	int lastg = (int)V[1].value;
	int lastr = (int)V[2].value;
	// Loop para calcular a diferenca para os coeficientes blue
	for (i=3;i<size;i+=3) {
		temp = (int)V[i].value - lastb;
		lastb += temp;
		V[i].diff = tobinary2(temp, &h); // Converte a diferenca para binario e calcula o respectivo sss
		V[i].sss = h;
	}
	// Loop para calcular a diferenca para os coeficientes green
	for (i=4;i<size;i+=3) {
		temp = (int)V[i].value - lastg;
		lastg += temp;
		V[i].diff = tobinary2(temp, &h); // Converte a diferenca para binario e calcula o respectivo sss
		V[i].sss = h;
	}
	// Loop para calcular a diferenca para os coeficientes red
	for (i=5;i<size;i+=3) {
		temp = (int)V[i].value - lastr;
		lastr += temp;
		V[i].diff = tobinary2(temp, &h); // Converte a diferenca para binario e calcula o respectivo sss
		V[i].sss = h;
	}
	// Converte tambem para binario os primeiros valores
	V[0].diff = tobinary(V[0].value, &h); // Converte o valor inicial para binario e calcula o respectivo sss
	V[0].sss = h;
	V[1].diff = tobinary(V[1].value, &h); // Converte o valor inicial para binario e calcula o respectivo sss
	V[1].sss = h;
	V[2].diff = tobinary(V[2].value, &h); // Converte o valor inicial para binario e calcula o respectivo sss
	V[2].sss = h;
}

// Realiza vetorizacao de um macrobloco, percorrendo os indices da matriz em zig-zag e armazenando
// os coeficientes vetorizados em MVector, a partir do indice ind
void Vetoriza(char M[8][8], char MVector[], int ind) {
	int i=0,j=0,ii=-1,jj=1; // indices: i, j. controladores de direcao de leitura: ii e jj
	int lendo = 1; // Variavel que controla o fim da leitura
	MVector[ind] = M[0][0]; // Armazena coeficiente DC na posicao ind do vetor
	ind++;
	while (lendo) {
		// Ao chegar na lateral superior ou inferior da matriz, inverte sentido da leitura
		if ((i==0) || (i==7)) {
			j++;
			MVector[ind] = M[i][j];
	        ind++;
			ii = ii * -1;
			jj = jj * -1;
			if ((i==7) && (j==7)) lendo = 0; // Quando chegar no canto inferior direito da matriz, finaliza leitura
		}
		// Ao chegar na lateral esquerda ou direita da matriz, inverte sentido da leitura (exceto quando trata-se de um "canto")
		if (((j==0) || (j==7)) && (i!=0) && lendo) {
			i++;
			MVector[ind] = M[i][j];
	        ind++;
			ii = ii * -1;
			jj = jj * -1;
		}
		// Se nao chegou em cantos, le valor e armazena na posicao correspondente
		if (lendo) {
			i = i + ii;
			j = j + jj;
			MVector[ind] = M[i][j];
	        ind++;
		}
		if ((i==7) && (j==7)) lendo = 0; // Se nesse momento chegou-se a um canto da matriz, finaliza leitura
	}
}

// Realiza operacao inversa a vetorizacao, percorrendo os indices do vetor a partir do indice ind e armazenando-os na matriz, em zig-zag
void matrifica(char MVector[], char M[8][8], int ind) {
	int i=0,j=0,ii=-1,jj=1; // indices: i, j. controladores de direcao de leitura: ii e jj
	int lendo = 1; // Variavel que controla o fim da leitura
	M[0][0] = MVector[ind]; // Armazena coeficiente DC na posicao 0,0 da matriz
	ind++;
	while (lendo) {
		// Ao chegar na lateral superior ou inferior da matriz, inverte sentido da leitura
		if ((i==0) || (i==7)) {
			j++;
			M[i][j] = MVector[ind];
	        ind++;
			ii = ii * -1;
			jj = jj * -1;
			if ((i==7) && (j==7)) lendo = 0; // Quando chegar no canto inferior direito da matriz, finaliza leitura
		}
		// Ao chegar na lateral esquerda ou direita da matriz, inverte sentido da leitura (exceto quando trata-se de um "canto")
		if (((j==0) || (j==7)) && (i!=0) && lendo) {
			i++;
			M[i][j] = MVector[ind];
	        ind++;
			ii = ii * -1;
			jj = jj * -1;
		}
		// Se nao chegou em cantos, le valor e armazena na posicao correspondente
		if (lendo) {
			i = i + ii;
			j = j + jj;
			M[i][j] = MVector[ind];
	        ind++;
		}
		if ((i==7) && (j==7)) lendo = 0; // Se nesse momento chegou-se a um canto da matriz, finaliza leitura
	}
}

// Insere Triple contendo skip, sss e value na posicao pos do vetor de Triples, no fim da lista encadeada correspondente
void Insere(Triple **ACs, int pos, char skip, char sss, char value) {
	Triple *temp = ACs[pos]; // Atribui na variavel temp a cabeca da lista encadeada correspondente a posicao pos de ACs
	// Aloca novo Triple "p" e atribui valores
	Triple *p = (Triple *)malloc(sizeof(Triple));
	p->skip = skip;
	p->sss = sss;
	p->value = value;
	p->next = NULL;
	if (temp == NULL) ACs[pos] = p; // Se cabeca da lista estava vazia, atribui p a ela
	else { // Senao, percorre a lista encadeada ate o fim e insere no pe da lista
		while (temp->next != NULL) temp = temp->next;
		temp->next = p;
	}
}

// Separa coeficientes DC e ACs do vetor MVector, armazenando na posicao correta de DCs o DC lido e em ACs os ACs lidos, das 3 cores
// IMPORTANTE: Tambem faz codificacao por carreira nos ACs.
void SplitMVector(char *MVector, Pair *DCs, Triple **ACs, int n) {
	int i;
	int skip=0;
	int y = 3 * n; // Posicao correta de insercao do coeficiente (3 vezes o numero do macrobloco em questao, n)
	DCs[y].value = MVector[0]; // Armazena valor DC da cor blue
	// Armazena valores AC da cor blue
	for (i=1;i<64;i++) {
		// Calcula skip (numero de zeros encontrados entre o valor anterior e o que esta sendo armazenado)
		while ((MVector[i] == 0) && (i<63)) {
			skip++;
			i++;
		}
		if (i==63) {
			// Se terminou macrobloco com coeficientes "zeros", armazena indicador de fim de macrobloco (skip = value = 0)
			if (MVector[i] == 0) Insere(ACs,y,0,0,0);
			// Senao, insere valor normalmente, com skip=0
			else Insere(ACs,y,skip,0,MVector[i]);
		}
		// Se nao terminou macrobloco, insere valor e zera skip para o proximo valor
		else {
			Insere(ACs,y,skip,0,MVector[i]);
			skip = 0;
		}
	}
	skip = 0;
	y++;
	DCs[y].value = MVector[64]; // Armazena valor DC da cor green
	// Armazena valores AC da cor blue
	for (i=65;i<128;i++) {
		// Calcula skip (numero de zeros encontrados entre o valor anterior e o que esta sendo armazenado)
		while ((MVector[i] == 0) && (i<127)) {
			skip++;
			i++;
		}
		if (i==127) {
			// Se terminou macrobloco com coeficientes "zeros", armazena indicador de fim de macrobloco (skip = value = 0)
			if (MVector[i] == 0) Insere(ACs,y,0,0,0);
			// Senao, insere valor normalmente, com skip=0
			else Insere(ACs,y,skip,0,MVector[i]);
		}
		// Se nao terminou macrobloco, insere valor e zera skip para o proximo valor
		else {
			Insere(ACs,y,skip,0,MVector[i]);
			skip = 0;
		}
	}
	skip = 0;
	y++;
	DCs[y].value = MVector[128]; // Armazena valor DC da cor red
	// Armazena valores AC da cor blue
	for (i=129;i<192;i++) {
		// Calcula skip (numero de zeros encontrados entre o valor anterior e o que esta sendo armazenado)
		while ((MVector[i] == 0) && (i<191)) {
			skip++;
			i++;
		}
		if (i==191) {
			// Se terminou macrobloco com coeficientes "zeros", armazena indicador de fim de macrobloco (skip = value = 0)
			if (MVector[i] == 0) Insere(ACs,y,0,0,0);
			// Senao, insere valor normalmente, com skip=0
			else Insere(ACs,y,skip,0,MVector[i]);
		}
		// Se nao terminou macrobloco, insere valor e zera skip para o proximo valor
		else {
			Insere(ACs,y,skip,0,MVector[i]);
			skip = 0;
		}
	}
}

// Calcula SSSs para os coeficientes AC, j� transformando values em complemento de um
void CalculateSSS(Triple **ACs, int n) {
	int i;
	unsigned char x;
	Triple *temp;
	
	// Percorre todos os ACs
	for (i=0;i<n;i++) {
		temp = ACs[i];
		while (temp != NULL) {
			temp->value = tobinary(temp->value,&x); // Transforma value em complemento de um e armazena, e calcula SSS
			temp->sss = x; // Armazena SSS calculado acima
			temp = temp->next;
		}
	}
}

// Aplica codificacao de Huffman nos coeficientes DC
void HuffD(Pair *DCs,Pair *huffcodes,int n) {
	int i;
	
	// Funcao de comparacao utilizada pelo quicksort
	int compare(const void *arg1,const void *arg2) {
		Tree *esq = *(Tree **)arg1;
		Tree *dir = *(Tree **)arg2;
		
		return (dir->freq - esq->freq);
	}
	
	// Declara e inicializa vetor para todos os possiveis valores de SSS (0 a 8 bits)
	Tree *vet[9];
	for (i=0;i<9;i++) {
		vet[i] = (Tree *)malloc(sizeof(Tree));
		vet[i]->freq = 0;
		vet[i]->sss = i;
		vet[i]->esq = NULL;
		vet[i]->dir = NULL;
	}
	
	for (i=0;i<n;i++) vet[DCs[i].sss]->freq++; // Armazena a frequencia de cada SSS dos DCs nas respectivas posicoes do vetor
	qsort((void *)vet,9,sizeof(Tree *),compare); // Ordena o vetor de acordo com as frequencias dos DCs
	i = 0;
	while (vet[i]->freq != 0 && i < 9) i++; // Conta o numero de frequencias existentes
	i--;
	
	// Monta a arvore Huffman. Ao final, a posicao 0 do vetor aponta para a arvore otima
	while (i>0) {
		Tree *new = (Tree *)malloc(sizeof(Tree)); // Declara um novo noh da arvore
		new->freq = vet[i-1]->freq + vet[i]->freq; // Atribui frequencia do noh como a soma das frequencias dos dois nos de menor frequencia
		new->sss = -1; // Atribui valor invalido de SSS para indicar noh pai
		new->esq = vet[i]; // Aponta para o filho da esquerda (ultimo noh do vetor)
		new->dir = vet[i-1]; // Aponta para o filho da direita (penultimo noh do vetor)
		vet[i-1] = new; // Armazena o noh pai no vetor
		if (i > 1) qsort((void *)vet,i,sizeof(Tree *),compare); // Ordena vetor atualizado de acordo com as frequencias
		i--; // Decrementa tamanho (utilizado) do vetor
	}
	
	// Percorre a arvore, derivando os codigos de Huffman
	unsigned char str = (unsigned char)0;
	traverseD(vet[0], huffcodes, &str, 0);
}

// Aplica codificacao de Huffman nos coeficientes AC
void HuffA(Triple **ACs,Pair **huffcodes,int n) {
	int i,j,k=0;
	
	// Funcao de comparacao utilizada pelo quicksort
	int compare(const void *arg1,const void *arg2) {
		Tree *esq = *(Tree **)arg1;
		Tree *dir = *(Tree **)arg2;
		
		return (dir->freq - esq->freq);
	}
	
	Tree *vet[62][9]; // Matriz de frequencias para todas as possiveis combinacoes de skip e SSS (62 x 9)
	Tree *vet2[558]; // Vetor de frequencias com o mesmo numero de posicoes e mesmos elementos da matriz de frequencias
	
	// Inicializa matriz de frequencias
	for (i=0;i<62;i++)
		for (j=0;j<9;j++) {
			vet[i][j] = (Tree *)malloc(sizeof(Tree));
			vet[i][j]->freq = 0;
			vet[i][j]->skip = i;
			vet[i][j]->sss = j;
			vet[i][j]->esq = NULL;
			vet[i][j]->dir = NULL;
			vet2[k++] = vet[i][j];
	}
	
	// Armazena a frequencia de skip e SSS dos ACs nas respectivas posicoes da matriz
	Triple *temp;
	for (i=0;i<n;i++) {
		temp = ACs[i];
		while (temp != NULL) {
			vet[temp->skip][temp->sss]->freq++;
			temp = temp->next;
		}
	}
	qsort((void *)vet2,558,sizeof(Tree *),compare); // Ordena o vetor de acordo com as frequencias dos ACs
	i = 0;
	while (vet2[i]->freq != 0 && i < 558) i++; // Conta o numero de frequencias existentes
	i--;
	
	// Monta a arvore Huffman. Ao final, a posicao 0 do vetor aponta para a arvore otima
	while (i>0) {
		Tree *new = (Tree *)malloc(sizeof(Tree)); // Declara um novo noh da arvore
		new->freq = vet2[i-1]->freq + vet2[i]->freq; // Atribui frequencia do noh como a soma das frequencias dos dois nos de menor frequencia
		new->sss = -1; // Atribui valor invalido de SSS para indicar noh pai
		new->esq = vet2[i]; // Aponta para o filho da esquerda (ultimo noh do vetor)
		new->dir = vet2[i-1]; // Aponta para o filho da direita (penultimo noh do vetor)
		vet2[i-1] = new; // Armazena o noh pai no vetor
		if (i > 1) qsort((void *)vet2,i,sizeof(Tree *),compare); // Ordena vetor atualizado de acordo com as frequencias
		i--; // Decrementa tamanho (utilizado) do vetor
	}
	
	// Percorre a arvore, derivando os codigos de Huffman
	int code = 0;
	traverseA(vet2[0], huffcodes, &code, 0);
}


// Percorre a arvore de Huffman dos DCs, derivando os codigos de Huffman
void traverseD(Tree *node, Pair *huffcodes, unsigned char *str, int n) {
	unsigned char *str1 = (char *)malloc(sizeof(char)); // Codigo de Huffman para o caminho da esquerda
	unsigned char *str2 = (char *)malloc(sizeof(char)); // Codigo de Huffman para o caminho da direita
	
	// Se noh pai
	if (node->sss == -1) {
		*str1 = *str << 1; // Insere 0 no final do codigo atual
		traverseD(node->esq, huffcodes, str1, n+1); // Deriva o resto do codigo para a esquerda
		*str2 = (*str << 1) + 1; // Insere 1 no final do codigo atual
		traverseD(node->dir, huffcodes, str2, n+1); // Deriva o resto do codigo para a direita
	}
	// Se noh folha
	else {
		huffcodes[node->sss].diff = *str; // Atribui o codigo de Huffman
		huffcodes[node->sss].sss = n; // Atribui o SSS do codigo de Huffman (profundidade da arvore)
	}
}

// Percorre a arvore de Huffman dos ACs, derivando os codigos de Huffman
void traverseA(Tree *node, Pair **huffcodes, int *code, int n) {
	int *code1 = (int *)malloc(sizeof(int)); // Codigo de Huffman para o caminho da esquerda
	int *code2 = (int *)malloc(sizeof(int)); // Codigo de Huffman para o caminho da direita
	
	// Se noh pai
	if (node->sss == -1) {
		*code1 = *code << 1; // Insere 0 no final do codigo atual
		traverseA(node->esq, huffcodes, code1, n+1); // Deriva o resto do codigo para a esquerda
		*code2 = (*code << 1) + 1; // Insere 1 no final do codigo atual
		traverseA(node->dir, huffcodes, code2, n+1); // Deriva o resto do codigo para a direita
	}
	// Se noh folha
	else {
		huffcodes[node->skip][node->sss].diff = *code; // Atribui o codigo de Huffman
		huffcodes[node->skip][node->sss].sss = n; // Atribui o SSS do codigo de Huffman (profundidade da arvore)
	}
}

// Percorre a arvore de Huffman dos DCs de acordo com os bits lidos do arquivo out.dat, retornando o SSS
int percorreD(Tree *node, unsigned char *buf, unsigned char *mbuff, FILE *in) {
	unsigned char aux;
	
	// Se foi lido todo o buffer
	if (*mbuff == 0) {
		fread(buf,sizeof(unsigned char),1,in); // Carrega outro conjunto de bits do arquivo e coloca-os no buffer
		*mbuff = 128; // Atualiza mascara do buffer
	}
	
	// Se noh pai
	if (node->sss == -1) {
		aux = *buf & *mbuff; // Recupera proximo bit
		*mbuff = *mbuff >> 1; // Atualiza mascara
		if (aux == 0) { // Se bit 0
			return percorreD(node->esq, buf, mbuff, in); // Percorre arvore para a esquerda
		} else { // Se bit 1
			return percorreD(node->dir, buf, mbuff, in); // Percorre arvore para a direita
		}
	}
	// Se noh folha
	else {
		return node->sss; // Retorna SSS
	}
}

// Percorre a arvore de Huffman dos ACs de acordo com os bits lidos do arquivo out.dat, retornando o skip e SSS
void percorreA(Tree *node, unsigned char *buf, unsigned char *mbuff, FILE *in, char *skip, char *sss) {
	unsigned char aux;
	
	// Se foi lido todo o buffer
	if (*mbuff == 0) {
		fread(buf,sizeof(unsigned char),1,in); // Carrega outro conjunto de bits do arquivo e coloca-os no buffer
		*mbuff = 128; // Atualiza mascara do buffer
	}
	
	// Se noh pai
	if (node->sss == -1) {
		aux = *buf & *mbuff; // Recupera proximo bit
		*mbuff = *mbuff >> 1; // Atualiza mascara
		if (aux == 0) { // Se bit 0
			percorreA(node->esq, buf, mbuff, in, skip, sss); // Percorre arvore para a esquerda
		} else { // Se bit 1
			percorreA(node->dir, buf, mbuff, in, skip, sss); // Percorre arvore para a direita
		}
	}
	// Se noh folha
	else {
		*skip = node->skip; // Atribui skip
		*sss = node->sss; // Atribui SSS
	}
}
