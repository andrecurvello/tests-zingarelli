/*	Gilson Araujo do Nascimento		6552042
	Rafael Yuri Bardini				6552098
	Tamires Tessarolli de Souza		6427282
*/

#include <stdint.h>
#include "BMPFile.h"


int main(int argc, char *argv[]) {
	FILE *fp = NULL; // Arquivo BMP de entrada
	MBlock *mblocks = NULL; // Vetor de Macroblocos
	BMPFILEHEADER fh;
	BMPINFOHEADER ih;
	// Verifica se foi fornecido um nome de arquivo
	if (argc < 2) {
		printf("Informe o nome do arquivo\n");
		return 1;
	}
	// Verifica se o arquivo existe e pode ser aberto
	if ((fp = fopen((char *)argv[1],"rb")) == NULL) {
		perror("Erro de leitura do arquivo");
		return 1;
	}
	// Le headers do arquivo e analisa retorno da funcao (deteccao de erros no header do arquivo fornecido)
	int x = readHeaders(&fh,&ih,fp);
	printf("Cabecalhos do arquivo lidos\n");
	switch (x) {
		case -1: printf("Forneca uma imagem BMP\n");
				 return 1;
		case -2: printf("A imagem nao possui profundidade 24bpp\n");
				 return 1;
		case -3: printf("A imagem possui compressao\n");
				 return 1;
		case -4: printf("A imagem possui dimensoes invalidas\n");
				 return 1;
		default: break;
	}
	// Posiciona ponteiro no comeco da area dos dados da imagem para leitura dos valores dos pixels
	fseek(fp,fh.bfOffBits,SEEK_SET);
	// Calcula quantidade de macroblocos que sera necessaria para armazenar os bits
	int nBlocks = (ih.biWidth*ih.biHeight)/64;
	// Aloca macroblocos
	mblocks = alocaMB(nBlocks);
	// Aloca hcodes
	int i,j,k,l; // Contadores
	unsigned char buf[4]; // Buffer de leitura das matrizes RGB
	int bytes = ih.biBitCount/8; // Converte biBitCount para bytes, para poder ler do arquivo
	int control = fh.bfOffBits; // Atualiza variavel de controle do seek
	char MVector[192]; // Armazena macroblocos vetorizados
	Pair DCs[3*nBlocks]; // Armazena os coeficientes DC da imagem
	Triple **ACs; // Armazena os coeficientes AC da imagem
	ACs = (Triple **)malloc(sizeof(Triple *) * 3 * nBlocks);
	for (i=0;i<3*nBlocks;i++) ACs[i] = NULL;
	FILE *out; // Arquivo de saida

    printf("CODIFICANDO\n");
	// Leitura e Preparacao da Imagem/Bloco
	for (l=0;l<(ih.biHeight/8);l++)
		for (j=7;j>=0;j--) {
			for (i=(ih.biWidth/8)-1;i>=0;i--) {
				for (k=0;k<8;k++) {
				fread(&buf,sizeof(char),bytes,fp); // Carrega buffer
				mblocks[i+l*(ih.biWidth/8)].b[j][k] = (char)(buf[0] - 128); // Armazena valor de "b" na matriz correspondente, com level shift
				mblocks[i+l*(ih.biWidth/8)].g[j][k] = (char)(buf[1] - 128); // Armazena valor de "g" na matriz correspondente, com level shift
				mblocks[i+l*(ih.biWidth/8)].r[j][k] = (char)(buf[2] - 128); // Armazena valor de "r" na matriz correspondente, com level shift
				control += bytes; // Atualiza variavel de controle do seek
				fseek(fp,control,SEEK_SET); // Realiza novo seek para a posicao correta do arquivo de entrada
				memset(&buf,0,4); // Limpa buffer de leitura
				}
			}
		}
	printf(" - Macroblocos preparados\n");

	// Codificacao por Entropia
	// Funcao que realiza a vetorizacao de uma matriz de pixels, percorrendo-a em zig-zag e armazenando os valores em MVector
    for (i=0;i<nBlocks;i++) {
		Vetoriza(mblocks[i].b,MVector,0);
        Vetoriza(mblocks[i].g,MVector,64);
        Vetoriza(mblocks[i].r,MVector,128);
		SplitMVector(MVector,DCs,ACs,i); // Separa os coeficientes DC e AC de MVector, armazenando-os em suas respectivas estruturas
	}
	printf(" - Matrizes vetorizadas (zig-zag scan)\n");
	printf(" - DCs e ACs separados\n");
	printf(" - ACs codificados por carreira\n");
    CalculateSSS(ACs,3*nBlocks); // Calcula valores SSS para os coeficientes AC, alem disso tambem transforma os values em complemento de um usando tobinary()
	printf(" - DCs codificados por diferenca\n");
    Diff(DCs,3*nBlocks); // Aplica codificacao por diferenca nos coeficientes DC
	Pair huffcodesD[9];
	// Inicializa estrutura que armazenara os codigos de huffman dos DCs
	for (i=0;i<9;i++) {
		huffcodesD[i].diff = 0;
		huffcodesD[i].sss = -1;
		huffcodesD[i].value = -1;
	}
	HuffD(DCs,huffcodesD,3*nBlocks); // Aplica codificacao de huffman nos coeficientes DC
	printf(" - Codificacao de Huffman aplicada nos coeficientes DC\n");
	Pair **huffcodesA = (Pair **)malloc(sizeof(Pair *) * 63);
	// Inicializa estrutura que armazenara os codigos de huffman dos ACs
	for (i=0;i<63;i++) huffcodesA[i] = (Pair *)malloc(sizeof(Pair) * 9);
	for (i=0;i<63;i++)
		for (j=0;j<9;j++) {
			huffcodesA[i][j].diff = 0;
			huffcodesA[i][j].sss = -1;
			huffcodesA[i][j].value = -1;
		}
	HuffA(ACs,huffcodesA,3*nBlocks); // Aplica codificacao de huffman nos coeficientes AC
	printf(" - Codificacao de Huffman aplicada nos coeficientes AC\n");
	writefiles(&fh,&ih,huffcodesD,huffcodesA,DCs,ACs,3*nBlocks); // Escreve arquivo de saida (out.dat)
	printf(" - Arquivo de saida temporario \"out.dat\" escrito\n");
	// Percorre estruturas de dados, zerando seus valores
	// Codigos de huffman dos coeficientes DC
	
	printf("\nDECODIFICANDO\n");
	for (i=0;i<9;i++) {
		huffcodesD[i].sss = -1;
		huffcodesD[i].value = -1;
		huffcodesD[i].diff = 0;
	}
	// Codigos de huffman dos coeficientes AC
	for (i=0;i<62;i++)
		for (j=0;j<9;j++) {
			huffcodesA[i][j].sss = -1;
			huffcodesA[i][j].diff = 0;
			huffcodesA[i][j].value = -1;
		}
	// Coeficientes AC
	for (i=0;i<3*(nBlocks);i++) ACs[i] = NULL;
	// Coeficientes DC
	for (i=0;i<3*(nBlocks);i++) {
		DCs[i].value = 0;
		DCs[i].sss = 0;
		DCs[i].diff = 0;
	}
	// Le a partir do arquivo out.dat e retorna os headers, juntamente com os coeficientes DCs e ACs e o numero de macroblocos da imagem
	readfiles(&fh,&ih,huffcodesD,huffcodesA,DCs,ACs,&nBlocks);
	mblocks = NULL;
	mblocks = alocaMB(nBlocks); // Re-aloca vetor de macroblocos
	for (i=0;i<192;i++) MVector[i] = (char)0;

	decode(DCs,ACs,MVector,mblocks,nBlocks); // Realiza as operacoes inversas da codificacao por entropia e prepara o bloco novamente para ser escrito no bmp

	printFile(&fh,&ih,mblocks,nBlocks,argv[1]); // Escreve os headers e as matrizes de pixels novamente no arquivo .bmp
	system("pause");
	return 0;
}
