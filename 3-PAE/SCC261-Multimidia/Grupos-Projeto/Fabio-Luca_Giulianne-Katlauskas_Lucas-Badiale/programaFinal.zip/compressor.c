/* Compressão de Imagem Digital
 * Fase 1
 *
 * Materia: SCC0261 Multimidia
 *
 * Entrega:  22/03/2011
 * Grupo: 7
 *  Fábio Abrão Luca
 *  Giulianne Katlauskas Montemurro
 *  Lucas Cuculo Badiale
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

/**** BMP file header structure ****/
typedef struct {
    unsigned short bfType;       /* Magic number for file */
} BMPMAGICNUMBER;

typedef struct {
    unsigned int   bfSize;       /* Size of file */
    unsigned short bfReserved1;  /* Reserved */
    unsigned short bfReserved2;  /* ... */
    unsigned int   bfOffBits;    /* Offset to bitmap data */
} BMPFILEHEADER;

/* bfType deve ser = "MB" */

/**** BMP file info structure ****/
typedef struct {
    unsigned int   biSize;          /* Size of info header */
    int            biWidth;         /* Width of image */
    int            biHeight;        /* Height of image */
    unsigned short biPlanes;        /* Number of color planes */
    unsigned short biBitCount;      /* Number of bits per pixel */
    unsigned int   biCompression;   /* Type of compression to use */
    unsigned int   biSizeImage;     /* Size of image data */
    int            biXPelsPerMeter; /* X pixels per meter */
    int            biYPelsPerMeter; /* Y pixels per meter */
    unsigned int   biClrUsed;       /* Number of colors used */
    unsigned int   biClrImportant;  /* Number of important colors */
} BMPINFOHEADER;

/* blocos 8x8 que formam a imagem em RGB*/
typedef struct Bloco {
    int r[8][8];
    int g[8][8];
    int b[8][8];
    struct Bloco *next;
} noBloco;

/*definicao do ponteiro para a struct Bloco*/
typedef noBloco *listaBloco;

/*cria nova lista*/
void novaLista(listaBloco *lista) {
    *lista = NULL;
}

/*cria um novo bloco*/
listaBloco AllocLista() {
    listaBloco p;
    p = (listaBloco) malloc(sizeof (noBloco));
    novaLista(&p->next);
    return p;
}

/*adiciona um novo bloco na lista*/
void novoBloco(listaBloco *lista) {
    listaBloco p, q, r;
    p = AllocLista();
    if (*lista == NULL) {
        *lista = p;
    } else {
        q = *lista;
        while (!(q->next == NULL)) {
            q = q->next;
        }
        r = q->next;
        q->next = p;
        p->next = r;
    }
}

/*confere se a lista esta vazia*/
int listaVazia(listaBloco lista) {
    return lista == NULL;
}

// tabela com quantidades de bits de cada numero dos blocos
typedef struct {
    /* montar esta estrutura
     tabela com quantidade de bits significativos
     por exemplo: 5 é 101 em binário, portanto tem 3 bits significativos
    */
    int *tabela;
    int n;
} TABELABITS;

// os bits
typedef struct {
    char *stream;
    int size;
} BITSTREAM;

void preparacaoImagem(char * filename, BMPFILEHEADER *fHeader, BMPINFOHEADER *header, listaBloco *bloco) {
    BMPMAGICNUMBER bmpnum;
    int nroBlocosLinha, nroBlocosCol, linha_aux, coluna_aux;
    int restaLinha, restaColuna;
    int i, j, k, l, exc, comecar;
    FILE *entrada;
    listaBloco bloco1, bloco1l;

    /*abertura do arquivo passado por parametro*/
    entrada = fopen(filename, "rb");

    if (entrada == NULL) {
        fprintf(stderr, "Nao foi possivel abrir o arquivo %s\n ", filename);
        exit(EXIT_FAILURE);
    } else {
        // Le o file headers do bitmap
        // a struct BMPFILEHEADER tem um tamanho errado, devido � problemas de alinhamento
        fread(&bmpnum, 2, 1, entrada);
        fread(fHeader, sizeof(BMPFILEHEADER), 1, entrada);

        // verifica se o arquivo eh um bitmap
        if (bmpnum.bfType != 19778) {
            fprintf(stderr, "Arquivo nao eh um bitmap.\n");
            exit(EXIT_FAILURE);
        }
        // le o info header
        fread(header, sizeof (BMPINFOHEADER), 1, entrada);
        //fseek(entrada, fHeader->bfOffBits, SEEK_SET);

        /*numero de blocos que existem na largura*/
        nroBlocosLinha = header->biWidth / 8;
        //nroBlocosLinha = 1680/8;

        /*numero de pixels a sobrar na largura*/
        restaLinha = header->biWidth % 8;
        //restaLinha = 1680%8;
        linha_aux = restaLinha;

        /*numero de blocos que existem na altura*/
        nroBlocosCol = header->biHeight / 8;
        // nroBlocosCol = 1050/8;

        /*numero de pixels a sobrar na altura*/
        restaColuna = header->biHeight % 8;
        //restaColuna = 1050%8;
        coluna_aux = restaColuna;

        /*cria nova lista de blocos*/
        novaLista(&(*bloco));

        /*extrai as cores de uma
        lista de blocos da imagem na vertical*/
        for (i = 0; i < nroBlocosCol; i++) {

            if ((*bloco) != NULL)
                while ((*bloco)->next != NULL)
                    (*bloco) = (*bloco)->next;

            /*calcula a quantidade de blocos presentes na vertical da imagem (qtas linhas de (*bloco))*/
            for (j = 0; j < nroBlocosLinha; j++) {
                novoBloco(&(*bloco));
                if ((i==0)&&(j==0)) {
                    bloco1 = (*bloco);
                    bloco1l = (*bloco);
                }
                else if ((i!=0)&&(j==0)) {
                    (*bloco) = (*bloco)->next;
                    bloco1l = (*bloco);
                }
            }

            /*o que restar sera colocado em um ultimo (*bloco)*/
            if (restaLinha != 0) {
                novoBloco(&(*bloco));
            }

            comecar = 1;

            /*cada (*bloco) da lista armazena as cores de apenas uma linha. executa 8 vezes para completar 8 linhas de 8 pixels*/
            for (j = 0; j < 8; j++) {
                /*armazena cores de uma linha de 8 pixels*/
                for (l = 0; l < nroBlocosLinha; l++) {
                    for (k = 0; k < 8; k++) {
                        (*bloco)->r[j][k] = fgetc(entrada);
                        (*bloco)->g[j][k] = fgetc(entrada);
                        (*bloco)->b[j][k] = fgetc(entrada);
                    }
                    /*aponta para o proximo (*bloco) da lista*/
                    (*bloco) = (*bloco)->next;
                }
                //se houver sobra de pixel, armazena no ultimo (*bloco) da lista
                if (restaLinha != 0) {
                    //completa uma linha de 8 pixels do ultimo (*bloco) da lista
                    for (k = 0; k < 8; k++) {
                        if (linha_aux != 0) {
                            (*bloco)->r[j][k] = fgetc(entrada);
                            (*bloco)->g[j][k] = fgetc(entrada);
                            (*bloco)->b[j][k] = fgetc(entrada);
                            linha_aux--;
                        } else {
                            (*bloco)->r[j][k] = 0;
                            (*bloco)->g[j][k] = 0;
                            (*bloco)->b[j][k] = 0;
                        }
                    }
                    //l� e ignora a informacao adicional que o proprio arquivo BMP cria qndo existe sobra de pixels
                    for (exc = 0; exc < header->biWidth % 4; exc++)
                        fgetc(entrada);

                    linha_aux = restaLinha;
                }
                (*bloco) = bloco1l;
            }
        }
        (*bloco) = bloco1;
    }
}

// faz o level shift dos elementos de cada bloco (subtrai 128)
void levelShift(listaBloco *blocos) {
    // cada elemento dos bloquinhos varia entre 0 e 255
    // nessa funcao temos que subtrair 128 de cada elemento.
    listaBloco b = *blocos;
    int i, j;

    while (b != NULL) {
        for (i = 0; i <8; i++) {
            for (j = 0; j < 8; j++) {
                b->r[i][j] -= 128;
                b->g[i][j] -= 128;
                b->b[i][j] -= 128;
            }
        }
        b = b->next;
    }
}


// conta os bits significativos e coloca essa quantidade na tabela
void tabelaBits(listaBloco blocos, TABELABITS *tabela) {
    int i, j, k;
    
    // Conta nro de blocos
    listaBloco b = blocos;
    i = 0;
    while (b != NULL) {
          i++;
          b = b->next;
    }
    // Aloca o vetor tabela de acordo com o nro de blocos i 8x8 RGB
    tabela->tabela = (int*) malloc(sizeof(int)*i*8*8*3);

    TABELABITS *tb = tabela;
    b = blocos;
    tb->n = 0;
    // Para todos os blocos, percorre os pixels e coloca no vetor tabela
    // na ordem RGB, o nro de bits significativos.
    while (b != NULL) {
        for (i = 0; i < 8; i++) {
            for (j = 0; j < 8; j++) {
                // O nro de bits significativos de um n�mero x � dado por
                // floor(lg(x))+1 onde lg � o log na base 2.
                if (b->r[i][j] < 0 && b->r[i][j] != -128) k = 1; else k = 0;
                if (b->r[i][j] == 0) tb->tabela[(tb->n)++] = 0;
                else tb->tabela[(tb->n)++] = floor(log(abs(b->r[i][j]))/log(2))+1 + k;
                if (b->g[i][j] < 0 && b->g[i][j] != -128) k = 1; else k = 0;
                if (b->g[i][j] == 0) tb->tabela[(tb->n)++] = 0;
                else tb->tabela[(tb->n)++] = floor(log(abs(b->g[i][j]))/log(2))+1 + k;
                if (b->b[i][j] < 0 && b->b[i][j] != -128) k = 1; else k = 0;
                if (b->b[i][j] == 0) tb->tabela[(tb->n)++] = 0;
                else tb->tabela[(tb->n)++] = floor(log(abs(b->b[i][j]))/log(2))+1 + k;
            }
        }
        b = b->next;
    }
}

// insere um numero no bitstream
void insereNumero (int *posicao, BITSTREAM *bits, int digitos, short numero) {
    int shift;
    char mask;
    char bit;
    char num = (char) numero;
    int deslocamento; // deslocamento necessario para colocar o bit que pegamos na posicao correta do bitstream

    // se for o numero for 0, nao faz nada
    if (digitos != 0) {
        if (numero < 0) {
            num = ~num;
        }
        shift = digitos - 1;
        while (shift >= 0) {
            // se a posicao for maior que 7, entao temos que alocar um novo elemento no vetor
            if (*posicao > 7 && shift >= 0) {
                bits->size = bits->size + 1;
                bits->stream = (char*) realloc (bits->stream, sizeof(char) * (bits->size)) ;
                bits->stream[bits->size - 1] = 0;
                *posicao = 0;
            }

            deslocamento = (7 - shift) - (*posicao);

            // cria uma mascara
            mask = 1 << shift;
        
            // pega o bit atual e shifta para a posicao certa no bitstream
            bit = (num & mask);

            if (deslocamento < 0) {
                bit = bit >> -deslocamento;
            } else {
                bit = bit << deslocamento;
            }
            
            // coloca o bit no bitstream
            bits->stream[bits->size - 1] = bits->stream[bits->size - 1] | bit;

            // vai para o proximo elemento
            *posicao = *posicao + 1;
            shift--;
        }
    }
}

// converte os blocos em bits, removendo os bits desnecessarios
void conversaoBinario(TABELABITS tabela, listaBloco blocos, BITSTREAM *bits) {
    // TODO
    // ler elemento por elemento dos blocos e
    // colocar no BITSTREAM, pulando os bits desnecessarios
    listaBloco b = blocos;
    int i, j;

    int posicao = 0;
    int tabela_pos = 0;

    // aloca a primeira dimensao
    bits->stream = (char*) malloc (sizeof(char) * 1) ;
    bits->size = 1;

    while (b != NULL) {
        for (i = 0; i <8; i++) {
            for (j = 0; j < 8; j++) {
                insereNumero(&posicao, bits, tabela.tabela[tabela_pos++], b->r[i][j]);
                insereNumero(&posicao, bits, tabela.tabela[tabela_pos++], b->g[i][j]);
                insereNumero(&posicao, bits, tabela.tabela[tabela_pos++], b->b[i][j]);
            }
        }
        b = b->next;
    }
}

// salva os bits no arquivo de destino
void salvar(char * destinationname, BMPFILEHEADER fheader, BMPINFOHEADER iheader, BITSTREAM bits) {
    FILE *fp = fopen(destinationname, "w");
    if (fp != NULL) {
        fwrite(&fheader, 14, 1, fp);
        fwrite(&iheader, sizeof(BMPINFOHEADER), 1, fp);
        fwrite(bits.stream, sizeof(char), bits.size, fp);
        fclose(fp);
    } else {
        fprintf(stderr, "Ocorreu um erro ao salvar o arquivo %s\n", destinationname);
    }
}

// salva a tabela com quantidade de bits significativos
void salvarTabela(char *destinationname, TABELABITS tabela) {
    FILE *fp = fopen(destinationname, "w");
    if (fp != NULL) {
        fwrite(tabela.tabela, sizeof(int), tabela.n, fp);
        fclose(fp);
    } else {
        fprintf(stderr, "Ocorreu um erro ao salvar o arquivo %s\n", destinationname);
    }
}

/*
 * 
 */
int main(int argc, char** argv) {
    // imagem BMP
    char *filename;

    // arquivo final "codificado"
    char *destinationname;

    // arquivo com a quantidade de bits significativos
    char *destinationnameTabela;
    
    // Headers do BMP original
    BMPFILEHEADER fheader;
    BMPINFOHEADER iheader;

    // bloco 8x8 de cada matriz RGB
    listaBloco blocos;

    // tabela com quantidades de bits de cada numero dos blocos
    TABELABITS tabela;

    // os bits
    BITSTREAM bits;

    // verificacoes da linha de comando
    if (argc != 3) {
        printf("Uso: %s arquivo.bmp arquivo_comprimido\n",argv[0]);
        exit(EXIT_FAILURE);
    }
    else {
        filename = argv[1];
        destinationname = argv[2];
        destinationnameTabela = (char*) malloc(sizeof(argv[2])+5);
        strcpy(destinationnameTabela,argv[2]);
        strcat(destinationnameTabela,".txt");
    }
    // carrega imagem separada em blocos 8x8 RGB
    preparacaoImagem(filename, &fheader, &iheader, &blocos);

    // faz o level shift dos elementos de cada bloco (subtrai 128)
    levelShift(&blocos);
    
    // conta os bits significativos e coloca essa quantidade na tabela
    tabelaBits(blocos, &tabela);

    // converte os blocos em bits, removendo os bits desnecessarios
    conversaoBinario(tabela, blocos, &bits);

    // salva os bits no arquivo de destino
    salvar(destinationname, fheader, iheader, bits);

    // salva a quantidade de bits significativos em um arquivo
    salvarTabela(destinationnameTabela, tabela);

    // libera memoria
    listaBloco b = blocos;
    listaBloco aux = b;
    while (aux != NULL) {
        aux = b->next;
        free(b);
        b = aux;
    }
    free(bits.stream);
    free(tabela.tabela);

    printf("Compressao do arquivo %s feita com sucesso.\n",argv[1]);
    return (EXIT_SUCCESS);
}

