/* Compressão de Imagem Digital
 * Fase 1
 *
 * Materia: SCC0261 Multimidia
 *
 * Entrega:  22/03/2011
 * Grupo: 7
 *  Fábio Abrão Luca
 *  Giulianne Katlauskas Montemurro
 *  Lucas Cuculo Badiale
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

/**** BMP file header structure ****/
typedef struct {
    unsigned short bfType;       /* Magic number for file */
} BMPMAGICNUMBER;

typedef struct {
    unsigned int   bfSize;       /* Size of file */
    unsigned short bfReserved1;  /* Reserved */
    unsigned short bfReserved2;  /* ... */
    unsigned int   bfOffBits;    /* Offset to bitmap data */
} BMPFILEHEADER;

/* bfType deve ser = "MB" */

/**** BMP file info structure ****/
typedef struct {
    unsigned int   biSize;          /* Size of info header */
    int            biWidth;         /* Width of image */
    int            biHeight;        /* Height of image */
    unsigned short biPlanes;        /* Number of color planes */
    unsigned short biBitCount;      /* Number of bits per pixel */
    unsigned int   biCompression;   /* Type of compression to use */
    unsigned int   biSizeImage;     /* Size of image data */
    int            biXPelsPerMeter; /* X pixels per meter */
    int            biYPelsPerMeter; /* Y pixels per meter */
    unsigned int   biClrUsed;       /* Number of colors used */
    unsigned int   biClrImportant;  /* Number of important colors */
} BMPINFOHEADER;

/* blocos 8x8 que formam a imagem em RGB*/
typedef struct Bloco {
    int r[8][8];
    int g[8][8];
    int b[8][8];
    struct Bloco *next;
} noBloco;

/*definicao do ponteiro para a struct Bloco*/
typedef noBloco *listaBloco;

// tabela com quantidades de bits de cada numero dos blocos
typedef struct {
    /* montar esta estrutura
     tabela com quantidade de bits significativos
     por exemplo: 5 é 101 em binário, portanto tem 3 bits significativos
    */
    int *tabela;
    int n;
} TABELABITS;

// os bits
typedef struct {
    char *stream;
    int size;
} BITSTREAM;


// carrega o bitstream do arquivo codificado
void carregarBits(char *decorig, BMPFILEHEADER *decfheader, BMPINFOHEADER *deciheader, BITSTREAM *decbits) {
    char c;
    FILE *fp = fopen(decorig, "rb");
    if (fp != NULL) {
        fread(decfheader, 14, 1, fp);
        fread(deciheader, sizeof(BMPINFOHEADER), 1, fp);
    
        decbits->size = 0;
        decbits->stream = NULL;

        while (fread(&c, sizeof(char), 1, fp) != 0) {
            decbits->size = decbits->size + 1;
            decbits->stream = (char*) realloc (decbits->stream, sizeof(char) * decbits->size);
            decbits->stream[decbits->size - 1] = c;
        }
        fclose(fp);
    } else {
        fprintf(stderr, "Ocorreu um erro ao ler o arquivo %s\n", decorig);
    }
}

// carrega a tabela de quantidade de digitos do arquivo codificado
void carregarTabela(char *dectable, TABELABITS *dectabela) {
    int c;
    FILE *fp = fopen(dectable, "rb");
    if (fp != NULL) {
        dectabela->n = 0;
        dectabela->tabela = NULL;

        while (fread(&c, sizeof(int), 1, fp) != 0) {
            dectabela->n = dectabela->n + 1;
            dectabela->tabela = (int*) realloc (dectabela->tabela, sizeof(int) * dectabela->n);
            dectabela->tabela[dectabela->n - 1] = c;
        }
        fclose(fp);
    } else {
        fprintf(stderr, "Ocorreu um erro ao ler o arquivo %s\n", dectable);
    }
}

// converte om numero do bitstream em um inteiro
int converteInteiro(int *posicao, int *index, int tamanho, BITSTREAM bits) {
    int num = 0;
    int mask, bit_pego;
    int i;
    int primeiro_digito;

    if (tamanho > 0) {
        mask = 1 << (7 - (*posicao));
        primeiro_digito = ((bits.stream[*index] & mask) >> (7 - (*posicao)));
        
        for (i = 0; i < tamanho; i++) {
            mask = 1 << (7 - (*posicao));
            bit_pego = (bits.stream[*index] & mask) >> (7 - (*posicao));
            //if (primeiro_digito == 0) bit_pego = ~bit_pego & 1;
            num = bit_pego | (num << 1);

            *posicao = *posicao + 1;
            if (*posicao > 7) {
                *index = *index + 1;
                *posicao = 0;
            }
        }

        if (primeiro_digito == 0) {
            if (num == 128) {
                num = -num;
            } else {
                num = (-num -1);
            }
        }
    }
    
    return num;
}

// decodifica o bitstream para uma lista de blocos RGB
void desconverteBinarios(TABELABITS dectabela, BITSTREAM decbits, listaBloco *decblocos) {
    listaBloco b;
    int i, j;
    int index = 0;
    int posicao = 0;
    int tabela_pos = 0;
    long int totalbits = 0;
    long int somabits = 0;
    for (i = 0; i < dectabela.n; i++) totalbits += dectabela.tabela[i];


    b = (listaBloco) malloc (sizeof(noBloco));
    b->next = NULL;
    *decblocos = b;
    while (somabits < totalbits || tabela_pos < dectabela.n) {
        for (i = 0; i < 8; i++) {
            for (j = 0; j < 8; j++) {
                somabits += dectabela.tabela[tabela_pos];
                b->r[i][j] = converteInteiro(&posicao, &index, dectabela.tabela[tabela_pos++], decbits);
                somabits += dectabela.tabela[tabela_pos];
                b->g[i][j] = converteInteiro(&posicao, &index, dectabela.tabela[tabela_pos++], decbits);
                somabits += dectabela.tabela[tabela_pos];
                b->b[i][j] = converteInteiro(&posicao, &index, dectabela.tabela[tabela_pos++], decbits);
                
            }
        }

        if (somabits < totalbits || tabela_pos < dectabela.n) {
            b->next = (listaBloco) malloc (sizeof(noBloco));
            b->next->next = NULL;
            b = b->next;
        }
    }
}

// faz o level UNshift dos elementos de cada bloco (soma 128)
void levelUnshift(listaBloco *decblocos) {
    // cada elemento dos bloquinhos varia entre -128 e 127
    // nessa funcao temos que somar 128 de cada elemento.
    listaBloco b = *decblocos;
    int i, j;

    while (b != NULL) {
        for (i = 0; i < 8; i++) {
            for (j = 0; j < 8; j++) {
                b->r[i][j] += 128;
                b->g[i][j] += 128;
                b->b[i][j] += 128;
            }
        }
        b = b->next;
    }
}

// salva o arquivo decodificado
void salvaBMP(char *decsaida, BMPFILEHEADER fheader, BMPINFOHEADER iheader, listaBloco decblocos) {
    // abre o arquivo de saida
    // salva o header de arquivo (fheader) com 14 bytes (nao usar sizeof)
    // salva o header de informacoes (iheader). (pode usar o sizeof neste caso)
    // salva os blocos
    // fecha o arquivo
    FILE *saida;
    int nroBlocosLinha;
    int i, j, l;
    listaBloco b, b1l;
    int contador = 0;
    unsigned short magicnum = 19778;
    
	// abre o arquivo de saida
    saida = fopen(decsaida, "wb");

    if (saida == NULL) {
        fprintf(stderr, "Nao foi possivel abrir o arquivo %s\n ", decsaida);
        exit(EXIT_FAILURE);
    } else {
        // salva o header de arquivo (fheader) com 14 bytes
        fwrite(&magicnum, 2, 1, saida);
        fwrite(&fheader, sizeof(BMPFILEHEADER), 1, saida);
        // salva o header de informacoes (iheader).
        fwrite(&iheader, sizeof(BMPINFOHEADER), 1, saida);
        
        nroBlocosLinha = iheader.biWidth / 8;
        b = decblocos;
        // salva os blocos
        while (b != NULL) {
            b1l = b;
            for (i = 0; i < 8; i++) {
                for (l = 0; l < nroBlocosLinha; l++) {
                    for (j = 0; j < 8; j++) {
                        fputc(b->r[i][j],saida);
                        fputc(b->g[i][j],saida);
                        fputc(b->b[i][j],saida);
                    }
                    b = b->next;
                }
                if (i != 7) b = b1l;
                else contador++;
            }
        }
        // fecha o arquivo
        fclose(saida);
    }
}

/*
 * 
 */
int main(int argc, char** argv) {
    // imagem codificada
    char *decorig;
    
    // arquivo da tabela de bits
    char *dectable;
    
    // arquivo BMP de saida
    char *decsaida;

    // headers do BMP original
    BMPFILEHEADER decfheader;
    BMPINFOHEADER deciheader;

    // os bits
    BITSTREAM decbits;

    // tabela de bits
    TABELABITS dectabela;
    
    // blocos da imagem
    listaBloco decblocos;

    // verificacoes da linha de comando
    if (argc != 3) {
        printf("Uso: %s arquivo.bmp arquivo_comprimido\n",argv[0]);
        exit(EXIT_FAILURE);
    }
    else {
        decsaida = argv[1];
        decorig = argv[2];
        dectable = (char*) malloc(sizeof(argv[2])+5);
        strcpy(dectable,argv[2]);
        strcat(dectable,".txt");
    }

    // carrega os bits codificados
    carregarBits(decorig, &decfheader, &deciheader, &decbits);

    // carrega tabela de bits do arquivo
    carregarTabela(dectable, &dectabela);

    // desconverte os bits
    desconverteBinarios(dectabela, decbits, &decblocos);

    // faz o level UNshift dos elementos de cada bloco (soma 128)
    levelUnshift(&decblocos);

    // salva arquivo descomprimido
    salvaBMP(decsaida, decfheader, deciheader, decblocos);

    // libera memoria
    listaBloco b = decblocos;
    listaBloco aux = b;
    while (aux != NULL) {
        aux = b->next;
        free(b);
        b = aux;
    }
    free(decbits.stream);
    free(dectabela.tabela);

    printf("Arquivo %s descomprimido com sucesso.\n", decsaida);
    return (EXIT_SUCCESS);
}

