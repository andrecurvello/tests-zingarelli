/* Compressão de Imagem Digital
 * Fase 2
 *
 * Materia: SCC0261 Multimidia
 *
 * Entrega:  10/05/2011
 * Grupo: 7
 *  Fábio Abrão Luca
 *  Giulianne Katlauskas Montemurro
 *  Lucas Cuculo Badiale
 */

#include "modulos/compressor.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void show_usage(char *program) {
	printf("Uso:\n");
	printf("\n");
	printf("%s [OPCOES] OPERACAO ENTRADA SAIDA\n\n", program);
	printf("Onde as possiveis opcoes sao:\n");
	printf("\t-t\tPara salvar as tabelas de frequencias em arquivos separados.\n");
	printf("\t-g\tPara criar uma unica tabela de frequencias para todos os ACs.\n");
	printf("\n");
	printf("As operacoes podem ser:\n");
	printf("\tc\tPara comprimir o arquivo bitmap de ENTRADA em um arquivo de SAIDA\n");
	printf("\td\tPara descomprimir o arquivo codificado de ENTRADA em um arquivo bitmap de SAIDA\n");
	printf("\tx\tPara comprimir o bitmpa ENTRADA, e logo em seguida descomprimi-lo em um bitmap de SAIDA\n");
	printf("\t\tmantendo os arquivos intermediarios gerados.\n");
	printf("\th\tPara visualizar esta tela de ajuda.\n");
}

int main(int argc, char** argv) {
	// nome do programa
	char *program = (char*) malloc (sizeof(char) * (strlen(argv[0]) + 1));
	strcpy(program, argv[0]);

	// pula o nome do programa
	argc--;
	argv++;
	
	// opcoes de linha de comando
	int tabelas_separadas = 0; // separar tabelas do arquivo comprimido
	int global            = 0; // separa uma tabela de frequencias global

	// parseia os argumentos
	while (argc > 0 && argv[0][0] == '-') {
		if (strcmp(argv[0], "-t") == 0) {
			tabelas_separadas = 1;
			printf("Salvando tabelas em arquivos separados\n");
			argc--;
			argv++;
		} else if (strcmp(argv[0], "-g") == 0) {
			global = 1;
			printf("Utilizando tabelas globais\n");
			argc--;
			argv++;
		} else {
			fprintf(stderr, "Opcao '%s' desconhecida\n", argv[0]);
			argc--;
			argv++;
		}
	}

	// mostra como usar o programa
	if (argc == 0) {
		show_usage(program);
		return 0;
	} else if (strcmp(argv[0], "h") == 0) {
		show_usage(program);
		return 0;
	} else if (argc != 3) {
		fprintf(stderr, "Numero incorreto de argumentos.\n");
		show_usage(program);
		return 1;
	}
	
	// comprime ou descomprime
	if (strcmp(argv[0], "c") == 0) {
		if (comprimir(argv[1], argv[2], global, tabelas_separadas)) {
			fprintf(stderr, "Erro ao comprimir arquivo.\n");
			return 1;
		} else {
			printf("Arquivo '%s' comprimido com sucesso e salvo em '%s'\n", argv[1], argv[2]);	
		}
	} else if (strcmp(argv[0], "d") == 0) {
		if (descomprime(argv[1], argv[2], global, tabelas_separadas)) {
			fprintf(stderr, "Erro ao descomprimir arquivo.\n");
			return 1;
		} else {
			printf("Arquivo '%s' descomprimido com sucesso e salvo em '%s'\n", argv[1], argv[2]);	
		}
	} else if (strcmp(argv[0], "x") == 0) {
		printf("Comprimindo\n");
		comprimir(argv[1], "temp.local.cod", global, tabelas_separadas);

		printf("Descomprimindo\n");
		descomprime("temp.local.cod", argv[2], global, tabelas_separadas);

		printf("Fim do programa\n");	
	} else if (strcmp(argv[0], "v") == 0) {
		bmp_equals(argv[1], argv[2]);
	} else {
		fprintf(stderr, "Opcao '%s' invalida\n", argv[0]);
		return 1;
	}

	return 0;
}
