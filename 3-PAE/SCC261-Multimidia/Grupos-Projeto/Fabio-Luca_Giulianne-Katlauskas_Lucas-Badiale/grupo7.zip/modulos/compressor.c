/* Compressão de Imagem Digital
 * Fase 2
 *
 * Materia: SCC0261 Multimidia
 *
 * Entrega:  10/05/2011
 * Grupo: 7
 *  Fábio Abrão Luca
 *  Giulianne Katlauskas Montemurro
 *  Lucas Cuculo Badiale
 */

#include "compressor.h"

#include "prepara.h"
#include "vetorizacao.h"
#include "diferencas.h"
#include "carreira/carreira.h"
#include "bitstream.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int comprimir (char *filename, char *destinationname, int global, int tabelas_separadas) {

    // Headers do BMP original
    BMPFILEHEADER fheader;
    BMPINFOHEADER iheader;

	// bloco 8x8 de cada matriz RGB
    listaBloco blocos;

	// carrega imagem separada em blocos 8x8 RGB
    preparacaoImagem(filename, &fheader, &iheader, &blocos);

    // faz o level shift dos elementos de cada bloco (subtrai 128)
    levelShift(&blocos);

	// Vetorizacao dos blocos
	ListaRGB *lrgb = vetoriza(blocos);
	ListaVetor *lvr = lrgb->r;
	ListaVetor *lvg = lrgb->g;
	ListaVetor *lvb = lrgb->b;
	
	// Abre arquivo binario para gravacao	
	FILE *fd = fopen(destinationname,"wb");
	
	// escreve os headers
	fwrite(&fheader, sizeof(BMPFILEHEADER), 1, fd);
	fwrite(&iheader, sizeof(BMPINFOHEADER), 1, fd);

	// Codificacao dos DCs por Diferencas
	FILE *tabela = NULL;
	if (tabelas_separadas) tabela = fopen("tabelas_diff", "wb");
	diferencas_encode(lvr,fd, tabela);
	diferencas_encode(lvg,fd, tabela);
	diferencas_encode(lvb,fd, tabela);
	if (tabelas_separadas) fclose(tabela);

	// Codificacao dos ACs por Carreira
	if (tabelas_separadas) tabela = fopen("tabelas_run", "wb");
	CarreiraCode (fd, lvr, global, tabela);
	CarreiraCode (fd, lvg, global, tabela);
	CarreiraCode (fd, lvb, global, tabela);
	if (tabelas_separadas) fclose(tabela);

	fclose(fd);

    // libera memoria
	limpa_listavetor(lvr);
	limpa_listavetor(lvg);
	limpa_listavetor(lvb);
    listaBloco b = blocos;
    listaBloco aux = b;
    while (aux != NULL) {
        aux = b->next;
        free(b);

        b = aux;
    }

    return (EXIT_SUCCESS);
}

int descomprime (char *decorig, char *decsaida, int global, int tabelas_separadas) {

    // headers do BMP original
    BMPFILEHEADER decfheader;
    BMPINFOHEADER deciheader;

    // blocos da imagem
    listaBloco decblocos;

	// Abre arquivo binario para leitura
	FILE *fd = fopen(decorig,"rb");

	// le os headers
	fread(&decfheader, sizeof(BMPFILEHEADER), 1, fd);
	fread(&deciheader, sizeof(BMPINFOHEADER), 1, fd);

	// Leitura e decodificacao dos DCs - Diferencas
	FILE *tabela = NULL;
	if (tabelas_separadas) tabela = fopen("tabelas_diff", "rb");
	ListaVetor *auxr = diferencas_decode(fd, tabela);
	ListaVetor *auxg = diferencas_decode(fd, tabela);
	ListaVetor *auxb = diferencas_decode(fd, tabela);
	if (tabelas_separadas) fclose(tabela);
	
	// Leitura e decodificacao dos ACs - Carreira
	if (tabelas_separadas) tabela = fopen("tabelas_run", "rb");
	ListaVetor *lvr = CarreiraDeCode(fd, global, tabela);
	ListaVetor *lvg = CarreiraDeCode(fd, global, tabela);
	ListaVetor *lvb = CarreiraDeCode(fd, global, tabela);
	if (tabelas_separadas) fclose(tabela);

	// junta os DCs com os ACs
	int i;
	for (i = 0; i < lvr->size; i++) (*pega_listavetor(lvr, i))[0] = (*pega_listavetor(auxr, i))[0];
	for (i = 0; i < lvg->size; i++) (*pega_listavetor(lvg, i))[0] = (*pega_listavetor(auxg, i))[0];
	for (i = 0; i < lvb->size; i++) (*pega_listavetor(lvb, i))[0] = (*pega_listavetor(auxb, i))[0];

	// retira os auxiliares da memoria
	limpa_listavetor(auxr);
	limpa_listavetor(auxg);
	limpa_listavetor(auxb);
	
	// Monta estrutura para desvetorizacao em um unico passo
	ListaRGB *lrgb = (ListaRGB*) malloc(sizeof(ListaRGB));
	lrgb->r = lvr;
	lrgb->g = lvg;
	lrgb->b = lvb;
	lrgb->size = lvr->size;
	
	// Desvetoriza blocos
	decblocos = desvetoriza(lrgb);	

    // faz o level UNshift dos elementos de cada bloco (soma 128)
    levelUnshift(&decblocos);

    // salva arquivo descomprimido
    salvaBMP(decsaida, decfheader, deciheader, decblocos);

    // libera memoria
    listaBloco b = decblocos;
    listaBloco aux = b;
    while (aux != NULL) {
        aux = b->next;
        free(b);
        b = aux;
    }
    
    return (EXIT_SUCCESS);
}

// verifica se duas imagems BMP sao iguais
void bmp_equals (char *a, char *b) {
	FILE *fa = fopen(a, "rb");
	FILE *fb = fopen(b, "rb");
	
	int i;

	BMPMAGICNUMBER magic_a, magic_b;
	BMPFILEHEADER file_a, file_b;
	BMPINFOHEADER info_a, info_b;
	char ra, rb;
	char ga, gb;
	char ba, bb;
	
	if (fread(&magic_a, 2, 1, fa) == 0) { printf("End of file: %s\n", a); exit(EXIT_FAILURE);};
	if (fread(&magic_b, 2, 1, fb) == 0) { printf("End of file: %s\n", b); exit(EXIT_FAILURE);};

	if (magic_a.bfType != magic_b.bfType) printf("Magic number are diferent: %d != %d\n", magic_a.bfType, magic_b.bfType);
	else printf("Magic numbers are fine.\n");
	
	if (fread(&file_a, sizeof(BMPFILEHEADER), 1, fa) == 0) { printf("End of file: %s\n", a); exit(EXIT_FAILURE);};
	if (fread(&file_b, sizeof(BMPFILEHEADER), 1, fb) == 0) { printf("End of file: %s\n", b); exit(EXIT_FAILURE);};
	if (fread(&info_a, sizeof(BMPINFOHEADER), 1, fa) == 0) { printf("End of file: %s\n", a); exit(EXIT_FAILURE);};
	if (fread(&info_b, sizeof(BMPINFOHEADER), 1, fb) == 0) { printf("End of file: %s\n", b); exit(EXIT_FAILURE);};

	printf("Cheking headers...\n");
	if (file_a.bfSize != file_b.bfSize) 
		printf("The sizes are diferent: %d != %d\n", file_a.bfSize, file_b.bfSize);
	if (file_a.bfReserved1 != file_b.bfReserved1) 
		printf("The reserved1 are diferent: %d != %d\n", file_a.bfReserved1, file_b.bfReserved1);
	if (file_a.bfReserved2 != file_b.bfReserved2) 
		printf("The reserved2 are diferent: %d != %d\n", file_a.bfReserved2, file_b.bfReserved2);
	if (file_a.bfOffBits != file_b.bfOffBits) 
		printf("The byte offsets are diferent: %d != %d\n", file_a.bfOffBits, file_b.bfOffBits);
	if (info_a.biSize != info_b.biSize) 
		printf("The size are diferent: %d != %d\n", info_a.biSize, info_b.biSize);
	if (info_a.biWidth != info_b.biWidth) 
		printf("The width are diferent: %d != %d\n", info_a.biWidth, info_b.biWidth);
	if (info_a.biHeight != info_b.biHeight) 
		printf("The height are diferent: %d != %d\n", info_a.biHeight, info_b.biHeight);
	if (info_a.biPlanes != info_b.biPlanes) 
		printf("The planes are diferent: %d != %d\n", info_a.biPlanes, info_b.biPlanes);
	if (info_a.biBitCount != info_b.biBitCount) 
		printf("The bit count are diferent: %d != %d\n", info_a.biBitCount, info_b.biBitCount);
	if (info_a.biCompression != info_b.biCompression) 
		printf("The compression are diferent: %d != %d\n", info_a.biCompression, info_b.biCompression);
	if (info_a.biSizeImage != info_b.biSizeImage) 
		printf("The size image are diferent: %d != %d\n", info_a.biSizeImage, info_b.biSizeImage);
	if (info_a.biXPelsPerMeter != info_b.biXPelsPerMeter) 
		printf("The x pels per meter are diferent: %d != %d\n", info_a.biXPelsPerMeter, info_b.biXPelsPerMeter);
	if (info_a.biYPelsPerMeter != info_b.biYPelsPerMeter) 
		printf("The y pels per meter are diferent: %d != %d\n", info_a.biYPelsPerMeter, info_b.biYPelsPerMeter);
	if (info_a.biClrUsed != info_b.biClrUsed) 
		printf("The colors used are diferent: %d != %d\n", info_a.biClrUsed, info_b.biClrUsed);
	if (info_a.biClrImportant != info_b.biClrImportant) 
		printf("The colors important are diferent: %d != %d\n", info_a.biClrImportant, info_b.biClrImportant);
	printf("Headers checked.\n");

	// compara todas as cores
	i = 0;
	printf("Checking colors...\n");
	while (!feof(fa) && !feof(fb)) {
		// compara o vermelho
		ra = fgetc(fa);
		rb = fgetc(fb);
		if (ra != rb) printf("Different RED   in position %d: %d != %d\n", i, (int) ra, (int) rb);

		// compara o verde 
		ga = fgetc(fa);
		gb = fgetc(fb);
		if (ga != gb) printf("Different GREEN in position %d: %d != %d\n", i, (int) ga, (int) gb);

		// compara o azul
		ba = fgetc(fa);
		bb = fgetc(fb);
		if (ba != bb) printf("Different BLUE  in position %d: %d != %d\n", i, (int) ba, (int) bb);
		
		i++;
	}
	printf("%d blocks checked.\n", i - 1);

	if (feof(fa)) printf("End of file: %s\n", a);
	else printf("'%s' not ended\n", a);

	if (feof(fb)) printf("End of file: %s\n", b);
	else printf("'%s' not ended\n", b);

	fclose(fa);
	fclose(fb);
}
