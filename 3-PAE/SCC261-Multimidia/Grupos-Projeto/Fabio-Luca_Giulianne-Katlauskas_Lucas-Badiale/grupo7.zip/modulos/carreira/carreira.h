/* Compressão de Imagem Digital
 * Fase 2
 *
 * Materia: SCC0261 Multimidia
 *
 * Entrega:  10/05/2011
 * Grupo: 7
 *  Fábio Abrão Luca
 *  Giulianne Katlauskas Montemurro
 *  Lucas Cuculo Badiale
 */

#ifndef _CARREIRA_H_
#define _CARREIRA_H_

#include "../vetorizacao.h"
#include "../bitstream.h"
#include "carreira_vetor_frequencias.h"
#include "carreira_huffman.h"

#include <stdio.h>

// codifica um vetor com carreiras e salva num arquivo
void CarreiraCodeVetor (BITSTREAM *bits, Vetor *v, CarreiraVetorFrequencias *cvf, CarreiraHuffman *ch, BITSTREAM *tabela);

// le um arquivo e descodifica com carreiras um vetor
Vetor* CarreiraDeCodeVetor (BITSTREAM *bits, CarreiraVetorFrequencias *cvf, CarreiraHuffman *ch, BITSTREAM *tabela);

// codifica uma lista de vetores e salva num arquivo
// global especifica se sao usadas tabelas de frequencia globais
void CarreiraCode (FILE *fp, ListaVetor *lv, int global, FILE *tabela);

// decodifica uma lista de vetores, lendo de um arquivo
// global especifica se sao usadas tabelas de frequencia globais
ListaVetor *CarreiraDeCode (FILE *fp, int global, FILE *tabela);

#endif
