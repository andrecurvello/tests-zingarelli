/* Compressão de Imagem Digital
 * Fase 2
 *
 * Materia: SCC0261 Multimidia
 *
 * Entrega:  10/05/2011
 * Grupo: 7
 *  Fábio Abrão Luca
 *  Giulianne Katlauskas Montemurro
 *  Lucas Cuculo Badiale
 */

#ifndef _CARREIRA_FREQUENCIA_H_
#define _CARREIRA_FREQUENCIA_H_

#include "carreira_skip_sss.h"
#include "../bitstream.h"

// frequencia de um par (skip, sss)
typedef struct {
	CarreiraSkipSSS* simbolo;
	int frequencia;
	BITSTREAM *bitstream;
} CarreiraFrequencia;

// constructors
CarreiraFrequencia* CarreiraFrequenciaNew (CarreiraSkipSSS *css);

// destructors
void CarreiraFrequenciaDelete (CarreiraFrequencia *cf);

// setters
void CarreiraFrequenciaSetSkip       (CarreiraFrequencia *cf, int skip);
void CarreiraFrequenciaSetSSS        (CarreiraFrequencia *cf, int sss);
void CarreiraFrequenciaSetSimble     (CarreiraFrequencia *cf, CarreiraSkipSSS *css);
void CarreiraFrequenciaSetFrequencia (CarreiraFrequencia *cf, int frequencia);
void CarreiraFrequenciaSetBitstream  (CarreiraFrequencia *cf, BITSTREAM *bitstream);

// getters
int              CarreiraFrequenciaGetSkip       (CarreiraFrequencia *cf);
int              CarreiraFrequenciaGetSSS        (CarreiraFrequencia *cf);
CarreiraSkipSSS* CarreiraFrequenciaGetSimble     (CarreiraFrequencia *cf);
int              CarreiraFrequenciaGetFrequencia (CarreiraFrequencia *cf);
BITSTREAM*       CarreiraFrequenciaGetBitstream  (CarreiraFrequencia *cf);

// other methods

// aumenta a frequencia (frequencia++)
void CarreiraFrequenciaFrequenciaUp (CarreiraFrequencia *cf);

// converte a frequencia para string
char* CarreiraFrequenciaToString (CarreiraFrequencia *cf);

// compara duas frequencias
int CarreiraFrequenciaEqualsSimble     (CarreiraFrequencia *cf1, CarreiraFrequencia *cf2);
int CarreiraFrequenciaEqualsFrequencia (CarreiraFrequencia *cf1, CarreiraFrequencia *cf2);

#endif
