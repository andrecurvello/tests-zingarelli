/* Compressão de Imagem Digital
 * Fase 2
 *
 * Materia: SCC0261 Multimidia
 *
 * Entrega:  10/05/2011
 * Grupo: 7
 *  Fábio Abrão Luca
 *  Giulianne Katlauskas Montemurro
 *  Lucas Cuculo Badiale
 */

#ifndef _CARREIRA_VETOR_FREQUENCIAS_H_
#define _CARREIRA_VETOR_FREQUENCIAS_H_

#include "carreira_skip_sss.h"
#include "carreira_frequencia.h"

#include <stdio.h>

// tabela com as frequencias (para montar o huffman)
typedef struct {
	CarreiraFrequencia** simbolos;
	int size;
} CarreiraVetorFrequencias;

// constructors
CarreiraVetorFrequencias* CarreiraVetorFrequenciasNew ();

// destructors
void CarreiraVetorFrequenciasDelete (CarreiraVetorFrequencias *cvf);

// add
void CarreiraVetorFrequenciasAddAt (CarreiraVetorFrequencias *cvf, int index, CarreiraFrequencia *cf);

void CarreiraVetorFrequenciasAdd (CarreiraVetorFrequencias *cvf, CarreiraSkipSSS *css);

// get
int CarreiraVetorFrequenciasGetSize (CarreiraVetorFrequencias *cvf);
CarreiraFrequencia* CarreiraVetorFrequenciasGet (CarreiraVetorFrequencias *cvf, int index);

// remove
void CarreiraVetorFrequenciasRemove (CarreiraVetorFrequencias *cvf, int index);

// searchs
CarreiraFrequencia* CarreiraVetorFrequenciasSearch (CarreiraVetorFrequencias *cvf, CarreiraFrequencia *cf);

// busca por um (skip,sss)
CarreiraFrequencia* CarreiraVetorFrequenciasSearchSkipSSS (CarreiraVetorFrequencias *cvf, CarreiraSkipSSS *css);

// other methods
// ordena o vetor
void CarreiraVetorFrequenciasSort (CarreiraVetorFrequencias *cvf);

// ordena o vetor pelas frequencias
void CarreiraVetorFrequenciasSortFrequencia (CarreiraVetorFrequencias *cvf);

// salva a tabela de frequencias
void CarreiraVetorFrequenciasSave (CarreiraVetorFrequencias *cvf, FILE *fp);

// carrega a tabela de frequencias
void CarreiraVetorFrequenciasLoad (CarreiraVetorFrequencias **cvf, FILE *fp);

// salva a tabela de frequencias usando menos bits
void CarreiraVetorFrequenciasSaveMinimun (CarreiraVetorFrequencias *cvf, BITSTREAM *bits);

// carrega a tabela de frequencias usando menos bits
void CarreiraVetorFrequenciasLoadMinimun (CarreiraVetorFrequencias **cvf, BITSTREAM *bits);

#endif
