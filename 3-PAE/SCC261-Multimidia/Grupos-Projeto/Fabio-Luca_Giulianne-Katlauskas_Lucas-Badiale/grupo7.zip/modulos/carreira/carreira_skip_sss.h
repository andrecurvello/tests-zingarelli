/* Compressão de Imagem Digital
 * Fase 2
 *
 * Materia: SCC0261 Multimidia
 *
 * Entrega:  10/05/2011
 * Grupo: 7
 *  Fábio Abrão Luca
 *  Giulianne Katlauskas Montemurro
 *  Lucas Cuculo Badiale
 */

#ifndef _CARREIRA_SKIP_SSS_H_
#define _CARREIRA_SKIP_SSS_H_

#include "carreira_skip_value.h"

// skip e o sss (quantidade de bits) do valor
typedef struct {
	int skip;
	int sss;
} CarreiraSkipSSS;

// constructors
CarreiraSkipSSS* CarreiraSkipSSSNew (CarreiraSkipValue *csv);
CarreiraSkipSSS* CarreiraSkipSSSNewSSS (int skip, int sss);
CarreiraSkipSSS* CarreiraSkipSSSNewValue (int skip, int value);

// destructors
void CarreiraSkipSSSDelete (CarreiraSkipSSS *css);

// setters
void CarreiraSkipSSSSetSkip (CarreiraSkipSSS *css, int skip);
void CarreiraSkipSSSSetSSS  (CarreiraSkipSSS *css, int sss );

// getters
int CarreiraSkipSSSGetSkip (CarreiraSkipSSS *css);
int CarreiraSkipSSSGetSSS  (CarreiraSkipSSS *css);

// others

// converte para string
char *CarreiraSkipSSSToString (CarreiraSkipSSS *css);

// compara dois pares (skip, sss)
int CarreiraSkipSSSEquals (CarreiraSkipSSS *css1, CarreiraSkipSSS *css2);

#endif
