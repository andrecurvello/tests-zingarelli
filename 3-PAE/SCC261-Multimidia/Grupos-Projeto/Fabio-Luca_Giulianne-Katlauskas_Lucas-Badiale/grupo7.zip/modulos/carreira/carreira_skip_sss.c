/* Compressão de Imagem Digital
 * Fase 2
 *
 * Materia: SCC0261 Multimidia
 *
 * Entrega:  10/05/2011
 * Grupo: 7
 *  Fábio Abrão Luca
 *  Giulianne Katlauskas Montemurro
 *  Lucas Cuculo Badiale
 */

#include "carreira_skip_sss.h"
#include "carreira_skip_value.h"
#include "../bitstream.h"

#include <stdlib.h>
#include <stdio.h>

// constructors
CarreiraSkipSSS* CarreiraSkipSSSNew (CarreiraSkipValue *csv) {
	return CarreiraSkipSSSNewValue (CarreiraSkipValueGetSkip(csv), CarreiraSkipValueGetValue(csv));
}

CarreiraSkipSSS* CarreiraSkipSSSNewSSS (int skip, int sss) {
	CarreiraSkipSSS *css = (CarreiraSkipSSS*) malloc (sizeof(CarreiraSkipSSS));
	css->skip = skip;
	css->sss = sss;
	return css;
}

CarreiraSkipSSS* CarreiraSkipSSSNewValue (int skip, int value) {
	CarreiraSkipSSS *css = (CarreiraSkipSSS*) malloc (sizeof(CarreiraSkipSSS));

	css->skip = skip;
	css->sss = nbits(value);

	return css;
}

// destructors
void CarreiraSkipSSSDelete (CarreiraSkipSSS *css) {
	if (css != NULL) {
		free(css);
		css = NULL;
	}
}

// setters
void CarreiraSkipSSSSetSkip (CarreiraSkipSSS *css, int skip) { css->skip = skip; }
void CarreiraSkipSSSSetSSS  (CarreiraSkipSSS *css, int sss ) { css->sss  = sss ; }

// getters
int CarreiraSkipSSSGetSkip (CarreiraSkipSSS *css) { return css->skip; }
int CarreiraSkipSSSGetSSS  (CarreiraSkipSSS *css) { return css->sss ; }

// others

// converte para string
char *CarreiraSkipSSSToString (CarreiraSkipSSS *css) {
	char *string = (char*) malloc (sizeof(char) * (11));

	int erro = !sprintf (string, "(%3d, %3d)",
			CarreiraSkipSSSGetSkip(css),
			CarreiraSkipSSSGetSSS(css));

	if (erro) {
		perror("CarreiraSkipSSSToString ");
		free(string);
		string = NULL;
	}

	return string;
}

// compara dois pares (skip, sss)
int CarreiraSkipSSSEquals (CarreiraSkipSSS *css1, CarreiraSkipSSS *css2) {
	int retorno = 0;
	
	if (css1->skip < css2->skip) {
		retorno = -1;
	} else if (css1->skip == css2->skip) {
		if (css1->sss < css2->sss) {
			retorno = -1;
		} else if (css1->sss == css2->sss) {
			retorno = 0;
		} else {
			retorno = 1;
		}
	} else {
		retorno = 1;
	}

	return retorno;
}

//// teste de unidade
//int main (void) {
//	CarreiraSkipValue *csv1 = CarreiraSkipValueNew (10, 2);
//	CarreiraSkipValue *csv2 = CarreiraSkipValueNew (1, -5);
//	
//	CarreiraSkipSSS* css1 = CarreiraSkipSSSNew (csv1);
//	CarreiraSkipSSS* css2 = CarreiraSkipSSSNew (csv2);
//
//	printf("%s -> %s\n", CarreiraSkipValueToString(csv1), CarreiraSkipSSSToString(css1));
//	printf("%s -> %s\n", CarreiraSkipValueToString(csv2), CarreiraSkipSSSToString(css2));
//
//	CarreiraSkipSSSDelete (css1);
//	CarreiraSkipSSSDelete (css2);
//
//	CarreiraSkipValueDelete (csv1);
//	CarreiraSkipValueDelete (csv2);
//	
//	return 0;
//}
