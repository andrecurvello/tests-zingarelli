/* Compressão de Imagem Digital
 * Fase 2
 *
 * Materia: SCC0261 Multimidia
 *
 * Entrega:  10/05/2011
 * Grupo: 7
 *  Fábio Abrão Luca
 *  Giulianne Katlauskas Montemurro
 *  Lucas Cuculo Badiale
 */

#include "carreira_huffman.h"

#include "carreira_frequencia.h"
#include "carreira_vetor_frequencias.h"
#include "../bitstream.h"

#include <stdlib.h>

// aloca um novo noh na memoria
void CarreiraHuffmanNew (
		CarreiraHuffman ** ch, 
		int peso, CarreiraFrequencia *simbolo, 
		CarreiraHuffman *esquerda, 
		CarreiraHuffman *direita) {
	*ch = (CarreiraHuffman*) malloc (sizeof(CarreiraHuffman));
	(*ch)->peso = peso;
	(*ch)->simbolo = simbolo;
	(*ch)->esquerda = esquerda;
	(*ch)->direita = direita;
}

// remove um noh da memoria
void CarreiraHuffmanDelete (CarreiraHuffman **ch) {
	if (*ch != NULL) free(*ch);
	*ch = NULL;
}

// remove uma arvore de huffman da memoria
// recursivo
void CarreiraHuffmanDeleteTree (CarreiraHuffman **ch) {
	if (*ch != NULL) {
		CarreiraHuffmanDeleteTree(&((*ch)->esquerda)); // nao se perca nos ponteiros
		CarreiraHuffmanDeleteTree(&((*ch)->direita));
		CarreiraHuffmanDelete(ch);
	}
}

// pega um no da esquerda
CarreiraHuffman *CarreiraHuffmanGetLeft (CarreiraHuffman *pai) {
	return CarreiraHuffmanGet(pai, CH_ESQUERDA);
}

// pega um no da direita
CarreiraHuffman *CarreiraHuffmanGetRight (CarreiraHuffman *pai) {
	return CarreiraHuffmanGet(pai, CH_DIREITA);
}

// pega um no da esquerda ou da direita, se o bit for 1 ou 0, respectivamente
CarreiraHuffman *CarreiraHuffmanGet (CarreiraHuffman *pai, int bit) {
	CarreiraHuffman *retorno = NULL;
	
	if (pai != NULL) {
		if (bit == CH_DIREITA) {
			retorno = pai->direita;
		} else {
			retorno = pai->esquerda;
		}
	}

	return retorno;
}

// monta os codigos de huffman a partir da arvore de huffman
// recursivo
void CarreiraHuffmanCreateCodesRec (CarreiraHuffman *pai, CarreiraVetorFrequencias *cvf, BITSTREAM *bitstream) {
	if (pai != NULL) {
		if (pai->simbolo != NULL) {
			// noh folha
			// busca pelo no, e seta o bitstream correto
			CarreiraFrequencia *cf = CarreiraVetorFrequenciasSearch(cvf, pai->simbolo);
			CarreiraFrequenciaSetBitstream(cf, bitstream);
		} else {
			// filho da esquerda
			BITSTREAM *esq = bitstream_new();
			bitstream_copy (bitstream, esq);
			bitstream_add_bit(esq, CH_ESQUERDA);
			CarreiraHuffmanCreateCodesRec(CarreiraHuffmanGetLeft(pai), cvf, esq);

			// filho da direita
			BITSTREAM *dir = bitstream_new();
			bitstream_copy (bitstream, dir);
			bitstream_add_bit(dir, CH_DIREITA);
			CarreiraHuffmanCreateCodesRec(CarreiraHuffmanGetRight(pai), cvf, dir);
		
			// libera memoria
			bitstream_delete(bitstream);
		}
	}
}

// monta os codigos de huffman a partir da arvore de huffman
void CarreiraHuffmanCreateCodes (CarreiraHuffman *pai, CarreiraVetorFrequencias *cvf) {
	CarreiraHuffmanCreateCodesRec (pai, cvf, bitstream_new());
}

// cria uma arvore de huffman, usando a tabela de frequencias
void CarreiraHuffmanCreate (CarreiraHuffman **pai, CarreiraVetorFrequencias *cvf) {
	int i;
	
	if (cvf->size == 1) {
		// coloca o unico elemento na raiz da arvore
		CarreiraHuffman *no = NULL;
		CarreiraFrequencia *cf = CarreiraVetorFrequenciasGet(cvf, 0);
		CarreiraHuffmanNew(&no, cf->frequencia, cf, NULL, NULL);

		// coloca o codigo de huffman como sendo 0
		CarreiraFrequenciaSetBitstream(cf, bitstream_new());

		*pai = no;
	} else {
		CarreiraVetorFrequenciasSort(cvf);
		CarreiraVetorFrequenciasSortFrequencia(cvf);

		// coloca todos os elementos nos nohs finais
		CarreiraHuffman **lista = (CarreiraHuffman**) malloc (sizeof(CarreiraHuffman*) * cvf->size);
		for (i = 0; i < cvf->size; i++) {
			CarreiraFrequencia *cf = CarreiraVetorFrequenciasGet(cvf, i);
			int peso = cf->frequencia;
			CarreiraHuffmanNew (&(lista[i]), peso, cf, NULL, NULL);
		}

		int n = cvf->size;
		int inicio = 0;
		while (inicio < n - 1) {
			CarreiraHuffman *no;
			CarreiraHuffmanNew(
					&no,                                              // noh
					lista[inicio]->peso + lista[inicio+1]->peso,      // peso total dos nohs
					NULL,                                             // nao tem simbolo, nao eh noh folha
					lista[inicio],                                    // filho da esquerda
					lista[inicio+1]);                                 // filho da direita

			// retira os dois primeiros da lista
			lista[inicio] = NULL;
			lista[inicio+1] = NULL;

			// coloca o novo noh em ordem
			i = inicio + 2;
			while ((i < n) && (no->peso > (lista[i])->peso)) {
				lista[i - 1] = lista[i];
				i++;
			}
			lista[i - 1] = no;
			
			// remove um elemento da lista (isto eh, tiramos 2 filhos e colocamos 1 pai no lugar)
			inicio++;
		}

		*pai = lista[n - 1];

		// gera os codigos de huffman
		CarreiraVetorFrequenciasSort(cvf);
		CarreiraHuffmanCreateCodes(*pai, cvf);
	}
}

// exibe a arvore de huffman
void CarreiraHuffmanPrint(CarreiraHuffman *pai) {
	if (pai != NULL) {
		printf("Pai\n");
		printf("%d", pai->peso);
		if (pai->simbolo != NULL) 
			printf("%s", CarreiraFrequenciaToString(pai->simbolo));
		printf("\n");

		printf("Esquerda\n");
		CarreiraHuffmanPrint(CarreiraHuffmanGetLeft(pai));
		printf("Fim Esquerda\n");
		
		printf("Direita\n");
		CarreiraHuffmanPrint(CarreiraHuffmanGetRight(pai));
		printf("Fim Direita\n");
		printf("Fim Pai\n");
	}
}

// pega o sss, percorrendo uma arvore de huffman
// recursivo
CarreiraSkipSSS* CarreiraHuffmanGetSimbleRec (CarreiraHuffman *pai, BITSTREAM *bitstream) {
	if (pai != NULL) {
		// noh folha
		if (pai->simbolo != NULL) {
			return pai->simbolo->simbolo;

		// no diretorio
		} else {
			int bit = bitstream_get_bit(bitstream);
			return CarreiraHuffmanGetSimbleRec(CarreiraHuffmanGet(pai, bit), bitstream);
		}
	} else {
		return NULL;
	}
}

// pega o sss, percorrendo uma arvore de huffman
CarreiraSkipSSS* CarreiraHuffmanGetSimble (CarreiraHuffman *pai, BITSTREAM *bitstream) {
	return CarreiraHuffmanGetSimbleRec (pai, bitstream);
}

//// teste de unidade
//int main (void) {
//	CarreiraSkipSSS *css1 = CarreiraSkipSSSNewValue( 2, 4);
//	CarreiraSkipSSS *css2 = CarreiraSkipSSSNewValue(10,-2);
//	CarreiraSkipSSS *css3 = CarreiraSkipSSSNewValue( 1, 5);
//	
//	CarreiraVetorFrequencias* cvf = CarreiraVetorFrequenciasNew ();
//	
//	// criando um vetor de frequencias para o teste
//	CarreiraVetorFrequenciasAdd(cvf, css1);
//	CarreiraVetorFrequenciasAdd(cvf, css2);
//	CarreiraVetorFrequenciasAdd(cvf, css3);
//	CarreiraVetorFrequenciasAdd(cvf, css3);
//
//	int i;
//	for (i = 0; i < CarreiraVetorFrequenciasGetSize(cvf); i++) {
//		printf("%s\n", CarreiraFrequenciaToString(CarreiraVetorFrequenciasGet(cvf, i)));
//	}
//	
//	// monta a arvore de huffman
//	CarreiraHuffman *arvore = NULL;
//	CarreiraHuffmanCreate (&arvore, cvf);
//
//	// exibe a arvore
//	CarreiraHuffmanPrint(arvore);
//	
//	// exibe a tabela de frequencias, agora com os codigos huffman
//	for (i = 0; i < CarreiraVetorFrequenciasGetSize(cvf); i++) {
//		printf("%s\n", CarreiraFrequenciaToString(CarreiraVetorFrequenciasGet(cvf, i)));
//	}
//
//	// deleta a arvore
//	CarreiraHuffmanDelete(&arvore);
//
//	CarreiraVetorFrequenciasDelete (cvf);
//
//	CarreiraSkipSSSDelete (css1);
//	CarreiraSkipSSSDelete (css2);
//	CarreiraSkipSSSDelete (css3);
//	return 0;
//}
