/* Compressão de Imagem Digital
 * Fase 2
 *
 * Materia: SCC0261 Multimidia
 *
 * Entrega:  10/05/2011
 * Grupo: 7
 *  Fábio Abrão Luca
 *  Giulianne Katlauskas Montemurro
 *  Lucas Cuculo Badiale
 */

#ifndef _PREPARA_H_
#define _PREPARA_H_

/**** BMP file header structure ****/
typedef struct {
    unsigned short bfType;       /* Magic number for file */
} BMPMAGICNUMBER;

typedef struct {
    unsigned int   bfSize;       /* Size of file */
    unsigned short bfReserved1;  /* Reserved */
    unsigned short bfReserved2;  /* ... */
    unsigned int   bfOffBits;    /* Offset to bitmap data */
} BMPFILEHEADER;

/* bfType deve ser = "MB" */

/**** BMP file info structure ****/
typedef struct {
    unsigned int   biSize;          /* Size of info header */
    int            biWidth;         /* Width of image */
    int            biHeight;        /* Height of image */
    unsigned short biPlanes;        /* Number of color planes */
    unsigned short biBitCount;      /* Number of bits per pixel */
    unsigned int   biCompression;   /* Type of compression to use */
    unsigned int   biSizeImage;     /* Size of image data */
    int            biXPelsPerMeter; /* X pixels per meter */
    int            biYPelsPerMeter; /* Y pixels per meter */
    unsigned int   biClrUsed;       /* Number of colors used */
    unsigned int   biClrImportant;  /* Number of important colors */
} BMPINFOHEADER;

/* blocos 8x8 que formam a imagem em RGB*/
typedef struct Bloco {
    int r[8][8];
    int g[8][8];
    int b[8][8];
    struct Bloco *next;
} noBloco;

/*definicao do ponteiro para a struct Bloco*/
typedef noBloco *listaBloco;

/*cria nova lista*/
void novaLista(listaBloco *lista);

/*cria um novo bloco*/
listaBloco AllocLista();

/*adiciona um novo bloco na lista*/
listaBloco novoBloco(listaBloco *lista);

/*confere se a lista esta vazia*/
int listaVazia(listaBloco lista);

void preparacaoImagem(char * filename, BMPFILEHEADER *fHeader, BMPINFOHEADER *header, listaBloco *bloco);

// salva o arquivo decodificado
void salvaBMP(char *decsaida, BMPFILEHEADER fheader, BMPINFOHEADER iheader, listaBloco decblocos);

// faz o level shift dos elementos de cada bloco (subtrai 128)
void levelShift(listaBloco *blocos);

// faz o level UNshift dos elementos de cada bloco (soma 128)
void levelUnshift(listaBloco *decblocos);

#endif
