/* Compressão de Imagem Digital
 * Fase 2
 *
 * Materia: SCC0261 Multimidia
 *
 * Entrega:  10/05/2011
 * Grupo: 7
 *  Fábio Abrão Luca
 *  Giulianne Katlauskas Montemurro
 *  Lucas Cuculo Badiale
 */

#ifndef _COMPRIME_H_
#define _COMPRIME_H_

// comprime a imagem filename, salvando ela em destinationame
// global especifica se sao usadas tabelas de frequencia globais
int comprimir (char *filename, char *destinationname, int global, int tabelas_separadas);

// descomprime uma imagem decorig, salvando em decsaida
// global especifica se sao usadas tabelas de frequencia globais
int descomprime (char *decorig, char *decsaida, int global, int tabelas_separadas);

// verifica se duas imagems BMP sao iguais
void bmp_equals (char *a, char *b);

#endif
