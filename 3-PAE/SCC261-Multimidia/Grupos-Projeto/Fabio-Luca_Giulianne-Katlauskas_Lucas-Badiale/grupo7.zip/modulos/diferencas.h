/* Compressão de Imagem Digital
 * Fase 2
 *
 * Materia: SCC0261 Multimidia
 *
 * Entrega:  10/05/2011
 * Grupo: 7
 *  Fábio Abrão Luca
 *  Giulianne Katlauskas Montemurro
 *  Lucas Cuculo Badiale
 */

#ifndef _DIFERENCAS_H_
#define _DIFERENCAS_H_

#include "vetorizacao.h"
#include "bitstream.h"

#include <stdio.h>
#include <stdlib.h>

typedef struct {
	int simbolo;	// Numero de Bits, 1 byte eh suficiente
	int frequencia; // 2 bytes eh suficiente
	BITSTREAM *huffcode;
} SimboloDif;

typedef struct {
	SimboloDif* tabela;
	int size;  // max = 8
} TabelaFrequenciaDif;

typedef struct hn {
	int simbolo;
	int peso;
	struct hn *esq;
	struct hn *dir;
} huffnode;

// ENCODE =====================================================================

// Calcula as diferenćas dos coeficientes DC
void diferencas (ListaVetor **vetores);

// Verifica se um simbolo esta na tabela de frequencias
// Retorno: Posicao do simbolo se encontrado ou -1 caso contrario
int tabelafreq_simbpos(TabelaFrequenciaDif *tf, int simbolo);

// Monta e retorna a tabela de frequencias dos coeficientes DC
TabelaFrequenciaDif* tabelafrequencia_dif(ListaVetor *vetores);

// Algoritmo de Huffman para as diferencas
huffnode* huffman_dif (TabelaFrequenciaDif *tf);

// Extrai os huffcodes da arvore para a tabela
void extraiHuffcodes (huffnode *hufftree, TabelaFrequenciaDif *tf);

// Monta o bitstream com os huffcodes e coeficientes DC
BITSTREAM* bitstream_dif(ListaVetor *vetores, TabelaFrequenciaDif *tf);

// Salva tabela de frequencias em um arquivo binario
void toFile_dif (TabelaFrequenciaDif *tf, FILE *fd);

// Executa todo o processo de codificacao por diferencas
void diferencas_encode(ListaVetor *vetores, FILE *fd, FILE *tabela);

// DECODE =====================================================================

// Calcula os coeficientes DC a partir das diferencas
void desdiferencas (ListaVetor **vetores);

// Carrega tabela de frequencias do arquivo binario
TabelaFrequenciaDif* loadTable_dif (FILE *fd);

// Executa processo de decodificacao e alocacao das estruturas
ListaVetor* diferencas_decode(FILE *fd, FILE *tabela);

#endif
