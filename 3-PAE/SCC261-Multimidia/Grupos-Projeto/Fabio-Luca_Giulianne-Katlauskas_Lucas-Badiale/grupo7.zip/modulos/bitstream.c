/* Compressão de Imagem Digital
 * Fase 2
 *
 * Materia: SCC0261 Multimidia
 *
 * Entrega:  10/05/2011
 * Grupo: 7
 *  Fábio Abrão Luca
 *  Giulianne Katlauskas Montemurro
 *  Lucas Cuculo Badiale
 */

#include "bitstream.h"

#include <stdlib.h>
#include <stdio.h>
#include <math.h>

// inicializa o bitstream
BITSTREAM* bitstream_new () {
	BITSTREAM *b = (BITSTREAM*) malloc (sizeof(BITSTREAM));
	b->vetor = NULL;
	b->size = 0;
	b->start = 0;
	b->end = -1;
	return b;
}

// deleta o bitstream
void bitstream_delete (BITSTREAM *b) {
	if (b->size > 0) free(b->vetor);
	free(b);
	b = NULL;
}

// coloca um bit no final
void bitstream_add_bit (BITSTREAM *b, int bit) {
	// o vetor aidna nao foi alocado
	if (b->size == 0) {
		b->size++;
		b->vetor = (char*) malloc (sizeof(char));
		b->vetor[b->size - 1] = 0;

	// ultrapassou 8 bits, tem que alocar mais espaco
	} else if ((b->end + 1) % 8 == 0) {
		b->size++;
		b->vetor = (char*) realloc (b->vetor, sizeof(char) * b->size);
		b->vetor[b->size - 1] = 0;
	}
	
	// coloca o bit no bitstream
	b->end++;
	b->vetor[b->size - 1] = (bit << (7 - (b->end % 8))) | b->vetor[b->size - 1];
}

// coloca um numero no final do bitstream
void bitstream_add_number (BITSTREAM *b, int numero, int quantidade_bits) {
	int i;
	if (numero < 0) { numero = ~numero; }

	for (i = 0; i < quantidade_bits; i++) {
		bitstream_add_bit(b, (1 << ((quantidade_bits - i - 1)) & numero) != 0);
	}
}

// pega um bit do comeco do bitstream
int bitstream_get_bit (BITSTREAM *b) {
	int position = (int) (b->start / 8);
	int bit = ((1 << (7 - (b->start % 8))) & (b->vetor[position])) != 0;
	b->start++;
	return bit;
}

// pega um numero do comeco do bitstream
int bitstream_get_number (BITSTREAM *b, int quantidade_de_bits) {
	int negativo = 0; // se eh um numero negativo
	int numero = 0;
	int i;

	if (quantidade_de_bits > 0) {
		numero = bitstream_get_bit(b);
		if (numero == 0) negativo = 1;

		for (i = 1; i < quantidade_de_bits; i++) {
			numero = (numero << 1) | bitstream_get_bit(b);
		}

		if (negativo) { numero = ~numero; }
	}

	return numero;
}

// pega um numero sem converter para negativo
int bitstream_get_number_no_conversion (BITSTREAM *b, int quantidade_de_bits) {
	int numero = 0;
	int i;

	if (quantidade_de_bits > 0) {
		numero = bitstream_get_bit(b);

		for (i = 1; i < quantidade_de_bits; i++) {
			numero = (numero << 1) | bitstream_get_bit(b);
		}

	}

	return numero;
}

// converte um bitstream em uma string
char* bitstream_to_string (BITSTREAM *b) {
	int i;
	int comeco = b->start;
	int length = b->end + 1;
	char *string = (char*) malloc (sizeof(char) * (length + 1));

	b->start = 0;
	for (i = 0; i < length; i++) {
		string[i] = bitstream_get_bit(b) + 48; // converte para o ascii de '0' ou '1'
	}
	b->start = comeco;
	
	string[length] = 0;

	return string;
}

// concatena um bitstream source no final do target
void bitstream_cat (BITSTREAM *target, BITSTREAM *source) {
	int i = 0;
	int comeco = source->start;
	int length = source->end + 1;
	
	for (i = 0; i < length; i++) {
		bitstream_add_bit(target, bitstream_get_bit(source));
	}
	
	source->start = comeco;
}

// copia o bitstream source no target
void bitstream_copy (BITSTREAM *source, BITSTREAM *target) {
	bitstream_cat(target,source);
}

// muda o inicio da 'cabeca de leitura'
void bitstream_seek (BITSTREAM *b, int posicao) {
	if (posicao < b->end) {
		b->start = posicao;
	} else {
		b->start = b->end;
	}
}

// salva o bitstream
int bitstream_save (BITSTREAM *b, FILE *fp) {
	int retorno = 0;

	if (fp == NULL) {
		retorno = 1;
	} else {
		int end = b->end;
		fwrite(&end, sizeof(int), 1, fp);
		
		if (end >= 0)
			fwrite(b->vetor, sizeof(char), b->size, fp);
	}

	return retorno;
}

// carrega o bitstream
int bitstream_load (BITSTREAM *b, FILE *fp) {
	int retorno = 0;

	if (fp == NULL) {
		retorno = 1;
	} else {
		int end;
		fread(&end, sizeof(int), 1, fp);
		b->end = end;

		if (end >= 0) {
			b->size = (int) (b->end / 8) + 1;
			b->vetor = (char*) malloc (sizeof(char) * b->size);
			fread(b->vetor, sizeof(char), b->size, fp);
		} else {
			b->vetor = NULL;
			b->size = 0;
			b->start = 0;
			b->end = -1;
		}
	}

	return retorno;
}

// Retorna a quantidade minima de bits necessarios para o inteiro 'numero'
int nbits (int numero) {
	int bits = 0;
	
	// se for 0, o log eh -infinito
	if (numero != 0) bits = floor(log(abs(numero))/log(2)) + 1;
	
	// verifica se precisa de mais bits, caso o numero seja negativo
	if (numero < 0) {
		int value = ~numero;
		int precisa = ((1 << (bits - 1)) & value) != 0;
		if (precisa) bits++;
	}

	//printf("numero %3d -> bits %3d\n", numero, bits);
	return bits;
}

//// teste de unidade
//int main () {
//	BITSTREAM *b = bitstream_new();
//	
//	printf("Adicionado 1 ao bitstream:    "); bitstream_add_bit(b, 1); printf("%s\n", bitstream_to_string(b));
//	printf("Adicionado 1 ao bitstream:    "); bitstream_add_bit(b, 1); printf("%s\n", bitstream_to_string(b));
//	printf("Adicionado 1 ao bitstream:    "); bitstream_add_bit(b, 1); printf("%s\n", bitstream_to_string(b));
//	printf("Adicionado 1 ao bitstream:    "); bitstream_add_bit(b, 1); printf("%s\n", bitstream_to_string(b));
//	
//	printf("Adicionado 5 ao bitstream:    "); bitstream_add_number(b, 5 , 3); printf("%s\n", bitstream_to_string(b));
//	printf("Adicionado 10 ao bitstream:   "); bitstream_add_number(b, 10, 4); printf("%s\n", bitstream_to_string(b));
//	printf("Adicionado 2 ao bitstream:    "); bitstream_add_number(b, 2 , 2); printf("%s\n", bitstream_to_string(b));
//	printf("Adicionado -2 ao bitstream:   "); bitstream_add_number(b, -2, 3); printf("%s\n", bitstream_to_string(b));
//	printf("Adicionado -5 ao bitstream:   "); bitstream_add_number(b, -5, 4); printf("%s\n", bitstream_to_string(b));
//	printf("Adicionado -128 ao bitstream: "); bitstream_add_number(b, -128, 8); printf("%s\n", bitstream_to_string(b));
//	
//	printf("Salvando o bitstream:   %s\n", bitstream_to_string(b)); 
//	FILE *fp = fopen ("teste.txt", "wb");
//	bitstream_save(b, fp);
//	fclose(fp);
//	bitstream_delete(b);
//
//	printf("Carregando o bitstream: "); 
//	fp = fopen ("teste.txt", "rb");
//	b = bitstream_new();
//	bitstream_load(b, fp);
//	fclose(fp);
//	printf("%s\n", bitstream_to_string(b));
//	
//	printf("4 primeiros bits: %d\n", bitstream_get_number(b, 4)); // 15
//	printf("3 primeiros bits: %d\n", bitstream_get_number(b, 3)); // 5
//	printf("4 primeiros bits: %d\n", bitstream_get_number(b, 4)); // 10
//	printf("2 primeiros bits: %d\n", bitstream_get_number(b, 2)); // 2
//	printf("3 primeiros bits: %d\n", bitstream_get_number(b, 3)); // -2
//	printf("4 primeiros bits: %d\n", bitstream_get_number(b, 4)); // -5
//	printf("8 primeiros bits: %d\n", bitstream_get_number(b, 8)); // -128
//	
//	printf("Volta para a posicao 4\n"); bitstream_seek(b, 4);
//	printf("3 primeiros bits: %d\n", bitstream_get_number(b, 3)); // 5
//	
//	bitstream_delete(b);
//	
//	return 0;
//}
