function im=Cinza(img)
[x,y,cor] = size(img);
img = double(img);
im = (img([1:x],[1:y],1)+img([1:x],[1:y],2)+img([1:x],[1:y],3))/4;
im = uint8(im);
im;