function im=Pixel(img, x, y)
im=img;
z = 15;
[w,h,cor]=size(img);
for k=1:cor
im(x,y,k) = 255;
for i=x-z:x+z
    im(i,y-z,k)=255;
    im(i,y+z,k)=255;
end

for j=y-z:y+z
    im(x-z,j,k)=255;
    im(x+z,j,k)=255;
end
end

figure, imshow(im);

im;