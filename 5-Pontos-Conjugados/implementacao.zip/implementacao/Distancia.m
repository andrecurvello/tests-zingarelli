function D=Distancia(esq, dir, l,c,f,b)

P = Conjugado(esq,dir,l,c,21,0)
paralaxe = c - P(2)
z = f*b/paralaxe
D = f+z
D;