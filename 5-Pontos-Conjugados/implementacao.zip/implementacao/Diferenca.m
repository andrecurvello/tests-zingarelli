function D=Diferenca(imagem1, lin1,col1,imagem2,lin2,col2, tam)
imagem1 = double(imagem1);
imagem2 = double(imagem2);
i1 = lin1-double(uint8((tam/2)));
j1 = col1-double(uint8((tam/2)));

i2 = lin2-double(uint8((tam/2)));
j2 = col2-double(uint8((tam/2)));
D=0;
for i=1:tam
    for j=1:tam
        D = D + (imagem1(i+i1-1,j+j1-1)-imagem2(i+i2-1,j+j2-1))^2;
    end
end
D;
