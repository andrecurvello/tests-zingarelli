function im=Inverte(img)
[x,y,cor] = size(img);
for k=1:cor
    for i=1:x
        for j=1:y
            im(i,j,k) = img(i,y-j+1,k);
        end
    end
end

im;