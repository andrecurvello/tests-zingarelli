function P=Conjugado(esq, dir, le, ce,tam,rl)
cesq = Cinza(esq);
cdir = Cinza(dir);
[h,w] = size(cesq);

iD = 1;

for i=le-rl:le+rl
for j=double(uint8(tam/2+1)):w-double(uint8(tam/2))
    D(iD) = Diferenca(cesq,le,ce,cdir,i,j,tam);   
    pi(iD) = i;
    pj(iD) = j;
    iD = iD +1;  
end              
end

[menor, indice] = min(D);
P(1)  = pi(indice);
P(2)  = pj(indice);
Pixel(esq,le,ce);
Pixel(dir,P(1),P(2));
P;